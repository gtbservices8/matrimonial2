import { useState, useEffect } from 'react';
import { doc, getDoc, onSnapshot } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { GlobalConfig, FormConfig } from '../types';

export function useCMSConfig() {
  const [config, setConfig] = useState<GlobalConfig | null>(null);
  const [formConfig, setFormConfig] = useState<FormConfig | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Listen to global config
    const unsubConfig = onSnapshot(doc(db, 'cms_settings', 'global_config'), (doc) => {
      if (doc.exists()) {
        setConfig(doc.data() as GlobalConfig);
      }
    });

    // Listen to form config
    const unsubForm = onSnapshot(doc(db, 'cms_settings', 'form_config'), (doc) => {
      if (doc.exists()) {
        setFormConfig(doc.data() as FormConfig);
      }
      setLoading(false);
    }, (err) => {
      console.error('Error fetching form config:', err);
      setLoading(false);
    });

    return () => {
      unsubConfig();
      unsubForm();
    };
  }, []);

  return { config, formConfig, loading };
}
