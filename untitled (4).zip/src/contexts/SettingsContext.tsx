import React, { createContext, useContext, ReactNode } from 'react';
import { useCMSConfig } from '../hooks/useCMSConfig';
import { GlobalConfig, FormConfig, PUNJAB_DISTRICTS, STATES, MAHASHA_GOTRAS, COMPLEXIONS, STANDARD_PROFESSIONS } from '../types';

interface SettingsContextType {
  config: GlobalConfig | null;
  formConfig: FormConfig | null;
  loading: boolean;
  districts: string[];
  states: string[];
  gotras: { value: string; label: string }[];
  complexions: { value: string; label: string }[];
  professions: string[];
  tehsils: string[];
  religions: string[];
  birthPlaces: string[];
  getFieldLabel: (fieldId: string, lang: 'en' | 'pa') => string;
  isFieldVisible: (fieldId: string) => boolean;
  isFieldRequired: (fieldId: string) => boolean;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider = ({ children }: { children: ReactNode }) => {
  const { config, formConfig, loading } = useCMSConfig();

  const districts = formConfig?.districts?.length ? formConfig.districts : PUNJAB_DISTRICTS;
  const states = formConfig?.states?.length ? formConfig.states : STATES;
  const gotras = formConfig?.gotras?.length ? formConfig.gotras : MAHASHA_GOTRAS;
  const complexions = formConfig?.complexions?.length ? formConfig.complexions : COMPLEXIONS;
  const professions = formConfig?.professions?.length ? formConfig.professions : STANDARD_PROFESSIONS;
  const tehsils = formConfig?.tehsils?.length ? formConfig.tehsils : [];
  const religions = formConfig?.religions?.length ? formConfig.religions : ['Hindu (ਹਿੰਦੂ)', 'Sikh (ਸਿੱਖ)'];
  const birthPlaces = formConfig?.birthPlaces?.length ? formConfig.birthPlaces : [];

  const getFieldLabel = (fieldId: string, lang: 'en' | 'pa') => {
    const field = formConfig?.fields?.find(f => f.id === fieldId);
    if (field) {
      return lang === 'en' ? field.labelEn : field.labelPa;
    }
    return fieldId; // Fallback to ID
  };

  const isFieldVisible = (fieldId: string) => {
    const field = formConfig?.fields?.find(f => f.id === fieldId);
    return field ? field.isVisible : true;
  };

  const isFieldRequired = (fieldId: string) => {
    const field = formConfig?.fields?.find(f => f.id === fieldId);
    return field ? field.isRequired : false;
  };

  return (
    <SettingsContext.Provider value={{ 
      config, 
      formConfig, 
      loading, 
      districts, 
      states,
      gotras, 
      complexions, 
      professions,
      tehsils,
      religions,
      birthPlaces,
      getFieldLabel,
      isFieldVisible,
      isFieldRequired
    }}>
      {children}
    </SettingsContext.Provider>
  );
};

export const useSettings = () => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
