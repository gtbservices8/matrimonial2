import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type SupportedLanguage = 'en' | 'pa' | 'hi';

export interface LanguageOption {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
}

export const LANGUAGES: LanguageOption[] = [
  { code: 'en', name: 'English', nativeName: 'English', flag: '🌐' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
];

export interface Translations {
  navHome: string;
  navMatches: string;
  navStories: string;
  navContact: string;
  navDashboard: string;
  navLogin: string;
  navRegister: string;
  navLogout: string;
  navAdmin: string;
  
  heroBadge: string;
  heroTitle1: string;
  heroTitleHighlight: string;
  heroSubtitle: string;
  heroRegisterBtn: string;
  heroExploreBtn: string;

  searchTitle: string;
  searchLookingFor: string;
  searchBride: string;
  searchGroom: string;
  searchAge: string;
  searchCommunity: string;
  searchSelectCommunity: string;
  searchBtn: string;

  whyChooseTitle: string;
  whyChooseSubtitle: string;
  feature1Title: string;
  feature1Desc: string;
  feature2Title: string;
  feature2Desc: string;
  feature3Title: string;
  feature3Desc: string;

  verifiedTrustBadge: string;
  culturalValuesBadge: string;
  smartMatchBadge: string;

  footerTagline: string;
  languageLabel: string;
}

const TRANSLATIONS: Record<SupportedLanguage, Translations> = {
  en: {
    navHome: 'Home',
    navMatches: 'Browse Matches',
    navStories: 'Success Stories',
    navContact: 'Contact Us',
    navDashboard: 'Dashboard',
    navLogin: 'Login',
    navRegister: 'Register Free',
    navLogout: 'Logout',
    navAdmin: 'Admin Panel',

    heroBadge: 'Exclusive Mahasha Community Matrimonial',
    heroTitle1: 'Find Your Blessed Life Partner Within',
    heroTitleHighlight: 'Mahasha Samaj',
    heroSubtitle: 'Exclusively dedicated to connecting verified Mahasha Biradari families across Punjab, Jammu, Delhi, and globally.',
    heroRegisterBtn: 'Register Free Today',
    heroExploreBtn: 'Browse Mahasha Profiles',

    searchTitle: 'Quick Mahasha Match Search',
    searchLookingFor: 'Looking for',
    searchBride: 'Mahasha Bride',
    searchGroom: 'Mahasha Groom',
    searchAge: 'Age Range',
    searchCommunity: 'Mahasha Gotra',
    searchSelectCommunity: 'All Mahasha Gotras',
    searchBtn: 'Find Matches',

    whyChooseTitle: 'Why Choose Us',
    whyChooseSubtitle: 'We provide a premium, secure, and smart platform to help you find your life partner with confidence and cultural pride.',
    feature1Title: '100% Verified Profiles',
    feature1Desc: 'Every profile is manually verified by community admins to ensure genuine authenticity and family safety.',
    feature2Title: 'Smart AI & Gotra Matchmaking',
    feature2Desc: 'Advanced compatibility analysis based on Mahasha gotra traditions, education, and mutual values.',
    feature3Title: 'Exclusive Mahasha Biradari',
    feature3Desc: 'Preserving and honoring Mahasha cultural heritage, traditions, and trusted family connections.',

    verifiedTrustBadge: '100% Verified Mahasha Profiles',
    culturalValuesBadge: 'Mahasha Community Traditions',
    smartMatchBadge: 'Gotra Compatibility',

    footerTagline: 'The premier trusted matrimonial portal dedicated exclusively to Mahasha Samaj brides and grooms worldwide.',
    languageLabel: 'Language',
  },
  pa: {
    navHome: 'ਘਰ',
    navMatches: 'ਰਿਸ਼ਤੇ ਲੱਭੋ',
    navStories: 'ਸਫਲ ਕਹਾਣੀਆਂ',
    navContact: 'ਸੰਪਰਕ ਕਰੋ',
    navDashboard: 'ਡੈਸ਼ਬੋਰਡ',
    navLogin: 'ਲੌਗਇਨ',
    navRegister: 'ਮੁਫ਼ਤ ਰਜਿਸਟਰ ਕਰੋ',
    navLogout: 'ਲੌਗਆਉਟ',
    navAdmin: 'ਐਡਮੀਨ ਪੈਨਲ',

    heroBadge: 'ਵਿਸ਼ੇਸ਼ ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਮੰਚ',
    heroTitle1: 'ਮਹਾਸ਼ਾ ਸਮਾਜ ਵਿੱਚ ਵਿਸ਼ਵਾਸ ਨਾਲ ਲੱਭੋ',
    heroTitleHighlight: 'ਸੰਪੂਰਨ ਜੀਵਨ ਸਾਥੀ',
    heroSubtitle: 'ਸਿਰਫ਼ ਅਤੇ ਸਿਰਫ਼ ਮਹਾਸ਼ਾ ਕਮਿਊਨਿਟੀ ਦੇ ਸੱਚੇ, ਪੜ੍ਹੇ-ਲਿਖੇ ਅਤੇ ਪ੍ਰਮਾਣਿਤ ਪਰਿਵਾਰਾਂ ਲਈ ਸਮਰਪਿਤ ਵਿਸ਼ੇਸ਼ ਵਿਆਹ ਮੰਚ।',
    heroRegisterBtn: "ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀ 'ਤੇ ਮੁਫ਼ਤ ਰਜਿਸਟਰ ਕਰੋ",
    heroExploreBtn: 'ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਵੇਖੋ',

    searchTitle: 'ਤੁਰੰਤ ਮਹਾਸ਼ਾ ਰਿਸ਼ਤਾ ਖੋਜ',
    searchLookingFor: 'ਮੈਂ ਲੱਭ ਰਿਹਾ ਹਾਂ',
    searchBride: 'ਮਹਾਸ਼ਾ ਲਾੜੀ (Bride)',
    searchGroom: 'ਮਹਾਸ਼ਾ ਲਾੜਾ (Groom)',
    searchAge: 'ਉਮਰ ਸੀਮਾ',
    searchCommunity: 'ਮਹਾਸ਼ਾ ਗੋਤਰ (Gotra)',
    searchSelectCommunity: 'ਸਾਰੇ ਮਹਾਸ਼ਾ ਗੋਤਰ (All Gotras)',
    searchBtn: 'ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਲੱਭੋ',

    whyChooseTitle: 'ਸਾਡਾ ਪਲੇਟਫਾਰਮ ਕਿਉਂ ਚੁਣੋ',
    whyChooseSubtitle: 'ਅਸੀਂ ਮਹਾਸ਼ਾ ਸਮਾਜ ਲਈ ਇੱਕ ਸੁਰੱਖਿਅਤ, ਪ੍ਰਮਾਣਿਤ ਅਤੇ ਆਧੁਨਿਕ ਮੰਚ ਪ੍ਰਦਾਨ ਕਰਦੇ ਹਾਂ।',
    feature1Title: '100% ਪ੍ਰਮਾਣਿਤ ਪ੍ਰੋਫਾਈਲ',
    feature1Desc: 'ਹਰੇਕ ਪ੍ਰੋਫਾਈਲ ਨੂੰ ਸਾਡੇ ਐਡਮਿਨ ਵੱਲੋਂ ਹੱਥੀਂ ਤਸਦੀਕ ਕੀਤਾ ਜਾਂਦਾ ਹੈ ਤਾਂ ਜੋ ਪੂਰੀ ਸੁਰੱਖਿਆ ਬਣੀ ਰਹੇ।',
    feature2Title: 'ਗੋਤਰ ਤੇ ਏਆਈ ਮੈਚਮੇਕਿੰਗ',
    feature2Desc: 'ਮਹਾਸ਼ਾ ਗੋਤਰ ਮਰਿਆਦਾ ਅਤੇ ਸਿੱਖਿਆ ਅਨੁਸਾਰ ਆਟੋਮੈਟਿਕ ਅਨੁਕੂਲ ਰਿਸ਼ਤੇ ਸੁਝਾਏ ਜਾਂਦੇ ਹਨ।',
    feature3Title: 'ਸਿਰਫ਼ ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ',
    feature3Desc: 'ਸਾਡੇ ਆਪਣੇ ਮਹਾਸ਼ਾ ਸਮਾਜ ਦੇ ਸੱਭਿਆਚਾਰ, ਗੋਤਰ ਅਤੇ ਪਰਿਵਾਰਕ ਮੁੱਲਾਂ ਅਨੁਸਾਰ ਆਦਰਸ਼ ਜੀਵਨ ਸਾਥੀ ਲੱਭੋ।',

    verifiedTrustBadge: '100% ਪ੍ਰਮਾਣਿਤ ਮਹਾਸ਼ਾ ਪ੍ਰੋਫਾਈਲ',
    culturalValuesBadge: 'ਮਹਾਸ਼ਾ ਸਮਾਜਿਕ ਮਰਿਆਦਾ',
    smartMatchBadge: 'ਗੋਤਰ ਅਤੇ ਕੁੰਡਲੀ ਮੈਚਿੰਗ',

    footerTagline: 'ਮਹਾਸ਼ਾ ਸਮਾਜ (Mahasha Samaj) ਦੇ ਲਾੜੇ ਅਤੇ ਲਾੜੀਆਂ ਲਈ ਵਿਸ਼ੇਸ਼ ਅਤੇ ਭਰੋਸੇਯੋਗ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਪਲੇਟਫਾਰਮ। ਸੰਜੋਗ, ਸਤਿਕਾਰ ਅਤੇ ਸੁਰੱਖਿਆ।',
    languageLabel: 'ਭਾਸ਼ਾ',
  },
  hi: {
    navHome: 'होम',
    navMatches: 'रिश्ते खोजें',
    navStories: 'सफलता की कहानियाँ',
    navContact: 'संपर्क करें',
    navDashboard: 'डैशबोर्ड',
    navLogin: 'लॉगिन',
    navRegister: 'नि:शुल्क पंजीकरण',
    navLogout: 'लॉगआउट',
    navAdmin: 'एडमिन पैनल',

    heroBadge: 'विशेष महाशा समुदाय वैवाहिक मंच',
    heroTitle1: 'महाशा समाज में विश्वास के साथ खोजें',
    heroTitleHighlight: 'आदर्श जीवन साथी',
    heroSubtitle: 'विशेष रूप से महाशा बिरादरी के परिवारों के लिए समर्पित विश्वसनीय एवं सुरक्षित वैवाहिक मंच।',
    heroRegisterBtn: 'आज ही निःशुल्क जुड़ें',
    heroExploreBtn: 'महाशा रिश्ते देखें',

    searchTitle: 'त्वरित महाशा रिश्ता खोज',
    searchLookingFor: 'तलाश है',
    searchBride: 'महाशा दुल्हन (Bride)',
    searchGroom: 'महाशा दूल्हा (Groom)',
    searchAge: 'आयु सीमा',
    searchCommunity: 'महाशा गोत्र (Gotra)',
    searchSelectCommunity: 'सभी महाशा गोत्र (All Gotras)',
    searchBtn: 'महाशा रिश्ते खोजें',

    whyChooseTitle: 'हमें क्यों चुनें',
    whyChooseSubtitle: 'हम महाशा समुदाय के लिए एक सुरक्षित, विश्वसनीय और आधुनिक वैवाहिक मंच प्रदान करते हैं।',
    feature1Title: '100% सत्यापित प्रोफाइल',
    feature1Desc: 'प्रत्येक प्रोफाइल को हमारे एडमिन द्वारा सत्यापित किया जाता है ताकि पूर्ण विश्वसनीयता बनी रहे।',
    feature2Title: 'गोत्र एवं स्मार्ट मिलान',
    feature2Desc: 'महाशा गोत्र मर्यादा और पारिवारिक मूल्यों के अनुसार सटीक अनुकूलता।',
    feature3Title: 'विशिष्ट महाशा बिरादरी',
    feature3Desc: 'महाशा सांस्कृतिक परंपराओं और पारिवारिक प्रतिष्ठा का सम्मान।',

    verifiedTrustBadge: '100% सत्यापित महाशा प्रोफाइल',
    culturalValuesBadge: 'महाशा पारिवारिक मूल्य',
    smartMatchBadge: 'गोत्र एवं सटीक अनुकूलता',

    footerTagline: 'महाशा समाज के वर और वधु के लिए समर्पित सुरक्षित एवं विश्वसनीय वैवाहिक मंच।',
    languageLabel: 'भाषा',
  }
};

interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: Translations;
  currentLanguageOption: LanguageOption;
  languages: LanguageOption[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    const saved = localStorage.getItem('sangam_lang');
    if (saved === 'en' || saved === 'pa' || saved === 'hi') {
      return saved;
    }
    return 'en'; // Default to English as requested
  });

  const setLanguage = (newLang: SupportedLanguage) => {
    setLanguageState(newLang);
    localStorage.setItem('sangam_lang', newLang);
  };

  const t = TRANSLATIONS[language];
  const currentLanguageOption = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];

  return (
    <LanguageContext.Provider value={{
      language,
      setLanguage,
      t,
      currentLanguageOption,
      languages: LANGUAGES,
    }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
