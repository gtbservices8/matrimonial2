import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import type { NotificationItem, NotificationCategory, NotificationFilter } from '../types/notification';
import { playNotificationSound } from '../utils/notificationSound';

interface NotificationContextType {
  notifications: NotificationItem[];
  unreadCount: number;
  activeToast: NotificationItem | null;
  soundEnabled: boolean;
  filter: NotificationFilter;
  setFilter: (filter: NotificationFilter) => void;
  toggleSound: () => void;
  dismissToast: () => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
  deleteNotification: (id: string) => void;
  clearAll: () => void;
  addNotification: (item: Omit<NotificationItem, 'id' | 'timestamp' | 'read'> & { timestamp?: string }) => void;
  acceptMessageRequest: (id: string) => void;
  declineMessageRequest: (id: string) => void;
  respondToInterest: (id: string, response: 'accept' | 'decline') => void;
  simulateNotification: (category?: NotificationCategory) => void;
}

const STORAGE_KEY = 'mahasha_inapp_notifications_v1';
const SOUND_STORAGE_KEY = 'mahasha_notification_sound_pref';

const SEED_NOTIFICATIONS: NotificationItem[] = [
  {
    id: 'notif-1',
    category: 'match',
    type: 'high_compatibility',
    title: 'New 96% Gotra Match: Advocate Navpreet Kaur Bajgal',
    titlePa: 'ਨਵਾਂ 96% ਗੋਤਰ ਮੇਲ: ਐਡਵੋਕੇਟ ਨਵਪ੍ਰੀਤ ਕੌਰ ਬਜਗਲ',
    message: 'High compatibility match with Bajgal gotra in Gurdaspur. BA.LLB & LLM qualified.',
    messagePa: 'ਗੁਰਦਾਸਪੁਰ ਵਿੱਚ ਬਜਗਲ ਗੋਤਰ ਨਾਲ ਉੱਚ ਅਨੁਕੂਲਤਾ। BA.LLB & LLM ਵਿੱਦਿਅਕ ਯੋਗਤਾ।',
    timestamp: new Date(Date.now() - 1000 * 60 * 12).toISOString(), // 12 mins ago
    read: false,
    avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&auto=format&fit=crop',
    senderName: 'Advocate Navpreet Kaur Bajgal',
    senderGotra: 'Bajgal (Bhogal)',
    targetProfileId: 'rec-advocate',
    actionUrl: '/profile/rec-advocate',
    badge: '96% Match',
    badgePa: '96% ਮੇਲ',
    priority: 'high',
    metadata: {
      compatibilityScore: 96,
      gotraPair: 'Bajgal & Ghangla',
      location: 'Gurdaspur, Punjab',
      profession: 'Advocate / PCS(J) Aspirant'
    }
  },
  {
    id: 'notif-2',
    category: 'message_request',
    type: 'message_request',
    title: 'Message Request from Kaler Family (Ludhiana)',
    titlePa: 'ਕਲੇਰ ਪਰਿਵਾਰ (ਲੁਧਿਆਣਾ) ਵੱਲੋਂ ਸੁਨੇਹਾ ਬੇਨਤੀ',
    message: '"Sat Sri Akal ji, we reviewed your profile and would love to initiate matrimonial talks."',
    messagePa: '"ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਜੀ, ਅਸੀਂ ਤੁਹਾਡਾ ਬਾਇਓਡਾਟਾ ਦੇਖਿਆ ਅਤੇ ਰਿਸ਼ਤੇ ਦੀ ਗੱਲਬਾਤ ਅੱਗੇ ਵਧਾਉਣਾ ਚਾਹੁੰਦੇ ਹਾਂ।"',
    timestamp: new Date(Date.now() - 1000 * 60 * 45).toISOString(), // 45 mins ago
    read: false,
    avatarUrl: 'https://images.unsplash.com/photo-1595922247653-9a3b68832a81?q=80&w=300&auto=format&fit=crop',
    senderName: 'Simranjit Kaur Kaler',
    senderGotra: 'Kaler',
    targetProfileId: 'rec-1',
    actionUrl: '/profile/rec-1',
    badge: 'New Request',
    badgePa: 'ਨਵੀਂ ਬੇਨਤੀ',
    status: 'pending',
    priority: 'high',
    metadata: {
      location: 'Ludhiana / Mohali',
      profession: 'Software Engineer',
      requestMessage: 'Sat Sri Akal ji, we reviewed your profile and would love to initiate matrimonial talks.'
    }
  },
  {
    id: 'notif-3',
    category: 'activity',
    type: 'profile_view',
    title: 'Gurinder Singh Badhan viewed your profile',
    titlePa: 'ਗੁਰਿੰਦਰ ਸਿੰਘ ਬੱਧਣ ਨੇ ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਵੇਖੀ',
    message: 'Senior Software Engineer (Badhan Gotra, Amritsar) inspected your complete biodata.',
    messagePa: 'ਸੀਨੀਅਰ ਸਾਫਟਵੇਅਰ ਇੰਜੀਨੀਅਰ (ਬੱਧਣ ਗੋਤਰ, ਅੰਮ੍ਰਿਤਸਰ) ਨੇ ਤੁਹਾਡਾ ਪੂਰਾ ਬਾਇਓਡਾਟਾ ਦੇਖਿਆ।',
    timestamp: new Date(Date.now() - 1000 * 60 * 180).toISOString(), // 3 hours ago
    read: false,
    avatarUrl: 'https://images.unsplash.com/photo-1610173827002-62c0f1f1d1eb?q=80&w=300&auto=format&fit=crop',
    senderName: 'Gurinder Singh Badhan',
    senderGotra: 'Badhan',
    targetProfileId: 'rec-2',
    actionUrl: '/profile/rec-2',
    badge: 'Profile View',
    badgePa: 'ਪ੍ਰੋਫਾਈਲ ਵਿਊ',
    priority: 'normal'
  },
  {
    id: 'notif-4',
    category: 'activity',
    type: 'verification_approved',
    title: 'Mahasha Community Verification Approved',
    titlePa: 'ਮਹਾਸ਼ਾ ਸਮਾਜ ਤਸਦੀਕ ਬੈਜ ਮਨਜ਼ੂਰ ਹੋ ਗਿਆ ਹੈ',
    message: 'Your Mahasha Gotra verification is active with the official Verified Seal.',
    messagePa: 'ਤੁਹਾਡਾ ਮਹਾਸ਼ਾ ਗੋਤਰ ਪ੍ਰਮਾਣੀਕਰਨ ਸਫਲਤਾਪੂਰਵਕ ਮਨਜ਼ੂਰ ਹੋ ਗਿਆ ਹੈ।',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 24).toISOString(), // 1 day ago
    read: true,
    badge: 'Verified',
    badgePa: 'ਪ੍ਰਮਾਣਿਤ',
    actionUrl: '/dashboard',
    priority: 'normal'
  },
  {
    id: 'notif-5',
    category: 'match',
    type: 'new_match',
    title: 'New Mahasha Profile: Amanpreet Badhan (Jalandhar)',
    titlePa: 'ਨਵੀਂ ਮਹਾਸ਼ਾ ਪ੍ਰੋਫਾਈਲ: ਅਮਨਪ੍ਰੀਤ ਬੱਧਣ (ਜਲੰਧਰ)',
    message: 'Bank Branch Manager with MBA Finance registered matching your partner criteria.',
    messagePa: 'ਤੁਹਾਡੀ ਪਸੰਦ ਮੁਤਾਬਕ ਬੈਂਕ ਬ੍ਰਾਂਚ ਮੈਨੇਜਰ (MBA ਫਾਈਨਾਂਸ) ਨੇ ਨਵੀਂ ਪ੍ਰੋਫਾਈਲ ਰਜਿਸਟਰ ਕੀਤੀ।',
    timestamp: new Date(Date.now() - 1000 * 60 * 60 * 48).toISOString(), // 2 days ago
    read: true,
    avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop',
    senderName: 'Amanpreet Badhan',
    senderGotra: 'Badhan',
    badge: 'New Profile',
    badgePa: 'ਨਵਾਂ ਰਿਸ਼ਤਾ',
    actionUrl: '/matches',
    priority: 'low'
  }
];

const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export function NotificationProvider({ children }: { children: ReactNode }) {
  const [notifications, setNotifications] = useState<NotificationItem[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.error('Failed to parse notifications from storage', e);
    }
    return SEED_NOTIFICATIONS;
  });

  const [activeToast, setActiveToast] = useState<NotificationItem | null>(null);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(() => {
    const savedSound = localStorage.getItem(SOUND_STORAGE_KEY);
    return savedSound !== null ? savedSound === 'true' : true;
  });
  const [filter, setFilter] = useState<NotificationFilter>('all');

  // Sync notifications to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(notifications));
    } catch (e) {
      console.error('Failed to save notifications to storage', e);
    }
  }, [notifications]);

  // Sync sound preference
  useEffect(() => {
    localStorage.setItem(SOUND_STORAGE_KEY, String(soundEnabled));
  }, [soundEnabled]);

  const unreadCount = notifications.filter(n => !n.read).length;

  const toggleSound = () => {
    setSoundEnabled(prev => !prev);
  };

  const dismissToast = () => {
    setActiveToast(null);
  };

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(item => (item.id === id ? { ...item, read: true } : item))
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(item => ({ ...item, read: true })));
  };

  const deleteNotification = (id: string) => {
    setNotifications(prev => prev.filter(item => item.id !== id));
    if (activeToast?.id === id) {
      setActiveToast(null);
    }
  };

  const clearAll = () => {
    setNotifications([]);
    setActiveToast(null);
  };

  const addNotification = (
    item: Omit<NotificationItem, 'id' | 'timestamp' | 'read'> & { timestamp?: string }
  ) => {
    const newNotif: NotificationItem = {
      ...item,
      id: `notif-${Date.now()}-${Math.random().toString(36).substr(2, 5)}`,
      timestamp: item.timestamp || new Date().toISOString(),
      read: false
    };

    setNotifications(prev => [newNotif, ...prev]);
    setActiveToast(newNotif);

    if (soundEnabled) {
      playNotificationSound();
    }
  };

  const acceptMessageRequest = (id: string) => {
    setNotifications(prev =>
      prev.map(item =>
        item.id === id
          ? {
              ...item,
              read: true,
              status: 'accepted',
              message: item.message + ' (Request Accepted)',
              messagePa: item.messagePa + ' (ਬੇਨਤੀ ਸਵੀਕਾਰ ਕੀਤੀ ਗਈ)'
            }
          : item
      )
    );

    // Add confirmation activity notification
    const target = notifications.find(n => n.id === id);
    if (target) {
      addNotification({
        category: 'activity',
        type: 'interest_accepted',
        title: `You accepted message request from ${target.senderName || 'Sender'}`,
        titlePa: `ਤੁਸੀਂ ${target.senderName || 'ਮੈਂਬਰ'} ਦੀ ਸੁਨੇਹਾ ਬੇਨਤੀ ਸਵੀਕਾਰ ਕਰ ਲਈ ਹੈ`,
        message: 'You can now share contact details or chat directly on WhatsApp / Phone.',
        messagePa: 'ਹੁਣ ਤੁਸੀਂ ਫੋਨ ਜਾਂ ਵਟਸਐਪ ਰਾਹੀਂ ਸਿੱਧੀ ਗੱਲਬਾਤ ਕਰ ਸਕਦੇ ਹੋ।',
        badge: 'Connected',
        badgePa: 'ਸੰਪਰਕ ਸਥਾਪਿਤ',
        actionUrl: target.actionUrl || '/matches'
      });
    }
  };

  const declineMessageRequest = (id: string) => {
    setNotifications(prev =>
      prev.map(item =>
        item.id === id
          ? {
              ...item,
              read: true,
              status: 'declined',
              message: item.message + ' (Request Declined)',
              messagePa: item.messagePa + ' (ਬੇਨਤੀ ਰੱਦ ਕੀਤੀ ਗਈ)'
            }
          : item
      )
    );
  };

  const respondToInterest = (id: string, response: 'accept' | 'decline') => {
    if (response === 'accept') {
      acceptMessageRequest(id);
    } else {
      declineMessageRequest(id);
    }
  };

  // Realistic simulator for testing all in-app alert flows
  const simulateNotification = (category?: NotificationCategory) => {
    const selectedCategory = category || (['match', 'message_request', 'activity'][Math.floor(Math.random() * 3)] as NotificationCategory);

    const matchPool = [
      {
        title: 'New 98% Compatibility Gotra Match: Dr. Raman Kaler',
        titlePa: 'ਨਵਾਂ 98% ਅਨੁਕੂਲਤਾ ਗੋਤਰ ਮੇਲ: ਡਾ. ਰਮਨ ਕਲੇਰ',
        message: 'MD Physician (Kaler Gotra, Amritsar) matches your preferences with 98% compatibility.',
        messagePa: 'ਐਮ.ਡੀ. ਫਿਜ਼ੀਸ਼ੀਅਨ (ਕਲੇਰ ਗੋਤਰ, ਅੰਮ੍ਰਿਤਸਰ) ਤੁਹਾਡੀ ਪਸੰਦ ਨਾਲ 98% ਮੇਲ ਖਾਂਦੇ ਹਨ।',
        avatarUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=300&auto=format&fit=crop',
        senderName: 'Dr. Raman Kaler',
        senderGotra: 'Kaler',
        targetProfileId: 'rec-1',
        actionUrl: '/profile/rec-1',
        badge: '98% Match',
        badgePa: '98% ਮੇਲ'
      },
      {
        title: 'New Bride Profile: Er. Harleen Kaur Banga (Mohali)',
        titlePa: 'ਨਵੀਂ ਲਾੜੀ ਪ੍ਰੋਫਾਈਲ: ਇੰਜੀ. ਹਰਲੀਨ ਕੌਰ ਬੰਗਾ (ਮੋਹਾਲੀ)',
        message: 'B.Tech IT, Software Engineer in Infosys Mohali, Banga gotra registered today.',
        messagePa: 'ਇਨਫੋਸਿਸ ਮੋਹਾਲੀ ਵਿੱਚ ਸਾਫਟਵੇਅਰ ਇੰਜੀਨੀਅਰ (ਬੰਗਾ ਗੋਤਰ) ਨੇ ਅੱਜ ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਕੀਤੀ।',
        avatarUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=300&auto=format&fit=crop',
        senderName: 'Er. Harleen Kaur Banga',
        senderGotra: 'Banga',
        targetProfileId: 'rec-advocate',
        actionUrl: '/profile/rec-advocate',
        badge: 'New Match',
        badgePa: 'ਨਵਾਂ ਮੇਲ'
      },
      {
        title: 'New High Match in Gurdaspur: Sandeep Singh Karloopia',
        titlePa: 'ਗੁਰਦਾਸਪੁਰ ਵਿੱਚ ਨਵਾਂ ਮੇਲ: ਸੰਦੀਪ ਸਿੰਘ ਕਰਲੂਪੀਆ',
        message: 'Govt. Teacher in Punjab Education Dept (Karloopia Gotra).',
        messagePa: 'ਸਰਕਾਰੀ ਅਧਿਆਪਕ ਪੰਜਾਬ ਸਿੱਖਿਆ ਵਿਭਾਗ (ਕਰਲੂਪੀਆ ਗੋਤਰ)।',
        avatarUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=300&auto=format&fit=crop',
        senderName: 'Sandeep Singh Karloopia',
        senderGotra: 'Karloopia',
        targetProfileId: 'rec-2',
        actionUrl: '/profile/rec-2',
        badge: '92% Match',
        badgePa: '92% ਮੇਲ'
      }
    ];

    const messagePool = [
      {
        title: 'New Message Request from Badhan Family (Canada)',
        titlePa: 'ਬੱਧਣ ਪਰਿਵਾਰ (ਕੈਨੇਡਾ) ਵੱਲੋਂ ਨਵੀਂ ਸੁਨੇਹਾ ਬੇਨਤੀ',
        message: '"Waheguru ji ka Khalsa, we are looking for match for our daughter in Vancouver."',
        messagePa: '"ਵਾਹਿਗੁਰੂ ਜੀ ਕਾ ਖਾਲਸਾ, ਅਸੀਂ ਵੈਨਕੂਵਰ ਵਿੱਚ ਆਪਣੀ ਧੀ ਲਈ ਯੋਗ ਮਹਾਸ਼ਾ ਰਿਸ਼ਤਾ ਲੱਭ ਰਹੇ ਹਾਂ।"',
        avatarUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300&auto=format&fit=crop',
        senderName: 'Jaswinder Kaur Badhan',
        senderGotra: 'Badhan',
        targetProfileId: 'rec-advocate',
        actionUrl: '/profile/rec-advocate',
        badge: 'Message Request',
        badgePa: 'ਸੁਨੇਹਾ ਬੇਨਤੀ'
      },
      {
        title: 'Interest Request: Rohit Bajgal sent contact request',
        titlePa: 'ਰਿਸ਼ਤਾ ਬੇਨਤੀ: ਰੋਹਿਤ ਬਜਗਲ ਨੇ ਸੰਪਰਕ ਬੇਨਤੀ ਭੇਜੀ',
        message: '"Hi! We would like to exchange horoscopes and bio-data details."',
        messagePa: '"ਨਮਸਤੇ! ਅਸੀਂ ਜਨਮ ਕੁੰਡਲੀ ਅਤੇ ਪਰਿਵਾਰਕ ਵੇਰਵੇ ਸਾਂਝੇ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹਾਂ।"',
        avatarUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=300&auto=format&fit=crop',
        senderName: 'Rohit Bajgal',
        senderGotra: 'Bajgal',
        targetProfileId: 'rec-2',
        actionUrl: '/profile/rec-2',
        badge: 'Contact Request',
        badgePa: 'ਸੰਪਰਕ ਬੇਨਤੀ'
      }
    ];

    const activityPool = [
      {
        title: 'Profile View Alert: 3 families viewed your biodata',
        titlePa: 'ਪ੍ਰੋਫਾਈਲ ਵਿਊ ਅਲਰਟ: 3 ਪਰਿਵਾਰਾਂ ਨੇ ਤੁਹਾਡਾ ਬਾਇਓਡਾਟਾ ਵੇਖਿਆ',
        message: 'Families from Jalandhar, Hoshiarpur and Mohali viewed your Mahasha profile in the last hour.',
        messagePa: 'ਜਲੰਧਰ, ਹੁਸ਼ਿਆਰਪੁਰ ਅਤੇ ਮੋਹਾਲੀ ਦੇ ਪਰਿਵਾਰਾਂ ਨੇ ਪਿਛਲੇ 1 ਘੰਟੇ ਵਿੱਚ ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਦੇਖੀ।',
        badge: '3 Views',
        badgePa: '3 ਵਿਊਜ਼',
        actionUrl: '/dashboard'
      },
      {
        title: 'Shortlisted by Ghangla Family (Pathankot)',
        titlePa: 'ਘਾਂਗਲਾ ਪਰਿਵਾਰ (ਪਠਾਨਕੋਟ) ਨੇ ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਸ਼ਾਰਟਲਿਸਟ ਕੀਤੀ',
        message: 'Your profile has been saved to their top favorites list for upcoming family discussions.',
        messagePa: 'ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਨੂੰ ਪਰਿਵਾਰਕ ਵਿਚਾਰ-ਵਟਾਂਦਰੇ ਲਈ ਪਸੰਦੀਦਾ ਸੂਚੀ ਵਿੱਚ ਸ਼ਾਮਲ ਕੀਤਾ ਗਿਆ ਹੈ।',
        avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=300&auto=format&fit=crop',
        senderName: 'Ghangla Family',
        senderGotra: 'Ghangla',
        badge: 'Shortlisted',
        badgePa: 'ਸ਼ਾਰਟਲਿਸਟ',
        actionUrl: '/dashboard'
      },
      {
        title: 'Profile Strength: 90% Completed!',
        titlePa: 'ਪ੍ਰੋਫਾਈਲ ਸੰਪੂਰਨਤਾ: 90% ਪੂਰੀ!',
        message: 'Your verified status gives your biodata 4x higher search priority in Mahasha Sangam.',
        messagePa: 'ਤੁਹਾਡੇ ਪ੍ਰਮਾਣਿਤ ਬੈਜ ਨਾਲ ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਨੂੰ 4 ਗੁਣਾ ਵੱਧ ਤਰਜੀਹ ਮਿਲ ਰਹੀ ਹੈ।',
        badge: 'Profile Update',
        badgePa: 'ਪ੍ਰੋਫਾਈਲ ਅਪਡੇਟ',
        actionUrl: '/profile/edit'
      }
    ];

    let chosen;
    let notifType: any = 'new_match';

    if (selectedCategory === 'match') {
      chosen = matchPool[Math.floor(Math.random() * matchPool.length)];
      notifType = 'high_compatibility';
    } else if (selectedCategory === 'message_request') {
      chosen = messagePool[Math.floor(Math.random() * messagePool.length)];
      notifType = 'message_request';
    } else {
      chosen = activityPool[Math.floor(Math.random() * activityPool.length)];
      notifType = 'profile_view';
    }

    addNotification({
      category: selectedCategory,
      type: notifType,
      title: chosen.title,
      titlePa: chosen.titlePa,
      message: chosen.message,
      messagePa: chosen.messagePa,
      avatarUrl: chosen.avatarUrl,
      senderName: (chosen as any).senderName,
      senderGotra: (chosen as any).senderGotra,
      targetProfileId: (chosen as any).targetProfileId,
      actionUrl: chosen.actionUrl,
      badge: chosen.badge,
      badgePa: chosen.badgePa,
      priority: 'high',
      status: selectedCategory === 'message_request' ? 'pending' : undefined
    });
  };

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        unreadCount,
        activeToast,
        soundEnabled,
        filter,
        setFilter,
        toggleSound,
        dismissToast,
        markAsRead,
        markAllAsRead,
        deleteNotification,
        clearAll,
        addNotification,
        acceptMessageRequest,
        declineMessageRequest,
        respondToInterest,
        simulateNotification
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
}

export function useNotifications() {
  const context = useContext(NotificationContext);
  if (!context) {
    throw new Error('useNotifications must be used within a NotificationProvider');
  }
  return context;
}
