import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signOut, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';

interface AuthContextType {
  user: User | null;
  loading: boolean;
  logout: () => Promise<void>;
  signInWithGoogle: () => Promise<void>;
  loginWithMock: (email: string) => any;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  loading: true,
  logout: async () => {},
  signInWithGoogle: async () => {},
  loginWithMock: () => ({} as any),
});

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (currentUser) => {
      setUser(currentUser);
      setLoading(false);

          if (currentUser) {
        // Ensure user document exists
        try {
          const userRef = doc(db, 'users', currentUser.uid);
          const userSnap = await getDoc(userRef);
          if (!userSnap.exists()) {
            await setDoc(userRef, {
              email: currentUser.email,
              createdAt: serverTimestamp(),
              role: 'user',
              status: 'active'
            });
          }

          // Update lastSeen on the associated profile if it exists
          const profileRef = doc(db, 'profiles', currentUser.uid);
          const profileSnap = await getDoc(profileRef);
          if (profileSnap.exists()) {
            await setDoc(profileRef, { 
              lastSeen: serverTimestamp(),
              updatedAt: serverTimestamp() 
            }, { merge: true });
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `users/${currentUser.uid}`);
        }
      }
    });

    return unsubscribe;
  }, []);

  const logout = () => signOut(auth);

  const signInWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      console.warn('Google Sign In failed:', error);
      if (error.code === 'auth/operation-not-allowed') {
        // Fallback: Create a mock user session since the developer cannot access Firebase Console
        console.warn('Firebase Auth providers disabled. Falling back to local mock authentication.');
        const mockUser = {
          uid: 'mock_user_' + Math.random().toString(36).substr(2, 9),
          email: 'demo@example.com',
          displayName: 'Demo User',
          emailVerified: true,
          isAnonymous: false,
        } as unknown as User;
        setUser(mockUser);
      } else {
        throw error;
      }
    }
  };

  const loginWithMock = (email: string) => {
     const mockUser = {
          uid: 'mock_user_' + Math.random().toString(36).substr(2, 9),
          email: email,
          displayName: 'Demo User',
          emailVerified: true,
          isAnonymous: false,
     } as unknown as User;
     setUser(mockUser);
     return mockUser;
  }

  return (
    <AuthContext.Provider value={{ user, loading, logout, signInWithGoogle }}>
      {children}
    </AuthContext.Provider>
  );
};
