import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app, firebaseConfig.firestoreDatabaseId);

export async function runFirebaseDiagnostic() {
  console.log('--- FIREBASE DIAGNOSTIC RUN ---');
  console.log('Project ID:', firebaseConfig.projectId);
  
  if (!app) {
    console.error('Diagnostic Failed: Firebase app is NOT initialized.');
    return;
  }
  console.log('Firebase app instance initialized successfully.');
  
  if (!auth) {
    console.error('Diagnostic Failed: Firebase auth is NOT initialized.');
    return;
  }
  console.log('Firebase auth instance initialized successfully.');

  try {
    const { fetchSignInMethodsForEmail } = await import('firebase/auth');
    // We use a dummy email to check what methods are enabled. 
    // If Email/Password is enabled, it should either return ['password'] (if user exists) 
    // or an empty array [] (if user doesn't exist but provider is enabled).
    // If it's disabled entirely at the console level, it might throw 'auth/operation-not-allowed'
    // or we can just catch and observe the error.
    console.log('Testing Email/Password provider availability...');
    const methods = await fetchSignInMethodsForEmail(auth, 'diagnostic_test@example.com');
    console.log('Available sign-in methods for test email:', methods);
    console.log('SUCCESS: The Email/Password provider appears to be active and responding.');
  } catch (error: any) {
    console.error('Diagnostic Error encountered during provider check:', error);
    if (error.code === 'auth/operation-not-allowed') {
      console.error('CRITICAL FINDING: The Email/Password provider is strictly DISABLED in the Firebase Console for project:', firebaseConfig.projectId);
      console.error('RESOLUTION: You MUST go to https://console.firebase.google.com/project/gen-lang-client-0887188807/authentication/providers and enable Email/Password.');
    }
  }
  console.log('--- DIAGNOSTIC COMPLETE ---');
}

export enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

export interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

export function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const rawMsg = error instanceof Error ? error.message : String(error);
  const errInfo: FirestoreErrorInfo = {
    error: rawMsg,
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error: ', JSON.stringify(errInfo));

  if (rawMsg.includes('code=unavailable') || rawMsg.includes('Could not reach Cloud Firestore backend')) {
    throw new Error('ਕਨੈਕਸ਼ਨ ਸਮੱਸਿਆ: ਸਰਵਰ ਨਾਲ ਸੰਪਰਕ ਨਹੀਂ ਹੋ ਰਿਹਾ। ਕਿਰਪਾ ਕਰਕੇ ਆਪਣਾ ਇੰਟਰਨੈੱਟ ਕਨੈਕਸ਼ਨ ਚੈੱਕ ਕਰੋ ਜਾਂ ਵੀਡੀਓ/ਫੋਟੋਆਂ ਦਾ ਸਾਈਜ਼ ਘਟਾਓ। (Network connection issue with Firestore backend)');
  }
  
  if (rawMsg.includes('exceeds the maximum allowed size')) {
    throw new Error('ਡਾਟਾਬੇਸ ਸੀਮਾ: ਪ੍ਰੋਫਾਈਲ ਦਾ ਕੁੱਲ ਸਾਈਜ਼ 1MB ਤੋਂ ਵੱਧ ਗਿਆ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਵੀਡੀਓ ਦੀ ਥਾਂ YouTube/Instagram ਲਿੰਕ ਵਰਤੋ। (Profile exceeds 1MB size limit)');
  }

  throw new Error(rawMsg);
}
