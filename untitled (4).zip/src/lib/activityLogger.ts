import { collection, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from './firebase';
import { ActivityLog } from '../types';

export const logActivity = async (activity: Omit<ActivityLog, 'id' | 'timestamp'>) => {
  try {
    const logsRef = collection(db, 'activity_logs');
    await addDoc(logsRef, {
      ...activity,
      timestamp: serverTimestamp()
    });
  } catch (error) {
    console.error('Failed to log activity:', error);
  }
};
