export interface FilterCriteria {
  // Demographic
  gender: 'Any' | 'Female' | 'Male';
  minAge: string;
  maxAge: string;
  minHeight: string;
  maxHeight: string;
  maritalStatus: string;
  complexion: string;

  // Keyword Search
  searchQuery: string;

  // Education Criteria (ਵਿੱਦਿਅਕ ਯੋਗਤਾ)
  educationLevel: string[];   // Changed to array
  educationField: string;   // e.g. Any, Law/Legal, Engineering & IT, Medical & Health, Business & Management, Commerce, Arts
  qualificationDegree: string; // e.g. LLM, BA.LLB, B.Tech, MBBS, MBA, M.Sc, etc.

  // Occupation & Income Criteria (ਕਿੱਤਾ ਅਤੇ ਆਮਦਨ)
  profession: string[];       // Changed to array
  employmentType: string;   // e.g. Any, Government / PSU, Private Sector, Professional Practice, Self Employed, Abroad / NRI
  incomeRange: string;      // e.g. Any, Below 5L, 5-10L, 10-20L, 20-50L, 50L+, NRI Currency

  // Location Criteria (ਰਿਹਾਇਸ਼ ਅਤੇ ਜ਼ਿਲ੍ਹਾ)
  country: string;          // e.g. Any, India, Canada, United Kingdom, USA, Australia, UAE
  stateRegion: string;      // e.g. Any, Majha (Gurdaspur/Amritsar), Doaba (Jalandhar/Hoshiarpur), Malwa (Ludhiana/Mohali), Chandigarh Tricity, Jammu & Kashmir
  state: string[];          // Added state field
  district: string[];         // Changed to array
  cityLocation: string;     // Specific city / town text

  // Mahasha Gotra & Caste Criteria (ਗੋਤਰ ਮਿਲਾਣ)
  fatherGotra: string;      // e.g. Bajgal, Badhan, Kaler, Kundal, Banga, Karloopia, Hans, Taak, Kajla, Suman, etc.
  motherGotra: string;      // e.g. Ghangla, Badhan, etc.

  // Preferences & Badges
  verifiedOnly: boolean;
  withPhotoOnly: boolean;

  // Sorting & Layout
  sortBy: 'relevance' | 'score' | 'newest' | 'age_asc' | 'age_desc' | 'education_high' | 'income_high';
}

export const DEFAULT_FILTERS: FilterCriteria = {
  gender: 'Any',
  minAge: '18',
  maxAge: '50',
  minHeight: 'Any',
  maxHeight: 'Any',
  maritalStatus: 'Any',
  complexion: 'Any',
  searchQuery: '',

  educationLevel: [],
  educationField: 'Any',
  qualificationDegree: '',

  profession: [],
  employmentType: 'Any',
  incomeRange: 'Any',

  country: 'Any',
  stateRegion: 'Any',
  state: [],
  district: [],
  cityLocation: '',

  fatherGotra: 'Any',
  motherGotra: 'Any',

  verifiedOnly: false,
  withPhotoOnly: false,

  sortBy: 'relevance'
};

export const EDUCATION_LEVEL_OPTIONS = [
  { value: 'Any', label: 'ਸਾਰੀਆਂ ਯੋਗਤਾਵਾਂ (All Education Levels)' },
  { value: 'Doctorate', label: 'Ph.D / Doctorate / M.Phil (ਡਾਕਟਰੇਟ)' },
  { value: 'Post Graduate', label: 'Master\'s / Post Graduate (LLM, MD, M.Tech, MBA, MCA, M.Sc, MA)' },
  { value: 'Graduate', label: 'Bachelor\'s / Graduate (BA.LLB, B.Tech, MBBS, BDS, BBA, B.Com, B.Sc)' },
  { value: 'Engineering Diploma', label: 'Engineering Diploma / Polytechnic (ਇੰਜੀਨੀਅਰਿੰਗ ਡਿਪਲੋਮਾ)' },
  { value: 'Professional Law', label: 'Law Specialization (LLM / BA.LLB / Advocate)' },
  { value: 'Medical Health', label: 'Medical & Healthcare (MBBS / BDS / BAMS / MD)' },
  { value: 'IT Computer', label: 'IT & Computer Science (B.Tech CSE / MCA / M.S)' },
  { value: 'Finance Commerce', label: 'Chartered Accountant / MBA / Finance' },
  { value: 'High School', label: '12th Pass / Higher Secondary' }
];

export const EDUCATION_FIELD_OPTIONS = [
  { value: 'Any', label: 'ਸਾਰੇ ਖੇਤਰ (All Fields)' },
  { value: 'Law', label: 'Legal & Judicial Studies (ਕਾਨੂੰਨ / ਐਡਵੋਕੇਟ)' },
  { value: 'Engineering', label: 'Engineering & Technology (ਇੰਜੀਨੀਅਰਿੰਗ)' },
  { value: 'Medical', label: 'Medicine & Healthcare (ਮੈਡੀਕਲ)' },
  { value: 'Management', label: 'Management & Business (MBA/BBA)' },
  { value: 'Finance', label: 'Commerce, Accounting & CA (ਵਿੱਤ)' },
  { value: 'Science', label: 'Sciences & Research (ਵਿਗਿਆਨ)' },
  { value: 'Arts', label: 'Arts & Humanities (ਆਰਟਸ)' },
  { value: 'Civil Services', label: 'Administrative & Civil Studies' }
];

export const OCCUPATION_OPTIONS = [
  { value: 'Any', label: 'ਸਾਰੇ ਪੇਸ਼ੇ (All Professions)' },
  { value: 'Advocate', label: 'Advocate / Legal Professional / PCS(J) Prep (ਵਕੀਲ)' },
  { value: 'Software Engineer', label: 'Software Engineer / IT Professional (ਸਾਫਟਵੇਅਰ ਇੰਜੀਨੀਅਰ)' },
  { value: 'Doctor', label: 'Doctor / Physician / Surgeon (ਡਾਕਟਰ)' },
  { value: 'Government Job', label: 'Government Officer / PSU Employee (ਸਰਕਾਰੀ ਅਧਿਕਾਰੀ)' },
  { value: 'Chartered Accountant', label: 'Chartered Accountant (CA) / Financial Auditor' },
  { value: 'Business', label: 'Business Owner / Entrepreneur / Industrialist (ਵਪਾਰੀ)' },
  { value: 'Civil Services', label: 'IAS / PCS / Allied Civil Services' },
  { value: 'Teacher', label: 'Professor / College Lecturer / Teacher (ਅਧਿਆਪਕ)' },
  { value: 'Banker', label: 'Banking & Financial Services (ਬੈਂਕ ਮੈਨੇਜਰ)' },
  { value: 'Police', label: 'Armed Forces / Police / Defence Officer (ਫੌਜ / ਪੁਲਿਸ)' },
  { value: 'NRI Career', label: 'Working Abroad / NRI Professional (ਵਿਦੇਸ਼ੀ ਨੌਕਰੀ)' },
  { value: 'Architect', label: 'Architect / Interior Designer' },
  { value: 'Other', label: 'ਹੋਰ ਕਿੱਤੇ (Other Careers)' }
];

export const EMPLOYMENT_TYPE_OPTIONS = [
  { value: 'Any', label: 'ਸਾਰੇ ਰੁਜ਼ਗਾਰ ਸੈਕਟਰ (All Sectors)' },
  { value: 'Government', label: 'ਸਰਕਾਰੀ ਮੁਲਾਜ਼ਮ (Government / PSU)' },
  { value: 'Professional Practice', label: 'ਪੇਸ਼ੇਵਰ ਪ੍ਰੈਕਟਿਸ (Advocate / Doctor Clinic / CA Firm)' },
  { value: 'Private Company', label: 'ਪ੍ਰਾਈਵੇਟ ਕੰਪਨੀ (MNC / Corporate / IT Firm)' },
  { value: 'Business', label: 'ਸਵੈ-ਰੁਜ਼ਗਾਰ / ਕਾਰੋਬਾਰ (Business / Self-Employed)' },
  { value: 'Abroad / NRI', label: 'ਵਿਦੇਸ਼ ਵਿੱਚ ਸਥਾਪਿਤ (Settled Abroad / NRI)' }
];

export const INCOME_RANGE_OPTIONS = [
  { value: 'Any', label: 'ਸਾਰੀਆਂ ਆਮਦਨ ਸੀਮਾਵਾਂ (All Income Ranges)' },
  { value: 'Below 5 Lakhs', label: '5 ਲੱਖ ਤੋਂ ਘੱਟ (Below 5 Lakhs / yr)' },
  { value: '5-10 Lakhs', label: '5 ਤੋਂ 10 ਲੱਖ (5 - 10 Lakhs / yr)' },
  { value: '10-20 Lakhs', label: '10 ਤੋਂ 20 ਲੱਖ (10 - 20 Lakhs / yr)' },
  { value: '20-50 Lakhs', label: '20 ਤੋਂ 50 ਲੱਖ (20 - 50 Lakhs / yr)' },
  { value: '50 Lakhs+', label: '50 ਲੱਖ ਤੋਂ ਵੱਧ (50 Lakhs+ / yr)' },
  { value: 'NRI $50k+', label: 'NRI Package ($50,000+ CAD/USD/GBP)' },
  { value: 'NRI $100k+', label: 'NRI High Earner ($100,000+ CAD/USD/GBP)' }
];

export const COUNTRY_OPTIONS = [
  { value: 'Any', label: 'ਸਾਰੇ ਦੇਸ਼ (All Countries)' },
  { value: 'India', label: 'ਭਾਰਤ (India)' },
  { value: 'Canada', label: 'ਕੈਨੇਡਾ (Canada - Ontario / BC / Alberta)' },
  { value: 'United Kingdom', label: 'ਯੂ.ਕੇ. (United Kingdom / England)' },
  { value: 'USA', label: 'ਅਮਰੀਕਾ (United States of America)' },
  { value: 'Australia', label: 'ਆਸਟ੍ਰੇਲੀਆ (Australia / New Zealand)' },
  { value: 'UAE', label: 'ਦੁਬਈ / ਯੂ.ਏ.ਈ. (UAE / Gulf)' },
  { value: 'Europe', label: 'ਯੂਰਪ (Germany / Italy / France / Spain)' }
];

export const STATE_REGION_OPTIONS = [
  { value: 'Any', label: 'ਸਾਰੇ ਖੇਤਰ / ਰੀਜਨ (All Regions)' },
  { value: 'Majha', label: 'ਮਾਝਾ - ਮਾਝਾ ਰੀਜਨ (Gurdaspur, Amritsar, Pathankot, Tarn Taran)' },
  { value: 'Doaba', label: 'ਦੁਆਬਾ - ਦੁਆਬਾ ਰੀਜਨ (Jalandhar, Hoshiarpur, Kapurthala, Nawanshahr)' },
  { value: 'Malwa', label: 'ਮਾਲਵਾ - ਮਾਲਵਾ ਰੀਜਨ (Ludhiana, Patiala, Bathinda, Mohali, Sangrur)' },
  { value: 'Chandigarh', label: 'ਚੰਡੀਗੜ੍ਹ ਟ੍ਰਾਈਸਿਟੀ (Chandigarh, Mohali, Panchkula)' },
  { value: 'Jammu', label: 'ਜੰਮੂ ਅਤੇ ਕਸ਼ਮੀਰ (Jammu, Kathua, Samba)' },
  { value: 'Delhi NCR', label: 'ਦਿੱਲੀ ਐਨ.ਸੀ.ਆਰ. (Delhi, Gurgaon, Noida, Faridabad)' },
  { value: 'Haryana', label: 'ਹਰਿਆਣਾ (Ambala, Karnal, Panipat, Kurukshetra)' },
  { value: 'Himachal', label: 'ਹਿਮਾਚਲ ਪ੍ਰਦੇਸ਼ (Kangra, Una, Solan, Shimla)' },
  { value: 'Overseas', label: 'ਵਿਦੇਸ਼ / NRI (Canada, UK, USA, Australia)' }
];

export const MARITAL_STATUS_OPTIONS = [
  { value: 'Any', label: 'ਕੋਈ ਵੀ (Any Marital Status)' },
  { value: 'Never Married', label: 'ਕਦੇ ਵਿਆਹ ਨਹੀਂ ਹੋਇਆ (Never Married)' },
  { value: 'Divorced', label: 'ਤਲਾਕਸ਼ੁਦਾ (Divorced)' },
  { value: 'Widowed', label: 'ਵਿਧਵਾ / ਵਿਧੁਰ (Widowed)' },
  { value: 'Awaiting Divorce', label: 'ਤਲਾਕ ਅਧੀਨ (Awaiting Divorce)' }
];
