export type NotificationCategory = 'match' | 'message_request' | 'activity';

export type NotificationType = 
  | 'new_match' 
  | 'high_compatibility' 
  | 'gotra_match' 
  | 'message_request' 
  | 'message_reply' 
  | 'contact_request' 
  | 'profile_view' 
  | 'interest_received' 
  | 'interest_accepted' 
  | 'shortlisted' 
  | 'verification_approved'
  | 'photo_approved';

export interface NotificationItem {
  id: string;
  category: NotificationCategory;
  type: NotificationType;
  title: string;
  titlePa?: string;
  titleHi?: string;
  message: string;
  messagePa?: string;
  messageHi?: string;
  timestamp: string; // ISO String
  read: boolean;
  avatarUrl?: string;
  senderName?: string;
  senderGotra?: string;
  targetProfileId?: string;
  actionUrl?: string;
  badge?: string;
  badgePa?: string;
  priority?: 'high' | 'normal' | 'low';
  status?: 'pending' | 'accepted' | 'declined';
  metadata?: {
    compatibilityScore?: number;
    gotraPair?: string;
    location?: string;
    profession?: string;
    contactNumber?: string;
    requestMessage?: string;
  };
}

export type NotificationFilter = 'all' | 'match' | 'message_request' | 'activity' | 'unread';
