import type { FilterCriteria } from '../types/filters';

// Majha, Doaba, Malwa district maps
const REGION_DISTRICTS: Record<string, string[]> = {
  Majha: ['gurdaspur', 'amritsar', 'pathankot', 'tarn taran'],
  Doaba: ['jalandhar', 'hoshiarpur', 'kapurthala', 'nawanshahr', 'sbs nagar'],
  Malwa: [
    'ludhiana', 'patiala', 'bathinda', 'sas nagar', 'mohali', 'sangrur', 
    'firozpur', 'faridkot', 'fazilka', 'mansa', 'moga', 'muktsar', 
    'fatehgarh sahib', 'barnala', 'malerkotla', 'rupnagar', 'ropar'
  ],
  Chandigarh: ['chandigarh', 'mohali', 'panchkula', 'zirakpur', 'kharar'],
  Jammu: ['jammu', 'kathua', 'samba', 'udhampur'],
  'Delhi NCR': ['delhi', 'noida', 'gurgaon', 'gurugram', 'faridabad', 'ghaziabad'],
  Haryana: ['ambala', 'karnal', 'panipat', 'kurukshetra', 'sonipat', 'panchkula'],
  Himachal: ['kangra', 'una', 'solan', 'shimla', 'hamirpur'],
  Overseas: ['canada', 'toronto', 'vancouver', 'brampton', 'surrey', 'calgary', 'uk', 'london', 'birmingham', 'usa', 'california', 'new york', 'texas', 'australia', 'sydney', 'melbourne', 'dubai', 'uae']
};

export function filterAndSortProfiles(profiles: any[], filters: FilterCriteria): any[] {
  let result = profiles.filter((p) => {
    // 1. Gender Filter
    if (filters.gender !== 'Any') {
      if (p.gender && p.gender.toLowerCase() !== filters.gender.toLowerCase()) {
        return false;
      }
    }

    // 2. Age Range
    if (filters.minAge) {
      const min = parseInt(filters.minAge, 10);
      const pAge = typeof p.age === 'number' ? p.age : parseInt(p.age || '0', 10);
      if (pAge > 0 && pAge < min) return false;
    }
    if (filters.maxAge) {
      const max = parseInt(filters.maxAge, 10);
      const pAge = typeof p.age === 'number' ? p.age : parseInt(p.age || '0', 10);
      if (pAge > 0 && pAge > max) return false;
    }

    // 3. Universal Search Query
    if (filters.searchQuery && filters.searchQuery.trim() !== '') {
      const query = filters.searchQuery.toLowerCase().trim();
      const searchableText = [
        p.fullName || '',
        p.fatherGotra || '',
        p.motherGotra || '',
        p.community || '',
        p.profession || '',
        p.occupationDetails || '',
        p.qualification1 || '',
        p.qualification2 || '',
        p.qualification3 || '',
        p.education || '',
        p.district || '',
        p.location || '',
        p.birthPlace || '',
        p.aboutMe || ''
      ].join(' ').toLowerCase();

      if (!searchableText.includes(query)) {
        return false;
      }
    }

    // 4. Education Level Filter
    if (filters.educationLevel && filters.educationLevel.length > 0) {
      const eduText = [
        p.qualification1 || '',
        p.qualification2 || '',
        p.qualification3 || '',
        p.education || '',
        p.profession || '',
        p.occupationDetails || ''
      ].join(' ').toLowerCase();

      const matchesAny = filters.educationLevel.some(level => {
        switch (level) {
          case 'Doctorate':
            return eduText.includes('phd') || eduText.includes('doctorate') || eduText.includes('m.phil');
          case 'Post Graduate':
            return eduText.includes('llm') || eduText.includes('master') || eduText.includes('post grad') || eduText.includes('m.tech') || eduText.includes('mtech') || eduText.includes('md') || eduText.includes('ms') || eduText.includes('m.s') || eduText.includes('mba') || eduText.includes('mca') || eduText.includes('m.sc') || eduText.includes('msc') || eduText.includes('ma');
          case 'Graduate':
            return eduText.includes('bachelor') || eduText.includes('b.tech') || eduText.includes('btech') || eduText.includes('ba.llb') || eduText.includes('ballb') || eduText.includes('llb') || eduText.includes('mbbs') || eduText.includes('bds') || eduText.includes('bba') || eduText.includes('b.com') || eduText.includes('bcom') || eduText.includes('b.sc') || eduText.includes('bsc') || eduText.includes('ba') || eduText.includes('b.e') || eduText.includes('degree');
          case 'Engineering Diploma':
            return eduText.includes('diploma') || eduText.includes('polytechnic') || eduText.includes('engineering diploma');
          case 'Professional Law':
            return eduText.includes('llm') || eduText.includes('llb') || eduText.includes('ba.llb') || eduText.includes('advocate') || eduText.includes('law');
          case 'Medical Health':
            return eduText.includes('mbbs') || eduText.includes('bds') || eduText.includes('bams') || eduText.includes('md') || eduText.includes('doctor') || eduText.includes('physician') || eduText.includes('nursing');
          case 'IT Computer':
            return eduText.includes('cse') || eduText.includes('computer') || eduText.includes('software') || eduText.includes('mca') || eduText.includes('bca') || eduText.includes('data science') || eduText.includes('it');
          case 'Finance Commerce':
            return eduText.includes('ca') || eduText.includes('chartered') || eduText.includes('b.com') || eduText.includes('m.com') || eduText.includes('mba') || eduText.includes('finance') || eduText.includes('account');
          default:
            return false;
        }
      });
      if (!matchesAny) return false;
    }

    // 5. Education Field
    if (filters.educationField && filters.educationField !== 'Any') {
      const fieldText = [
        p.qualification1 || '',
        p.qualification2 || '',
        p.qualification3 || '',
        p.education || '',
        p.profession || '',
        p.occupationDetails || ''
      ].join(' ').toLowerCase();

      switch (filters.educationField) {
        case 'Law':
          if (!fieldText.includes('law') && !fieldText.includes('llm') && !fieldText.includes('llb') && !fieldText.includes('advocate') && !fieldText.includes('legal') && !fieldText.includes('pcs')) return false;
          break;
        case 'Engineering':
          if (!fieldText.includes('engineer') && !fieldText.includes('tech') && !fieldText.includes('diploma') && !fieldText.includes('b.e') && !fieldText.includes('polytechnic')) return false;
          break;
        case 'Medical':
          if (!fieldText.includes('medic') && !fieldText.includes('doctor') && !fieldText.includes('mbbs') && !fieldText.includes('bds') && !fieldText.includes('bams') && !fieldText.includes('health') && !fieldText.includes('pharma')) return false;
          break;
        case 'Management':
          if (!fieldText.includes('mba') && !fieldText.includes('bba') && !fieldText.includes('management') && !fieldText.includes('business')) return false;
          break;
        case 'Finance':
          if (!fieldText.includes('ca') && !fieldText.includes('account') && !fieldText.includes('finance') && !fieldText.includes('b.com') && !fieldText.includes('commerce') && !fieldText.includes('banking')) return false;
          break;
        case 'Science':
          if (!fieldText.includes('b.sc') && !fieldText.includes('m.sc') && !fieldText.includes('science') && !fieldText.includes('physics') && !fieldText.includes('chemistry')) return false;
          break;
        case 'Arts':
          if (!fieldText.includes('ba') && !fieldText.includes('m.a') && !fieldText.includes('arts') && !fieldText.includes('humanities')) return false;
          break;
        case 'Civil Services':
          if (!fieldText.includes('civil') && !fieldText.includes('ias') && !fieldText.includes('pcs') && !fieldText.includes('upsc') && !fieldText.includes('administrative')) return false;
          break;
      }
    }

    // 6. Specific Qualification Degree Text
    if (filters.qualificationDegree && filters.qualificationDegree.trim() !== '') {
      const deg = filters.qualificationDegree.toLowerCase().trim();
      const qualifications = [
        p.qualification1 || '',
        p.qualification2 || '',
        p.qualification3 || '',
        p.education || ''
      ].join(' ').toLowerCase();
      if (!qualifications.includes(deg)) return false;
    }

    // 7. Occupation / Profession Filter
    if (filters.profession && filters.profession.length > 0) {
      const profText = [
        p.profession || '',
        p.occupationDetails || ''
      ].join(' ').toLowerCase();

      const matchesAny = filters.profession.some(pTarget => {
        switch (pTarget) {
          case 'Advocate':
            return profText.includes('advocate') || profText.includes('lawyer') || profText.includes('pcs') || profText.includes('legal') || profText.includes('criminology');
          case 'Software Engineer':
            return profText.includes('software') || profText.includes('developer') || profText.includes('programmer') || profText.includes('data scientist') || profText.includes('tech') || profText.includes('engineer');
          case 'Doctor':
            return profText.includes('doctor') || profText.includes('physician') || profText.includes('surgeon') || profText.includes('mbbs') || profText.includes('medical') || profText.includes('dentist');
          case 'Government Job':
            return profText.includes('government') || profText.includes('govt') || profText.includes('psu') || profText.includes('cpwd') || profText.includes('railway') || profText.includes('bank') || profText.includes('officer');
          case 'Chartered Accountant':
            return profText.includes('chartered') || profText.includes('ca') || profText.includes('auditor') || profText.includes('tax');
          case 'Business':
            return profText.includes('business') || profText.includes('trader') || profText.includes('entrepreneur') || profText.includes('store') || profText.includes('export') || profText.includes('manufacturing');
          case 'Civil Services':
            return profText.includes('civil') || profText.includes('ias') || profText.includes('pcs') || profText.includes('allied') || profText.includes('magistrate');
          case 'Teacher':
            return profText.includes('teacher') || profText.includes('professor') || profText.includes('lecturer') || profText.includes('faculty') || profText.includes('academic');
          case 'Banker':
            return profText.includes('bank') || profText.includes('finance') || profText.includes('loan') || profText.includes('credit');
          case 'Police':
            return profText.includes('police') || profText.includes('army') || profText.includes('defence') || profText.includes('armed') || profText.includes('inspector') || profText.includes('dsp');
          case 'NRI Career':
            return profText.includes('nri') || profText.includes('toronto') || profText.includes('canada') || profText.includes('uk') || profText.includes('usa') || profText.includes('abroad') || profText.includes('overseas');
          case 'Architect':
            return profText.includes('architect') || profText.includes('interior') || profText.includes('design');
          default:
            return profText.includes(pTarget.toLowerCase());
        }
      });
      if (!matchesAny) return false;
    }

    // 8. Employment Type Filter
    if (filters.employmentType && filters.employmentType !== 'Any') {
      const empText = [
        p.profession || '',
        p.occupationDetails || '',
        p.fatherOccupation || '',
        p.motherOccupation || ''
      ].join(' ').toLowerCase();

      switch (filters.employmentType) {
        case 'Government':
          if (!empText.includes('government') && !empText.includes('govt') && !empText.includes('psu') && !empText.includes('cpwd') && !empText.includes('official') && !empText.includes('officer')) return false;
          break;
        case 'Professional Practice':
          if (!empText.includes('practicing') && !empText.includes('practice') && !empText.includes('advocate') && !empText.includes('clinic') && !empText.includes('firm') && !empText.includes('court')) return false;
          break;
        case 'Private Company':
          if (!empText.includes('private') && !empText.includes('mnc') && !empText.includes('software') && !empText.includes('corp') && !empText.includes('company') && !empText.includes('ltd')) return false;
          break;
        case 'Business':
          if (!empText.includes('business') && !empText.includes('self-employed') && !empText.includes('trader') && !empText.includes('owner')) return false;
          break;
        case 'Abroad / NRI':
          if (!empText.includes('canada') && !empText.includes('toronto') && !empText.includes('usa') && !empText.includes('uk') && !empText.includes('abroad') && !empText.includes('nri')) return false;
          break;
      }
    }

    // 9. Income Range Filter
    if (filters.incomeRange && filters.incomeRange !== 'Any') {
      const incText = (p.income || '').toLowerCase();
      switch (filters.incomeRange) {
        case 'Below 5 Lakhs':
          if (!incText.includes('below') && !incText.includes('2-5') && !incText.includes('3-5') && !incText.includes('under 5')) return false;
          break;
        case '5-10 Lakhs':
          if (!incText.includes('5-10') && !incText.includes('5 to 10') && !incText.includes('7-10')) return false;
          break;
        case '10-20 Lakhs':
          if (!incText.includes('10-20') && !incText.includes('10 to 20') && !incText.includes('12-18') && !incText.includes('15-20')) return false;
          break;
        case '20-50 Lakhs':
          if (!incText.includes('20-50') && !incText.includes('20 to 50') && !incText.includes('25-35') && !incText.includes('30-40')) return false;
          break;
        case '50 Lakhs+':
          if (!incText.includes('50 lakhs+') && !incText.includes('50+') && !incText.includes('crore') && !incText.includes('1 cr')) return false;
          break;
        case 'NRI $50k+':
        case 'NRI $100k+':
          if (!incText.includes('$') && !incText.includes('cad') && !incText.includes('usd') && !incText.includes('nri') && !incText.includes('gbp')) return false;
          break;
      }
    }

    // 10. Country Location
    if (filters.country && filters.country !== 'Any') {
      const locText = [
        p.location || '',
        p.district || '',
        p.birthPlace || '',
        p.occupationDetails || ''
      ].join(' ').toLowerCase();

      switch (filters.country) {
        case 'India':
          if (locText.includes('toronto') || locText.includes('vancouver') || locText.includes('london') || locText.includes('sydney') || locText.includes('dubai') || locText.includes('california')) return false;
          break;
        case 'Canada':
          if (!locText.includes('canada') && !locText.includes('toronto') && !locText.includes('ontario') && !locText.includes('vancouver') && !locText.includes('brampton') && !locText.includes('calgary') && !locText.includes('bc')) return false;
          break;
        case 'United Kingdom':
          if (!locText.includes('uk') && !locText.includes('united kingdom') && !locText.includes('london') && !locText.includes('birmingham') && !locText.includes('england')) return false;
          break;
        case 'USA':
          if (!locText.includes('usa') && !locText.includes('united states') && !locText.includes('america') && !locText.includes('california') && !locText.includes('texas') && !locText.includes('new york')) return false;
          break;
        case 'Australia':
          if (!locText.includes('australia') && !locText.includes('sydney') && !locText.includes('melbourne') && !locText.includes('brisbane')) return false;
          break;
        case 'UAE':
          if (!locText.includes('uae') && !locText.includes('dubai') && !locText.includes('abu dhabi') && !locText.includes('sharjah') && !locText.includes('gulf')) return false;
          break;
        case 'Europe':
          if (!locText.includes('germany') && !locText.includes('italy') && !locText.includes('france') && !locText.includes('spain') && !locText.includes('europe')) return false;
          break;
      }
    }

    // 11. State / Region Location
    if (filters.stateRegion && filters.stateRegion !== 'Any') {
      const locText = [
        p.location || '',
        p.district || '',
        p.birthPlace || '',
        p.occupationDetails || ''
      ].join(' ').toLowerCase();

      const districtKeywords = REGION_DISTRICTS[filters.stateRegion];
      if (districtKeywords && districtKeywords.length > 0) {
        const matchesRegion = districtKeywords.some(keyword => locText.includes(keyword));
        if (!matchesRegion) return false;
      }
    }

    // 12. Specific Punjab State
    if (filters.state && filters.state.length > 0) {
      const locText = [
        p.state || '',
        p.location || '',
        p.district || '',
        p.birthPlace || ''
      ].join(' ').toLowerCase();

      const matchesAny = filters.state.some(st => {
        const pureSt = st.split('(')[0].trim().toLowerCase();
        return locText.includes(pureSt);
      });
      if (!matchesAny) return false;
    }

    // 13. Specific Punjab District
    if (filters.district && filters.district.length > 0) {
      const locText = [
        p.district || '',
        p.location || '',
        p.birthPlace || ''
      ].join(' ').toLowerCase();

      const matchesAny = filters.district.some(dist => {
        const pureDist = dist.split('(')[0].trim().toLowerCase();
        return locText.includes(pureDist);
      });
      if (!matchesAny) return false;
    }

    // 13. Specific City / Town
    if (filters.cityLocation && filters.cityLocation.trim() !== '') {
      const city = filters.cityLocation.toLowerCase().trim();
      const locText = [
        p.location || '',
        p.district || '',
        p.birthPlace || ''
      ].join(' ').toLowerCase();

      if (!locText.includes(city)) return false;
    }

    // 14. Father Gotra Filter
    if (filters.fatherGotra && filters.fatherGotra !== 'Any') {
      const pureGotra = filters.fatherGotra.split('(')[0].trim().toLowerCase();
      const gotraText = [
        p.fatherGotra || '',
        p.community || ''
      ].join(' ').toLowerCase();

      if (!gotraText.includes(pureGotra)) return false;
    }

    // 15. Mother Gotra Filter
    if (filters.motherGotra && filters.motherGotra !== 'Any') {
      const pureMother = filters.motherGotra.split('(')[0].trim().toLowerCase();
      const motherText = (p.motherGotra || '').toLowerCase();
      if (!motherText.includes(pureMother)) return false;
    }

    // 16. Verified Badge Only
    if (filters.verifiedOnly && !p.isVerified) {
      return false;
    }

    // 17. Photo Only
    if (filters.withPhotoOnly) {
      const hasPhoto = Boolean(p.photoUrl || (p.photoUrls && p.photoUrls.length > 0));
      if (!hasPhoto) return false;
    }

    // 18. Marital Status
    if (filters.maritalStatus && filters.maritalStatus !== 'Any') {
      const ms = (p.maritalStatus || 'Never Married').toLowerCase();
      if (!ms.includes(filters.maritalStatus.toLowerCase())) return false;
    }

    return true;
  });

  // Sorting
  result.sort((a, b) => {
    switch (filters.sortBy) {
      case 'age_asc': {
        const ageA = typeof a.age === 'number' ? a.age : parseInt(a.age || '0', 10);
        const ageB = typeof b.age === 'number' ? b.age : parseInt(b.age || '0', 10);
        return ageA - ageB;
      }
      case 'age_desc': {
        const ageA = typeof a.age === 'number' ? a.age : parseInt(a.age || '0', 10);
        const ageB = typeof b.age === 'number' ? b.age : parseInt(b.age || '0', 10);
        return ageB - ageA;
      }
      case 'newest': {
        return (b.isVerified ? 1 : 0) - (a.isVerified ? 1 : 0);
      }
      case 'education_high': {
        const hasHighA = a.qualification3 || a.qualification2 || a.qualification1;
        const hasHighB = b.qualification3 || b.qualification2 || b.qualification1;
        return (hasHighB ? 1 : 0) - (hasHighA ? 1 : 0);
      }
      case 'income_high': {
        const incA = a.income || '';
        const incB = b.income || '';
        return incB.localeCompare(incA);
      }
      case 'relevance':
      default: {
        // Prioritize verified profiles and higher profile completeness
        if (a.isVerified !== b.isVerified) {
          return a.isVerified ? -1 : 1;
        }
        return (b.profileCompletion || 50) - (a.profileCompletion || 50);
      }
    }
  });

  return result;
}

export function countActiveFilters(filters: FilterCriteria): number {
  let count = 0;
  if (filters.gender !== 'Any') count++;
  if (filters.minAge !== '18' || filters.maxAge !== '50') count++;
  if (filters.searchQuery.trim() !== '') count++;
  if (filters.educationLevel.length > 0) count++;
  if (filters.educationField !== 'Any') count++;
  if (filters.qualificationDegree.trim() !== '') count++;
  if (filters.profession.length > 0) count++;
  if (filters.employmentType !== 'Any') count++;
  if (filters.incomeRange !== 'Any') count++;
  if (filters.country !== 'Any') count++;
  if (filters.stateRegion !== 'Any') count++;
  if (filters.state && filters.state.length > 0) count++;
  if (filters.district.length > 0) count++;
  if (filters.cityLocation.trim() !== '') count++;
  if (filters.fatherGotra !== 'Any') count++;
  if (filters.motherGotra !== 'Any') count++;
  if (filters.verifiedOnly) count++;
  if (filters.withPhotoOnly) count++;
  if (filters.maritalStatus !== 'Any') count++;
  return count;
}
