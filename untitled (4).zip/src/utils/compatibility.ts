import { ProfileData, MatchCompatibility } from '../types';

// Regional district clusters in Punjab / nearby for proximity scoring
const REGIONS: Record<string, string[]> = {
  majha: ['gurdaspur', 'amritsar', 'pathankot', 'tarn taran'],
  doaba: ['jalandhar', 'hoshiarpur', 'kapurthala', 'nawanshahr', 'shahid bhagat singh nagar'],
  malwa: ['ludhiana', 'patiala', 'bathinda', 'sas nagar', 'mohali', 'sangrur', 'rupnagar', 'ropar', 'firozpur', 'faridkot', 'fazilka', 'mansa', 'moga', 'muktsar', 'fatehgarh sahib', 'barnala', 'malerkotla'],
  tricity_delhi: ['chandigarh', 'panchkula', 'mohali', 'delhi'],
  jammu: ['jammu', 'kathua', 'samba', 'udhampur']
};

function normalizeString(str?: string): string {
  if (!str) return '';
  return str.toLowerCase().replace(/[\(\)\[\]\/\,\-]/g, ' ').replace(/\s+/g, ' ').trim();
}

function getRegion(districtOrLocation: string): string | null {
  const norm = normalizeString(districtOrLocation);
  for (const [regionName, districts] of Object.entries(REGIONS)) {
    for (const d of districts) {
      if (norm.includes(d)) return regionName;
    }
  }
  return null;
}

/**
 * Calculates a comprehensive matrimonial compatibility score between two profiles
 */
export function calculateCompatibility(
  source: Partial<ProfileData>,
  target: Partial<ProfileData>
): MatchCompatibility {
  const highlights: string[] = [];
  const considerations: string[] = [];

  // 1. Caste & Gotra Score (Weight: 35%)
  let casteGotraScore = 80;
  const sFatherGotra = normalizeString(source.fatherGotra);
  const tFatherGotra = normalizeString(target.fatherGotra);
  const sMotherGotra = normalizeString(source.motherGotra);
  const tMotherGotra = normalizeString(target.motherGotra);

  if (sFatherGotra && tFatherGotra) {
    if (sFatherGotra === tFatherGotra) {
      // Same father gotra
      casteGotraScore = 55;
      considerations.push('ਦੋਹਾਂ ਪਰਿਵਾਰਾਂ ਦਾ ਪਿਤਾ ਗੋਤਰ ਇੱਕੋ ਹੈ (' + (source.fatherGotra || '') + ') - ਰਵਾਇਤੀ ਜਾਂਚ ਕਰੋ');
    } else if (sFatherGotra !== tFatherGotra && (!sMotherGotra || sMotherGotra !== tMotherGotra)) {
      casteGotraScore = 98;
      highlights.push('ਮਹਾਸ਼ਾ ਸਮਾਜ ਵਿੱਚ ਸ਼ੁੱਧ ਗੋਤਰ ਮਿਲਾਣ (ਵੱਖ-ਵੱਖ ਪਿਤਾ ਅਤੇ ਮਾਤਾ ਗੋਤਰ ਅਨੁਕੂਲ)');
    } else {
      casteGotraScore = 90;
      highlights.push('ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ ਵਿੱਚ ਸ਼ਾਨਦਾਰ ਸੰਜੋਗ');
    }
  } else {
    casteGotraScore = 85;
    highlights.push('ਮਹਾਸ਼ਾ ਸਮਾਜ ਦਾ ਭਰੋਸੇਯੋਗ ਰਿਸ਼ਤਾ');
  }

  // 2. Education Score (Weight: 25%)
  let educationScore = 75;
  const sEdu = normalizeString((source.qualification1 || '') + ' ' + (source.qualification2 || '') + ' ' + (source.qualification3 || '') + ' ' + (source.education || ''));
  const tEdu = normalizeString((target.qualification1 || '') + ' ' + (target.qualification2 || '') + ' ' + (target.qualification3 || '') + ' ' + (target.education || ''));

  const isHigherDegree = (text: string) => 
    text.includes('llm') || text.includes('m.tech') || text.includes('mba') || text.includes('ms') || 
    text.includes('md') || text.includes('mbbs') || text.includes('phd') || text.includes('mca') || text.includes('ca');
  
  const isProfessionalDegree = (text: string) => 
    text.includes('b.tech') || text.includes('llb') || text.includes('law') || text.includes('b.e') || 
    text.includes('engineering') || text.includes('bca') || text.includes('bba') || text.includes('b.com') || text.includes('b.ed');

  if (sEdu && tEdu) {
    if (isHigherDegree(sEdu) && isHigherDegree(tEdu)) {
      educationScore = 98;
      highlights.push('ਦੋਵੇਂ ਉੱਚ ਸਿੱਖਿਅਤ (Higher Masters / Professional Degrees)');
    } else if ((isHigherDegree(sEdu) || isProfessionalDegree(sEdu)) && (isHigherDegree(tEdu) || isProfessionalDegree(tEdu))) {
      educationScore = 92;
      highlights.push('ਵਧੀਆ ਵਿੱਦਿਅਕ ਯੋਗਤਾ ਦਾ ਮੇਲ (Well-Educated Professionals)');
    } else {
      educationScore = 82;
      highlights.push('ਯੋਗ ਵਿੱਦਿਅਕ ਪੱਧਰ');
    }
  }

  // 3. Location & District Score (Weight: 20%)
  let locationScore = 70;
  const sDist = normalizeString((source.district || '') + ' ' + (source.location || ''));
  const tDist = normalizeString((target.district || '') + ' ' + (target.location || ''));

  const sRegion = getRegion(sDist);
  const tRegion = getRegion(tDist);

  if (sDist && tDist) {
    // Check direct district match
    const primaryDistricts = ['gurdaspur', 'amritsar', 'pathankot', 'jalandhar', 'hoshiarpur', 'ludhiana', 'patiala', 'bathinda', 'mohali', 'chandigarh', 'jammu'];
    let sameDistrict = false;
    for (const d of primaryDistricts) {
      if (sDist.includes(d) && tDist.includes(d)) {
        sameDistrict = true;
        break;
      }
    }

    if (sameDistrict) {
      locationScore = 98;
      highlights.push('ਇੱਕੋ ਜ਼ਿਲ੍ਹੇ / ਨੇੜਲੇ ਇਲਾਕੇ ਦੀ ਰਿਹਾਇਸ਼ (Same District / Local Hub)');
    } else if (sRegion && tRegion && sRegion === tRegion) {
      locationScore = 90;
      highlights.push('ਇੱਕੋ ਖਿੱਤੇ (Region: ' + sRegion.toUpperCase() + ') ਦੀ ਨੇੜਤਾ');
    } else if (sRegion && tRegion) {
      locationScore = 80;
      highlights.push('ਪੰਜਾਬ / ਉੱਤਰੀ ਭਾਰਤ ਅੰਦਰ ਆਸਾਨ ਆਵਾਜਾਈ');
    } else {
      locationScore = 75;
    }
  }

  // 4. Profession Synergy Score (Weight: 10%)
  let professionScore = 80;
  const sProf = normalizeString((source.profession || '') + ' ' + (source.occupationDetails || ''));
  const tProf = normalizeString((target.profession || '') + ' ' + (target.occupationDetails || ''));

  if (sProf && tProf) {
    if ((sProf.includes('advocate') || sProf.includes('law') || sProf.includes('pcs')) && (tProf.includes('advocate') || tProf.includes('law') || tProf.includes('pcs') || tProf.includes('govt'))) {
      professionScore = 96;
      highlights.push('ਕਾਨੂੰਨੀ ਅਤੇ ਸਰਕਾਰੀ ਖੇਤਰ ਵਿੱਚ ਉੱਚ ਪੱਧਰੀ ਪੇਸ਼ੇਵਰ ਮੇਲ (Legal/Govt synergy)');
    } else if ((sProf.includes('engineer') || sProf.includes('software') || sProf.includes('tech')) && (tProf.includes('engineer') || tProf.includes('software') || tProf.includes('tech'))) {
      professionScore = 95;
      highlights.push('ਆਈ.ਟੀ. / ਇੰਜੀਨੀਅਰਿੰਗ ਖੇਤਰ ਵਿੱਚ ਸਮਾਨ ਰੁਚੀ');
    } else if (sProf.includes('govt') || tProf.includes('govt')) {
      professionScore = 92;
      highlights.push('ਸਥਿਰ ਅਤੇ ਸਤਿਕਾਰਯੋਗ ਸਰਕਾਰੀ/ਪੇਸ਼ੇਵਰ ਨੌਕਰੀ');
    } else {
      professionScore = 84;
    }
  }

  // 5. Age Difference Score (Weight: 10%)
  let ageScore = 85;
  const sAge = typeof source.age === 'number' ? source.age : parseInt(String(source.age || 0), 10);
  const tAge = typeof target.age === 'number' ? target.age : parseInt(String(target.age || 0), 10);

  if (sAge > 0 && tAge > 0) {
    const diff = Math.abs(sAge - tAge);
    if (diff >= 1 && diff <= 4) {
      ageScore = 98;
      highlights.push(`ਸੰਪੂਰਨ ਉਮਰ ਦਾ ਫਰਕ (${diff} ਸਾਲ ਦਾ ਸੁਹਾਵਣਾ ਅੰਤਰ)`);
    } else if (diff === 0 || (diff > 4 && diff <= 6)) {
      ageScore = 90;
      highlights.push(`ਅਨੁਕੂਲ ਉਮਰ ਸਮੂਹ (${diff} ਸਾਲ ਦਾ ਫਰਕ)`);
    } else if (diff > 6 && diff <= 9) {
      ageScore = 75;
      considerations.push(`${diff} ਸਾਲ ਦਾ ਉਮਰ ਫਰਕ ਹੈ`);
    } else {
      ageScore = 60;
      considerations.push(`${diff} ਸਾਲ ਦਾ ਵੱਡਾ ਉਮਰ ਫਰਕ`);
    }
  }

  // Weighted total score:
  // Caste (35%) + Education (25%) + Location (20%) + Profession (10%) + Age (10%)
  const totalScore = Math.min(
    99,
    Math.round(
      casteGotraScore * 0.35 +
      educationScore * 0.25 +
      locationScore * 0.20 +
      professionScore * 0.10 +
      ageScore * 0.10
    )
  );

  let rating: MatchCompatibility['rating'] = 'Good (ਚੰਗਾ ਮੇਲ)';
  if (totalScore >= 92) {
    rating = 'Exceptional (ਸ਼ਾਨਦਾਰ)';
  } else if (totalScore >= 82) {
    rating = 'Great (ਬਹੁਤ ਵਧੀਆ)';
  } else if (totalScore >= 70) {
    rating = 'Good (ਚੰਗਾ ਮੇਲ)';
  } else {
    rating = 'Moderate (ਦਰਮਿਆਨਾ)';
  }

  return {
    totalScore,
    rating,
    casteGotraScore,
    educationScore,
    locationScore,
    professionScore,
    ageScore,
    highlights: highlights.slice(0, 3),
    considerations
  };
}
