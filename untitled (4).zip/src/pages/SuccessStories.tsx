import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useCMSConfig } from '../hooks/useCMSConfig';
import SEO from '../components/common/SEO';
import { Heart, Calendar, Quote } from 'lucide-react';

export default function SuccessStories() {
  const { language } = useLanguage();
  const { config } = useCMSConfig();

  const siteName = config?.siteNameEn || 'Mahasha Matrimonial';

  const translations = {
    en: {
      title: 'Success Stories',
      subtitle: 'Real connections, beautiful marriages. See how we have helped Mahasha families find their perfect match.',
      readMore: 'Read Full Story'
    },
    pa: {
      title: 'ਸਫਲ ਕਹਾਣੀਆਂ',
      subtitle: 'ਅਸਲ ਰਿਸ਼ਤੇ, ਖੂਬਸੂਰਤ ਵਿਆਹ। ਦੇਖੋ ਕਿਵੇਂ ਅਸੀਂ ਮਹਾਸ਼ਾ ਪਰਿਵਾਰਾਂ ਨੂੰ ਉਹਨਾਂ ਦਾ ਸੰਪੂਰਨ ਜੀਵਨ ਸਾਥੀ ਲੱਭਣ ਵਿੱਚ ਮਦਦ ਕੀਤੀ ਹੈ।',
      readMore: 'ਪੂਰੀ ਕਹਾਣੀ ਪੜ੍ਹੋ'
    },
    hi: {
      title: 'सफलता की कहानियाँ',
      subtitle: 'सच्चे रिश्ते, सुंदर विवाह। देखें कि हमने महाशा परिवारों को उनका सही जीवन साथी खोजने में कैसे मदद की है।',
      readMore: 'पूरी कहानी पढ़ें'
    }
  };

  const stories = [
    {
      id: 1,
      names: language === 'pa' ? 'ਰਾਹੁਲ ਅਤੇ ਪ੍ਰਿਆ' : language === 'hi' ? 'राहुल और प्रिया' : 'Rahul & Priya',
      date: 'October 2025',
      image: 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=800&auto=format&fit=crop',
      story: {
        en: "We found each other within just two months of registering. The Gotra matching feature made our parents confident, and the rest is history. Thank you for this wonderful platform!",
        pa: "ਰਜਿਸਟਰ ਕਰਨ ਦੇ ਸਿਰਫ਼ ਦੋ ਮਹੀਨਿਆਂ ਦੇ ਅੰਦਰ ਹੀ ਸਾਨੂੰ ਇੱਕ ਦੂਜੇ ਦਾ ਸਾਥ ਮਿਲ ਗਿਆ। ਗੋਤਰ ਮੈਚਿੰਗ ਫੀਚਰ ਨੇ ਸਾਡੇ ਮਾਪਿਆਂ ਦਾ ਭਰੋਸਾ ਵਧਾਇਆ, ਅਤੇ ਬਾਕੀ ਸਭ ਇਤਿਹਾਸ ਹੈ। ਇਸ ਸ਼ਾਨਦਾਰ ਪਲੇਟਫਾਰਮ ਲਈ ਧੰਨਵਾਦ!",
        hi: "पंजीकरण के केवल दो महीने के भीतर हमें एक-दूसरे का साथ मिल गया। गोत्र मिलान सुविधा ने हमारे माता-पिता का विश्वास बढ़ाया, और बाकी सब इतिहास है। इस शानदार मंच के लिए धन्यवाद!"
      }
    },
    {
      id: 2,
      names: language === 'pa' ? 'ਅਮਿਤ ਅਤੇ ਨੇਹਾ' : language === 'hi' ? 'अमित और नेहा' : 'Amit & Neha',
      date: 'February 2026',
      image: 'https://images.unsplash.com/photo-1621801306185-305bc85863ad?q=80&w=800&auto=format&fit=crop',
      story: {
        en: "As working professionals, we didn't have much time to look for matches traditionally. This platform understood our community values and helped us connect instantly.",
        pa: "ਕੰਮਕਾਜੀ ਹੋਣ ਕਾਰਨ, ਸਾਡੇ ਕੋਲ ਰਵਾਇਤੀ ਤੌਰ 'ਤੇ ਰਿਸ਼ਤੇ ਲੱਭਣ ਲਈ ਜ਼ਿਆਦਾ ਸਮਾਂ ਨਹੀਂ ਸੀ। ਇਸ ਪਲੇਟਫਾਰਮ ਨੇ ਸਾਡੇ ਭਾਈਚਾਰੇ ਦੀਆਂ ਕਦਰਾਂ-ਕੀਮਤਾਂ ਨੂੰ ਸਮਝਿਆ ਅਤੇ ਸਾਨੂੰ ਤੁਰੰਤ ਜੁੜਨ ਵਿੱਚ ਮਦਦ ਕੀਤੀ।",
        hi: "कामकाजी होने के कारण, हमारे पास पारंपरिक रूप से रिश्ते खोजने के लिए ज्यादा समय नहीं था। इस मंच ने हमारे समुदाय के मूल्यों को समझा और हमें तुरंत जुड़ने में मदद की।"
      }
    },
    {
      id: 3,
      names: language === 'pa' ? 'ਸੰਦੀਪ ਅਤੇ ਕਿਰਨ' : language === 'hi' ? 'संदीप और किरण' : 'Sandeep & Kiran',
      date: 'August 2026',
      image: 'https://images.unsplash.com/photo-1511285560929-80b456fea0bc?q=80&w=800&auto=format&fit=crop',
      story: {
        en: "Our families were looking for a verified and secure platform. The admin verification process here gave us peace of mind. We are happily married now!",
        pa: "ਸਾਡੇ ਪਰਿਵਾਰ ਇੱਕ ਪ੍ਰਮਾਣਿਤ ਅਤੇ ਸੁਰੱਖਿਅਤ ਪਲੇਟਫਾਰਮ ਲੱਭ ਰਹੇ ਸਨ। ਇੱਥੇ ਐਡਮਿਨ ਵੈਰੀਫਿਕੇਸ਼ਨ ਪ੍ਰਕਿਰਿਆ ਨੇ ਸਾਨੂੰ ਮਨ ਦੀ ਸ਼ਾਂਤੀ ਦਿੱਤੀ। ਅਸੀਂ ਹੁਣ ਖੁਸ਼ਹਾਲ ਵਿਆਹੁਤਾ ਹਾਂ!",
        hi: "हमारे परिवार एक सत्यापित और सुरक्षित मंच की तलाश में थे। यहां एडमिन सत्यापन प्रक्रिया ने हमें मन की शांति दी। हम अब खुशी-खुशी शादीशुदा हैं!"
      }
    }
  ];

  const currentContent = translations[language as keyof typeof translations] || translations.en;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-16">
      <SEO 
        title={`${currentContent.title} - ${siteName}`}
        description={currentContent.subtitle}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center justify-center p-3 bg-rose-100 rounded-full mb-6">
            <Heart className="w-8 h-8 text-rose-600" />
          </div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-gray-900 font-serif mb-6 leading-tight">
            {currentContent.title}
          </h1>
          <p className="text-lg text-gray-600 leading-relaxed">
            {currentContent.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10">
          {stories.map((story) => (
            <div key={story.id} className="bg-white rounded-3xl overflow-hidden shadow-xl border border-rose-100/50 group hover:shadow-2xl hover:-translate-y-2 transition-all duration-300">
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={story.image} 
                  alt={story.names} 
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-gray-900/80 via-transparent to-transparent"></div>
                <div className="absolute bottom-4 left-6 right-6 text-white">
                  <h3 className="text-2xl font-bold font-serif mb-1">{story.names}</h3>
                  <div className="flex items-center gap-2 text-sm font-medium text-rose-200">
                    <Calendar className="w-4 h-4" />
                    {story.date}
                  </div>
                </div>
              </div>
              <div className="p-8 relative">
                <Quote className="w-10 h-10 text-amber-100 absolute top-6 right-6 rotate-180" />
                <p className="text-gray-600 leading-relaxed relative z-10 italic">
                  "{story.story[language as keyof typeof story.story] || story.story.en}"
                </p>
                <div className="mt-6 pt-6 border-t border-gray-100">
                  <button className="text-rose-700 font-bold hover:text-rose-900 transition-colors flex items-center gap-2 text-sm">
                    {currentContent.readMore}
                    <span className="text-lg">→</span>
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
