import { useEffect, useState } from 'react';
import { collection, getDocs, doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { ShieldCheck, UserCircle, X, Check } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';

interface Profile {
  id: string;
  fullName: string;
  isVerified: boolean;
  email: string;
}

export default function AdminDashboard() {
  const { user } = useAuth();
  const [profiles, setProfiles] = useState<Profile[]>([]);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    // Hardcoded admin check for now, should be replaced with a real DB check
    const adminEmails = ['gtbservices8@gmail.com']; 
    if (user && adminEmails.includes(user.email || '')) {
      setIsAdmin(true);
      fetchProfiles();
    }
  }, [user]);

  async function fetchProfiles() {
    const snap = await getDocs(collection(db, 'profiles'));
    setProfiles(snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as Profile)));
  }

  async function toggleVerification(id: string, currentStatus: boolean) {
    await updateDoc(doc(db, 'profiles', id), { isVerified: !currentStatus });
    fetchProfiles();
  }

  if (!isAdmin) return <div>Unauthorized</div>;

  return (
    <div className="p-8">
      <h1 className="text-2xl font-bold mb-6">Admin CMS Control</h1>
      <table className="w-full bg-white rounded-lg shadow">
        <thead>
          <tr className="bg-gray-100 text-left">
            <th className="p-4">Name</th>
            <th className="p-4">Status</th>
            <th className="p-4">Actions</th>
          </tr>
        </thead>
        <tbody>
          {profiles.map(p => (
            <tr key={p.id} className="border-b">
              <td className="p-4">{p.fullName}</td>
              <td className="p-4">{p.isVerified ? 'Verified' : 'Pending'}</td>
              <td className="p-4">
                <button onClick={() => toggleVerification(p.id, p.isVerified)} className="text-blue-600">
                  {p.isVerified ? 'Unverify' : 'Verify'}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
