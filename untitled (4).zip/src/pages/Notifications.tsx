import { useState } from 'react';
import { 
  Bell, Sparkles, MessageSquare, Eye, CheckCheck, 
  Trash2, Volume2, VolumeX, Search, Filter, RefreshCw, 
  Settings, CheckCircle2, ShieldCheck, Heart, UserPlus, 
  ArrowLeft, Sliders
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { useNotifications } from '../contexts/NotificationContext';
import { useLanguage } from '../contexts/LanguageContext';
import NotificationCard from '../components/notifications/NotificationCard';
import SEO from '../components/common/SEO';
import type { NotificationCategory, NotificationFilter } from '../types/notification';

export default function Notifications() {
  const { 
    notifications, 
    unreadCount, 
    markAllAsRead, 
    clearAll, 
    soundEnabled, 
    toggleSound, 
    simulateNotification 
  } = useNotifications();
  const { language } = useLanguage();

  const [activeCategory, setActiveCategory] = useState<NotificationFilter>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showSettings, setShowSettings] = useState(false);

  // Preference switches state
  const [preferences, setPreferences] = useState({
    matchAlerts: true,
    messageAlerts: true,
    profileViewAlerts: true,
    weeklyGotraDigest: true,
    soundAlerts: soundEnabled
  });

  const handleTogglePref = (key: keyof typeof preferences) => {
    setPreferences(prev => {
      const updated = { ...prev, [key]: !prev[key] };
      if (key === 'soundAlerts') {
        toggleSound();
      }
      return updated;
    });
  };

  // Filter notifications
  const filteredNotifications = notifications.filter(item => {
    // Category filter
    if (activeCategory === 'unread' && item.read) return false;
    if (activeCategory !== 'all' && activeCategory !== 'unread' && item.category !== activeCategory) {
      return false;
    }

    // Search filter
    if (searchTerm.trim()) {
      const query = searchTerm.toLowerCase();
      const matchTitle = (item.title || '').toLowerCase().includes(query);
      const matchTitlePa = (item.titlePa || '').toLowerCase().includes(query);
      const matchMsg = (item.message || '').toLowerCase().includes(query);
      const matchMsgPa = (item.messagePa || '').toLowerCase().includes(query);
      const matchGotra = (item.senderGotra || '').toLowerCase().includes(query);
      const matchSender = (item.senderName || '').toLowerCase().includes(query);
      return matchTitle || matchTitlePa || matchMsg || matchMsgPa || matchGotra || matchSender;
    }

    return true;
  });

  const matchesTotal = notifications.filter(n => n.category === 'match').length;
  const requestsTotal = notifications.filter(n => n.category === 'message_request').length;
  const activityTotal = notifications.filter(n => n.category === 'activity').length;

  return (
    <div className="min-h-screen bg-gray-50/80 pb-16">
      <SEO 
        title="ਸੂਚਨਾਵਾਂ & ਅਲਰਟ (Notifications Hub) - Mahasha Matrimonial"
        description="ਨਵੇਂ ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ, ਮੈਚ ਅਲਰਟ, ਸੁਨੇਹਾ ਬੇਨਤੀਆਂ ਅਤੇ ਪ੍ਰੋਫਾਈਲ ਗਤੀਵਿਧੀਆਂ ਦੇ ਤਾਜ਼ਾ ਨੋਟੀਫਿਕੇਸ਼ਨ।"
        noIndex={true}
      />

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-amber-950 text-white py-8 border-b-2 border-amber-500/30">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            
            <div>
              <div className="inline-flex items-center gap-2 bg-amber-400/20 border border-amber-400/30 px-3 py-1 rounded-full text-xs font-bold text-amber-300 mb-2">
                <Bell className="w-3.5 h-3.5" />
                <span>{language === 'pa' ? 'ਲਾਈਵ ਇਨ-ਐਪ ਅਲਰਟ ਸਿਸਟਮ' : 'Live In-App Alert System'}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold font-serif text-white flex items-center gap-3">
                <span>{language === 'pa' ? 'ਸੂਚਨਾ ਕੇਂਦਰ (Notifications Center)' : 'Notifications & Match Alerts'}</span>
                {unreadCount > 0 && (
                  <span className="text-xs bg-amber-400 text-rose-950 px-2.5 py-0.5 rounded-full font-extrabold shadow-sm">
                    {unreadCount} {language === 'pa' ? 'ਨਵੀਆਂ' : 'Unread'}
                  </span>
                )}
              </h1>
              <p className="text-xs sm:text-sm text-amber-200/90 mt-1">
                {language === 'pa' 
                  ? 'ਨਵੇਂ ਗੋਤਰ ਮੇਲ, ਸੁਨੇਹਾ ਬੇਨਤੀਆਂ, ਅਤੇ ਪ੍ਰੋਫਾਈਲ ਗਤੀਵਿਧੀਆਂ ਦੇ ਤੁਰੰਤ ਅਲਰਟ' 
                  : 'Real-time alerts for high compatibility Gotra matches, message requests, and profile activities.'}
              </p>
            </div>

            {/* Quick Header Actions */}
            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => setShowSettings(!showSettings)}
                className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold border transition-all ${
                  showSettings 
                    ? 'bg-amber-400 text-rose-950 border-amber-400 shadow-sm' 
                    : 'bg-white/10 hover:bg-white/20 text-amber-200 border-amber-400/30'
                }`}
              >
                <Sliders className="w-3.5 h-3.5" />
                <span>{language === 'pa' ? 'ਸੈਟਿੰਗਾਂ' : 'Alert Settings'}</span>
              </button>

              {unreadCount > 0 && (
                <button
                  type="button"
                  onClick={markAllAsRead}
                  className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold border border-white/20 transition-all"
                >
                  <CheckCheck className="w-3.5 h-3.5 text-amber-400" />
                  <span>{language === 'pa' ? 'ਸਭ ਪੜ੍ਹੋ (Mark All Read)' : 'Mark All as Read'}</span>
                </button>
              )}

              <button
                type="button"
                onClick={clearAll}
                className="inline-flex items-center gap-1.5 px-3 py-2 rounded-xl bg-rose-950/80 hover:bg-rose-900 text-rose-200 text-xs font-semibold border border-rose-800 transition-all"
                title="Clear all notifications"
              >
                <Trash2 className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{language === 'pa' ? 'ਸਭ ਹਟਾਓ' : 'Clear All'}</span>
              </button>
            </div>

          </div>
        </div>
      </div>

      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 mt-6">
        
        {/* KPI Counter Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
          <div 
            onClick={() => setActiveCategory('all')}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${
              activeCategory === 'all' 
                ? 'bg-rose-950 text-white border-amber-500 shadow-md' 
                : 'bg-white text-gray-800 border-gray-200 hover:border-amber-300 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider ${activeCategory === 'all' ? 'text-amber-300' : 'text-gray-500'}`}>
                {language === 'pa' ? 'ਕੁੱਲ ਸੂਚਨਾਵਾਂ' : 'Total Alerts'}
              </span>
              <Bell className={`w-4 h-4 ${activeCategory === 'all' ? 'text-amber-400' : 'text-gray-400'}`} />
            </div>
            <div className="text-2xl font-extrabold mt-1 font-serif">{notifications.length}</div>
            <div className={`text-[11px] ${activeCategory === 'all' ? 'text-rose-200' : 'text-gray-500'}`}>
              {unreadCount} {language === 'pa' ? 'ਅਣਪੜ੍ਹੀਆਂ (Unread)' : 'unread'}
            </div>
          </div>

          <div 
            onClick={() => setActiveCategory('match')}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${
              activeCategory === 'match' 
                ? 'bg-amber-500 text-rose-950 border-amber-600 shadow-md' 
                : 'bg-white text-gray-800 border-amber-200 hover:border-amber-400 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold uppercase tracking-wider">
                {language === 'pa' ? 'ਗੋਤਰ ਮੈਚ ਅਲਰਟ' : 'Matches'}
              </span>
              <Sparkles className="w-4 h-4 text-amber-600" />
            </div>
            <div className="text-2xl font-extrabold mt-1 font-serif">{matchesTotal}</div>
            <div className="text-[11px] opacity-80">
              {language === 'pa' ? 'ਉੱਚ ਅਨੁਕੂਲਤਾ ਮੇਲ' : 'Gotra compatibility'}
            </div>
          </div>

          <div 
            onClick={() => setActiveCategory('message_request')}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${
              activeCategory === 'message_request' 
                ? 'bg-rose-900 text-white border-rose-950 shadow-md' 
                : 'bg-white text-gray-800 border-rose-200 hover:border-rose-400 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider ${activeCategory === 'message_request' ? 'text-amber-300' : 'text-rose-900'}`}>
                {language === 'pa' ? 'ਸੁਨੇਹਾ ਬੇਨਤੀਆਂ' : 'Message Requests'}
              </span>
              <MessageSquare className="w-4 h-4 text-rose-600" />
            </div>
            <div className="text-2xl font-extrabold mt-1 font-serif">{requestsTotal}</div>
            <div className={`text-[11px] ${activeCategory === 'message_request' ? 'text-rose-200' : 'text-gray-500'}`}>
              {language === 'pa' ? 'ਸੰਪਰਕ ਗੱਲਬਾਤ' : 'Pending & accepted'}
            </div>
          </div>

          <div 
            onClick={() => setActiveCategory('activity')}
            className={`p-4 rounded-2xl border cursor-pointer transition-all ${
              activeCategory === 'activity' 
                ? 'bg-emerald-800 text-white border-emerald-900 shadow-md' 
                : 'bg-white text-gray-800 border-emerald-200 hover:border-emerald-400 shadow-xs'
            }`}
          >
            <div className="flex items-center justify-between">
              <span className={`text-xs font-bold uppercase tracking-wider ${activeCategory === 'activity' ? 'text-emerald-200' : 'text-emerald-700'}`}>
                {language === 'pa' ? 'ਪ੍ਰੋਫਾਈਲ ਗਤੀਵਿਧੀ' : 'Profile Activity'}
              </span>
              <Eye className="w-4 h-4 text-emerald-600" />
            </div>
            <div className="text-2xl font-extrabold mt-1 font-serif">{activityTotal}</div>
            <div className={`text-[11px] ${activeCategory === 'activity' ? 'text-emerald-200' : 'text-gray-500'}`}>
              {language === 'pa' ? 'ਵਿਊਜ਼ ਅਤੇ ਸ਼ਾਰਟਲਿਸਟ' : 'Views & badges'}
            </div>
          </div>
        </div>

        {/* Live Simulator Test Bar */}
        <div className="bg-gradient-to-r from-amber-500/15 via-rose-500/10 to-amber-500/15 border-2 border-amber-300/80 rounded-2xl p-4 sm:p-5 mb-6 shadow-xs">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-xs sm:text-sm font-bold text-rose-950 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-amber-600" />
                <span>{language === 'pa' ? 'ਲਾਈਵ ਇਨ-ਐਪ ਨੋਟੀਫਿਕੇਸ਼ਨ ਸਿਮੂਲੇਟਰ (Test Triggers)' : 'Live In-App Notification Simulator:'}</span>
              </h3>
              <p className="text-xs text-gray-600 mt-0.5">
                {language === 'pa' 
                  ? 'ਅਲਰਟ ਬੈਨਰ, ਸਾਊਂਡ ਚਾਈਮ ਅਤੇ ਡ੍ਰੌਪਡਾਊਨ ਕਾਰਜਪ੍ਰਣਾਲੀ ਦੀ ਜਾਂਚ ਕਰਨ ਲਈ ਹੇਠਾਂ ਕਲਿੱਕ ਕਰੋ' 
                  : 'Click any button to trigger instant real-time in-app alerts, audio chime, and badges.'}
              </p>
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              <button
                type="button"
                onClick={() => simulateNotification('match')}
                className="px-3.5 py-2 bg-amber-500 hover:bg-amber-400 text-rose-950 rounded-xl text-xs font-bold shadow-xs transition-all active:scale-95 flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>+ {language === 'pa' ? 'ਨਵਾਂ ਮੈਚ ਅਲਰਟ' : 'Simulate Match'}</span>
              </button>

              <button
                type="button"
                onClick={() => simulateNotification('message_request')}
                className="px-3.5 py-2 bg-rose-900 hover:bg-rose-800 text-amber-300 rounded-xl text-xs font-bold shadow-xs transition-all active:scale-95 flex items-center gap-1.5"
              >
                <MessageSquare className="w-3.5 h-3.5" />
                <span>+ {language === 'pa' ? 'ਸੁਨੇਹਾ ਬੇਨਤੀ' : 'Simulate Message'}</span>
              </button>

              <button
                type="button"
                onClick={() => simulateNotification('activity')}
                className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs transition-all active:scale-95 flex items-center gap-1.5"
              >
                <Eye className="w-3.5 h-3.5" />
                <span>+ {language === 'pa' ? 'ਪ੍ਰੋਫਾਈਲ ਵਿਊ' : 'Simulate View'}</span>
              </button>
            </div>
          </div>
        </div>

        {/* Preferences / Settings Accordion */}
        {showSettings && (
          <div className="bg-white rounded-2xl border border-amber-300 p-5 mb-6 shadow-sm animate-in fade-in slide-in-from-top-2 duration-200">
            <div className="flex items-center justify-between border-b border-gray-100 pb-3 mb-4">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-rose-900" />
                <h3 className="text-base font-bold text-gray-900 font-serif">
                  {language === 'pa' ? 'ਨੋਟੀਫਿਕੇਸ਼ਨ ਤਰਜੀਹਾਂ (Notification Preferences)' : 'Notification & Alert Preferences'}
                </h3>
              </div>
              <button 
                onClick={() => setShowSettings(false)}
                className="text-xs font-bold text-gray-500 hover:text-gray-800"
              >
                {language === 'pa' ? 'ਬੰਦ ਕਰੋ' : 'Close'}
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 text-xs">
              <label className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer">
                <div>
                  <span className="font-bold text-gray-900 block">ਗੋਤਰ ਮੈਚ ਅਲਰਟ (Match Alerts)</span>
                  <span className="text-gray-500 text-[11px]">90%+ ਅਨੁਕੂਲਤਾ ਵਾਲੇ ਨਵੇਂ ਰਿਸ਼ਤੇ</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={preferences.matchAlerts} 
                  onChange={() => handleTogglePref('matchAlerts')}
                  className="w-4 h-4 text-amber-600 rounded border-gray-300 focus:ring-amber-500"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer">
                <div>
                  <span className="font-bold text-gray-900 block">ਸੁਨੇਹਾ ਬੇਨਤੀਆਂ (Message Alerts)</span>
                  <span className="text-gray-500 text-[11px]">ਪਰਿਵਾਰਾਂ ਵੱਲੋਂ ਸੰਪਰਕ ਸੰਦੇਸ਼</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={preferences.messageAlerts} 
                  onChange={() => handleTogglePref('messageAlerts')}
                  className="w-4 h-4 text-rose-600 rounded border-gray-300 focus:ring-rose-500"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer">
                <div>
                  <span className="font-bold text-gray-900 block">ਪ੍ਰੋਫਾਈਲ ਵਿਊ ਅਲਰਟ (View Alerts)</span>
                  <span className="text-gray-500 text-[11px]">ਜਦੋਂ ਕੋਈ ਤੁਹਾਡਾ ਬਾਇਓਡਾਟਾ ਦੇਖੇ</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={preferences.profileViewAlerts} 
                  onChange={() => handleTogglePref('profileViewAlerts')}
                  className="w-4 h-4 text-emerald-600 rounded border-gray-300 focus:ring-emerald-500"
                />
              </label>

              <label className="flex items-center justify-between p-3 rounded-xl border border-gray-200 hover:bg-gray-50 cursor-pointer">
                <div>
                  <span className="font-bold text-gray-900 block">ਸਾਊਂਡ ਚਾਈਮ (Audio Chime)</span>
                  <span className="text-gray-500 text-[11px]">ਅਲਰਟ ਆਉਣ 'ਤੇ ਹਲਕੀ ਧੁਨੀ</span>
                </div>
                <input 
                  type="checkbox" 
                  checked={soundEnabled} 
                  onChange={() => handleTogglePref('soundAlerts')}
                  className="w-4 h-4 text-amber-600 rounded border-gray-300 focus:ring-amber-500"
                />
              </label>
            </div>
          </div>
        )}

        {/* Filter Toolbar & Search */}
        <div className="bg-white p-4 rounded-2xl border border-gray-200 shadow-xs mb-6 flex flex-col md:flex-row gap-4 justify-between items-center">
          
          {/* Search */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={language === 'pa' ? 'ਨਾਮ, ਗੋਤਰ ਜਾਂ ਸੁਨੇਹੇ ਨਾਲ ਖੋਜੋ...' : 'Search by name, gotra, message...'}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9.5 pr-4 py-2 text-xs sm:text-sm border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
            />
          </div>

          {/* Category Tabs */}
          <div className="flex flex-wrap items-center gap-1.5 w-full md:w-auto">
            <button
              type="button"
              onClick={() => setActiveCategory('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeCategory === 'all'
                  ? 'bg-rose-950 text-white shadow-xs'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              {language === 'pa' ? 'ਸਾਰੇ' : 'All'} ({notifications.length})
            </button>

            <button
              type="button"
              onClick={() => setActiveCategory('match')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                activeCategory === 'match'
                  ? 'bg-amber-500 text-rose-950 shadow-xs'
                  : 'bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-200'
              }`}
            >
              <Sparkles className="w-3 h-3" />
              <span>{language === 'pa' ? 'ਮੈਚ' : 'Matches'} ({matchesTotal})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveCategory('message_request')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                activeCategory === 'message_request'
                  ? 'bg-rose-900 text-white shadow-xs'
                  : 'bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-200'
              }`}
            >
              <MessageSquare className="w-3 h-3" />
              <span>{language === 'pa' ? 'ਸੁਨੇਹੇ' : 'Requests'} ({requestsTotal})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveCategory('activity')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1 ${
                activeCategory === 'activity'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200'
              }`}
            >
              <Eye className="w-3 h-3" />
              <span>{language === 'pa' ? 'ਗਤੀਵਿਧੀ' : 'Activity'} ({activityTotal})</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveCategory('unread')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                activeCategory === 'unread'
                  ? 'bg-amber-600 text-white shadow-xs'
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
              }`}
            >
              {language === 'pa' ? 'ਸਿਰਫ਼ ਅਣਪੜ੍ਹੀਆਂ' : 'Unread'} ({unreadCount})
            </button>
          </div>
        </div>

        {/* Notifications List */}
        <div className="space-y-3">
          {filteredNotifications.length === 0 ? (
            <div className="bg-white rounded-3xl border border-gray-200 p-12 text-center shadow-xs">
              <Bell className="w-16 h-16 text-gray-300 mx-auto mb-3" />
              <h3 className="text-lg font-bold text-gray-900 font-serif">
                {language === 'pa' ? 'ਕੋਈ ਨੋਟੀਫਿਕੇਸ਼ਨ ਨਹੀਂ ਮਿਲੀ' : 'No notifications found'}
              </h3>
              <p className="text-xs sm:text-sm text-gray-500 mt-1 max-w-sm mx-auto">
                {language === 'pa' 
                  ? 'ਤੁਸੀਂ ਸਾਰੀਆਂ ਸੂਚਨਾਵਾਂ ਦੇਖ ਲਈਆਂ ਹਨ ਜਾਂ ਫਿਲਟਰ ਨਾਲ ਕੋਈ ਰਿਕਾਰਡ ਮੇਲ ਨਹੀਂ ਖਾਂਦਾ।' 
                  : 'You are all caught up! Use the simulator buttons above to trigger live test alerts.'}
              </p>
              <button
                type="button"
                onClick={() => simulateNotification('match')}
                className="mt-4 inline-flex items-center gap-1.5 px-4 py-2 bg-amber-500 hover:bg-amber-400 text-rose-950 font-bold text-xs rounded-xl shadow-xs transition-all"
              >
                <Sparkles className="w-3.5 h-3.5" />
                {language === 'pa' ? 'ਟੈਸਟ ਮੈਚ ਅਲਰਟ ਭੇਜੋ (Simulate Alert)' : 'Trigger Test Match Alert'}
              </button>
            </div>
          ) : (
            filteredNotifications.map(item => (
              <NotificationCard 
                key={item.id} 
                notification={item} 
              />
            ))
          )}
        </div>

      </div>
    </div>
  );
}
