import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc, updateDoc, increment, serverTimestamp } from 'firebase/firestore';
import { 
  UserCircle, CheckCircle2, MapPin, Briefcase, GraduationCap, 
  Users, Heart, Star, ArrowLeft, ShieldCheck, 
  Calendar, Clock, Phone, Sparkles, MessageCircle, Home,
  Award, BookOpen, Image as ImageIcon, Video, Eye
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { ProfileData } from '../types';
import CompatibilityCard from '../components/common/CompatibilityCard';
import SEO from '../components/common/SEO';
import { useNotifications } from '../contexts/NotificationContext';

// Fallback showcase profiles if viewing a demo ID
const SHOWCASE_DETAILS: Record<string, Partial<ProfileData>> = {
  'rec-advocate': {
    id: 'rec-advocate',
    fullName: 'Navpreet Kaur Bajgal',
    gender: 'Female',
    age: 26,
    height: '5\'4" (162 cm)',
    complexion: 'Fair (ਗੋਰਾ)',
    birthPlace: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    birthTime: '10:15 AM',
    district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    location: 'Civil Lines, Gurdaspur, Punjab',
    religion: 'Hindu',
    community: 'Mahasha (Bajgal)',
    fatherGotra: 'Bajgal (Bhogal)',
    motherGotra: 'Ghangla',
    qualification1: 'Computer Engineering Diploma',
    qualification2: 'BA.LLB',
    qualification3: 'LLM (Criminology)',
    education: 'LLM (Criminology) & BA.LLB',
    profession: 'Advocate / Lawyer',
    occupationDetails: 'Now practicing as an Advocate with her mother & preparation of PCS (J)',
    income: '10-20 Lakhs',
    fatherOccupation: '(Expire) Retired cashier from CPWD',
    motherOccupation: 'Advocate',
    brotherDetails: 'Advocate',
    sisterDetails: 'None',
    familyType: 'Nuclear Family',
    contactNumber: '+91 98765 43210',
    alternateContact: '+91 98123 45678',
    aboutMe: 'Practicing Advocate at District Courts with deep respect for family traditions and high academic aspirations for Judicial Services PCS(J). Looking for an educated, understanding partner from Mahasha community.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop'
  }
};

export default function ProfileDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addNotification } = useNotifications();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [interestSent, setInterestSent] = useState(false);
  const [isShortlisted, setIsShortlisted] = useState(false);
  const [showContact, setShowContact] = useState(false);

  useEffect(() => {
    async function loadProfile() {
      if (!id) return;
      try {
        setLoading(true);

        // Check if demo profile
        if (SHOWCASE_DETAILS[id]) {
          setProfile(SHOWCASE_DETAILS[id] as ProfileData);
          setLoading(false);
          return;
        }

        const docRef = doc(db, 'profiles', id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          const data = { id: docSnap.id, ...docSnap.data() } as ProfileData;
          setProfile(data);
          
          // Increment view count on load (only for real profiles)
          updateDoc(docRef, {
            viewCount: increment(1)
          }).catch(err => console.warn('Failed to increment view count:', err));
        } else {
          setProfile(null);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `profiles/${id}`);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, [id]);

  const formatLastSeen = (timestamp: any) => {
    if (!timestamp) return 'ਕਦੇ ਨਹੀਂ (Never)';
    try {
      const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
      const now = new Date();
      const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

      if (diffInSeconds < 60) return 'ਹੁਣੇ (just now)';
      if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} ਮਿੰਟ ਪਹਿਲਾਂ`;
      if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} ਘੰਟੇ ਪਹਿਲਾਂ`;
      if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} ਦਿਨ ਪਹਿਲਾਂ`;
      
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return 'ਹੁਣੇ (just now)';
    }
  };

  const formatLastSeenEn = (timestamp: any) => {
    if (!timestamp) return 'Never';
    try {
      const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return 'just now';
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 max-w-md w-full text-center">
          <UserCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2 font-serif">ਪ੍ਰੋਫਾਈਲ ਨਹੀਂ ਮਿਲੀ (Profile Not Found)</h2>
          <p className="text-gray-600 mb-6">ਇਹ ਪ੍ਰੋਫਾਈਲ ਸ਼ਾਇਦ ਹਟਾ ਦਿੱਤੀ ਗਈ ਹੈ ਜਾਂ ਮੌਜੂਦ ਨਹੀਂ ਹੈ।</p>
          <Link 
            to="/matches" 
            className="inline-flex items-center justify-center gap-2 bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30 px-6 py-2.5 rounded-xl font-bold transition-all shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" /> ਵਾਪਸ ਮੈਚਾਂ 'ਤੇ ਜਾਓ (Back to Matches)
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <SEO 
        title={`${profile.fullName} (${profile.fatherGotra ? `ਗੋਤਰ: ${profile.fatherGotra}` : 'ਮਹਾਸ਼ਾ'}) - ਬਾਇਓਡਾਟਾ | Mahasha Matrimonial`}
        description={`${profile.fullName}, ${profile.age || ''} ਸਾਲ, ${profile.profession || ''}, ${profile.district || profile.location || 'ਪੰਜਾਬ'}। ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ ਗੋਤਰ: ${profile.fatherGotra || 'ਮਹਾਸ਼ਾ'}। ਵਿਆਹ ਲਈ ਵੈਰੀਫਾਈਡ ਬਾਇਓਡਾਟਾ।`}
        keywords={[`${profile.fullName}`, `${profile.fatherGotra} gotra`, 'Mahasha matrimonial profile', `${profile.profession || ''}`, `${profile.district || ''} mahasha rishtey`]}
        ogType="profile"
        ogImage={profile.photoUrl || (profile.photoUrls && profile.photoUrls[0]) || undefined}
        structuredData={{
          "@context": "https://schema.org",
          "@type": "Person",
          "name": profile.fullName,
          "gender": profile.gender,
          "jobTitle": profile.profession,
          "address": {
            "@type": "PostalAddress",
            "addressLocality": profile.district || profile.location || "Punjab",
            "addressCountry": "IN"
          },
          "description": profile.aboutMe || `Matrimonial profile for ${profile.fullName}`
        }}
      />
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Navigation Bar */}
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex flex-wrap items-center gap-3">
            <button 
              onClick={() => navigate(-1)}
              className="inline-flex items-center gap-2 text-rose-900 hover:text-rose-700 font-bold transition-colors text-sm bg-white px-3 py-1.5 rounded-lg border border-gray-200 shadow-sm"
            >
              <ArrowLeft className="w-4 h-4" /> ਵਾਪਸ (Back)
            </button>
            <div className="flex items-center gap-2 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200 text-xs font-bold text-amber-800 shadow-sm">
              <Eye className="w-3.5 h-3.5" />
              {profile.viewCount || 1} ਵਾਰ ਦੇਖਿਆ ਗਿਆ (Views)
            </div>
            {profile.lastSeen && (
              <div className="flex items-center gap-2 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200 text-xs font-bold text-emerald-800 shadow-sm">
                <Clock className="w-3.5 h-3.5" />
                ਆਖਰੀ ਵਾਰ ਦੇਖਿਆ: {formatLastSeen(profile.lastSeen)} ({formatLastSeenEn(profile.lastSeen)})
              </div>
            )}
          </div>
          <div className="text-[10px] uppercase tracking-widest font-bold text-gray-400 bg-gray-100 px-3 py-1.5 rounded-lg border border-gray-200">
            ਪ੍ਰੋਫਾਈਲ ID: <span className="font-mono text-rose-900">{profile.id?.slice(0, 10)}</span>
          </div>
        </div>

        {/* Hero Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-8">
          <div className="h-36 bg-gradient-to-r from-rose-950 via-rose-900 to-rose-950 relative border-b border-amber-500/20">
            <div className="absolute top-4 right-4 flex gap-2">
              <button 
                onClick={() => setIsShortlisted(!isShortlisted)}
                className={`p-2 rounded-full backdrop-blur-md transition-all ${
                  isShortlisted ? 'bg-amber-500 text-rose-950' : 'bg-white/20 text-white hover:bg-white/30'
                }`}
                title={isShortlisted ? "ਸ਼ਾਰਟਲਿਸਟ ਵਿੱਚੋਂ ਹਟਾਓ" : "ਸ਼ਾਰਟਲਿਸਟ ਵਿੱਚ ਸ਼ਾਮਲ ਕਰੋ"}
              >
                <Star className={`w-5 h-5 ${isShortlisted ? 'fill-rose-950' : ''}`} />
              </button>
            </div>
          </div>

          <div className="px-6 pb-6 pt-0 relative">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 -mt-16 mb-6">
              
              <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5 text-center sm:text-left">
                {/* Avatar */}
                <div className="w-32 h-32 rounded-2xl overflow-hidden bg-white ring-4 ring-white shadow-lg relative flex-shrink-0">
                  {profile.photoUrl || (profile.photoUrls && profile.photoUrls.length > 0) ? (
                    <img src={profile.photoUrl || profile.photoUrls![0]} alt={profile.fullName} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-rose-50 flex items-center justify-center border border-amber-200">
                      <UserCircle className="w-24 h-24 text-rose-300" />
                    </div>
                  )}
                  {profile.isVerified && (
                    <div className="absolute bottom-1 right-1 bg-amber-500 text-rose-950 p-1 rounded-full shadow" title="ਪ੍ਰਮਾਣਿਤ ਪ੍ਰੋਫਾਈਲ">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  )}
                </div>

                <div>
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900 font-serif">{profile.fullName}</h1>
                    {profile.isVerified && (
                      <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-emerald-200">
                        <ShieldCheck className="w-3.5 h-3.5" /> ਪ੍ਰਮਾਣਿਤ (Verified)
                      </span>
                    )}
                  </div>
                  
                  <p className="text-gray-600 text-sm flex flex-wrap items-center justify-center sm:justify-start gap-2 font-medium">
                    <span>{profile.age ? `${profile.age} ਸਾਲ (${profile.gender})` : '26 ਸਾਲ'}</span>
                    <span>•</span>
                    <span>ਕੱਦ: {profile.height || '5\'4"'}</span>
                    <span>•</span>
                    <span>ਰੰਗ: {profile.complexion || 'Fair (ਗੋਰਾ)'}</span>
                    <span>•</span>
                    <span className="text-rose-900 font-bold">ਪਿਤਾ ਗੋਤਰ: {profile.fatherGotra || 'Bajgal (Bhogal)'}</span>
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3">
                <button 
                  onClick={() => {
                    const nextState = !interestSent;
                    setInterestSent(nextState);
                    if (nextState && profile) {
                      addNotification({
                        category: 'activity',
                        type: 'interest_received',
                        title: `Interest Sent to ${profile.fullName}`,
                        titlePa: `${profile.fullName} ਨੂੰ ਰਿਸ਼ਤਾ ਬੇਨਤੀ (Interest) ਭੇਜੀ ਗਈ`,
                        message: `Your matrimony interest and profile summary was successfully sent to ${profile.fullName} (${profile.fatherGotra || 'Mahasha'} Gotra).`,
                        messagePa: `ਤੁਹਾਡੀ ਰਿਸ਼ਤਾ ਬੇਨਤੀ ਸਫਲਤਾਪੂਰਵਕ ${profile.fullName} (${profile.fatherGotra || 'ਮਹਾਸ਼ਾ'} ਗੋਤਰ) ਨੂੰ ਭੇਜੀ ਗਈ ਹੈ।`,
                        avatarUrl: profile.photoUrl || (profile.photoUrls && profile.photoUrls[0]),
                        senderName: profile.fullName,
                        senderGotra: profile.fatherGotra,
                        targetProfileId: profile.id,
                        actionUrl: `/profile/${profile.id}`,
                        badge: 'Interest Sent',
                        badgePa: 'ਬੇਨਤੀ ਭੇਜੀ',
                        priority: 'high'
                      });
                    }
                  }}
                  className={`px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all shadow-sm text-sm ${
                    interestSent 
                      ? 'bg-rose-100 text-rose-900 border border-rose-300'
                      : 'bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${interestSent ? 'fill-rose-900' : 'text-amber-400'}`} />
                  {interestSent ? 'ਰਿਸ਼ਤਾ ਭੇਜਿਆ ਗਿਆ (Interest Sent)' : 'ਰਿਸ਼ਤਾ ਭੇਜੋ (Send Interest)'}
                </button>

                <button 
                  onClick={() => {
                    const nextState = !showContact;
                    setShowContact(nextState);
                    if (nextState && profile) {
                      addNotification({
                        category: 'activity',
                        type: 'contact_request',
                        title: `Contact Viewed: ${profile.fullName}`,
                        titlePa: `ਸੰਪਰਕ ਨੰਬਰ ਵੇਖਿਆ: ${profile.fullName}`,
                        message: `You viewed verified contact details for ${profile.fullName} (${profile.contactNumber || 'Contact'}).`,
                        messagePa: `ਤੁਸੀਂ ${profile.fullName} ਦਾ ਪ੍ਰਮਾਣਿਤ ਸੰਪਰਕ ਨੰਬਰ ਦੇਖਿਆ।`,
                        avatarUrl: profile.photoUrl || (profile.photoUrls && profile.photoUrls[0]),
                        senderName: profile.fullName,
                        senderGotra: profile.fatherGotra,
                        targetProfileId: profile.id,
                        actionUrl: `/profile/${profile.id}`,
                        badge: 'Contact Viewed',
                        badgePa: 'ਸੰਪਰਕ ਦੇਖਿਆ',
                        priority: 'normal'
                      });
                    }
                  }}
                  className="bg-amber-500 hover:bg-amber-400 text-rose-950 px-5 py-2.5 rounded-xl font-bold transition-all shadow-sm flex items-center gap-2 text-sm"
                >
                  <Phone className="w-4 h-4" />
                  {showContact ? 'ਨੰਬਰ ਛੁਪਾਓ' : 'ਸੰਪਰਕ ਨੰਬਰ ਵੇਖੋ (Contact No)'}
                </button>
              </div>

            </div>

            {/* Revealed Contact Card */}
            {showContact && (
              <div className="p-5 bg-gradient-to-r from-amber-50 to-amber-100/70 border-2 border-amber-300 rounded-2xl mb-6 shadow-sm transition-all">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-sm font-bold text-rose-950 flex items-center gap-1.5 mb-1">
                      <Phone className="w-4 h-4 text-amber-700" />
                      ਸਿੱਧਾ ਸੰਪਰਕ ਵੇਰਵਾ (Direct Contact Information)
                    </h3>
                    <div className="text-base font-bold text-gray-900">
                      ਮੋਬਾਈਲ: <span className="text-rose-900 font-mono">{profile.contactNumber || '+91 98765 43210'}</span>
                    </div>
                    {profile.alternateContact && (
                      <div className="text-xs text-gray-600 mt-0.5">
                        ਦੂਜਾ ਨੰਬਰ / ਵਟਸਐਪ: <span className="font-mono font-semibold">{profile.alternateContact}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <a 
                      href={`tel:${profile.contactNumber || '9876543210'}`}
                      className="bg-rose-900 hover:bg-rose-800 text-amber-300 px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Phone className="w-3.5 h-3.5" /> ਕਾਲ ਕਰੋ (Call Now)
                    </a>
                    <a 
                      href={`https://wa.me/${(profile.contactNumber || '9876543210').replace(/[^0-9]/g, '')}`}
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> ਵਟਸਐਪ (WhatsApp)
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-gray-100 text-sm">
              <div className="flex items-center gap-2 text-gray-700">
                <MapPin className="w-4 h-4 text-rose-900 flex-shrink-0" />
                <span className="truncate">{profile.district || profile.location || 'Gurdaspur'}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Briefcase className="w-4 h-4 text-rose-900 flex-shrink-0" />
                <span className="truncate">{profile.profession || 'Advocate'}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <GraduationCap className="w-4 h-4 text-rose-900 flex-shrink-0" />
                <span className="truncate">{profile.qualification1 || profile.education || 'Diploma / Degree'}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Sparkles className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span className="truncate">ਮਹਾਸ਼ਾ ਸਮਾਜ ਪ੍ਰੋਫਾਈਲ</span>
              </div>
            </div>

          </div>
        </div>

        {/* Detailed Sections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Main Column */}
          <div className="md:col-span-2 space-y-6">

            {/* Photos Gallery */}
            {profile.photoUrls && profile.photoUrls.length > 0 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                  <ImageIcon className="w-5 h-5 text-rose-900" />
                  <div>
                    <h2 className="text-lg font-bold text-gray-900 font-serif">ਪ੍ਰੋਫਾਈਲ ਫੋਟੋਆਂ (Profile Photos)</h2>
                  </div>
                </div>
                <div className="flex overflow-x-auto gap-4 pb-2 snap-x">
                  {profile.photoUrls.map((url, idx) => (
                    <div key={idx} className="flex-shrink-0 w-48 h-64 rounded-xl overflow-hidden shadow-sm border border-gray-100 snap-center cursor-pointer hover:shadow-md transition-shadow" onClick={() => window.open(url, '_blank')}>
                      <img src={url} alt={`${profile.fullName} photo ${idx + 1}`} className="w-full h-full object-cover" />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Video Section */}
            {profile.videoUrl && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
                <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                  <Video className="w-5 h-5 text-rose-900" />
                  <div>
                    <h2 className="text-lg font-bold text-gray-900 font-serif">ਵੀਡੀਓ (Video)</h2>
                  </div>
                </div>
                {profile.videoUrl.startsWith('data:video') || profile.videoUrl.match(/\.(mp4|webm|mov|ogg)$/i) ? (
                  <div className="w-full bg-black rounded-xl overflow-hidden shadow-inner flex justify-center">
                    <video 
                      src={profile.videoUrl} 
                      controls 
                      className="w-full max-h-96 object-contain"
                    />
                  </div>
                ) : (
                  <div className="w-full bg-gray-50 rounded-xl overflow-hidden border border-gray-200 p-6">
                    <a href={profile.videoUrl} target="_blank" rel="noopener noreferrer" className="flex flex-col items-center justify-center text-center hover:opacity-95 transition-opacity">
                      <div className="p-4 bg-rose-100 text-rose-900 rounded-full mb-3 shadow-xs">
                        <Video className="w-8 h-8" />
                      </div>
                      <span className="text-gray-900 font-bold text-base">ਵੀਡੀਓ ਦੇਖਣ ਲਈ ਇੱਥੇ ਕਲਿੱਕ ਕਰੋ (Click to view video)</span>
                      <span className="text-rose-700 text-sm mt-1 font-medium underline break-all max-w-md">{profile.videoUrl}</span>
                    </a>
                  </div>
                )}
              </div>
            )}
            
            {/* Career, Practice & Aspirations */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Briefcase className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਕਿੱਤਾ ਅਤੇ ਅਭਿਆਸ (Profession & Career Practice)</h2>
                  <p className="text-xs text-gray-500">ਮੌਜੂਦਾ ਕੰਮ ਅਤੇ ਭਵਿੱਖੀ ਤਿਆਰੀ</p>
                </div>
              </div>
              
              <div className="space-y-4 text-sm">
                <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-200">
                  <dt className="text-xs font-semibold text-rose-950 uppercase tracking-wider mb-1">
                    ਮੌਜੂਦਾ ਕੰਮ / ਪ੍ਰੈਕਟਿਸ ਦਾ ਵੇਰਵਾ (Current Practice & Goals)
                  </dt>
                  <dd className="font-bold text-gray-900 text-base leading-relaxed">
                    {profile.occupationDetails || "Now practicing as an Advocate with her mother & preparation of PCS (J)"}
                  </dd>
                </div>

                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <dt className="text-gray-500 text-xs">ਮੁੱਖ ਪੇਸ਼ਾ (Profession)</dt>
                    <dd className="font-semibold text-gray-900 mt-0.5">{profile.profession || 'Advocate / Lawyer'}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-500 text-xs">ਸਾਲਾਨਾ ਆਮਦਨ (Annual Income)</dt>
                    <dd className="font-semibold text-gray-900 mt-0.5">{profile.income || '10-20 Lakhs'}</dd>
                  </div>
                </dl>
              </div>
            </div>

            {/* Qualifications 1, 2, 3 */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <GraduationCap className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਵਿੱਦਿਅਕ ਯੋਗਤਾਵਾਂ (Qualifications 1, 2, 3)</h2>
                  <p className="text-xs text-gray-500">ਸਾਰੀਆਂ ਡਿਗਰੀਆਂ ਅਤੇ ਡਿਪਲੋਮੇ</p>
                </div>
              </div>
              
              <div className="space-y-3">
                {/* Qualification 1 */}
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-3">
                  <span className="w-7 h-7 rounded-lg bg-rose-900 text-amber-300 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <span className="text-xs font-semibold text-gray-500 block">Qualification-1 (ਮੁੱਖ / ਮੁੱਢਲੀ ਯੋਗਤਾ)</span>
                    <span className="font-bold text-gray-900 text-sm">{profile.qualification1 || 'Computer Engineering Diploma'}</span>
                  </div>
                </div>

                {/* Qualification 2 */}
                {(profile.qualification2 || profile.qualification2 === undefined) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-3">
                    <span className="w-7 h-7 rounded-lg bg-rose-900 text-amber-300 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                      2
                    </span>
                    <div>
                      <span className="text-xs font-semibold text-gray-500 block">Qualification-2 (ਗ੍ਰੈਜੂਏਸ਼ਨ / ਦੂਜੀ ਡਿਗਰੀ)</span>
                      <span className="font-bold text-gray-900 text-sm">{profile.qualification2 || 'BA.LLB'}</span>
                    </div>
                  </div>
                )}

                {/* Qualification 3 */}
                {(profile.qualification3 || profile.qualification3 === undefined) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-3">
                    <span className="w-7 h-7 rounded-lg bg-rose-900 text-amber-300 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                      3
                    </span>
                    <div>
                      <span className="text-xs font-semibold text-gray-500 block">Qualification-3 (ਉੱਚ ਯੋਗਤਾ / ਮਾਸਟਰਜ਼)</span>
                      <span className="font-bold text-gray-900 text-sm">{profile.qualification3 || 'LLM (Criminology)'}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Birth, Kundali & Physical Attributes */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Calendar className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਜਨਮ ਅਤੇ ਕੁੰਡਲੀ ਵੇਰਵਾ (Birth & Kundali Details)</h2>
                  <p className="text-xs text-gray-500">ਜਨਮ ਸਥਾਨ, ਸਮਾਂ, ਕੱਦ ਅਤੇ ਰੰਗ</p>
                </div>
              </div>
              
              <dl className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਜਨਮ ਸਥਾਨ (Birth Place)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.birthPlace || 'Gurdaspur'}</dd>
                </div>

                {profile.dateOfBirth ? (
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                    <dt className="text-gray-500 text-xs">ਜਨਮ ਮਿਤੀ (Date of Birth)</dt>
                    <dd className="font-bold text-gray-900 mt-1">
                      {profile.dateOfBirth.includes('-') && profile.dateOfBirth.split('-')[0].length === 4 
                        ? `${profile.dateOfBirth.split('-')[2]}-${profile.dateOfBirth.split('-')[1]}-${profile.dateOfBirth.split('-')[0]}`
                        : profile.dateOfBirth}
                    </dd>
                  </div>
                ) : (
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                    <dt className="text-gray-500 text-xs">ਜਨਮ ਮਿਤੀ (Date of Birth)</dt>
                    <dd className="font-medium text-gray-400 mt-1 italic">ਦਰਜ ਨਹੀਂ ਕੀਤਾ (Not Specified)</dd>
                  </div>
                )}

                {profile.birthTime ? (
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                    <dt className="text-gray-500 text-xs">ਜਨਮ ਸਮਾਂ (Birth Time)</dt>
                    <dd className="font-bold text-gray-900 mt-1">{profile.birthTime}</dd>
                  </div>
                ) : (
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                    <dt className="text-gray-500 text-xs">ਜਨਮ ਸਮਾਂ (Birth Time)</dt>
                    <dd className="font-medium text-gray-400 mt-1 italic">ਦਰਜ ਨਹੀਂ ਕੀਤਾ (Not Specified)</dd>
                  </div>
                )}

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਕੱਦ (Height / Hight)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.height || '5\'4" (162 cm)'}</dd>
                </div>

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਰੰਗ (Rang / Complexion)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.complexion || 'Fair (ਗੋਰਾ)'}</dd>
                </div>

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ (District)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.district || 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)'}</dd>
                </div>

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਵਿਆਹੁਤਾ ਸਥਿਤੀ (Marital Status)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.maritalStatus || 'Never Married'}</dd>
                </div>
              </dl>
            </div>

            {/* Family Background */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Users className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਪਰਿਵਾਰਕ ਪਿਛੋਕੜ (Family Background)</h2>
                  <p className="text-xs text-gray-500">ਮਾਤਾ-ਪਿਤਾ ਅਤੇ ਭੈਣ-ਭਰਾਵਾਂ ਦਾ ਵੇਰਵਾ</p>
                </div>
              </div>
              
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Father Name & Occupation)</dt>
                  <dd className="font-bold text-gray-900 mt-1">
                    {profile.fatherName && <span className="block text-rose-950 font-extrabold">{profile.fatherName}</span>}
                    <span>{profile.fatherOccupation || '(Expire) Retired cashier from CPWD'}</span>
                  </dd>
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਮਾਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Mother Name & Occupation)</dt>
                  <dd className="font-bold text-gray-900 mt-1">
                    {profile.motherName && <span className="block text-rose-950 font-extrabold">{profile.motherName}</span>}
                    <span>{profile.motherOccupation || 'Advocate'}</span>
                  </dd>
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਭਰਾ ਦਾ ਵੇਰਵਾ (Brother Details)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.brotherDetails || 'Advocate'}</dd>
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਪਰਿਵਾਰਕ ਢਾਂਚਾ (Family Type)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.familyType || 'Nuclear Family'}</dd>
                </div>
              </dl>
            </div>

            {/* About Me */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Heart className="w-5 h-5 text-rose-900" />
                <h2 className="text-lg font-bold text-gray-900 font-serif">ਮੇਰੇ ਬਾਰੇ (About Me & Preferences)</h2>
              </div>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line text-sm">
                {profile.aboutMe || "A warm, family-oriented individual with professional integrity and deep roots in our Mahasha community culture. Looking for an understanding, educated and respectful life partner."}
              </p>
            </div>

          </div>

          {/* Side Column */}
          <div className="space-y-6">
            
            {/* Compatibility Scoring Card */}
            <CompatibilityCard targetProfile={profile} />

            {/* Gotra & Community Heritage Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Sparkles className="w-5 h-5 text-amber-600" />
                <h2 className="text-lg font-bold text-gray-900 font-serif">ਮਹਾਸ਼ਾ ਗੋਤਰ ਵੇਰਵਾ (Gotra Heritage)</h2>
              </div>
              
              <div className="space-y-3.5 text-sm">
                <div className="p-3 bg-rose-50/60 rounded-xl border border-rose-200">
                  <span className="text-xs text-rose-900 font-bold block">ਪਿਤਾ ਦਾ ਗੋਤਰ / ਕਾਸਟ (Father Caste):</span>
                  <span className="font-extrabold text-base text-rose-950 block mt-0.5">
                    {profile.fatherGotra || 'Bajgal (Bhogal)'}
                  </span>
                </div>

                <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200">
                  <span className="text-xs text-amber-900 font-bold block">ਮਾਤਾ ਦਾ ਗੋਤਰ / ਨਾਨਕੇ ਕਾਸਟ (Mother Caste):</span>
                  <span className="font-extrabold text-base text-amber-950 block mt-0.5">
                    {profile.motherGotra || 'Ghangla'}
                  </span>
                </div>

                <div className="pt-2 border-t border-gray-100 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-500">ਸਮਾਜ (Community)</span>
                    <span className="font-semibold text-gray-900">ਮਹਾਸ਼ਾ ਬਿਰਾਦਰੀ</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">ਧਰਮ (Religion)</span>
                    <span className="font-semibold text-gray-900">{profile.religion || 'Hindu'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ</span>
                    <span className="font-semibold text-gray-900">{profile.district || 'Gurdaspur'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Contact & Verification Card */}
            <div className="bg-gradient-to-br from-rose-950 via-rose-900 to-rose-950 rounded-2xl shadow-sm p-6 text-white border border-amber-500/20">
              <div className="flex items-center gap-2 mb-3">
                <ShieldCheck className="w-6 h-6 text-amber-400" />
                <h3 className="font-bold text-lg text-white">ਪ੍ਰਮਾਣਿਤ ਬਾਇਓਡਾਟਾ</h3>
              </div>
              <p className="text-rose-200/90 text-xs leading-relaxed mb-4">
                ਇਸ ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ ਜਨਮ ਸਥਾਨ, ਜਨਮ ਸਮਾਂ, ਮਾਤਾ-ਪਿਤਾ ਦੇ ਗੋਤਰ ਅਤੇ ਸੰਪਰਕ ਨੰਬਰ ਦੀ ਪੁਸ਼ਟੀ ਕੀਤੀ ਗਈ ਹੈ।
              </p>
              <button 
                onClick={() => setShowContact(true)}
                className="w-full bg-amber-500 hover:bg-amber-400 text-rose-950 py-2.5 rounded-xl font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" /> ਸੰਪਰਕ ਨੰਬਰ ਵੇਖੋ (View Phone)
              </button>
            </div>

            {/* Address / Location Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 text-sm">
              <div className="flex items-center gap-2 mb-3 text-gray-900 font-bold border-b border-gray-100 pb-2">
                <MapPin className="w-4 h-4 text-rose-900" /> ਰਿਹਾਇਸ਼ੀ ਪਤਾ (Location)
              </div>
              <p className="text-gray-700 font-medium">
                {profile.location || 'Gurdaspur, Punjab, India'}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                ਜ਼ਿਲ੍ਹਾ: <strong className="text-gray-800">{profile.district || 'Gurdaspur'}</strong>
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
