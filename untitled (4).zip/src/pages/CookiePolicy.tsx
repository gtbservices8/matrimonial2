import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useCMSConfig } from '../hooks/useCMSConfig';
import SEO from '../components/common/SEO';
import { Cookie, CheckCircle } from 'lucide-react';

export default function CookiePolicy() {
  const { language } = useLanguage();
  const { config } = useCMSConfig();

  const siteNameEn = config?.siteNameEn || 'Mahasha Matrimonial';
  const siteNamePa = config?.siteNamePa || 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ';

  const content = {
    en: {
      title: 'Cookie Policy',
      lastUpdated: 'Last Updated: September 2026',
      sections: [
        {
          heading: '1. What Are Cookies?',
          text: 'Cookies are small text files that are stored on your computer or mobile device when you visit a website. They are widely used to make websites work more efficiently and provide a better user experience.'
        },
        {
          heading: '2. How We Use Cookies',
          text: `At ${siteNameEn}, we use cookies to understand how you interact with our platform, remember your preferences (like language selection), keep you logged in securely, and improve the overall matrimonial matchmaking experience.`
        },
        {
          heading: '3. Types of Cookies We Use',
          text: 'We use the following types of cookies: \n• Essential Cookies: Required for the operation of the website, such as user authentication and security.\n• Preference Cookies: Used to remember your settings, like your preferred language (English, Punjabi, or Hindi).\n• Analytics Cookies: Help us understand how visitors use our site, allowing us to improve its design and functionality.'
        },
        {
          heading: '4. Third-Party Cookies',
          text: 'In some special cases, we also use cookies provided by trusted third parties, such as Google Analytics, to help us understand site usage and improve your experience. These third parties may track things like how long you spend on the site and the pages you visit.'
        },
        {
          heading: '5. Managing Your Cookies',
          text: 'You have the right to decide whether to accept or reject cookies. You can set or amend your web browser controls to accept or refuse cookies. However, if you choose to reject cookies, you may still use our website, but your access to some functionality and secure areas may be restricted.'
        }
      ]
    },
    pa: {
      title: 'ਕੁਕੀਜ਼ ਨੀਤੀ (Cookie Policy)',
      lastUpdated: 'ਆਖਰੀ ਅੱਪਡੇਟ: ਸਤੰਬਰ 2026',
      sections: [
        {
          heading: '1. ਕੁਕੀਜ਼ ਕੀ ਹਨ?',
          text: 'ਕੁਕੀਜ਼ ਛੋਟੀਆਂ ਟੈਕਸਟ ਫਾਈਲਾਂ ਹੁੰਦੀਆਂ ਹਨ ਜੋ ਤੁਹਾਡੇ ਕੰਪਿਊਟਰ ਜਾਂ ਮੋਬਾਈਲ ਡਿਵਾਈਸ ਵਿੱਚ ਸਟੋਰ ਹੁੰਦੀਆਂ ਹਨ ਜਦੋਂ ਤੁਸੀਂ ਕਿਸੇ ਵੈੱਬਸਾਈਟ ਤੇ ਜਾਂਦੇ ਹੋ। ਇਹ ਵੈੱਬਸਾਈਟਾਂ ਨੂੰ ਬਿਹਤਰ ਅਤੇ ਤੇਜ਼ੀ ਨਾਲ ਕੰਮ ਕਰਨ ਵਿੱਚ ਮਦਦ ਕਰਦੀਆਂ ਹਨ।'
        },
        {
          heading: '2. ਅਸੀਂ ਕੁਕੀਜ਼ ਦੀ ਵਰਤੋਂ ਕਿਵੇਂ ਕਰਦੇ ਹਾਂ',
          text: `ਅਸੀਂ ${siteNamePa} ਤੇ ਕੁਕੀਜ਼ ਦੀ ਵਰਤੋਂ ਤੁਹਾਡੀਆਂ ਪਸੰਦਾਂ (ਜਿਵੇਂ ਭਾਸ਼ਾ) ਨੂੰ ਯਾਦ ਰੱਖਣ, ਤੁਹਾਨੂੰ ਸੁਰੱਖਿਅਤ ਢੰਗ ਨਾਲ ਲੌਗਇਨ ਰੱਖਣ, ਅਤੇ ਪਲੇਟਫਾਰਮ ਨੂੰ ਹੋਰ ਬਿਹਤਰ ਬਣਾਉਣ ਲਈ ਕਰਦੇ ਹਾਂ।`
        },
        {
          heading: '3. ਅਸੀਂ ਕਿਹੜੀਆਂ ਕੁਕੀਜ਼ ਵਰਤਦੇ ਹਾਂ',
          text: 'ਅਸੀਂ ਹੇਠ ਲਿਖੀਆਂ ਕਿਸਮਾਂ ਦੀਆਂ ਕੁਕੀਜ਼ ਵਰਤਦੇ ਹਾਂ: \n• ਜ਼ਰੂਰੀ ਕੁਕੀਜ਼ (Essential): ਵੈੱਬਸਾਈਟ ਦੇ ਸਹੀ ਢੰਗ ਨਾਲ ਕੰਮ ਕਰਨ ਲਈ (ਜਿਵੇਂ ਲੌਗਇਨ ਅਤੇ ਸੁਰੱਖਿਆ)।\n• ਪਸੰਦ ਦੀਆਂ ਕੁਕੀਜ਼ (Preference): ਤੁਹਾਡੀ ਚੁਣੀ ਹੋਈ ਭਾਸ਼ਾ (ਪੰਜਾਬੀ, ਹਿੰਦੀ ਜਾਂ ਅੰਗਰੇਜ਼ੀ) ਨੂੰ ਯਾਦ ਰੱਖਣ ਲਈ।\n• ਵਿਸ਼ਲੇਸ਼ਣ ਕੁਕੀਜ਼ (Analytics): ਇਹ ਸਮਝਣ ਲਈ ਕਿ ਯੂਜ਼ਰ ਸਾਡੀ ਸਾਈਟ ਦੀ ਵਰਤੋਂ ਕਿਵੇਂ ਕਰਦੇ ਹਨ।'
        },
        {
          heading: '4. ਥਰਡ-ਪਾਰਟੀ ਕੁਕੀਜ਼',
          text: 'ਕੁਝ ਖਾਸ ਮਾਮਲਿਆਂ ਵਿੱਚ, ਅਸੀਂ ਗੂਗਲ ਐਨਾਲਿਟਿਕਸ ਵਰਗੀਆਂ ਭਰੋਸੇਮੰਦ ਥਰਡ-ਪਾਰਟੀ ਕੰਪਨੀਆਂ ਦੀਆਂ ਕੁਕੀਜ਼ ਦੀ ਵਰਤੋਂ ਵੀ ਕਰਦੇ ਹਾਂ ਤਾਂ ਜੋ ਅਸੀਂ ਸਾਈਟ ਦੀ ਕਾਰਗੁਜ਼ਾਰੀ ਨੂੰ ਬਿਹਤਰ ਬਣਾ ਸਕੀਏ।'
        },
        {
          heading: '5. ਕੁਕੀਜ਼ ਦਾ ਪ੍ਰਬੰਧਨ',
          text: 'ਤੁਹਾਡੇ ਕੋਲ ਕੁਕੀਜ਼ ਨੂੰ ਸਵੀਕਾਰ ਜਾਂ ਅਸਵੀਕਾਰ ਕਰਨ ਦਾ ਅਧਿਕਾਰ ਹੈ। ਤੁਸੀਂ ਆਪਣੇ ਵੈੱਬ ਬ੍ਰਾਊਜ਼ਰ ਦੀਆਂ ਸੈਟਿੰਗਾਂ ਰਾਹੀਂ ਕੁਕੀਜ਼ ਨੂੰ ਬੰਦ ਕਰ ਸਕਦੇ ਹੋ, ਪਰ ਇਸ ਨਾਲ ਸਾਈਟ ਦੇ ਕੁਝ ਜ਼ਰੂਰੀ ਫੀਚਰ ਕੰਮ ਕਰਨਾ ਬੰਦ ਕਰ ਸਕਦੇ ਹਨ।'
        }
      ]
    },
    hi: {
      title: 'कुकीज़ नीति (Cookie Policy)',
      lastUpdated: 'अंतिम अपडेट: सितंबर 2026',
      sections: [
        {
          heading: '1. कुकीज़ क्या हैं?',
          text: 'कुकीज़ छोटी टेक्स्ट फ़ाइलें होती हैं जो किसी वेबसाइट पर जाने पर आपके कंप्यूटर या मोबाइल डिवाइस पर संग्रहीत होती हैं। इनका उपयोग वेबसाइटों को बेहतर और तेज़ी से काम करने में मदद करने के लिए किया जाता है।'
        },
        {
          heading: '2. हम कुकीज़ का उपयोग कैसे करते हैं',
          text: `हम ${siteNameEn} पर कुकीज़ का उपयोग आपकी प्राथमिकताओं (जैसे भाषा) को याद रखने, आपको सुरक्षित रूप से लॉग इन रखने और प्लेटफॉर्म को बेहतर बनाने के लिए करते हैं।`
        },
        {
          heading: '3. हम किन कुकीज़ का उपयोग करते हैं',
          text: 'हम निम्नलिखित प्रकार की कुकीज़ का उपयोग करते हैं: \n• आवश्यक कुकीज़ (Essential): वेबसाइट के सुचारू संचालन के लिए (जैसे लॉगिन और सुरक्षा)।\n• प्राथमिकता कुकीज़ (Preference): आपकी चुनी हुई भाषा (हिंदी, पंजाबी या अंग्रेजी) को याद रखने के लिए।\n• एनालिटिक्स कुकीज़ (Analytics): यह समझने के लिए कि उपयोगकर्ता हमारी साइट का उपयोग कैसे करते हैं।'
        },
        {
          heading: '4. थर्ड-पार्टी कुकीज़',
          text: 'कुछ विशेष मामलों में, हम Google Analytics जैसी विश्वसनीय थर्ड-पार्टी कंपनियों की कुकीज़ का भी उपयोग करते हैं ताकि हम साइट के प्रदर्शन को बेहतर बना सकें।'
        },
        {
          heading: '5. कुकीज़ का प्रबंधन',
          text: 'आपको कुकीज़ स्वीकार या अस्वीकार करने का अधिकार है। आप अपने वेब ब्राउज़र की सेटिंग्स के माध्यम से कुकीज़ बंद कर सकते हैं, लेकिन इससे साइट की कुछ आवश्यक सुविधाएँ काम करना बंद कर सकती हैं।'
        }
      ]
    }
  };

  const currentContent = content[language as keyof typeof content] || content.en;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <SEO 
        title={`${currentContent.title} - ${config?.siteNameEn || 'Mahasha Matrimonial'}`}
        description="Cookie policy and tracking information."
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-amber-100 rounded-full mb-4">
            <Cookie className="w-8 h-8 text-amber-600" />
          </div>
          <h1 className="text-4xl font-extrabold text-gray-900 font-serif mb-4">
            {currentContent.title}
          </h1>
          <p className="text-gray-500 font-medium">
            {currentContent.lastUpdated}
          </p>
        </div>

        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-amber-100/50 space-y-10">
          {currentContent.sections.map((section, index) => (
            <div key={index} className="space-y-4">
              <h2 className="text-xl font-bold text-rose-950 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-amber-500 shrink-0" />
                {section.heading}
              </h2>
              <div className="text-gray-600 leading-relaxed pl-7 whitespace-pre-line">
                {section.text}
              </div>
            </div>
          ))}

          <div className="mt-12 pt-8 border-t border-gray-100 pl-7">
            <p className="text-sm text-gray-500">
              {language === 'pa' 
                ? 'ਜੇਕਰ ਤੁਹਾਡੇ ਇਸ ਕੁਕੀਜ਼ ਨੀਤੀ ਬਾਰੇ ਕੋਈ ਸਵਾਲ ਹਨ, ਤਾਂ ਕਿਰਪਾ ਕਰਕੇ ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ ਪੰਨੇ ਰਾਹੀਂ ਸੰਪਰਕ ਕਰੋ।' 
                : language === 'hi'
                ? 'यदि इस कुकीज़ नीति के बारे में आपके कोई प्रश्न हैं, तो कृपया हमसे संपर्क करें पृष्ठ के माध्यम से संपर्क करें।'
                : 'If you have any questions about this Cookie Policy, please contact us via the Contact Us page.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
