import { useState, useEffect } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { useAuth } from '../contexts/AuthContext';
import { useSettings } from '../contexts/SettingsContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { 
  User, Briefcase, Users, Heart, Save, AlertCircle, 
  MapPin, GraduationCap, Phone, Clock, Sparkles, CheckCircle2, Image as ImageIcon, X, Upload,
  Camera, Video, FileVideo, ChevronRight, ChevronLeft, Bot, Wand2, FileText
} from 'lucide-react';
import { 
  MAHASHA_GOTRAS, PUNJAB_DISTRICTS, COMPLEXIONS, 
  HEIGHT_OPTIONS, STANDARD_PROFESSIONS 
} from '../types';
import AIProfileAssistant from '../components/common/AIProfileAssistant';
import SuccessAnimation from '../components/common/SuccessAnimation';
import SEO from '../components/common/SEO';
import { logActivity } from '../lib/activityLogger';

const STEPS_LIST = [
  { id: 1, name: 'ਫੋਟੋਆਂ & ਵੀਡੀਓ', icon: ImageIcon },
  { id: 2, name: 'ਨਿੱਜੀ ਵੇਰਵਾ', icon: User },
  { id: 3, name: 'ਰਿਹਾਇਸ਼ & ਗੋਤਰ', icon: MapPin },
  { id: 4, name: 'ਯੋਗਤਾ & ਕਿੱਤਾ', icon: GraduationCap },
  { id: 5, name: 'ਪਰਿਵਾਰ & ਸੰਪਰਕ', icon: Users },
];

export default function EditProfile() {
  const { user } = useAuth();
  const { districts, states, gotras, complexions, professions, tehsils, religions, birthPlaces, getFieldLabel, isFieldVisible, isFieldRequired } = useSettings();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [draftToast, setDraftToast] = useState(false);
  const [showAiAssistant, setShowAiAssistant] = useState(false);
  const [isNewProfile, setIsNewProfile] = useState(true);
  const [currentStep, setCurrentStep] = useState(1);

  // Form State with user's requested matrimonial fields
  const [formData, setFormData] = useState({
    fullName: '',
    gender: 'Female',
    age: '',
    fatherName: '',
    motherName: '',
    dateOfBirth: '',
    birthPlace: '',
    birthTime: '',
    complexion: 'Fair',
    height: '5\'4" (162 cm)',
    state: 'Punjab (ਪੰਜਾਬ)',
    district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    tehsil: '',
    location: '',
    fatherGotra: 'Bajgal (Bhogal)',
    motherGotra: 'Ghangla',
    religion: 'Hindu',
    community: 'Mahasha (Bajgal)',
    qualification1: '',
    qualification2: '',
    qualification3: '',
    education: '',
    profession: '',
    occupationDetails: '',
    income: '',
    fatherOccupation: '',
    motherOccupation: '',
    brotherDetails: '',
    sisterDetails: '',
    familyType: 'Nuclear',
    maritalStatus: 'Never Married',
    contactNumber: '',
    alternateContact: '',
    aboutMe: '',
    photoUrls: [] as string[],
    videoUrl: '',
  });

  // State for Profession dropdown and custom text box
  const [professionSelect, setProfessionSelect] = useState('');
  const [customProfession, setCustomProfession] = useState('');

  // State for custom Father / Mother Gotra if 'Other'
  const [fatherGotraSelect, setFatherGotraSelect] = useState('Bajgal (Bhogal)');
  const [customFatherGotra, setCustomFatherGotra] = useState('');
  const [motherGotraSelect, setMotherGotraSelect] = useState('Ghangla');
  const [customMotherGotra, setCustomMotherGotra] = useState('');

  useEffect(() => {
    async function fetchProfile() {
      if (!user) return;
      try {
        const docRef = doc(db, 'profiles', user.uid);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          setIsNewProfile(false);
          const data = docSnap.data();
          
          // Format dateOfBirth to DD-MM-YYYY if it's in YYYY-MM-DD format
          let formattedDob = data.dateOfBirth || '';
          if (formattedDob && formattedDob.includes('-') && formattedDob.split('-')[0].length === 4) {
            const parts = formattedDob.split('-');
            if (parts.length === 3) {
              formattedDob = `${parts[2]}-${parts[1]}-${parts[0]}`;
            }
          }

          setFormData(prev => ({
            ...prev,
            ...data,
            dateOfBirth: formattedDob,
            photoUrls: data.photoUrls || (data.photoUrl ? [data.photoUrl] : []),
            videoUrl: data.videoUrl || ''
          }));

          // Handle Profession Select & Custom input
          if (data.profession) {
            if (STANDARD_PROFESSIONS.includes(data.profession)) {
              setProfessionSelect(data.profession);
              setCustomProfession('');
            } else {
              setProfessionSelect('Other');
              setCustomProfession(data.profession);
            }
          }

          // Handle Father Gotra
          if (data.fatherGotra) {
            const match = MAHASHA_GOTRAS.find(g => g.value === data.fatherGotra);
            if (match) {
              setFatherGotraSelect(data.fatherGotra);
            } else {
              setFatherGotraSelect('Other');
              setCustomFatherGotra(data.fatherGotra);
            }
          }

          // Handle Mother Gotra
          if (data.motherGotra) {
            const match = MAHASHA_GOTRAS.find(g => g.value === data.motherGotra);
            if (match) {
              setMotherGotraSelect(data.motherGotra);
            } else {
              setMotherGotraSelect('Other');
              setCustomMotherGotra(data.motherGotra);
            }
          }
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `profiles/${user.uid}`);
      } finally {
        setLoading(false);
      }
    }

    fetchProfile();
  }, [user]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name } = e.target;
    let { value } = e.target;

    // Apply DD-MM-YYYY mask for dateOfBirth
    if (name === 'dateOfBirth') {
      const v = value.replace(/\D/g, '');
      if (v.length > 4) {
        value = `${v.substring(0, 2)}-${v.substring(2, 4)}-${v.substring(4, 8)}`;
      } else if (v.length > 2) {
        value = `${v.substring(0, 2)}-${v.substring(2, 4)}`;
      } else {
        value = v;
      }
    }

    setFormData(prev => {
      const newData = { ...prev, [name]: value };
      
      // Auto-calculate age if date of birth changes
      if (name === 'dateOfBirth' && value.length === 10) {
        const parts = value.split('-');
        if (parts.length === 3) {
          const birthDate = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
          if (!isNaN(birthDate.getTime())) {
            const today = new Date();
            let calculatedAge = today.getFullYear() - birthDate.getFullYear();
            const m = today.getMonth() - birthDate.getMonth();
            if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
              calculatedAge--;
            }
            if (calculatedAge >= 18) {
              newData.age = calculatedAge.toString();
            }
          }
        }
      }
      return newData;
    });
  };

  const handleProfessionSelectChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setProfessionSelect(value);
    if (value === 'Other') {
      setFormData(prev => ({ ...prev, profession: customProfession }));
    } else {
      setFormData(prev => ({ ...prev, profession: value }));
    }
  };

  const handleCustomProfessionChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setCustomProfession(value);
    setFormData(prev => ({ ...prev, profession: value }));
  };

  const handleFatherGotraChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setFatherGotraSelect(val);
    if (val === 'Other') {
      setFormData(prev => ({ ...prev, fatherGotra: customFatherGotra || 'Other' }));
    } else {
      setFormData(prev => ({ ...prev, fatherGotra: val }));
    }
  };

  const handleMotherGotraChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setMotherGotraSelect(val);
    if (val === 'Other') {
      setFormData(prev => ({ ...prev, motherGotra: customMotherGotra || 'Other' }));
    } else {
      setFormData(prev => ({ ...prev, motherGotra: val }));
    }
  };

  const handlePhotoUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files || files.length === 0) return;
    
    if (formData.photoUrls.length + files.length > 5) {
      setError('ਵੱਧ ਤੋਂ ਵੱਧ 5 ਫੋਟੋਆਂ ਅਪਲੋਡ ਕੀਤੀਆਂ ਜਾ ਸਕਦੀਆਂ ਹਨ। (Maximum 5 photos allowed)');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    Array.from(files as FileList).forEach((file: File) => {
      const reader = new FileReader();
      reader.onload = (event) => {
        const img = new Image();
        img.onload = () => {
          const canvas = document.createElement('canvas');
          let width = img.width;
          let height = img.height;
          
          const MAX_SIZE = 500;
          if (width > height && width > MAX_SIZE) {
            height *= MAX_SIZE / width;
            width = MAX_SIZE;
          } else if (height > MAX_SIZE) {
            width *= MAX_SIZE / height;
            height = MAX_SIZE;
          }
          
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          ctx?.drawImage(img, 0, 0, width, height);
          
          const dataUrl = canvas.toDataURL('image/jpeg', 0.5);
          
          setFormData(prev => ({
            ...prev,
            photoUrls: [...prev.photoUrls, dataUrl]
          }));
        };
        img.src = event.target?.result as string;
      };
      reader.readAsDataURL(file);
    });
  };

  const removePhoto = (indexToRemove: number) => {
    setFormData(prev => ({
      ...prev,
      photoUrls: prev.photoUrls.filter((_, index) => index !== indexToRemove)
    }));
  };

  const handleVideoFileUpload = (e: ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 2 * 1024 * 1024) {
      setError('ਫਾਇਰਸਟੋਰ ਡਾਟਾਬੇਸ ਦੀ 1MB ਲਿਮਿਟ ਕਾਰਨ ਵੀਡੀਓ 2MB ਤੋਂ ਛੋਟੀ ਹੋਣੀ ਚਾਹੀਦੀ ਹੈ। ਵੀਡੀਓ ਲਿੰਕ (YouTube / Instagram Reel) ਪਾਉਣਾ ਸਭ ਤੋਂ ਵਧੀਆ ਹੈ।');
      window.scrollTo({ top: 0, behavior: 'smooth' });
      return;
    }

    setSaving(true);
    setError('');
    const reader = new FileReader();
    reader.onload = (event) => {
      const result = event.target?.result as string;
      if (result) {
        if (result.length > 500000) {
          setError('ਵੀਡੀਓ ਫਾਈਲ ਦਾ ਸਾਈਜ਼ ਬਹੁਤ ਵੱਡਾ ਹੈ। ਡਾਟਾਬੇਸ ਵਿੱਚ ਲਿਮਿਟ ਹੁੰਦੀ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ YouTube / Instagram Reel ਦਾ ਵੀਡੀਓ ਲਿੰਕ ਪਾਓ।');
          setSaving(false);
          return;
        }
        setFormData(prev => ({
          ...prev,
          videoUrl: result
        }));
      }
      setSaving(false);
    };
    reader.onerror = () => {
      setError('ਵੀਡੀਓ ਫਾਈਲ ਪੜ੍ਹਨ ਵਿੱਚ ਗਲਤੀ ਆਈ। (Failed to read video file)');
      setSaving(false);
    };
    reader.readAsDataURL(file);
  };

  const removeVideo = () => {
    setFormData(prev => ({ ...prev, videoUrl: '' }));
  };

  const validateStep = (step: number): boolean => {
    setError('');
    if (step === 1) {
      if (!formData.photoUrls || formData.photoUrls.length < 2) {
        setError('ਕਿਰਪਾ ਕਰਕੇ ਘੱਟੋ ਘੱਟ 2 ਫੋਟੋਆਂ ਅਪਲੋਡ ਕਰੋ। (Please upload at least 2 photos)');
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return false;
      }
    } else if (step === 2) {
      const required = [
        { key: 'fullName', label: 'ਪੂਰਾ ਨਾਮ (Full Name)' },
        { key: 'fatherName', label: 'ਪਿਤਾ ਦਾ ਨਾਮ (Father Name)' },
        { key: 'motherName', label: 'ਮਾਤਾ ਦਾ ਨਾਮ (Mother Name)' },
        { key: 'age', label: 'ਉਮਰ (Age)' },
        { key: 'birthPlace', label: 'ਜਨਮ ਸਥਾਨ (Birth Place)' },
        { key: 'complexion', label: 'ਰੰਗ (Rang / Complexion)' },
        { key: 'height', label: 'ਕੱਦ (Height)' },
      ];
      for (const item of required) {
        const val = (formData as any)[item.key];
        if (!val || val.toString().trim() === '') {
          setError(`ਕਿਰਪਾ ਕਰਕੇ ਜਰੂਰੀ ਫੀਲਡ "${item.label}" ਦਰਜ ਕਰੋ।`);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return false;
        }
      }
    } else if (step === 3) {
      const required = [
        { key: 'district', label: 'ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ (Residence District)' },
        { key: 'location', label: 'ਪਤਾ / ਸ਼ਹਿਰ (Location)' },
        { key: 'fatherGotra', label: 'ਪਿਤਾ ਦਾ ਗੋਤਰ (Father Gotra)' },
        { key: 'motherGotra', label: 'ਮਾਤਾ ਦਾ ਗੋਤਰ (Mother Gotra)' },
      ];
      for (const item of required) {
        const val = (formData as any)[item.key];
        if (!val || val.toString().trim() === '') {
          setError(`ਕਿਰਪਾ ਕਰਕੇ ਜਰੂਰੀ ਫੀਲਡ "${item.label}" ਦਰਜ ਕਰੋ।`);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return false;
        }
      }
    } else if (step === 4) {
      const required = [
        { key: 'qualification1', label: 'ਯੋਗਤਾ-1 (Qualification 1)' },
        { key: 'profession', label: 'ਪੇਸ਼ਾ (Profession)' },
        { key: 'occupationDetails', label: 'ਕੰਮ ਦਾ ਵੇਰਵਾ (Occupation Details)' },
      ];
      for (const item of required) {
        const val = (formData as any)[item.key];
        if (!val || val.toString().trim() === '') {
          setError(`ਕਿਰਪਾ ਕਰਕੇ ਜਰੂਰੀ ਫੀਲਡ "${item.label}" ਦਰਜ ਕਰੋ।`);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return false;
        }
      }
    } else if (step === 5) {
      const required = [
        { key: 'fatherOccupation', label: 'ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Father Details)' },
        { key: 'motherOccupation', label: 'ਮਾਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Mother Details)' },
        { key: 'contactNumber', label: 'ਸੰਪਰਕ ਨੰਬਰ (Contact No)' },
      ];
      for (const item of required) {
        const val = (formData as any)[item.key];
        if (!val || val.toString().trim() === '') {
          setError(`ਕਿਰਪਾ ਕਰਕੇ ਜਰੂਰੀ ਫੀਲਡ "${item.label}" ਦਰਜ ਕਰੋ।`);
          window.scrollTo({ top: 0, behavior: 'smooth' });
          return false;
        }
      }
    }
    return true;
  };

  const nextStep = () => {
    if (validateStep(currentStep)) {
      setCurrentStep(prev => Math.min(prev + 1, 5));
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const prevStep = () => {
    setError('');
    setCurrentStep(prev => Math.max(prev - 1, 1));
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Calculate profile completion percentage based on required & important fields
  const calculateCompletion = (data: typeof formData) => {
    const essentialFields = [
      'fullName', 'gender', 'age', 'birthPlace', 
      'complexion', 'height', 'district', 'location', 
      'fatherGotra', 'motherGotra', 'qualification1', 
      'profession', 'occupationDetails', 'fatherOccupation', 
      'motherOccupation', 'contactNumber'
    ];
    const filled = essentialFields.filter(field => {
      const val = (data as any)[field];
      return val && val.toString().trim() !== '';
    });
    return Math.round((filled.length / essentialFields.length) * 100);
  };

  const handleApplyAiFields = (fields: Partial<typeof formData>) => {
    setFormData(prev => ({
      ...prev,
      ...fields
    }));
    if (fields.profession) {
      if (STANDARD_PROFESSIONS.includes(fields.profession)) {
        setProfessionSelect(fields.profession);
        setCustomProfession('');
      } else {
        setProfessionSelect('Other');
        setCustomProfession(fields.profession);
      }
    }
    setSuccess('AI ਵੇਰਵੇ ਫਾਰਮ ਵਿੱਚ ਭਰ ਦਿੱਤੇ ਗਏ ਹਨ! (AI details applied)');
    setTimeout(() => setSuccess(''), 3000);
  };

  const handleSaveDraft = async (e?: FormEvent) => {
    if (e) e.preventDefault();
    if (!user) return;

    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const docRef = doc(db, 'profiles', user.uid);
      const completion = calculateCompletion(formData);
      const highestEdu = formData.qualification3 || formData.qualification2 || formData.qualification1;

      const dataToSave: any = {
        ...formData,
        age: formData.age ? parseInt(formData.age.toString(), 10) : null,
        community: `Mahasha (${formData.fatherGotra})`,
        education: highestEdu,
        profileCompletion: completion,
        isDraft: true,
        updatedAt: serverTimestamp()
      };

      delete dataToSave.createdAt;
      delete dataToSave.isVerified;
      delete dataToSave.userId;

      if (isNewProfile) {
        dataToSave.userId = user.uid;
        dataToSave.createdAt = serverTimestamp();
        dataToSave.isVerified = false;
        setIsNewProfile(false);
      }

      await setDoc(docRef, dataToSave, { merge: true });

      await logActivity({
        type: 'profile_update',
        action: 'Draft Saved',
        details: `${formData.fullName} updated their profile draft (${completion}% complete).`,
        performedBy: user.uid,
        performedByName: formData.fullName,
        targetId: user.uid
      });

      setDraftToast(true);
      setTimeout(() => setDraftToast(false), 4000);
    } catch (err: any) {
      setError('ਡਰਾਫਟ ਸੇਵ ਕਰਨ ਵਿੱਚ ਗਲਤੀ: ' + err.message);
      handleFirestoreError(err, OperationType.UPDATE, `profiles/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    // Validate final step & overall requirements
    if (!validateStep(1) || !validateStep(2) || !validateStep(3) || !validateStep(4) || !validateStep(5)) {
      return;
    }

    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const docRef = doc(db, 'profiles', user.uid);
      const completion = calculateCompletion(formData);
      
      const highestEdu = formData.qualification3 || formData.qualification2 || formData.qualification1;

      const dataToSave: any = {
        ...formData,
        age: formData.age ? parseInt(formData.age.toString(), 10) : null,
        community: `Mahasha (${formData.fatherGotra})`,
        education: highestEdu,
        profileCompletion: completion,
        isDraft: false,
        updatedAt: serverTimestamp()
      };

      delete dataToSave.createdAt;
      delete dataToSave.isVerified;
      delete dataToSave.userId;

      if (isNewProfile) {
        dataToSave.userId = user.uid;
        dataToSave.createdAt = serverTimestamp();
        dataToSave.isVerified = false;
        setIsNewProfile(false);
      }

      // Check total document payload size to prevent Firestore 1MB limit crash
      const payloadStr = JSON.stringify(dataToSave);
      if (payloadStr.length > 900000) {
        setError('ਪ੍ਰੋਫਾਈਲ ਡਾਟਾ (ਫੋਟੋਆਂ/ਵੀਡੀਓ) ਦਾ ਸਾਈਜ਼ 1MB ਦੀ ਸੀਮਾ ਤੋਂ ਵੱਧ ਗਿਆ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਵੀਡੀਓ ਹਟਾ ਕੇ YouTube/Instagram ਲਿੰਕ ਵਰਤੋ।');
        setSaving(false);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }

      await setDoc(docRef, dataToSave, { merge: true });
      
      await logActivity({
        type: 'profile_update',
        action: isNewProfile ? 'Profile Created' : 'Profile Updated',
        details: `${formData.fullName} ${isNewProfile ? 'created' : 'updated'} their public profile.`,
        performedBy: user.uid,
        performedByName: formData.fullName,
        targetId: user.uid
      });

      setSuccess('ਪ੍ਰੋਫਾਈਲ ਸਫਲਤਾਪੂਰਵਕ ਸੇਵ ਹੋ ਗਈ ਹੈ! (Profile updated successfully!)');
      
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      setTimeout(() => navigate('/dashboard'), 1800);

    } catch (err: any) {
      setError(err.message || 'Failed to update profile.');
      handleFirestoreError(err, OperationType.UPDATE, `profiles/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const completionPercent = calculateCompletion(formData);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8 lg:py-12">
      <SEO 
        title="ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਬਾਇਓਡਾਟਾ ਫਾਰਮ (Create & Edit Biodata)"
        description="ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਪੋਰਟਲ 'ਤੇ ਆਪਣਾ ਵਿਆਹ ਬਾਇਓਡਾਟਾ ਭਰੋ, ਫੋਟੋਆਂ ਅਪਲੋਡ ਕਰੋ ਅਤੇ ਗੋਤਰ ਵੇਰਵੇ ਦਰਜ ਕਰੋ।"
        keywords={['Mahasha biodata form', 'create mahasha matrimony profile', 'punjabi matrimony registration']}
        noIndex={true}
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col xl:flex-row items-start gap-8">
        
        {/* Left Sidebar - Floating Profile Completion (Desktop) */}
        <div className="hidden xl:block w-72 shrink-0 sticky top-10">
          <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2.5 bg-emerald-100 text-emerald-700 rounded-xl">
                <CheckCircle2 className="w-6 h-6" />
              </div>
              <div>
                <h3 className="font-bold text-gray-900 text-base leading-tight">ਪ੍ਰੋਫਾਈਲ ਮੁਕੰਮਲਤਾ</h3>
                <p className="text-xs text-gray-500 font-medium">Profile Completion</p>
              </div>
            </div>
            
            <div className="flex items-end justify-between mb-2">
              <span className="text-sm font-semibold text-gray-600">ਸਥਿਤੀ (Status)</span>
              <span className="text-2xl font-black text-rose-900">{completionPercent}%</span>
            </div>
            
            <div className="w-full bg-gray-100 rounded-full h-3 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-amber-500 to-rose-700 h-3 rounded-full transition-all duration-700" 
                style={{ width: `${completionPercent}%` }}
              ></div>
            </div>
            
            {completionPercent < 100 && (
              <p className="text-xs text-gray-500 mt-4 bg-gray-50 p-3 rounded-lg border border-gray-100">
                ਆਪਣੀ ਪ੍ਰੋਫਾਈਲ ਨੂੰ ਹੋਰ ਪ੍ਰਭਾਵਸ਼ਾਲੀ ਬਣਾਉਣ ਲਈ ਸਾਰੇ ਜ਼ਰੂਰੀ ਵੇਰਵੇ ਭਰੋ।
              </p>
            )}
            {completionPercent === 100 && (
              <p className="text-xs text-emerald-700 mt-4 bg-emerald-50 p-3 rounded-lg border border-emerald-100 font-medium flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4" /> ਬਹੁਤ ਵਧੀਆ! ਪ੍ਰੋਫਾਈਲ ਮੁਕੰਮਲ ਹੈ।
              </p>
            )}
          </div>
        </div>

        <div className="flex-1 max-w-4xl w-full mx-auto">
          {/* Page Header */}
          <div className="mb-6">
            <div className="flex flex-wrap items-center justify-between gap-4 mb-2">
              <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 font-serif">
                ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਬਾਇਓਡਾਟਾ (Edit Biodata)
              </h1>
              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setShowAiAssistant(!showAiAssistant)}
                  className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full text-xs font-bold bg-gradient-to-r from-rose-950 to-amber-900 text-amber-300 border border-amber-400/40 shadow-sm hover:opacity-95 transition-all"
                >
                  <Bot className="w-4 h-4 text-amber-400" />
                  {showAiAssistant ? 'AI ਸਹਾਇਕ ਬੰਦ ਕਰੋ' : 'AI ਪ੍ਰੋਫਾਈਲ ਸਹਾਇਕ (Smart AI)'}
                </button>
              </div>
            </div>
            <p className="text-gray-600 text-xs sm:text-sm">
              ਰਿਸ਼ਤੇ ਲਈ ਲੋੜੀਂਦੇ ਸਾਰੇ ਜ਼ਰੂਰੀ ਵੇਰਵੇ ਭਰੋ। ਲਾਲ ਤਾਰੇ (<span className="text-red-600 font-bold">*</span>) ਵਾਲੇ ਖਾਨੇ ਭਰਨੇ ਜ਼ਰੂਰੀ ਹਨ।
            </p>

            {/* AI Assistant Section Dropdown */}
            {showAiAssistant && (
              <div className="mt-4 animate-in fade-in slide-in-from-top-3 duration-300">
                <AIProfileAssistant
                  formData={formData}
                  onApplyFields={handleApplyAiFields}
                  onClose={() => setShowAiAssistant(false)}
                />
              </div>
            )}

            {/* Draft Saved Toast Banner */}
            {draftToast && (
              <div className="mt-4 p-3 bg-purple-50 border border-purple-300 text-purple-900 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-between shadow-sm animate-in fade-in">
                <span className="flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-purple-700" />
                  ਡਰਾਫਟ ਸੁਰੱਖਿਅਤ ਕਰ ਲਿਆ ਗਿਆ ਹੈ! ਤੁਸੀਂ ਬਾਅਦ ਵਿੱਚ ਜਾਰੀ ਰੱਖ ਸਕਦੇ ਹੋ। (Draft saved)
                </span>
                <button type="button" onClick={() => setDraftToast(false)} className="text-xs text-purple-700 underline">ਬੰਦ ਕਰੋ</button>
              </div>
            )}

            {/* Profile Completion Bar (Mobile/Tablet Only) */}
            <div className="xl:hidden mt-4 bg-white p-4 rounded-xl border border-gray-200 shadow-xs">
              <div className="flex items-center justify-between text-sm font-semibold mb-1.5">
                <span className="text-gray-700 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  ਪ੍ਰੋਫਾਈਲ ਮੁਕੰਮਲਤਾ (Profile Completion)
                </span>
                <span className="text-rose-900 font-bold">{completionPercent}%</span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden">
                <div 
                  className="bg-gradient-to-r from-amber-500 to-rose-700 h-2.5 rounded-full transition-all duration-500" 
                  style={{ width: `${completionPercent}%` }}
                ></div>
              </div>
            </div>
          </div>

          {/* Step-by-Step Navigation Indicator Bar */}
          <div className="mb-6 bg-white p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-sm">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-base sm:text-lg font-bold text-gray-900 flex items-center gap-2">
                <span className="w-7 h-7 bg-rose-900 text-amber-300 rounded-full flex items-center justify-center text-sm font-bold">
                  {currentStep}
                </span>
                <span>ਕਦਮ {currentStep} / 5: {STEPS_LIST[currentStep - 1].name}</span>
              </h2>
              <span className="text-xs font-semibold px-3 py-1 rounded-full bg-amber-100 text-rose-950 border border-amber-300">
                Step {currentStep} of 5
              </span>
            </div>

            {/* Steps Progress Buttons Grid */}
            <div className="grid grid-cols-5 gap-1.5 sm:gap-3">
              {STEPS_LIST.map((st) => {
                const IconComp = st.icon;
                const isActive = st.id === currentStep;
                const isCompleted = st.id < currentStep;

                return (
                  <button
                    key={st.id}
                    type="button"
                    onClick={() => {
                      if (st.id < currentStep) {
                        setCurrentStep(st.id);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      } else if (st.id > currentStep && validateStep(currentStep)) {
                        setCurrentStep(st.id);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }
                    }}
                    className={`flex flex-col items-center justify-center p-2 rounded-xl text-center transition-all ${
                      isActive
                        ? 'bg-rose-900 text-amber-300 font-bold shadow-md ring-2 ring-amber-400'
                        : isCompleted
                        ? 'bg-emerald-50 text-emerald-800 border border-emerald-200 hover:bg-emerald-100 font-semibold'
                        : 'bg-gray-50 text-gray-500 border border-gray-200 hover:bg-gray-100'
                    }`}
                  >
                    <div className="flex items-center gap-1 mb-1">
                      {isCompleted ? (
                        <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                      ) : (
                        <IconComp className={`w-4 h-4 shrink-0 ${isActive ? 'text-amber-400' : 'text-gray-400'}`} />
                      )}
                      <span className="text-xs sm:text-sm font-bold">0{st.id}</span>
                    </div>
                    <span className="text-[11px] sm:text-xs truncate max-w-full hidden sm:inline">{st.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          {error && (
            <div className="mb-6 bg-rose-50 border-l-4 border-rose-500 p-4 flex items-start gap-3 rounded-r-lg shadow-xs">
              <AlertCircle className="w-5 h-5 text-rose-600 mt-0.5 flex-shrink-0" />
              <p className="text-rose-700 font-medium text-sm">{error}</p>
            </div>
          )}

          {success && (
            <SuccessAnimation isVisible={!!success} message={success} className="mb-6" />
          )}

          <form onSubmit={handleSubmit} className="space-y-6">

            {/* STEP 1: Photos & Video */}
            {currentStep === 1 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 space-y-8">
                <div className="flex items-center gap-2 border-b border-gray-100 pb-4">
                  <ImageIcon className="w-6 h-6 text-rose-900" />
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 font-serif">ਕਦਮ 1: ਪ੍ਰੋਫਾਈਲ ਫੋਟੋਆਂ ਅਤੇ ਵੀਡੀਓ (Photos & Video)</h2>
                    <p className="text-xs text-gray-500">ਘੱਟੋ-ਘੱਟ 2 ਫੋਟੋਆਂ ਜ਼ਰੂਰੀ ਹਨ (At least 2 photos required)</p>
                  </div>
                </div>

                {/* Photo Upload Section */}
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-gray-800">
                    ਫੋਟੋਆਂ ਅੱਪਲੋਡ ਕਰੋ (Upload Photos) <span className="text-red-600">*</span>
                  </label>
                  <div className="flex flex-wrap gap-4">
                    {formData.photoUrls && formData.photoUrls.map((url, idx) => (
                      <div key={idx} className="relative group w-32 h-32 rounded-xl overflow-hidden border border-gray-200 shadow-sm">
                        <img src={url} alt={`Upload ${idx + 1}`} className="w-full h-full object-cover" />
                        <button
                          type="button"
                          onClick={() => removePhoto(idx)}
                          className="absolute top-1 right-1 bg-white/90 text-red-600 p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity shadow-sm hover:bg-red-50"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                    
                    {(!formData.photoUrls || formData.photoUrls.length < 5) && (
                      <label className="w-32 h-32 flex flex-col items-center justify-center gap-2 bg-gray-50 border-2 border-dashed border-gray-300 rounded-xl cursor-pointer hover:bg-gray-100 hover:border-amber-400 transition-colors">
                        <Upload className="w-6 h-6 text-gray-400" />
                        <span className="text-xs font-semibold text-gray-500 text-center px-2">ਫੋਟੋ ਚੁਣੋ<br/>(Add Photo)</span>
                        <input 
                          type="file" 
                          accept="image/*" 
                          multiple 
                          onChange={handlePhotoUpload}
                          className="hidden" 
                        />
                      </label>
                    )}
                  </div>
                  <p className="text-xs text-gray-500">
                    ਨੋਟ: ਸਾਫ਼ ਅਤੇ ਵਧੀਆ ਕੁਆਲਿਟੀ ਦੀਆਂ ਫੋਟੋਆਂ ਅਪਲੋਡ ਕਰੋ (Max 2MB per photo)
                  </p>
                </div>
                
                {/* Video Capture & Upload Section */}
                <div className="border-t border-gray-100 pt-6 space-y-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-base font-bold text-gray-900 flex items-center gap-2">
                        <Video className="w-5 h-5 text-rose-900" />
                        ਪ੍ਰੋਫਾਈਲ ਵੀਡੀਓ (Profile Video)
                      </h3>
                      <p className="text-xs text-gray-500">ਮੋਬਾਈਲ ਕੈਮਰੇ ਨਾਲ ਰਿਕਾਰਡ ਕਰੋ, ਵੀਡੀਓ ਫਾਈਲ ਅੱਪਲੋਡ ਕਰੋ ਜਾਂ ਲਿੰਕ ਪਾਓ</p>
                    </div>
                    <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded">ਵਿਕਲਪਿਕ / Optional</span>
                  </div>

                  {formData.videoUrl ? (
                    <div className="bg-gray-50 p-4 rounded-xl border border-gray-200 space-y-3">
                      <div className="flex items-center justify-between">
                        <span className="text-xs font-bold text-emerald-700 flex items-center gap-1.5">
                          <CheckCircle2 className="w-4 h-4 text-emerald-600" /> ਵੀਡੀਓ ਮੌਜੂਦ ਹੈ (Video Ready)
                        </span>
                        <button
                          type="button"
                          onClick={removeVideo}
                          className="text-xs font-semibold text-rose-700 hover:bg-rose-100 px-2.5 py-1 rounded-lg border border-rose-200 transition-colors flex items-center gap-1"
                        >
                          <X className="w-3.5 h-3.5" /> ਵੀਡੀਓ ਹਟਾਓ (Remove)
                        </button>
                      </div>

                      {formData.videoUrl.startsWith('data:video') || formData.videoUrl.match(/\.(mp4|webm|mov|ogg)$/i) ? (
                        <video controls src={formData.videoUrl} className="w-full max-h-60 bg-black rounded-xl object-contain shadow-inner" />
                      ) : (
                        <div className="p-3 bg-white border border-gray-200 rounded-lg text-xs font-mono text-gray-700 break-all">
                          {formData.videoUrl}
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {/* Action buttons: Camera capture vs Video file upload */}
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                        <label className="cursor-pointer flex items-center justify-center gap-2.5 p-4 bg-rose-900 hover:bg-rose-800 text-amber-300 font-bold rounded-xl text-sm shadow-md hover:shadow-lg transition-all border border-amber-400/30">
                          <Camera className="w-5 h-5 text-amber-400 shrink-0" />
                          <span className="text-center">ਕੈਮਰੇ ਨਾਲ ਵੀਡੀਓ ਬਣਾਓ<br/><span className="text-xs font-normal text-amber-200/80">(Record with Camera)</span></span>
                          <input 
                            type="file" 
                            accept="video/*" 
                            capture="user" 
                            onChange={handleVideoFileUpload} 
                            className="hidden" 
                          />
                        </label>

                        <label className="cursor-pointer flex items-center justify-center gap-2.5 p-4 bg-white hover:bg-gray-50 text-gray-800 font-bold rounded-xl text-sm shadow-sm border border-gray-300 transition-colors">
                          <FileVideo className="w-5 h-5 text-rose-900 shrink-0" />
                          <span className="text-center">ਵੀਡੀਓ ਫਾਈਲ ਅੱਪਲੋਡ ਕਰੋ<br/><span className="text-xs font-normal text-gray-500">(Upload Video File)</span></span>
                          <input 
                            type="file" 
                            accept="video/*" 
                            onChange={handleVideoFileUpload} 
                            className="hidden" 
                          />
                        </label>
                      </div>

                      {/* Video Link option */}
                      <div className="bg-gray-50 p-3.5 rounded-xl border border-gray-200 space-y-1.5">
                        <label className="block text-xs font-bold text-gray-700">
                          ਜਾਂ ਵੀਡੀਓ ਲਿੰਕ ਪਾਓ (Or enter Instagram / YouTube Video Link)
                        </label>
                        <input 
                          type="url" 
                          name="videoUrl" 
                          value={formData.videoUrl} 
                          onChange={handleChange} 
                          placeholder="https://www.instagram.com/reel/... ਜਾਂ https://youtube.com/shorts/..."
                          className="w-full border border-gray-300 rounded-lg p-2.5 text-sm bg-white focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                        />
                      </div>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 2: Personal & Birth Details */}
            {currentStep === 2 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 space-y-6">
                <div className="flex items-center gap-2 border-b border-gray-100 pb-4">
                  <User className="w-6 h-6 text-rose-900" />
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 font-serif">ਕਦਮ 2: ਨਿੱਜੀ ਅਤੇ ਜਨਮ ਵੇਰਵਾ (Personal & Birth Details)</h2>
                    <p className="text-xs text-gray-500">ਕੁੰਡਲੀ ਅਤੇ ਪਛਾਣ ਲਈ ਜਨਮ ਦਾ ਸਹੀ ਵੇਰਵਾ ਦਰਜ ਕਰੋ</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {isFieldVisible('fullName') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('fullName', 'pa')} ({getFieldLabel('fullName', 'en')}) {isFieldRequired('fullName') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('fullName')}
                        type="text" 
                        name="fullName" 
                        value={formData.fullName} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Simranjit Kaur / Rajesh Kumar"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                      />
                    </div>
                  )}

                  {isFieldVisible('fatherName') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('fatherName', 'pa')} ({getFieldLabel('fatherName', 'en')}) {isFieldRequired('fatherName') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('fatherName')}
                        type="text" 
                        name="fatherName" 
                        value={formData.fatherName} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Shri Harish Kumar / Subhash Chand"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                      />
                    </div>
                  )}

                  {isFieldVisible('motherName') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('motherName', 'pa')} ({getFieldLabel('motherName', 'en')}) {isFieldRequired('motherName') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('motherName')}
                        type="text" 
                        name="motherName" 
                        value={formData.motherName} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Smt. Sunita Devi / Asha Rani"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                      />
                    </div>
                  )}
                  
                  {isFieldVisible('gender') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('gender', 'pa')} ({getFieldLabel('gender', 'en')}) {isFieldRequired('gender') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="gender" 
                        value={formData.gender} 
                        onChange={handleChange} 
                        required={isFieldRequired('gender')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        <option value="Female">ਲਾੜੀ ਲਈ (Bride / Female)</option>
                        <option value="Male">ਲਾੜੇ ਲਈ (Groom / Male)</option>
                      </select>
                    </div>
                  )}

                  {isFieldVisible('age') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('age', 'pa')} ({getFieldLabel('age', 'en')}) {isFieldRequired('age') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('age')}
                        type="number" 
                        name="age" 
                        value={formData.age} 
                        onChange={handleChange} 
                        min="18" 
                        max="75" 
                        placeholder="e.g. 26" 
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                      />
                    </div>
                  )}

                  {isFieldVisible('dateOfBirth') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('dateOfBirth', 'pa')} ({getFieldLabel('dateOfBirth', 'en')}) {isFieldRequired('dateOfBirth') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('dateOfBirth')}
                        type="text" 
                        name="dateOfBirth" 
                        value={formData.dateOfBirth} 
                        onChange={handleChange} 
                        placeholder="DD-MM-YYYY (ਜਿਵੇਂ: 25-10-1998)"
                        maxLength={10}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                      />
                    </div>
                  )}

                  {isFieldVisible('birthPlace') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('birthPlace', 'pa')} ({getFieldLabel('birthPlace', 'en')}) {isFieldRequired('birthPlace') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-rose-700 font-normal">ਕੁੰਡਲੀ ਲਈ ਲੋੜੀਂਦਾ</span>
                      </label>
                      {birthPlaces && birthPlaces.length > 0 ? (
                        <select 
                          name="birthPlace" 
                          value={formData.birthPlace} 
                          onChange={handleChange} 
                          required={isFieldRequired('birthPlace')}
                          className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                        >
                          <option value="">ਜਨਮ ਸਥਾਨ ਚੁਣੋ (Select Birth Place)</option>
                          {birthPlaces.map(bp => <option key={bp} value={bp}>{bp}</option>)}
                        </select>
                      ) : (
                        <input 
                          required={isFieldRequired('birthPlace')}
                          type="text" 
                          name="birthPlace" 
                          value={formData.birthPlace} 
                          onChange={handleChange} 
                          placeholder="ਜਿਵੇਂ: Gurdaspur, Batala, Pathankot, Amritsar..." 
                          className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                        />
                      )}
                    </div>
                  )}

                  {isFieldVisible('birthTime') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('birthTime', 'pa')} ({getFieldLabel('birthTime', 'en')}) {isFieldRequired('birthTime') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-gray-500 font-normal">ਵਿਕਲਪਿਕ (Optional)</span>
                      </label>
                      <div className="relative">
                        <input 
                          required={isFieldRequired('birthTime')}
                          type="text" 
                          name="birthTime" 
                          value={formData.birthTime} 
                          onChange={handleChange} 
                          placeholder="ਜਿਵੇਂ: 10:30 AM, 04:15 PM (Optional)" 
                          className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none pl-10" 
                        />
                        <Clock className="w-5 h-5 text-gray-400 absolute left-3 top-3.5" />
                      </div>
                    </div>
                  )}

                  {isFieldVisible('complexion') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('complexion', 'pa')} ({getFieldLabel('complexion', 'en')}) {isFieldRequired('complexion') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="complexion" 
                        value={formData.complexion} 
                        onChange={handleChange} 
                        required={isFieldRequired('complexion')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        {complexions.map(c => (
                          <option key={c.value} value={c.value}>{c.label}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  {isFieldVisible('height') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('height', 'pa')} ({getFieldLabel('height', 'en')}) {isFieldRequired('height') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="height" 
                        value={formData.height} 
                        onChange={handleChange} 
                        required={isFieldRequired('height')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        <option value="">ਕੱਦ ਸਿਲੈਕਟ ਕਰੋ (Select Height)</option>
                        {HEIGHT_OPTIONS.map(h => (
                          <option key={h} value={h}>{h}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  {isFieldVisible('maritalStatus') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('maritalStatus', 'pa')} ({getFieldLabel('maritalStatus', 'en')}) {isFieldRequired('maritalStatus') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="maritalStatus" 
                        value={formData.maritalStatus} 
                        onChange={handleChange} 
                        required={isFieldRequired('maritalStatus')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        <option value="Never Married">ਕਦੇ ਵਿਆਹ ਨਹੀਂ ਹੋਇਆ (Never Married)</option>
                        <option value="Awaiting Divorce">ਤਲਾਕ ਅਧੀਨ (Awaiting Divorce)</option>
                        <option value="Divorced">ਤਲਾਕਸ਼ੁਦਾ (Divorced)</option>
                        <option value="Widowed">ਵਿਧਵਾ / ਵਿਧੁਰ (Widowed)</option>
                      </select>
                    </div>
                  )}

                  {isFieldVisible('religion') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('religion', 'pa')} ({getFieldLabel('religion', 'en')}) {isFieldRequired('religion') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="religion" 
                        value={formData.religion} 
                        onChange={handleChange} 
                        required={isFieldRequired('religion')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        <option value="">-- ਚੁਣੋ --</option>
                        {religions.map(r => <option key={r} value={r}>{r}</option>)}
                      </select>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 3: Residence & Gotra */}
            {currentStep === 3 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 space-y-6">
                <div className="flex items-center gap-2 border-b border-gray-100 pb-4">
                  <MapPin className="w-6 h-6 text-rose-900" />
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 font-serif">ਕਦਮ 3: ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ ਅਤੇ ਗੋਤਰ ਵੇਰਵਾ (Location & Gotra)</h2>
                    <p className="text-xs text-gray-500">ਮਹਾਸ਼ਾ ਸਮਾਜ ਵਿੱਚ ਰਿਸ਼ਤਾ ਤੈਅ ਕਰਨ ਲਈ ਦੋਵੇਂ ਪਾਸੇ ਦੇ ਗੋਤਰ ਜ਼ਰੂਰੀ ਹਨ</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {isFieldVisible('state') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('state', 'pa')} ({getFieldLabel('state', 'en')}) {isFieldRequired('state') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="state" 
                        value={formData.state} 
                        onChange={handleChange} 
                        required={isFieldRequired('state')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        <option value="">ਸਟੇਟ ਸਿਲੈਕਟ ਕਰੋ (Select State)</option>
                        {states.map(s => (
                          <option key={s} value={s}>{s}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  {isFieldVisible('district') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('district', 'pa')} ({getFieldLabel('district', 'en')}) {isFieldRequired('district') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="district" 
                        value={formData.district} 
                        onChange={handleChange} 
                        required={isFieldRequired('district')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        <option value="">ਜ਼ਿਲ੍ਹਾ ਸਿਲੈਕਟ ਕਰੋ (Select District)</option>
                        {districts.map(d => (
                          <option key={d} value={d}>{d}</option>
                        ))}
                      </select>
                    </div>
                  )}

                  {isFieldVisible('tehsil') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('tehsil', 'pa') || 'ਤਹਿਸੀਲ'} ({getFieldLabel('tehsil', 'en') || 'Tehsil'}) {isFieldRequired('tehsil') && <span className="text-red-600">*</span>}
                      </label>
                      {tehsils && tehsils.length > 0 ? (
                        <select 
                          name="tehsil" 
                          value={formData.tehsil || ''} 
                          onChange={handleChange} 
                          required={isFieldRequired('tehsil')}
                          className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                        >
                          <option value="">ਤਹਿਸੀਲ ਚੁਣੋ (Select Tehsil)</option>
                          {tehsils.map(t => <option key={t} value={t}>{t}</option>)}
                        </select>
                      ) : (
                        <input 
                          type="text" 
                          name="tehsil" 
                          value={formData.tehsil || ''} 
                          onChange={handleChange} 
                          required={isFieldRequired('tehsil')}
                          placeholder="ਜਿਵੇਂ: Batala, Pathankot..." 
                          className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                        />
                      )}
                    </div>
                  )}

                  {isFieldVisible('location') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('location', 'pa')} ({getFieldLabel('location', 'en')}) {isFieldRequired('location') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('location')}
                        type="text" 
                        name="location" 
                        value={formData.location} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Gurdaspur City, Punjab" 
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                      />
                    </div>
                  )}

                  {/* Father Gotra */}
                  {isFieldVisible('fatherGotra') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('fatherGotra', 'pa')} ({getFieldLabel('fatherGotra', 'en')}) {isFieldRequired('fatherGotra') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="fatherGotraSelect" 
                        value={fatherGotraSelect} 
                        onChange={handleFatherGotraChange} 
                        required={isFieldRequired('fatherGotra')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        {gotras.map(g => (
                          <option key={g.value} value={g.value}>{g.label}</option>
                        ))}
                      </select>

                      {fatherGotraSelect === 'Other' && (
                        <div className="mt-2.5 p-2.5 bg-amber-50 border border-amber-300 rounded-lg">
                          <label className="block text-xs font-bold text-rose-950 mb-1">
                            ਪਿਤਾ ਦਾ ਗੋਤਰ ਲਿਖੋ (Type Custom Father Gotra) <span className="text-red-600">*</span>
                          </label>
                          <input 
                            type="text" 
                            value={customFatherGotra} 
                            onChange={(e) => {
                              setCustomFatherGotra(e.target.value);
                              setFormData(prev => ({ ...prev, fatherGotra: e.target.value }));
                            }}
                            placeholder="ਜਿਵੇਂ: Bajgal (Bhogal), Gill, Sandhu..." 
                            className="w-full border border-amber-400 rounded-md p-2 text-sm bg-white outline-none" 
                          />
                        </div>
                      )}
                      <p className="text-xs text-gray-500 mt-1">ਜਿਵੇਂ: Bajgal (Bhogal), Kaler, Badhan, Banga...</p>
                    </div>
                  )}

                  {/* Mother Gotra */}
                  {isFieldVisible('motherGotra') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('motherGotra', 'pa')} ({getFieldLabel('motherGotra', 'en')}) {isFieldRequired('motherGotra') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="motherGotraSelect" 
                        value={motherGotraSelect} 
                        onChange={handleMotherGotraChange} 
                        required={isFieldRequired('motherGotra')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        {gotras.map(g => (
                          <option key={g.value} value={g.value}>{g.label}</option>
                        ))}
                      </select>

                      {motherGotraSelect === 'Other' && (
                        <div className="mt-2.5 p-2.5 bg-amber-50 border border-amber-300 rounded-lg">
                          <label className="block text-xs font-bold text-rose-950 mb-1">
                            ਮਾਤਾ ਦਾ ਗੋਤਰ ਲਿਖੋ (Type Custom Mother Gotra) <span className="text-red-600">*</span>
                          </label>
                          <input 
                            type="text" 
                            value={customMotherGotra} 
                            onChange={(e) => {
                              setCustomMotherGotra(e.target.value);
                              setFormData(prev => ({ ...prev, motherGotra: e.target.value }));
                            }}
                            placeholder="ਜਿਵੇਂ: Ghangla, Hans, Taak..." 
                            className="w-full border border-amber-400 rounded-md p-2 text-sm bg-white outline-none" 
                          />
                        </div>
                      )}
                      <p className="text-xs text-gray-500 mt-1">ਜਿਵੇਂ: Ghangla, Taak, Hans, Kundal...</p>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 4: Education & Profession */}
            {currentStep === 4 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 space-y-6">
                <div className="flex items-center gap-2 border-b border-gray-100 pb-4">
                  <GraduationCap className="w-6 h-6 text-rose-900" />
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 font-serif">ਕਦਮ 4: ਵਿੱਦਿਅਕ ਯੋਗਤਾ ਅਤੇ ਕਿੱਤਾ (Education & Profession)</h2>
                    <p className="text-xs text-gray-500">ਯੋਗਤਾਵਾਂ, ਮੌਜੂਦਾ ਕੰਮ ਅਤੇ ਆਮਦਨ ਦਾ ਵੇਰਵਾ</p>
                  </div>
                </div>
                
                <div className="space-y-4">
                  {isFieldVisible('qualification1') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('qualification1', 'pa')} ({getFieldLabel('qualification1', 'en')}) {isFieldRequired('qualification1') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium">ਜ਼ਰੂਰੀ / Mandatory</span>
                      </label>
                      <input 
                        required={isFieldRequired('qualification1')}
                        type="text" 
                        name="qualification1" 
                        value={formData.qualification1} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Computer Engineering Diploma, Polytechnic Diploma, B.A..." 
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}

                  {isFieldVisible('qualification2') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('qualification2', 'pa')} ({getFieldLabel('qualification2', 'en')}) {isFieldRequired('qualification2') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ (Optional)</span>
                      </label>
                      <input 
                        required={isFieldRequired('qualification2')}
                        type="text" 
                        name="qualification2" 
                        value={formData.qualification2} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: BA.LLB, B.Tech, B.Com, B.Sc, B.Ed..." 
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}

                  {isFieldVisible('qualification3') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('qualification3', 'pa')} ({getFieldLabel('qualification3', 'en')}) {isFieldRequired('qualification3') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ (Optional)</span>
                      </label>
                      <input 
                        required={isFieldRequired('qualification3')}
                        type="text" 
                        name="qualification3" 
                        value={formData.qualification3} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: LLM (Criminology), M.Tech, MBA, Ph.D..." 
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 border-t border-gray-100 pt-6">
                  {isFieldVisible('profession') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('profession', 'pa')} ({getFieldLabel('profession', 'en')}) {isFieldRequired('profession') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="professionSelect" 
                        value={professionSelect} 
                        onChange={handleProfessionSelectChange} 
                        required={isFieldRequired('profession')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                      >
                        <option value="">ਸਿਲੈਕਟ ਕਰੋ / Select Profession</option>
                        {professions.map(p => (
                          <option key={p} value={p}>{p}</option>
                        ))}
                        <option value="Other">ਅਦਰ / ਹੋਰ ਪੇਸ਼ਾ (Other Profession)</option>
                      </select>

                      {professionSelect === 'Other' && (
                        <div className="mt-3 p-3.5 bg-amber-50/90 border border-amber-300 rounded-xl transition-all">
                          <label className="block text-xs font-bold text-rose-950 mb-1.5">
                            ਆਪਣਾ ਖਾਸ ਪੇਸ਼ਾ ਇੱਥੇ ਲਿਖੋ (Type Custom Profession) <span className="text-red-600">*</span>
                          </label>
                          <input
                            type="text"
                            name="customProfessionInput"
                            value={customProfession}
                            onChange={handleCustomProfessionChange}
                            placeholder="ਜਿਵੇਂ: Architect, Civil Contractor, Pharmacist..."
                            required={professionSelect === 'Other'}
                            className="w-full border border-amber-400 rounded-lg p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white text-gray-900 font-medium text-sm"
                          />
                        </div>
                      )}
                    </div>
                  )}

                  {isFieldVisible('income') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('income', 'pa')} ({getFieldLabel('income', 'en')}) {isFieldRequired('income') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="income" 
                        value={formData.income} 
                        onChange={handleChange} 
                        required={isFieldRequired('income')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white font-medium"
                      >
                        <option value="">ਸਿਲੈਕਟ ਕਰੋ (Select Income Range)</option>
                        <option value="Under 5 Lakhs">5 ਲੱਖ ਤੋਂ ਘੱਟ (Under 5 Lakhs)</option>
                        <option value="5-10 Lakhs">5 ਤੋਂ 10 ਲੱਖ (5-10 Lakhs)</option>
                        <option value="10-20 Lakhs">10 ਤੋਂ 20 ਲੱਖ (10-20 Lakhs)</option>
                        <option value="20-30 Lakhs">20 ਤੋਂ 30 ਲੱਖ (20-30 Lakhs)</option>
                        <option value="30+ Lakhs">30 ਲੱਖ ਤੋਂ ਵੱਧ (30+ Lakhs)</option>
                      </select>
                    </div>
                  )}

                  {isFieldVisible('occupationDetails') && (
                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('occupationDetails', 'pa')} ({getFieldLabel('occupationDetails', 'en')}) {isFieldRequired('occupationDetails') && <span className="text-red-600">*</span>}</span>
                      </label>
                      <textarea 
                        required={isFieldRequired('occupationDetails')}
                        rows={2}
                        name="occupationDetails" 
                        value={formData.occupationDetails} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Now practicing as an Advocate with her mother & preparation of PCS (J)"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-sm font-medium"
                      ></textarea>
                    </div>
                  )}
                </div>
              </div>
            )}

            {/* STEP 5: Family & Contact Details */}
            {currentStep === 5 && (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 space-y-6">
                <div className="flex items-center gap-2 border-b border-gray-100 pb-4">
                  <Users className="w-6 h-6 text-rose-900" />
                  <div>
                    <h2 className="text-xl font-bold text-gray-900 font-serif">ਕਦਮ 5: ਪਰਿਵਾਰਕ ਅਤੇ ਸੰਪਰਕ ਵੇਰਵਾ (Family & Contact Details)</h2>
                    <p className="text-xs text-gray-500">ਮਾਤਾ-ਪਿਤਾ, ਸੰਪਰਕ ਨੰਬਰ ਅਤੇ ਆਪਣੇ ਬਾਰੇ ਜਾਣਕਾਰੀ</p>
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {isFieldVisible('fatherOccupation') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('fatherOccupation', 'pa')} ({getFieldLabel('fatherOccupation', 'en')}) {isFieldRequired('fatherOccupation') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('fatherOccupation')}
                        type="text" 
                        name="fatherOccupation" 
                        value={formData.fatherOccupation} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: (Expire) Retired cashier from CPWD / Business / Govt Service"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}

                  {isFieldVisible('motherOccupation') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('motherOccupation', 'pa')} ({getFieldLabel('motherOccupation', 'en')}) {isFieldRequired('motherOccupation') && <span className="text-red-600">*</span>}
                      </label>
                      <input 
                        required={isFieldRequired('motherOccupation')}
                        type="text" 
                        name="motherOccupation" 
                        value={formData.motherOccupation} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Advocate / Homemaker / Teacher / Govt Employee"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}

                  {isFieldVisible('brotherDetails') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('brotherDetails', 'pa')} ({getFieldLabel('brotherDetails', 'en')}) {isFieldRequired('brotherDetails') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ</span>
                      </label>
                      <input 
                        required={isFieldRequired('brotherDetails')}
                        type="text" 
                        name="brotherDetails" 
                        value={formData.brotherDetails} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: Advocate, 1 Elder Brother (Married)..."
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}

                  {isFieldVisible('sisterDetails') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('sisterDetails', 'pa')} ({getFieldLabel('sisterDetails', 'en')}) {isFieldRequired('sisterDetails') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ</span>
                      </label>
                      <input 
                        required={isFieldRequired('sisterDetails')}
                        type="text" 
                        name="sisterDetails" 
                        value={formData.sisterDetails} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: 1 Younger Sister (Unmarried) / None"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}

                  {isFieldVisible('familyType') && (
                    <div className="md:col-span-2">
                      <label className="block text-sm font-semibold text-gray-800 mb-1">
                        {getFieldLabel('familyType', 'pa')} ({getFieldLabel('familyType', 'en')}) {isFieldRequired('familyType') && <span className="text-red-600">*</span>}
                      </label>
                      <select 
                        name="familyType" 
                        value={formData.familyType} 
                        onChange={handleChange} 
                        required={isFieldRequired('familyType')}
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white font-medium"
                      >
                        <option value="Nuclear">ਇਕਹਿਰਾ ਪਰਿਵਾਰ (Nuclear Family)</option>
                        <option value="Joint">ਸੰਯੁਕਤ ਪਰਿਵਾਰ (Joint Family)</option>
                      </select>
                    </div>
                  )}

                  {isFieldVisible('contactNumber') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('contactNumber', 'pa')} ({getFieldLabel('contactNumber', 'en')}) {isFieldRequired('contactNumber') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium">ਜ਼ਰੂਰੀ / Mandatory</span>
                      </label>
                      <div className="relative">
                        <input 
                          required={isFieldRequired('contactNumber')}
                          type="tel" 
                          name="contactNumber" 
                          value={formData.contactNumber} 
                          onChange={handleChange} 
                          placeholder="ਜਿਵੇਂ: 9876543210 / +91 98765-43210"
                          className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium pl-10" 
                        />
                        <Phone className="w-5 h-5 text-gray-400 absolute left-3 top-3.5" />
                      </div>
                    </div>
                  )}

                  {isFieldVisible('alternateContact') && (
                    <div>
                      <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                        <span>{getFieldLabel('alternateContact', 'pa')} ({getFieldLabel('alternateContact', 'en')}) {isFieldRequired('alternateContact') && <span className="text-red-600">*</span>}</span>
                        <span className="text-xs text-gray-500">Optional</span>
                      </label>
                      <input 
                        required={isFieldRequired('alternateContact')}
                        type="tel" 
                        name="alternateContact" 
                        value={formData.alternateContact} 
                        onChange={handleChange} 
                        placeholder="ਜਿਵੇਂ: 9812345678"
                        className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                      />
                    </div>
                  )}
                </div>

                {isFieldVisible('aboutMe') && (
                  <div className="border-t border-gray-100 pt-6">
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm font-semibold text-gray-800">
                        {getFieldLabel('aboutMe', 'pa')} ({getFieldLabel('aboutMe', 'en')}) {isFieldRequired('aboutMe') && <span className="text-red-600">*</span>}
                      </label>
                      <button
                        type="button"
                        onClick={() => setShowAiAssistant(true)}
                        className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-bold bg-amber-50 hover:bg-amber-100 text-rose-950 border border-amber-300 transition-colors"
                      >
                        <Bot className="w-3.5 h-3.5 text-amber-600" />
                        AI ਨਾਲ ਬਾਇਓ ਲਿਖੋ (Auto-Write Bio)
                      </button>
                    </div>
                    <textarea 
                      name="aboutMe" 
                      value={formData.aboutMe} 
                      onChange={handleChange} 
                      required={isFieldRequired('aboutMe')}
                      rows={4} 
                      className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none text-sm font-medium"
                      placeholder="ਮੇਰੇ ਬਾਰੇ ਕੁਝ ਸ਼ਬਦ, ਪਰਿਵਾਰਕ ਕਦਰਾਂ-ਕੀਮਤਾਂ ਅਤੇ ਜੀਵਨ ਸਾਥੀ ਤੋਂ ਉਮੀਦਾਂ ਬਾਰੇ ਲਿਖੋ..."
                    ></textarea>
                  </div>
                )}
              </div>
            )}

            {/* Step Navigation Controls Bar */}
            <div className="sticky bottom-4 z-50 flex flex-wrap items-center justify-between gap-3 p-4 bg-white/95 backdrop-blur-md rounded-2xl border border-rose-100 shadow-[0_-4px_20px_rgba(0,0,0,0.08)] mt-8">
              <div className="flex items-center gap-2">
                {currentStep > 1 ? (
                  <button 
                    type="button" 
                    onClick={prevStep}
                    className="px-4 py-2.5 border border-gray-300 hover:bg-gray-100 text-gray-700 rounded-xl font-bold transition-colors flex items-center gap-1.5 text-xs sm:text-sm"
                  >
                    <ChevronLeft className="w-4 h-4" /> ਪਿਛਲਾ (Back)
                  </button>
                ) : (
                  <button 
                    type="button" 
                    onClick={() => navigate('/dashboard')}
                    className="px-4 py-2.5 border border-gray-300 hover:bg-gray-100 text-gray-700 rounded-xl font-bold transition-colors text-xs sm:text-sm"
                  >
                    ਰੱਦ ਕਰੋ (Cancel)
                  </button>
                )}

                {/* Save as Draft Button (Available in all steps) */}
                <button
                  type="button"
                  disabled={saving}
                  onClick={handleSaveDraft}
                  className="px-4 py-2.5 bg-purple-50 hover:bg-purple-100 text-purple-900 border border-purple-300 rounded-xl font-bold text-xs sm:text-sm transition-all flex items-center gap-1.5"
                  title="ਫਾਰਮ ਨੂੰ ਬਾਅਦ ਵਿੱਚ ਭਰਨ ਲਈ ਡਰਾਫਟ ਸੇਵ ਕਰੋ"
                >
                  <Save className="w-4 h-4 text-purple-700" />
                  ਡਰਾਫਟ ਸੇਵ ਕਰੋ (Save Draft)
                </button>
              </div>

              <div className="flex items-center gap-2">
                {currentStep < 5 ? (
                  <button 
                    type="button" 
                    onClick={nextStep}
                    className="px-5 py-2.5 bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-400/30 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-md hover:shadow-lg flex items-center gap-1.5"
                  >
                    ਅਗਲਾ ਕਦਮ (Next Step) <ChevronRight className="w-4 h-4" />
                  </button>
                ) : (
                  <button 
                    type="submit" 
                    disabled={saving}
                    className="px-6 py-2.5 bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-lg hover:shadow-xl flex items-center justify-center gap-1.5 disabled:opacity-70"
                  >
                    {saving ? 'ਸੇਵ ਹੋ ਰਿਹਾ ਹੈ...' : (
                      <>
                        <Save className="w-4 h-4 text-amber-400" /> ਪ੍ਰੋਫਾਈਲ ਪ੍ਰਕਾਸ਼ਿਤ ਕਰੋ (Publish Profile)
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>

          </form>
        </div>
      </div>
    </div>
  );
}
