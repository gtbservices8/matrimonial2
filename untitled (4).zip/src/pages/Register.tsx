import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { Save, Check, CheckCircle2, AlertCircle } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { createUserWithEmailAndPassword } from 'firebase/auth';
import { auth, db } from '../lib/firebase';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import AppLogo from '../components/common/AppLogo';
import SuccessAnimation from '../components/common/SuccessAnimation';
import SEO from '../components/common/SEO';
import { useCMSConfig } from '../hooks/useCMSConfig';
import { logActivity } from '../lib/activityLogger';
import { useSettings } from '../contexts/SettingsContext';

export default function Register() {
  const { signInWithGoogle, loginWithMock } = useAuth();
  const navigate = useNavigate();
  const { config, loading: configLoading } = useCMSConfig();
  const { getFieldLabel, isFieldVisible, isFieldRequired, gotras, states } = useSettings();
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    password: '',
    gender: 'Male',
    gotra: 'Kaler',
    state: 'Punjab (ਪੰਜਾਬ)',
  });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [draftSaved, setDraftSaved] = useState(false);
  const [successRegistered, setSuccessRegistered] = useState(false);

  const handleRegister = async (e: FormEvent) => {
    e.preventDefault();
    try {
      setError('');
      setLoading(true);
      const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
      
      const profileRef = doc(db, 'profiles', userCredential.user.uid);
      await setDoc(profileRef, {
        userId: userCredential.user.uid,
        fullName: formData.fullName,
        gender: formData.gender,
        community: `Mahasha (${formData.gotra})`,
        gotra: formData.gotra,
        fatherGotra: formData.gotra,
        isVerified: false,
        isDraft: false,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await logActivity({
        type: 'registration',
        action: 'New Registration',
        details: `${formData.fullName} (${formData.gender}) from ${formData.gotra} gotra registered.`,
        performedBy: userCredential.user.uid,
        performedByName: formData.fullName,
        targetId: userCredential.user.uid
      });

      setSuccessRegistered(true);
      setTimeout(() => navigate('/dashboard'), 2000);
    } catch (err: any) {
      if (err.code === 'auth/operation-not-allowed') {
        // Fallback for AI Studio without Firebase Console access
        console.warn('Firebase Auth Disabled. Using local demo registration.');
        const mockUser = loginWithMock(formData.email);
        
        // Ensure profile is created even in demo mode (requires public write rules which we set)
        const mockUid = mockUser.uid;
        const profileRef = doc(db, 'profiles', mockUid);
        await setDoc(profileRef, {
          userId: mockUid,
          fullName: formData.fullName,
          gender: formData.gender,
          community: `Mahasha (${formData.gotra})`,
          gotra: formData.gotra,
          fatherGotra: formData.gotra,
          isVerified: false,
          isDraft: false,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });
        
        setSuccessRegistered(true);
        setTimeout(() => navigate('/dashboard'), 2000);
      } else {
        setError(err.message || 'Failed to register.');
      }
    } finally {
      setLoading(false);
    }
  };

  const handleSaveDraft = async () => {
    try {
      setError('');
      // If user provided email and password, create account and mark draft
      if (formData.email && formData.password) {
        setLoading(true);
        const userCredential = await createUserWithEmailAndPassword(auth, formData.email, formData.password);
        const profileRef = doc(db, 'profiles', userCredential.user.uid);
        await setDoc(profileRef, {
          userId: userCredential.user.uid,
          fullName: formData.fullName || 'Draft Candidate',
          gender: formData.gender,
          community: `Mahasha (${formData.gotra})`,
          gotra: formData.gotra,
          fatherGotra: formData.gotra,
          isVerified: false,
          isDraft: true,
          createdAt: serverTimestamp(),
          updatedAt: serverTimestamp(),
        });

        await logActivity({
          type: 'registration',
          action: 'Draft Profile Created',
          details: `${formData.fullName || 'Candidate'} saved their registration as a draft.`,
          performedBy: userCredential.user.uid,
          performedByName: formData.fullName || 'Draft User',
          targetId: userCredential.user.uid
        });

        setDraftSaved(true);
        setTimeout(() => navigate('/edit-profile'), 1000);
      } else {
        // Save to browser local storage so user doesn't lose inputs
        localStorage.setItem('matrimonial_registration_draft', JSON.stringify(formData));
        setDraftSaved(true);
        setTimeout(() => setDraftSaved(false), 3000);
      }
    } catch (err: any) {
      if (err.code === 'auth/operation-not-allowed') {
        setError('Draft saving failed: Email/Password sign-in is not enabled in your Firebase Console.');
      }
      // If account exists or auth fails, still preserve in local draft
      localStorage.setItem('matrimonial_registration_draft', JSON.stringify(formData));
      setDraftSaved(true);
      setTimeout(() => setDraftSaved(false), 3000);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    try {
      setError('');
      setLoading(true);
      await signInWithGoogle();
      navigate('/dashboard');
    } catch (err: any) {
      if (err.code === 'auth/operation-not-allowed') {
        setError('Google sign-in is not enabled in your Firebase Console. Please enable it in Authentication > Sign-in method.');
      } else {
        setError('Failed to sign in with Google.');
      }
    } finally {
      setLoading(false);
    }
  };

  if (configLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }

  if (config && !config.isRegistrationOpen) {
    return (
      <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-md mx-auto w-full bg-white p-10 rounded-3xl shadow-xl border border-rose-100 text-center flex flex-col items-center">
          <div className="w-20 h-20 bg-rose-50 rounded-full flex items-center justify-center mb-6">
            <AlertCircle className="w-10 h-10 text-rose-600" />
          </div>
          <h2 className="text-2xl font-bold text-rose-950 font-serif mb-4">ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਫਿਲਹਾਲ ਬੰਦ ਹੈ</h2>
          <p className="text-gray-600 mb-8 leading-relaxed">
            {config.announcementPa || 'ਸਾਈਟ ਉੱਤੇ ਨਵੀਂ ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਫਿਲਹਾਲ ਬੰਦ ਕੀਤੀ ਗਈ ਹੈ। ਕਿਰਪਾ ਕਰਕੇ ਕੁਝ ਸਮੇਂ ਬਾਅਦ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।'}
          </p>
          <Link 
            to="/" 
            className="w-full py-3 bg-rose-900 text-white rounded-xl font-bold hover:bg-rose-950 transition-all shadow-lg"
          >
            ਵਾਪਸ ਹੋਮਪੇਜ 'ਤੇ ਜਾਓ (Back to Home)
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <SEO 
        title="ਮੁਫ਼ਤ ਰਜਿਸਟ੍ਰੇਸ਼ਨ (Free Registration) - ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ"
        description="ਮਹਾਸ਼ਾ ਸਮਾਜ ਦੇ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਪੋਰਟਲ 'ਤੇ ਮੁਫ਼ਤ ਖਾਤਾ ਬਣਾਓ। ਲਾੜੇ ਅਤੇ ਲਾੜੀਆਂ ਲਈ 100% ਗੋਤਰ-ਅਧਾਰਿਤ ਪ੍ਰਮਾਣਿਤ ਰਿਸ਼ਤੇ।"
        keywords={['Mahasha matrimony registration', 'register mahasha matrimonial', 'free matrimony punjab', 'mahasha gotra shaadi']}
      />
      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <div className="flex justify-center mb-4">
          <AppLogo size="lg" variant="full" />
        </div>
        <div className="flex justify-center mb-2">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-rose-950 border border-amber-300">
            ਸਿਰਫ਼ ਮਹਾਸ਼ਾ ਸਮਾਜ ਲਈ (Exclusive Mahasha Samaj)
          </span>
        </div>
        <h2 className="mt-1 text-center text-2xl sm:text-3xl font-extrabold text-gray-900 font-serif">
          ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਅਕਾਊਂਟ ਬਣਾਓ
        </h2>
        <p className="mt-2 text-center text-sm text-gray-600">
          Already have an account?{' '}
          <Link to="/login" className="font-semibold text-rose-900 hover:text-rose-700">
            Sign in
          </Link>
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-white py-8 px-4 shadow-xl sm:rounded-2xl sm:px-10 border border-amber-100">
          
          {error && (
            <div className="mb-4 bg-rose-50 border border-rose-200 text-rose-700 px-4 py-3 rounded-lg text-sm">
              {error}
            </div>
          )}

          {draftSaved && (
            <div className="mb-4 bg-emerald-50 border border-emerald-300 text-emerald-800 px-4 py-3 rounded-lg text-sm flex items-center gap-2 animate-in fade-in">
              <Check className="w-4 h-4 text-emerald-600" />
              ਡਰਾਫਟ ਸੁਰੱਖਿਅਤ ਕਰ ਲਿਆ ਗਿਆ ਹੈ! (Draft saved successfully)
            </div>
          )}

          {successRegistered ? (
            <SuccessAnimation 
              isVisible={successRegistered} 
              containerClassName="bg-emerald-50 border border-emerald-300 text-emerald-800 px-6 py-12 rounded-2xl text-center flex flex-col items-center gap-4"
              message={
                  <>
                    <h3 className="text-xl font-bold">ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਸਫਲ!</h3>
                    <p className="text-sm">ਤੁਹਾਡਾ ਅਕਾਊਂਟ ਸਫਲਤਾਪੂਰਵਕ ਬਣ ਗਿਆ ਹੈ।</p>
                  </>
              }
            />
          ) : (
            <form className="space-y-6" onSubmit={handleRegister}>
            {isFieldVisible('fullName') && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  {getFieldLabel('fullName', 'pa')} ({getFieldLabel('fullName', 'en')}) {isFieldRequired('fullName') && <span className="text-red-600">*</span>}
                </label>
                <div className="mt-1">
                  <input
                    type="text"
                    required={isFieldRequired('fullName')}
                    value={formData.fullName}
                    onChange={(e) => setFormData({...formData, fullName: e.target.value})}
                    className="appearance-none block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                  />
                </div>
              </div>
            )}

            {isFieldVisible('gender') && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  {getFieldLabel('gender', 'pa')} ({getFieldLabel('gender', 'en')}) {isFieldRequired('gender') && <span className="text-red-600">*</span>}
                </label>
                <div className="mt-1">
                  <select
                    required={isFieldRequired('gender')}
                    value={formData.gender}
                    onChange={(e) => setFormData({...formData, gender: e.target.value})}
                    className="block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm bg-white"
                  >
                    <option value="Male">Male (ਲਾੜਾ / Groom)</option>
                    <option value="Female">Female (ਲਾੜੀ / Bride)</option>
                  </select>
                </div>
              </div>
            )}

            {isFieldVisible('gotra') && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  {getFieldLabel('gotra', 'pa')} ({getFieldLabel('gotra', 'en')}) {isFieldRequired('gotra') && <span className="text-red-600">*</span>}
                </label>
                <div className="mt-1">
                  <select
                    required={isFieldRequired('gotra')}
                    value={formData.gotra}
                    onChange={(e) => setFormData({...formData, gotra: e.target.value})}
                    className="block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm bg-white font-medium"
                  >
                    {gotras.map(g => (
                      <option key={g.value} value={g.value}>{g.label}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {isFieldVisible('state') && (
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  {getFieldLabel('state', 'pa')} ({getFieldLabel('state', 'en')}) {isFieldRequired('state') && <span className="text-red-600">*</span>}
                </label>
                <div className="mt-1">
                  <select
                    required={isFieldRequired('state')}
                    value={formData.state}
                    onChange={(e) => setFormData({...formData, state: e.target.value})}
                    className="block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm bg-white font-medium"
                  >
                    {states.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
              </div>
            )}
            
            <div>
              <label className="block text-sm font-medium text-gray-700">Email address</label>
              <div className="mt-1">
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="appearance-none block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700">Password</label>
              <div className="mt-1">
                <input
                  type="password"
                  required
                  value={formData.password}
                  onChange={(e) => setFormData({...formData, password: e.target.value})}
                  className="appearance-none block w-full px-3 py-2.5 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-amber-500 focus:border-amber-500 sm:text-sm"
                />
              </div>
            </div>

            <div className="space-y-2.5">
              <button
                type="submit"
                disabled={loading}
                className="w-full flex justify-center py-2.5 px-4 border border-transparent rounded-xl shadow-sm text-sm font-bold text-rose-950 bg-amber-500 hover:bg-amber-400 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-amber-500 disabled:opacity-50 transition-all shadow-amber-500/20"
              >
                {loading ? 'Creating Account...' : 'Register for Free (ਰਜਿਸਟਰੇਸ਼ਨ ਮੁਕੰਮਲ ਕਰੋ)'}
              </button>

              {/* Save as Draft Button */}
              <button
                type="button"
                onClick={handleSaveDraft}
                disabled={loading}
                className="w-full flex items-center justify-center gap-2 py-2 px-4 border border-gray-300 hover:border-amber-400 rounded-xl text-xs font-bold text-gray-700 hover:bg-amber-50/60 transition-all"
              >
                <Save className="w-3.5 h-3.5 text-amber-600" />
                ਡਰਾਫਟ ਵਜੋਂ ਸੁਰੱਖਿਅਤ ਕਰੋ (Save as Draft & Finish Later)
              </button>
            </div>
          </form>
          )}
  <div className="mt-6">
            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-gray-200" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-white text-gray-500">Or continue with</span>
              </div>
            </div>

            <div className="mt-6">
              <button
                onClick={handleGoogleLogin}
                disabled={loading}
                className="w-full flex justify-center py-2.5 px-4 border border-gray-300 rounded-xl shadow-sm bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500"
              >
                <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                  <path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
                  <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
                  <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z" />
                  <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
                  <path fill="none" d="M1 1h22v22H1z" />
                </svg>
                Sign in with Google
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

