import { useState, useEffect } from 'react';
import type { FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { Search, ShieldCheck, HeartHandshake, Sparkles, UserPlus } from 'lucide-react';
import CountingMetrics from '../components/CountingMetrics';
import SuccessStories from '../components/SuccessStories';
import SpecialSomeoneSteps from '../components/SpecialSomeoneSteps';
import RecentProfilesSection from '../components/RecentProfilesSection';
import { useLanguage } from '../contexts/LanguageContext';
import SEO from '../components/common/SEO';

const HOME_STRUCTURED_DATA = [
  {
    "@context": "https://schema.org",
    "@type": "WebSite",
    "name": "Mahasha Sangam Matrimonial",
    "url": "https://ais-dev-falywo4lgq7b5dzgshvz6m-254213925493.asia-southeast1.run.app",
    "potentialAction": {
      "@type": "SearchAction",
      "target": "https://ais-dev-falywo4lgq7b5dzgshvz6m-254213925493.asia-southeast1.run.app/matches?gotra={search_term_string}",
      "query-input": "required name=search_term_string"
    }
  },
  {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": [
      {
        "@type": "Question",
        "name": "ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਕੀ ਹੈ? (What is Mahasha Matrimonial?)",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "ਇਹ ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ ਲਈ ਸਮਰਪਿਤ ਇੱਕ ਵਿਸ਼ੇਸ਼ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਪੋਰਟਲ ਹੈ ਜਿੱਥੇ ਪੰਜਾਬ ਅਤੇ ਵਿਦੇਸ਼ਾਂ ਵਿੱਚ ਵਸਦੇ ਯੋਗ ਮਹਾਸ਼ਾ ਲਾੜੇ ਅਤੇ ਲਾੜੀਆਂ ਦੇ ਵੈਰੀਫਾਈਡ ਬਾਇਓਡਾਟਾ ਅਤੇ ਗੋਤਰ ਮਿਲਾਣ ਉਪਲਬਧ ਹਨ।"
        }
      },
      {
        "@type": "Question",
        "name": "ਕੀ ਮਹਾਸ਼ਾ ਗੋਤਰ ਮਿਲਾਣ ਦੀ ਸੁਵਿਧਾ ਉਪਲਬਧ ਹੈ?",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "ਹਾਂ, ਸਾਡੇ ਪੋਰਟਲ ਉੱਤੇ ਬਾਜਗਲ (ਭੋਗਲ), ਬੱਧਣ, ਕਲੇਰ, ਕੁੰਡਲ, ਸੰਧੂ, ਚਨਾਲੀਆ, ਫਾਂਗਲਾ, ਬੰਗੜ ਸਮੇਤ 60+ ਮਹਾਸ਼ਾ ਗੋਤਰਾਂ ਅਨੁਸਾਰ ਆਟੋਮੈਟਿਕ ਫਿਲਟਰ ਅਤੇ ਅਨੁਕੂਲਤਾ ਸਕੋਰਿੰਗ ਉਪਲਬਧ ਹੈ।"
        }
      }
    ]
  }
];

const WEDDING_IMAGES = [
  "https://images.unsplash.com/photo-1583939000140-5a507851a70c?q=80&w=1920&auto=format&fit=crop", // Mehndi/Hands
  "https://images.unsplash.com/photo-1610173827002-62c0f1f1d1eb?q=80&w=1920&auto=format&fit=crop", // Indian Couple
  "https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=1920&auto=format&fit=crop", // Indian Wedding Ceremony
  "https://images.unsplash.com/photo-1595922247653-9a3b68832a81?q=80&w=1920&auto=format&fit=crop", // Indian Bride
  "https://images.unsplash.com/photo-1611030799632-15fbeabdf3df?q=80&w=1920&auto=format&fit=crop", // Traditional Indian Bride
  "https://images.unsplash.com/photo-1587311820462-8e104e1da74d?q=80&w=1920&auto=format&fit=crop"  // Rituals / Flowers
];

export default function Home() {
  const navigate = useNavigate();
  const { t } = useLanguage();
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [searchGender, setSearchGender] = useState('Female');
  const [searchMinAge, setSearchMinAge] = useState('20');
  const [searchMaxAge, setSearchMaxAge] = useState('32');
  const [searchCommunity, setSearchCommunity] = useState('Select Community');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentImageIndex((prev) => (prev + 1) % WEDDING_IMAGES.length);
    }, 6000); // 6 seconds per slide for a premium slow feel
    return () => clearInterval(timer);
  }, []);

  const handleQuickSearch = (e: FormEvent) => {
    e.preventDefault();
    navigate('/matches', {
      state: {
        filters: {
          gender: searchGender,
          minAge: searchMinAge,
          maxAge: searchMaxAge,
          community: searchCommunity !== 'Select Community' ? searchCommunity : 'Any',
          religion: 'Any',
          location: '',
          profession: 'Any'
        }
      }
    });
  };

  return (
    <div className="min-h-screen bg-neutral-50 flex flex-col">
      <SEO 
        title="ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ - ਯੋਗ ਲਾੜੇ ਅਤੇ ਲਾੜੀਆਂ | Mahasha Matrimonial Punjab"
        description="ਮਹਾਸ਼ਾ ਸਮਾਜ (Mahasha Community) ਦਾ ਨੰਬਰ 1 ਭਰੋਸੇਯੋਗ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਪੋਰਟਲ। ਪੰਜਾਬ ਅਤੇ ਦੇਸ਼-ਵਿਦੇਸ਼ ਦੇ ਵੈਰੀਫਾਈਡ ਮਹਾਸ਼ਾ ਲਾੜੇ, ਲਾੜੀਆਂ ਅਤੇ ਗੋਤਰ ਮਿਲਾਣ ਦੇ ਸੰਪੂਰਨ ਬਾਇਓਡਾਟਾ।"
        keywords={['Mahasha matrimonial', 'Mahasha rishtey', 'punjabi mahasha gotra', 'punjab matrimonial', 'mahasha marriage bureau', 'bajgal gotra', 'badhan gotra', 'kaler gotra', 'kundal gotra']}
        structuredData={HOME_STRUCTURED_DATA}
      />

      {/* Hero Section */}
      <section className="relative pt-20 pb-32 lg:pt-32 lg:pb-48 overflow-hidden bg-rose-950">
        {/* Image Carousel */}
        {WEDDING_IMAGES.map((img, index) => (
          <div 
            key={img}
            className={`absolute inset-0 w-full h-full transition-all duration-1000 ease-in-out ${
              index === currentImageIndex ? 'opacity-100 scale-105' : 'opacity-0 scale-100'
            }`}
          >
            <img 
              src={img} 
              alt={`Indian Wedding Background ${index + 1}`} 
              className="w-full h-full object-cover object-center" 
              loading={index === 0 ? "eager" : "lazy"}
            />
          </div>
        ))}
        
        {/* Gradient Overlays for Readability - Royal Maroon & Gold blend */}
        <div className="absolute inset-0 bg-gradient-to-r from-rose-950/95 via-rose-900/80 to-rose-900/40 mix-blend-multiply" />
        <div className="absolute inset-0 bg-rose-950/40" />

        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-[20%] -right-[10%] w-[70%] h-[70%] rounded-full bg-amber-500/15 blur-3xl" />
          <div className="absolute -bottom-[20%] -left-[10%] w-[60%] h-[60%] rounded-full bg-rose-800/30 blur-3xl" />
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="inline-flex items-center gap-2 bg-rose-900/60 border border-amber-400/40 px-4 py-1.5 rounded-full text-xs font-bold text-amber-300 mb-6 backdrop-blur-sm shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-400" />
            <span>{t.heroBadge}</span>
          </div>

          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white font-serif mb-6 leading-tight">
            {t.heroTitle1} <br className="hidden md:block"/>
            <span className="text-amber-400">{t.heroTitleHighlight}</span>
          </h1>
          <p className="mt-4 max-w-2xl mx-auto text-lg md:text-xl text-rose-200/90 mb-10 leading-relaxed">
            {t.heroSubtitle}
          </p>
          
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Link 
              to="/register" 
              className="bg-amber-500 hover:bg-amber-400 text-rose-950 px-8 py-4 rounded-full font-bold text-lg transition-all shadow-lg shadow-amber-500/25 flex items-center justify-center gap-2"
            >
              <UserPlus className="w-5 h-5" />
              {t.heroRegisterBtn}
            </Link>
            <Link 
              to="/matches" 
              className="bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-amber-400/40 hover:border-amber-400 px-8 py-4 rounded-full font-bold text-lg transition-colors flex items-center justify-center gap-2"
            >
              <Search className="w-5 h-5" />
              {t.heroExploreBtn}
            </Link>
          </div>
        </div>
      </section>

      {/* Quick Search Widget */}
      <section className="max-w-5xl mx-auto px-4 -mt-16 relative z-10 w-full mb-12">
        <div className="bg-white rounded-2xl shadow-xl p-6 md:p-8 border border-amber-100">
          <h2 className="text-xl font-bold text-gray-800 mb-6 flex items-center gap-2">
            <Search className="w-5 h-5 text-rose-900" />
            {t.searchTitle}
          </h2>
          <form onSubmit={handleQuickSearch} className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t.searchLookingFor}</label>
              <select 
                value={searchGender}
                onChange={(e) => setSearchGender(e.target.value)}
                className="w-full border-gray-300 rounded-lg shadow-sm focus:border-amber-500 focus:ring-amber-500 p-2.5 bg-gray-50 border outline-none"
              >
                <option value="Female">{t.searchBride}</option>
                <option value="Male">{t.searchGroom}</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t.searchAge}</label>
              <div className="flex items-center gap-2">
                <select 
                  value={searchMinAge}
                  onChange={(e) => setSearchMinAge(e.target.value)}
                  className="w-full border-gray-300 rounded-lg shadow-sm p-2.5 bg-gray-50 border outline-none"
                >
                  <option value="18">18</option>
                  <option value="20">20</option>
                  <option value="22">22</option>
                  <option value="25">25</option>
                  <option value="28">28</option>
                </select>
                <span className="text-gray-400">to</span>
                <select 
                  value={searchMaxAge}
                  onChange={(e) => setSearchMaxAge(e.target.value)}
                  className="w-full border-gray-300 rounded-lg shadow-sm p-2.5 bg-gray-50 border outline-none"
                >
                  <option value="28">28</option>
                  <option value="30">30</option>
                  <option value="32">32</option>
                  <option value="35">35</option>
                  <option value="40">40</option>
                  <option value="50">50</option>
                </select>
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">{t.searchCommunity}</label>
              <select 
                value={searchCommunity}
                onChange={(e) => setSearchCommunity(e.target.value)}
                className="w-full border-gray-300 rounded-lg shadow-sm focus:border-amber-500 focus:ring-amber-500 p-2.5 bg-gray-50 border outline-none font-medium"
              >
                <option value="Select Community">{t.searchSelectCommunity}</option>
                <option value="Kaler">ਕਲੇਰ (Kaler)</option>
                <option value="Badhan">ਬੱਧਣ (Badhan)</option>
                <option value="Banga">ਬੰਗਾ (Banga)</option>
                <option value="Kundal">ਕੁੰਡਲ (Kundal)</option>
                <option value="Ghotra">ਘੋਤੜਾ (Ghotra)</option>
                <option value="Karloopia">ਕਰਲੂਪੀਆ (Karloopia)</option>
                <option value="Hans">ਹੰਸ (Hans)</option>
                <option value="Taak">ਟਾਕ (Taak)</option>
                <option value="Kajla">ਕਾਜਲਾ (Kajla)</option>
                <option value="Suman">ਸੁਮਨ (Suman)</option>
                <option value="Nahar">ਨਾਹਰ (Nahar)</option>
                <option value="Bhatti">ਭੱਟੀ (Bhatti)</option>
                <option value="Chumber">ਚੁੰਬਰ (Chumber)</option>
                <option value="Gill">ਗਿੱਲ (Gill)</option>
                <option value="Sandhu">ਸੰਧੂ (Sandhu)</option>
              </select>
            </div>
            <div className="flex items-end">
              <button type="submit" className="w-full bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30 p-2.5 rounded-lg font-bold transition-colors h-[46px] shadow-sm">
                {t.searchBtn}
              </button>
            </div>
          </form>
        </div>
      </section>

      {/* Recent Brides & Grooms Showcase with Privacy Blurred Photos */}
      <RecentProfilesSection />

      {/* Counting & Milestones Cards */}
      <CountingMetrics />

      {/* Find your Special Someone - 3 Step Guide */}
      <SpecialSomeoneSteps />

      {/* Features */}
      <section className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4 font-serif">{t.whyChooseTitle}</h2>
            <p className="text-gray-600 max-w-2xl mx-auto">{t.whyChooseSubtitle}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10">
            <div className="text-center p-6">
              <div className="bg-rose-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-rose-100">
                <ShieldCheck className="w-8 h-8 text-rose-900" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{t.feature1Title}</h3>
              <p className="text-gray-600">{t.feature1Desc}</p>
            </div>
            
            <div className="text-center p-6">
              <div className="bg-amber-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-amber-100">
                <Sparkles className="w-8 h-8 text-amber-600" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{t.feature2Title}</h3>
              <p className="text-gray-600">{t.feature2Desc}</p>
            </div>

            <div className="text-center p-6">
              <div className="bg-rose-50 w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-6 border border-rose-100">
                <HeartHandshake className="w-8 h-8 text-rose-900" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">{t.feature3Title}</h3>
              <p className="text-gray-600">{t.feature3Desc}</p>
            </div>
          </div>
        </div>
      </section>

      {/* Success Stories & Happy Couples */}
      <SuccessStories />
      
      {/* Stats */}
      <section className="py-20 bg-rose-950 text-white relative overflow-hidden border-t border-amber-500/20">
        <div className="absolute inset-0 opacity-10 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] mix-blend-overlay"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-amber-400 mb-2 font-serif">10K+</div>
              <div className="text-rose-200/90">Active Profiles</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-400 mb-2 font-serif">5K+</div>
              <div className="text-rose-200/90">Success Stories</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-400 mb-2 font-serif">100%</div>
              <div className="text-rose-200/90">Verified Users</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-amber-400 mb-2 font-serif">24/7</div>
              <div className="text-rose-200/90">Customer Support</div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
