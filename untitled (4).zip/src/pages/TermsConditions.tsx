import React from 'react';
import { useLanguage } from '../contexts/LanguageContext';
import { useCMSConfig } from '../hooks/useCMSConfig';
import SEO from '../components/common/SEO';
import { Shield, CheckCircle } from 'lucide-react';

export default function TermsConditions() {
  const { language } = useLanguage();
  const { config } = useCMSConfig();

  const siteNameEn = config?.siteNameEn || 'Mahasha Matrimonial';
  const siteNamePa = config?.siteNamePa || 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ';

  const content = {
    en: {
      title: 'Terms & Conditions',
      lastUpdated: 'Last Updated: September 2026',
      sections: [
        {
          heading: '1. Introduction',
          text: `Welcome to ${siteNameEn}. By accessing or using our website, you agree to be bound by these Terms and Conditions. This platform is exclusively designed for the Mahasha community to help families find suitable matches.`
        },
        {
          heading: '2. Eligibility',
          text: 'To register as a member, you must be of legal marriageable age as per the laws of India (currently, 18 years or over for females and 21 years or over for males). By using this site, you represent and warrant that you have the right, authority, and legal capacity to enter into this agreement.'
        },
        {
          heading: '3. Account Security & Verification',
          text: 'You are responsible for maintaining the confidentiality of your login credentials. All profiles are subject to manual verification by our admin team. We reserve the right to suspend or delete accounts that provide false information or violate our community guidelines.'
        },
        {
          heading: '4. Code of Conduct',
          text: 'Members must use this platform solely for matrimonial purposes. Any misuse, including sending abusive, obscene, or threatening messages, uploading inappropriate images, or using the platform for commercial solicitation, is strictly prohibited and will result in immediate termination.'
        },
        {
          heading: '5. Privacy',
          text: 'We are committed to protecting your privacy. Your personal information is handled in accordance with our Privacy Policy. Contact details are only shared with premium members or when explicitly approved by you.'
        },
        {
          heading: '6. Modifications to Terms',
          text: 'We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting on the website. Your continued use of the service signifies your acceptance of the updated terms.'
        }
      ]
    },
    pa: {
      title: 'ਨਿਯਮ ਅਤੇ ਸ਼ਰਤਾਂ',
      lastUpdated: 'ਆਖਰੀ ਅੱਪਡੇਟ: ਸਤੰਬਰ 2026',
      sections: [
        {
          heading: '1. ਜਾਣ-ਪਛਾਣ',
          text: `ਸਾਡੀ ਵੈੱਬਸਾਈਟ ${siteNamePa} 'ਤੇ ਤੁਹਾਡਾ ਸੁਆਗਤ ਹੈ। ਸਾਡੀ ਵੈੱਬਸਾਈਟ ਦੀ ਵਰਤੋਂ ਕਰਕੇ, ਤੁਸੀਂ ਇਹਨਾਂ ਨਿਯਮਾਂ ਅਤੇ ਸ਼ਰਤਾਂ ਨਾਲ ਸਹਿਮਤ ਹੁੰਦੇ ਹੋ। ਇਹ ਪਲੇਟਫਾਰਮ ਵਿਸ਼ੇਸ਼ ਤੌਰ 'ਤੇ ਮਹਾਸ਼ਾ ਭਾਈਚਾਰੇ ਲਈ ਢੁਕਵੇਂ ਰਿਸ਼ਤੇ ਲੱਭਣ ਲਈ ਬਣਾਇਆ ਗਿਆ ਹੈ।`
        },
        {
          heading: '2. ਯੋਗਤਾ',
          text: 'ਮੈਂਬਰ ਵਜੋਂ ਰਜਿਸਟਰ ਕਰਨ ਲਈ, ਤੁਹਾਡੀ ਉਮਰ ਭਾਰਤ ਦੇ ਕਾਨੂੰਨਾਂ ਅਨੁਸਾਰ ਵਿਆਹ ਦੇ ਯੋਗ ਹੋਣੀ ਚਾਹੀਦੀ ਹੈ (ਵਰਤਮਾਨ ਵਿੱਚ, ਕੁੜੀਆਂ ਲਈ 18 ਸਾਲ ਜਾਂ ਇਸ ਤੋਂ ਵੱਧ ਅਤੇ ਮੁੰਡਿਆਂ ਲਈ 21 ਸਾਲ ਜਾਂ ਇਸ ਤੋਂ ਵੱਧ)। ਇਸ ਸਾਈਟ ਦੀ ਵਰਤੋਂ ਕਰਕੇ, ਤੁਸੀਂ ਇਹ ਪੁਸ਼ਟੀ ਕਰਦੇ ਹੋ ਕਿ ਤੁਹਾਡੇ ਕੋਲ ਇਸ ਸਮਝੌਤੇ ਨੂੰ ਮੰਨਣ ਦਾ ਅਧਿਕਾਰ ਅਤੇ ਕਾਨੂੰਨੀ ਸਮਰੱਥਾ ਹੈ।'
        },
        {
          heading: '3. ਖਾਤੇ ਦੀ ਸੁਰੱਖਿਆ ਅਤੇ ਤਸਦੀਕ',
          text: 'ਤੁਸੀਂ ਆਪਣੇ ਲੌਗਇਨ ਵੇਰਵਿਆਂ ਦੀ ਗੁਪਤਤਾ ਬਣਾਈ ਰੱਖਣ ਲਈ ਜ਼ਿੰਮੇਵਾਰ ਹੋ। ਸਾਰੀਆਂ ਪ੍ਰੋਫਾਈਲਾਂ ਸਾਡੀ ਐਡਮਿਨ ਟੀਮ ਦੁਆਰਾ ਹੱਥੀਂ ਤਸਦੀਕ (Verify) ਕੀਤੀਆਂ ਜਾਂਦੀਆਂ ਹਨ। ਅਸੀਂ ਗਲਤ ਜਾਣਕਾਰੀ ਦੇਣ ਵਾਲੇ ਜਾਂ ਸਾਡੇ ਭਾਈਚਾਰੇ ਦੇ ਨਿਯਮਾਂ ਦੀ ਉਲੰਘਣਾ ਕਰਨ ਵਾਲੇ ਖਾਤਿਆਂ ਨੂੰ ਮੁਅੱਤਲ ਕਰਨ ਜਾਂ ਮਿਟਾਉਣ ਦਾ ਅਧਿਕਾਰ ਰਾਖਵਾਂ ਰੱਖਦੇ ਹਾਂ।'
        },
        {
          heading: '4. ਆਚਰਣ ਦੇ ਨਿਯਮ',
          text: 'ਮੈਂਬਰਾਂ ਨੂੰ ਇਸ ਪਲੇਟਫਾਰਮ ਦੀ ਵਰਤੋਂ ਸਿਰਫ਼ ਵਿਆਹ ਦੇ ਉਦੇਸ਼ਾਂ ਲਈ ਕਰਨੀ ਚਾਹੀਦੀ ਹੈ। ਕਿਸੇ ਵੀ ਤਰ੍ਹਾਂ ਦੀ ਦੁਰਵਰਤੋਂ, ਜਿਸ ਵਿੱਚ ਗਲਤ ਜਾਂ ਧਮਕੀ ਭਰੇ ਸੁਨੇਹੇ ਭੇਜਣਾ, ਅਣਉਚਿਤ ਤਸਵੀਰਾਂ ਅੱਪਲੋਡ ਕਰਨਾ ਸ਼ਾਮਲ ਹੈ, ਦੀ ਸਖ਼ਤ ਮਨਾਹੀ ਹੈ।'
        },
        {
          heading: '5. ਗੁਪਤਤਾ (Privacy)',
          text: 'ਅਸੀਂ ਤੁਹਾਡੀ ਗੁਪਤਤਾ ਦੀ ਰੱਖਿਆ ਕਰਨ ਲਈ ਵਚਨਬੱਧ ਹਾਂ। ਤੁਹਾਡੀ ਨਿੱਜੀ ਜਾਣਕਾਰੀ ਸਾਡੀ ਗੁਪਤਤਾ ਨੀਤੀ (Privacy Policy) ਦੇ ਅਨੁਸਾਰ ਸੰਭਾਲੀ ਜਾਂਦੀ ਹੈ। ਸੰਪਰਕ ਵੇਰਵੇ ਸਿਰਫ਼ ਤੁਹਾਡੀ ਮਨਜ਼ੂਰੀ ਤੋਂ ਬਾਅਦ ਹੀ ਸਾਂਝੇ ਕੀਤੇ ਜਾਂਦੇ ਹਨ।'
        },
        {
          heading: '6. ਨਿਯਮਾਂ ਵਿੱਚ ਬਦਲਾਅ',
          text: `ਅਸੀਂ ਕਿਸੇ ਵੀ ਸਮੇਂ ਇਹਨਾਂ ਨਿਯਮਾਂ ਨੂੰ ਬਦਲਣ ਦਾ ਅਧਿਕਾਰ ਰਾਖਵਾਂ ਰੱਖਦੇ ਹਾਂ। ਵੈੱਬਸਾਈਟ 'ਤੇ ਪੋਸਟ ਕਰਨ ਤੋਂ ਤੁਰੰਤ ਬਾਅਦ ਬਦਲਾਅ ਲਾਗੂ ਹੋਣਗੇ।`
        }
      ]
    },
    hi: {
      title: 'नियम एवं शर्तें',
      lastUpdated: 'अंतिम अपडेट: सितंबर 2026',
      sections: [
        {
          heading: '1. परिचय',
          text: `${siteNameEn} पर आपका स्वागत है। हमारी वेबसाइट का उपयोग करके, आप इन नियमों और शर्तों से सहमत होते हैं। यह मंच विशेष रूप से महाशा समुदाय के लिए उपयुक्त रिश्ते खोजने के लिए बनाया गया है।`
        },
        {
          heading: '2. योग्यता',
          text: 'सदस्य के रूप में पंजीकरण करने के लिए, भारत के कानूनों के अनुसार आपकी आयु विवाह योग्य होनी चाहिए (वर्तमान में, लड़कियों के लिए 18 वर्ष या उससे अधिक और लड़कों के लिए 21 वर्ष या उससे अधिक)। इस साइट का उपयोग करके, आप पुष्टि करते हैं कि आपके पास इस समझौते को स्वीकार करने का कानूनी अधिकार है।'
        },
        {
          heading: '3. खाता सुरक्षा और सत्यापन',
          text: 'आप अपने लॉगिन विवरण की गोपनीयता बनाए रखने के लिए जिम्मेदार हैं। सभी प्रोफाइल हमारी एडमिन टीम द्वारा मैन्युअल रूप से सत्यापित की जाती हैं। हम गलत जानकारी प्रदान करने वाले या हमारे समुदाय के दिशानिर्देशों का उल्लंघन करने वाले खातों को निलंबित या हटाने का अधिकार सुरक्षित रखते हैं।'
        },
        {
          heading: '4. आचरण के नियम',
          text: 'सदस्यों को इस मंच का उपयोग केवल विवाह के उद्देश्यों के लिए करना चाहिए। किसी भी प्रकार का दुरुपयोग, जिसमें अपमानजनक या धमकी भरे संदेश भेजना, अनुचित चित्र अपलोड करना शामिल है, सख्त वर्जित है।'
        },
        {
          heading: '5. गोपनीयता (Privacy)',
          text: 'हम आपकी गोपनीयता की रक्षा के लिए प्रतिबद्ध हैं। आपकी व्यक्तिगत जानकारी हमारी गोपनीयता नीति के अनुसार संभाली जाती है। संपर्क विवरण केवल आपकी स्पष्ट स्वीकृति के बाद ही साझा किए जाते हैं।'
        },
        {
          heading: '6. शर्तों में संशोधन',
          text: 'हम किसी भी समय इन शर्तों को संशोधित करने का अधिकार सुरक्षित रखते हैं। परिवर्तन वेबसाइट पर पोस्ट होने के तुरंत बाद प्रभावी होंगे।'
        }
      ]
    }
  };

  const currentContent = content[language as keyof typeof content] || content.en;

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <SEO 
        title={`${currentContent.title} - ${config?.siteNameEn || 'Mahasha Matrimonial'}`}
        description="Terms and conditions for using our matrimonial services."
      />

      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center p-3 bg-amber-100 rounded-full mb-4">
            <Shield className="w-8 h-8 text-amber-600" />
          </div>
          <h1 className="text-4xl font-extrabold text-gray-900 font-serif mb-4">
            {currentContent.title}
          </h1>
          <p className="text-gray-500 font-medium">
            {currentContent.lastUpdated}
          </p>
        </div>

        <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl border border-rose-100/50 space-y-10">
          {currentContent.sections.map((section, index) => (
            <div key={index} className="space-y-4">
              <h2 className="text-xl font-bold text-rose-950 flex items-center gap-2">
                <CheckCircle className="w-5 h-5 text-amber-500 shrink-0" />
                {section.heading}
              </h2>
              <p className="text-gray-600 leading-relaxed pl-7">
                {section.text}
              </p>
            </div>
          ))}

          <div className="mt-12 pt-8 border-t border-gray-100 pl-7">
            <p className="text-sm text-gray-500">
              {language === 'pa' 
                ? 'ਜੇਕਰ ਤੁਹਾਡੇ ਇਹਨਾਂ ਨਿਯਮਾਂ ਅਤੇ ਸ਼ਰਤਾਂ ਬਾਰੇ ਕੋਈ ਸਵਾਲ ਹਨ, ਤਾਂ ਕਿਰਪਾ ਕਰਕੇ ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ ਪੰਨੇ ਰਾਹੀਂ ਸੰਪਰਕ ਕਰੋ।' 
                : language === 'hi'
                ? 'यदि इन नियमों और शर्तों के बारे में आपके कोई प्रश्न हैं, तो कृपया हमसे संपर्क करें पृष्ठ के माध्यम से संपर्क करें।'
                : 'If you have any questions about these Terms and Conditions, please contact us via the Contact Us page.'}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
