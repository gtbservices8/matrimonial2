import { useEffect, useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useNotifications } from '../contexts/NotificationContext';
import { useLanguage } from '../contexts/LanguageContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { 
  UserCircle, Heart, Mail, Eye, Star, Settings, Bell, 
  Sparkles, MessageSquare, ArrowRight, ShieldCheck, CheckCheck
} from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import SearchSidebar, { FilterState } from '../components/SearchSidebar';
import NotificationCard from '../components/notifications/NotificationCard';
import SEO from '../components/common/SEO';
import { DashboardSkeleton } from '../components/common/Skeleton';

export default function Dashboard() {
  const { user } = useAuth();
  const { notifications, unreadCount, simulateNotification, markAllAsRead } = useNotifications();
  const { language } = useLanguage();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [activeNotifTab, setActiveNotifTab] = useState<'all' | 'match' | 'message_request' | 'activity'>('all');
  
  const [searchFilters, setSearchFilters] = useState<FilterState>({
    gender: 'Any',
    minAge: '18',
    maxAge: '50',
    location: '',
    community: 'Any',
    profession: [],
    educationLevel: [],
    district: []
  });

  const handleFilterChange = (e: ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setSearchFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleMultiChange = (name: string, value: string, checked: boolean) => {
    setSearchFilters(prev => {
        const current = (prev[name as keyof FilterState] as string[]) || [];
        if (checked) {
            return { ...prev, [name]: [...current, value] };
        } else {
            return { ...prev, [name]: current.filter(v => v !== value) };
        }
    });
  };

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    navigate('/matches', { state: { filters: searchFilters } });
  };

  useEffect(() => {
    async function fetchProfile() {
      if (user) {
        try {
          const profileRef = doc(db, 'profiles', user.uid);
          const snap = await getDoc(profileRef);
          if (snap.exists()) {
            setProfile(snap.data());
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `profiles/${user.uid}`);
        } finally {
          setLoading(false);
        }
      }
    }
    fetchProfile();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <DashboardSkeleton />
        </div>
      </div>
    );
  }

  // Filter top dashboard notifications
  const dashboardNotifications = notifications.filter(item => {
    if (activeNotifTab === 'all') return true;
    return item.category === activeNotifTab;
  }).slice(0, 4);

  const matchAlertsCount = notifications.filter(n => n.category === 'match').length;
  const messageRequestsCount = notifications.filter(n => n.category === 'message_request').length;

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <SEO 
        title="ਮੇਰਾ ਡੈਸ਼ਬੋਰਡ (My Dashboard) - Mahasha Matrimonial"
        description="ਪ੍ਰੋਫਾਈਲ ਵੇਰਵੇ, ਮੈਚ ਅਨੁਕੂਲਤਾ, ਗੋਤਰ ਸਿਫ਼ਾਰਸ਼ਾਂ ਅਤੇ ਤਾਜ਼ਾ ਸੂਚਨਾਵਾਂ।"
        noIndex={true}
      />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Draft Notice Banner */}
        {profile?.isDraft && (
          <div className="mb-6 p-4 sm:p-5 rounded-2xl bg-gradient-to-r from-purple-50 via-amber-50/60 to-purple-50 border-2 border-purple-200 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-start sm:items-center gap-3.5">
              <div className="p-2.5 bg-purple-100 rounded-xl text-purple-800 shrink-0">
                <Settings className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-sm sm:text-base font-bold text-purple-950">
                  ਤੁਹਾਡੀ ਪ੍ਰੋਫਾਈਲ ਡਰਾਫਟ (ਅਧੂਰੀ) ਸਥਿਤੀ ਵਿੱਚ ਹੈ (Profile is Saved as Draft)
                </h3>
                <p className="text-xs sm:text-sm text-purple-700">
                  ਬਾਇਓਡਾਟਾ ਪੂਰਾ ਭਰੋ ਅਤੇ ਪ੍ਰਕਾਸ਼ਿਤ (Publish) ਕਰੋ ਤਾਂ ਜੋ ਹੋਰ ਮੈਂਬਰ ਤੁਹਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰ ਸਕਣ।
                </p>
              </div>
            </div>
            <Link
              to="/profile/edit"
              className="px-5 py-2.5 bg-purple-800 hover:bg-purple-900 text-white rounded-xl text-xs sm:text-sm font-bold shadow-xs whitespace-nowrap"
            >
              ਫਾਰਮ ਪੂਰਾ ਕਰੋ (Resume & Complete)
            </Link>
          </div>
        )}

        {/* Welcome Section */}
        <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-6 md:p-8 mb-8">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-24 h-24 bg-rose-100 rounded-2xl flex items-center justify-center flex-shrink-0 border border-amber-200 overflow-hidden">
              {(profile?.photoUrls && profile.photoUrls.length > 0) ? (
                <img src={profile.photoUrls[0]} alt="Avatar" className="w-full h-full object-cover" />
              ) : profile?.photoUrl ? (
                <img src={profile.photoUrl} alt="Avatar" className="w-full h-full object-cover" />
              ) : (
                <UserCircle className="w-16 h-16 text-rose-900" />
              )}
            </div>
            <div className="flex-1 text-center md:text-left">
              <div className="flex flex-wrap items-center justify-center md:justify-start gap-2 mb-1">
                <h1 className="text-2xl md:text-3xl font-bold text-gray-900 font-serif">
                  Welcome back, {profile?.fullName || user?.email?.split('@')[0]}!
                </h1>
                {profile?.isDraft ? (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-purple-100 text-purple-800 font-bold border border-purple-200">
                    Draft Profile
                  </span>
                ) : (
                  <span className="text-xs px-2.5 py-0.5 rounded-full bg-emerald-100 text-emerald-800 font-bold border border-emerald-200 flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    Verified Active
                  </span>
                )}
              </div>
              <p className="text-gray-600 mt-2">
                Your profile is {profile?.profileCompletion || 20}% complete. Complete all gotra details for 4x more responses.
              </p>
              
              <div className="mt-4 w-full max-w-md bg-gray-200 rounded-full h-2.5 overflow-hidden">
                <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: `${profile?.profileCompletion || 20}%` }}></div>
              </div>
            </div>
            <div className="flex gap-3">
              <Link to="/profile/edit" className="bg-rose-900 text-white px-6 py-2.5 rounded-xl font-bold hover:bg-rose-800 transition-colors border border-amber-500/30 shadow-xs">
                {profile?.isDraft ? 'Resume Form (ਜਾਰੀ ਰੱਖੋ)' : 'Edit Profile'}
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 sm:gap-6 mb-8">
          
          <Link to="/notifications" className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center gap-4 hover:shadow-md hover:border-amber-300 transition-all group">
            <div className="bg-rose-50 p-3 rounded-xl border border-rose-100 group-hover:bg-rose-100 transition-colors">
              <Eye className="w-6 h-6 text-rose-900" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900 font-serif">124</div>
              <div className="text-xs sm:text-sm text-gray-600">Profile Views</div>
            </div>
          </Link>
          
          <Link to="/notifications" className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center gap-4 hover:shadow-md hover:border-amber-300 transition-all group">
            <div className="bg-amber-50 p-3 rounded-xl border border-amber-100 group-hover:bg-amber-100 transition-colors">
              <Sparkles className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900 font-serif">{matchAlertsCount}</div>
              <div className="text-xs sm:text-sm text-gray-600">Gotra Matches</div>
            </div>
          </Link>

          <Link to="/notifications" className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center gap-4 hover:shadow-md hover:border-rose-300 transition-all group">
            <div className="bg-rose-50 p-3 rounded-xl border border-rose-100 group-hover:bg-rose-100 transition-colors">
              <MessageSquare className="w-6 h-6 text-rose-900" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900 font-serif">{messageRequestsCount}</div>
              <div className="text-xs sm:text-sm text-gray-600">Message Requests</div>
            </div>
          </Link>

          <Link to="/notifications" className="bg-white p-5 rounded-2xl shadow-xs border border-gray-200 flex items-center gap-4 hover:shadow-md hover:border-amber-300 transition-all group">
            <div className="bg-amber-50 p-3 rounded-xl border border-amber-100 group-hover:bg-amber-100 transition-colors">
              <Bell className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900 font-serif">{unreadCount}</div>
              <div className="text-xs sm:text-sm text-gray-600">Unread Alerts</div>
            </div>
          </Link>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            
            {/* IN-APP NOTIFICATIONS & ACTIVITY HUB WIDGET */}
            <div className="bg-white rounded-3xl shadow-sm border-2 border-amber-300/70 p-6 overflow-hidden">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 mb-5 pb-4 border-b border-gray-100">
                <div className="flex items-center gap-2.5">
                  <div className="p-2 bg-gradient-to-br from-amber-500 to-rose-600 rounded-xl text-white shadow-xs">
                    <Bell className="w-5 h-5" />
                  </div>
                  <div>
                    <h2 className="text-lg sm:text-xl font-bold text-gray-900 font-serif flex items-center gap-2">
                      <span>{language === 'pa' ? 'ਤਾਜ਼ਾ ਸੂਚਨਾਵਾਂ ਅਤੇ ਗਤੀਵਿਧੀ' : 'In-App Alerts & Activity Updates'}</span>
                      {unreadCount > 0 && (
                        <span className="bg-amber-400 text-rose-950 text-xs px-2.5 py-0.5 rounded-full font-extrabold shadow-2xs">
                          {unreadCount} {language === 'pa' ? 'ਨਵੀਆਂ' : 'New'}
                        </span>
                      )}
                    </h2>
                    <p className="text-xs text-gray-500">
                      {language === 'pa' ? 'ਨਵੇਂ ਮੈਚ, ਸੁਨੇਹਾ ਬੇਨਤੀਆਂ ਅਤੇ ਪ੍ਰੋਫਾਈਲ ਅਪਡੇਟਸ' : 'Live alerts for new matches, family chat requests & profile views'}
                    </p>
                  </div>
                </div>

                <div className="flex items-center gap-2">
                  {unreadCount > 0 && (
                    <button
                      type="button"
                      onClick={markAllAsRead}
                      className="text-xs font-bold text-rose-900 hover:text-rose-700 flex items-center gap-1 bg-rose-50 px-2.5 py-1 rounded-lg border border-rose-200"
                    >
                      <CheckCheck className="w-3.5 h-3.5" />
                      <span>{language === 'pa' ? 'ਸਭ ਪੜ੍ਹੋ' : 'Mark all read'}</span>
                    </button>
                  )}
                  <Link 
                    to="/notifications" 
                    className="text-xs font-bold text-rose-950 hover:text-rose-800 bg-amber-100 hover:bg-amber-200 px-3 py-1.5 rounded-lg border border-amber-300 transition-colors flex items-center gap-1"
                  >
                    <span>{language === 'pa' ? 'ਸਭ ਵੇਖੋ' : 'View Hub'}</span>
                    <ArrowRight className="w-3 h-3" />
                  </Link>
                </div>
              </div>

              {/* Category Filter Tabs */}
              <div className="flex items-center gap-1.5 mb-4 bg-gray-100/80 p-1 rounded-xl text-xs overflow-x-auto">
                <button
                  type="button"
                  onClick={() => setActiveNotifTab('all')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all whitespace-nowrap ${
                    activeNotifTab === 'all'
                      ? 'bg-white text-rose-950 shadow-xs'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  {language === 'pa' ? 'ਸਾਰੀਆਂ ਸੂਚਨਾਵਾਂ' : 'All Alerts'}
                </button>
                <button
                  type="button"
                  onClick={() => setActiveNotifTab('match')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1 whitespace-nowrap ${
                    activeNotifTab === 'match'
                      ? 'bg-white text-rose-950 shadow-xs'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Sparkles className="w-3 h-3 text-amber-600" />
                  <span>{language === 'pa' ? 'ਮੈਚ ਅਲਰਟ' : 'Matches'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveNotifTab('message_request')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1 whitespace-nowrap ${
                    activeNotifTab === 'message_request'
                      ? 'bg-white text-rose-950 shadow-xs'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <MessageSquare className="w-3 h-3 text-rose-600" />
                  <span>{language === 'pa' ? 'ਸੁਨੇਹਾ ਬੇਨਤੀਆਂ' : 'Requests'}</span>
                </button>
                <button
                  type="button"
                  onClick={() => setActiveNotifTab('activity')}
                  className={`px-3 py-1.5 rounded-lg font-bold transition-all flex items-center gap-1 whitespace-nowrap ${
                    activeNotifTab === 'activity'
                      ? 'bg-white text-rose-950 shadow-xs'
                      : 'text-gray-600 hover:text-gray-900'
                  }`}
                >
                  <Eye className="w-3 h-3 text-emerald-600" />
                  <span>{language === 'pa' ? 'ਗਤੀਵਿਧੀ' : 'Activity'}</span>
                </button>
              </div>

              {/* Notification Cards List */}
              <div className="space-y-3">
                {dashboardNotifications.length === 0 ? (
                  <div className="text-center py-8 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                    <p className="text-xs text-gray-500">
                      {language === 'pa' ? 'ਕੋਈ ਨੋਟੀਫਿਕੇਸ਼ਨ ਨਹੀਂ ਮਿਲੀ' : 'No notifications in this category.'}
                    </p>
                  </div>
                ) : (
                  dashboardNotifications.map(notif => (
                    <NotificationCard 
                      key={notif.id} 
                      notification={notif}
                      compact={true} 
                    />
                  ))
                )}
              </div>

              {/* Simulator Action Row */}
              <div className="mt-4 pt-3 border-t border-gray-100 flex flex-wrap items-center justify-between gap-2">
                <span className="text-[11px] font-bold text-gray-500">
                  {language === 'pa' ? 'ਲਾਈਵ ਟੈਸਟ ਅਲਰਟ (Live Test):' : 'Trigger Live Test Alert:'}
                </span>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => simulateNotification('match')}
                    className="px-2.5 py-1 bg-amber-100 hover:bg-amber-200 text-rose-950 text-[11px] font-bold rounded-lg border border-amber-300 transition-colors"
                  >
                    + 🔥 Match
                  </button>
                  <button
                    type="button"
                    onClick={() => simulateNotification('message_request')}
                    className="px-2.5 py-1 bg-rose-100 hover:bg-rose-200 text-rose-900 text-[11px] font-bold rounded-lg border border-rose-300 transition-colors"
                  >
                    + 💌 Message
                  </button>
                  <button
                    type="button"
                    onClick={() => simulateNotification('activity')}
                    className="px-2.5 py-1 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-[11px] font-bold rounded-lg border border-emerald-300 transition-colors"
                  >
                    + 👁️ View
                  </button>
                </div>
              </div>
            </div>

            {/* Recommended Matches Section */}
            <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <div>
                  <h2 className="text-xl font-bold text-gray-900 font-serif">Recommended Matches</h2>
                  <p className="text-xs text-gray-500">Curated profiles based on Gotra compatibility and location</p>
                </div>
                <Link to="/matches" className="text-rose-900 font-bold hover:text-rose-700 text-sm">View All</Link>
              </div>
              
              <div className="text-center py-10 bg-gray-50 rounded-2xl border border-gray-200 border-dashed">
                <Heart className="w-10 h-10 text-amber-500 mx-auto mb-2" />
                <h3 className="text-base font-bold text-gray-900 font-serif">Search Verified Profiles</h3>
                <p className="text-xs text-gray-500 max-w-sm mx-auto mt-1">
                  Discover prospective brides and grooms from the Mahasha community with verified gotra attributes.
                </p>
                <Link to="/matches" className="mt-4 inline-block bg-rose-900 text-amber-300 border border-amber-500/30 px-6 py-2.5 rounded-xl font-bold hover:bg-rose-800 transition-colors shadow-xs text-xs">
                  Browse All Matches (ਰਿਸ਼ਤੇ ਵੇਖੋ)
                </Link>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <SearchSidebar 
              filters={searchFilters}
              onChange={handleFilterChange}
              onMultiChange={handleMultiChange}
              onSearch={handleSearch}
              buttonLabel="Search Matches"
            />
            
            <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-lg font-bold text-gray-900 font-serif mb-4">Quick Actions</h2>
              <div className="space-y-2">
                <Link to="/profile/edit" className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-rose-50 text-left border border-transparent hover:border-rose-100 transition-colors">
                  <span className="font-semibold text-xs text-gray-700 flex items-center gap-3">
                    <UserCircle className="w-4 h-4 text-rose-900" /> Edit Profile Details
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-gray-400" />
                </Link>
                <Link to="/notifications" className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-amber-50 text-left border border-transparent hover:border-amber-100 transition-colors">
                  <span className="font-semibold text-xs text-gray-700 flex items-center gap-3">
                    <Bell className="w-4 h-4 text-amber-600" /> In-App Notification Hub
                  </span>
                  <span className="text-[10px] font-bold bg-amber-200 text-rose-950 px-2 py-0.5 rounded-full">
                    {unreadCount} New
                  </span>
                </Link>
                <Link to="/matches" className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-rose-50 text-left border border-transparent hover:border-rose-100 transition-colors">
                  <span className="font-semibold text-xs text-gray-700 flex items-center gap-3">
                    <Heart className="w-4 h-4 text-rose-600" /> Gotra Compatibility Matcher
                  </span>
                  <ArrowRight className="w-3.5 h-3.5 text-gray-400" />
                </Link>
              </div>
            </div>
            
            {/* Status Card */}
            <div className="bg-gradient-to-br from-rose-950 via-rose-900 to-amber-950 rounded-3xl shadow-md p-6 text-white border border-amber-500/30">
              <div className="flex items-center gap-2 mb-2">
                <ShieldCheck className="w-5 h-5 text-amber-400" />
                <h3 className="font-bold font-serif text-amber-300">Mahasha Verification Status</h3>
              </div>
              <p className="text-rose-100 text-xs mb-4 leading-relaxed">
                {profile?.isVerified 
                  ? "Your profile is officially verified. You receive top ranking in search results and match notifications." 
                  : "Verify your Mahasha community details to earn the Trust Seal and receive instant high-compatibility match alerts."}
              </p>
              {!profile?.isVerified && (
                <Link 
                  to="/profile/edit"
                  className="w-full block text-center bg-gradient-to-r from-amber-500 to-amber-600 text-rose-950 py-2.5 rounded-xl text-xs font-extrabold hover:from-amber-400 hover:to-amber-500 transition-all shadow-xs"
                >
                  Complete Verification Details
                </Link>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
