import { useState, useEffect, useMemo } from 'react';
import { collection, query, limit, getDocs, DocumentData } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { 
  UserCircle, ChevronRight, Sparkles, Filter, 
  RotateCcw, SlidersHorizontal, BookOpen, GraduationCap, Briefcase, MapPin
} from 'lucide-react';
import { useLocation } from 'react-router-dom';
import type { ProfileData } from '../types';
import type { FilterCriteria } from '../types/filters';
import { DEFAULT_FILTERS } from '../types/filters';
import { filterAndSortProfiles, countActiveFilters } from '../utils/filterMatches';
import AdvancedFilterSidebar from '../components/matches/AdvancedFilterSidebar';
import MatchesTopBar from '../components/matches/MatchesTopBar';
import MatchCard from '../components/matches/MatchCard';
import SEO from '../components/common/SEO';
import { useLanguage } from '../contexts/LanguageContext';
import { MatchCardSkeleton } from '../components/common/Skeleton';

// Comprehensive Mahasha community showcase profiles covering diverse educations, careers, and regions
const MAHASHA_SHOWCASE_PROFILES: ProfileData[] = [
  {
    id: 'rec-advocate',
    fullName: 'Navpreet Kaur Bajgal',
    gender: 'Female',
    age: 26,
    height: "5'4\" (162 cm)",
    complexion: 'Fair (ਗੋਰਾ)',
    birthPlace: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    birthTime: '10:15 AM',
    district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Civil Lines, Gurdaspur, Punjab',
    religion: 'Hindu',
    community: 'Mahasha (Bajgal)',
    fatherGotra: 'Bajgal (Bhogal)',
    motherGotra: 'Ghangla',
    qualification1: 'Computer Engineering Diploma',
    qualification2: 'BA.LLB',
    qualification3: 'LLM (Criminology)',
    education: 'LLM (Criminology) & BA.LLB',
    profession: 'Advocate / Lawyer',
    occupationDetails: 'Now practicing as an Advocate with her mother & preparation of PCS (J)',
    income: '10-20 Lakhs',
    fatherOccupation: '(Expire) Retired cashier from CPWD',
    motherOccupation: 'Advocate',
    brotherDetails: 'Advocate',
    sisterDetails: 'None',
    familyType: 'Nuclear Family',
    maritalStatus: 'Never Married',
    contactNumber: '+91 98765 43210',
    alternateContact: '+91 98123 45678',
    aboutMe: 'Practicing Advocate at District Courts with deep respect for family traditions and high academic aspirations for Judicial Services PCS(J). Looking for an educated, understanding partner from Mahasha community.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 100
  },
  {
    id: 'rec-1',
    fullName: 'Simranjit Kaur Kaler',
    gender: 'Female',
    age: 26,
    height: "5'4\" (162 cm)",
    complexion: 'Very Fair',
    birthPlace: 'Jalandhar',
    district: 'SAS Nagar / Mohali (ਮੋਹਾਲੀ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Sector 70, Mohali / Chandigarh',
    religion: 'Hindu',
    community: 'Mahasha (Kaler)',
    fatherGotra: 'Kaler',
    motherGotra: 'Badhan',
    qualification1: 'B.Tech CSE (Computer Science)',
    qualification2: 'Executive MBA',
    education: 'B.Tech Computer Science & MBA',
    profession: 'Software Engineer',
    occupationDetails: 'Senior Tech Lead at MNC in Mohali IT Park',
    income: '20-50 Lakhs',
    fatherOccupation: 'Executive Engineer (Retd)',
    motherOccupation: 'School Principal',
    familyType: 'Nuclear',
    maritalStatus: 'Never Married',
    contactNumber: '+91 98111 22334',
    aboutMe: 'Working as a Senior Software Engineer in Mohali. Enjoys travel and values cultural heritage.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1595922247653-9a3b68832a81?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 95
  },
  {
    id: 'rec-2',
    fullName: 'Gurinder Singh Badhan',
    gender: 'Male',
    age: 28,
    height: "5'11\" (180 cm)",
    complexion: 'Fair',
    birthPlace: 'Amritsar',
    district: 'Amritsar (ਅੰਮ੍ਰਿਤਸਰ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Amritsar ↔ Toronto (Ontario, Canada)',
    religion: 'Sikh',
    community: 'Mahasha (Badhan)',
    fatherGotra: 'Badhan',
    motherGotra: 'Kundal',
    qualification1: 'B.Tech CSE (Guru Nanak Dev University)',
    qualification2: 'M.S. in Computer Science (University of Toronto)',
    education: 'M.S. in Computer Science',
    profession: 'Software Engineer',
    occupationDetails: 'Senior Data Scientist at Cloud AI Corp, Toronto. PR Holder.',
    income: 'NRI $100k+',
    fatherOccupation: 'Senior Superintendent (Customs)',
    motherOccupation: 'Homemaker',
    familyType: 'Joint',
    maritalStatus: 'Never Married',
    contactNumber: '+1 416-555-0199',
    aboutMe: 'Canadian Permanent Resident working in Toronto. Strong roots in Amritsar. Seeking a progressive life partner.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1610173827002-62c0f1f1d1eb?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 100
  },
  {
    id: 'rec-3',
    fullName: 'Dr. Rohan Banga (MBBS, MD)',
    gender: 'Male',
    age: 30,
    height: "5'10\" (178 cm)",
    complexion: 'Wheatish',
    birthPlace: 'Jalandhar',
    district: 'Jalandhar (ਜਲੰਧਰ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Model Town, Jalandhar, Punjab',
    religion: 'Hindu',
    community: 'Mahasha (Banga)',
    fatherGotra: 'Banga',
    motherGotra: 'Ghotra',
    qualification1: 'MBBS (Govt Medical College)',
    qualification2: 'MD Medicine (AIIMS)',
    education: 'MD Medicine & MBBS',
    profession: 'Doctor / Medical',
    occupationDetails: 'Consultant Physician at Super Specialty Hospital, Jalandhar',
    income: '20-50 Lakhs',
    fatherOccupation: 'Senior Medical Officer (SMO Retd)',
    motherOccupation: 'Professor in Botany',
    familyType: 'Nuclear',
    maritalStatus: 'Never Married',
    contactNumber: '+91 98450 11223',
    aboutMe: 'Medical Doctor practicing in Jalandhar. Values compassion, family warmth, and professional excellence.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 95
  },
  {
    id: 'rec-4',
    fullName: 'Manpreet Kaur Kundal',
    gender: 'Female',
    age: 27,
    height: "5'5\" (165 cm)",
    complexion: 'Fair',
    birthPlace: 'Hoshiarpur',
    district: 'Hoshiarpur (ਹੁਸ਼ਿਆਰਪੁਰ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Hoshiarpur, Punjab',
    religion: 'Hindu',
    community: 'Mahasha (Kundal)',
    fatherGotra: 'Kundal',
    motherGotra: 'Karloopia',
    qualification1: 'B.Com (Hons)',
    qualification2: 'Chartered Accountant (ICAI)',
    education: 'Chartered Accountant (CA)',
    profession: 'Chartered Accountant (CA)',
    occupationDetails: 'Senior Audit Manager at Big-4 Accounting Firm, Chandigarh',
    income: '10-20 Lakhs',
    fatherOccupation: 'Bank Branch Manager (Retd)',
    motherOccupation: 'Government Teacher',
    familyType: 'Nuclear',
    maritalStatus: 'Never Married',
    contactNumber: '+91 98222 33445',
    aboutMe: 'Chartered Accountant with a modern outlook and deep cultural values. Seeking a well-settled partner.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1580489944761-15a19d654956?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 100
  },
  {
    id: 'rec-5',
    fullName: 'Er. Vikramjeet Singh Hans',
    gender: 'Male',
    age: 29,
    height: "6'0\" (183 cm)",
    complexion: 'Fair',
    birthPlace: 'Ludhiana',
    district: 'Ludhiana (ਲੁਧਿਆਣਾ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Sarabha Nagar, Ludhiana',
    religion: 'Sikh',
    community: 'Mahasha (Hans)',
    fatherGotra: 'Hans',
    motherGotra: 'Taak',
    qualification1: 'B.Tech Mechanical Engineering',
    qualification2: 'MBA in Operations',
    education: 'B.Tech & MBA',
    profession: 'Business / Trader',
    occupationDetails: 'Managing Director at Hans Industrial Components & Export Corporation',
    income: '50 Lakhs+',
    fatherOccupation: 'Industrialist / Business Owner',
    motherOccupation: 'Homemaker',
    familyType: 'Joint',
    maritalStatus: 'Never Married',
    contactNumber: '+91 98777 88990',
    aboutMe: 'Industrial entrepreneur in Ludhiana managing family engineering manufacturing firm. Seeking an educated match.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 90
  },
  {
    id: 'rec-6',
    fullName: 'Pooja Karloopia (PCS Aspirant)',
    gender: 'Female',
    age: 25,
    height: "5'3\" (160 cm)",
    complexion: 'Fair',
    birthPlace: 'Pathankot',
    district: 'Pathankot (ਪਠਾਨਕੋਟ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Pathankot ↔ Chandigarh',
    religion: 'Hindu',
    community: 'Mahasha (Karloopia)',
    fatherGotra: 'Karloopia',
    motherGotra: 'Kajla',
    qualification1: 'B.A. Public Administration (Gold Medalist)',
    qualification2: 'M.A. Political Science',
    education: 'M.A. Political Science & Civil Prep',
    profession: 'Civil Services',
    occupationDetails: 'Punjab Civil Services (PCS / Allied) Candidate & Research Scholar',
    income: '5-10 Lakhs',
    fatherOccupation: 'SDO Punjab Irrigation Dept',
    motherOccupation: 'Headmistress',
    familyType: 'Nuclear',
    maritalStatus: 'Never Married',
    contactNumber: '+91 98333 44556',
    aboutMe: 'Dedicated academic scholar preparing for Civil Services. Looking for an understanding partner from Mahasha community.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 95
  },
  {
    id: 'rec-7',
    fullName: 'Harmandeep Singh Ghotra',
    gender: 'Male',
    age: 27,
    height: "5'9\" (175 cm)",
    complexion: 'Wheatish',
    birthPlace: 'Batala, Gurdaspur',
    district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    state: 'Punjab (ਪੰਜਾਬ)',
    location: 'Batala, Gurdaspur, Punjab',
    religion: 'Sikh',
    community: 'Mahasha (Ghotra)',
    fatherGotra: 'Ghotra',
    motherGotra: 'Bajgal (Bhogal)',
    qualification1: 'B.Sc Agriculture (PAU Ludhiana)',
    qualification2: 'M.Sc Agronomy',
    education: 'M.Sc Agriculture',
    profession: 'Government Job',
    occupationDetails: 'Agriculture Development Officer (ADO) in Punjab Govt',
    income: '10-20 Lakhs',
    fatherOccupation: 'Inspector in Punjab Police (Retd)',
    motherOccupation: 'Homemaker',
    familyType: 'Joint',
    maritalStatus: 'Never Married',
    contactNumber: '+91 98888 77665',
    aboutMe: 'Class-1 Officer in Punjab Agriculture Department posted in Majha region. Deep family values.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=600&auto=format&fit=crop',
    profileCompletion: 95
  }
];

export default function Matches() {
  const location = useLocation();
  const { language } = useLanguage();
  const isPa = language === 'pa';

  // Parse incoming filter state from router navigation if any
  const routerState = location.state as { filters?: Partial<FilterCriteria> } | null;

  const [dbProfiles, setDbProfiles] = useState<ProfileData[]>([]);
  const [loading, setLoading] = useState(true);
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [mobileFilterOpen, setMobileFilterOpen] = useState(false);

  // Filters State
  const [filters, setFilters] = useState<FilterCriteria>(() => {
    if (routerState?.filters) {
      return {
        ...DEFAULT_FILTERS,
        ...routerState.filters
      };
    }
    return DEFAULT_FILTERS;
  });

  // Fetch Firestore profiles
  useEffect(() => {
    async function loadData() {
      try {
        setLoading(true);
        const profilesRef = collection(db, 'profiles');
        const q = query(profilesRef, limit(50));
        const snapshot = await getDocs(q);

        const fetched: ProfileData[] = snapshot.docs.map(doc => ({
          id: doc.id,
          ...doc.data()
        } as ProfileData));

        setDbProfiles(fetched);
      } catch (err) {
        handleFirestoreError(err, OperationType.LIST, 'profiles');
      } finally {
        setLoading(false);
      }
    }
    loadData();
  }, []);

  // Update filters handler with multi-select support
  const handleFilterUpdate = (updates: Partial<FilterCriteria>) => {
    setFilters(prev => ({ ...prev, ...updates }));
  };

  const handleMultiChange = (name: keyof FilterCriteria, value: string, checked: boolean) => {
    const currentValues = (filters[name] as string[]) || [];
    if (checked) {
      setFilters(prev => ({ ...prev, [name]: [...currentValues, value] }));
    } else {
      setFilters(prev => ({ ...prev, [name]: currentValues.filter(v => v !== value) }));
    }
  };

  // Reset filters handler
  const handleResetFilters = () => {
    setFilters(DEFAULT_FILTERS);
  };

  // Combine Firestore profiles and Showcase profiles
  const allCandidateProfiles = useMemo(() => {
    const map = new Map<string, ProfileData>();
    
    // Add showcase profiles first
    MAHASHA_SHOWCASE_PROFILES.forEach(p => map.set(p.id!, p));
    
    // Add real Firestore profiles (overwriting if same id)
    dbProfiles.forEach(p => map.set(p.id!, p));

    return Array.from(map.values());
  }, [dbProfiles]);

  // Apply full multi-criteria filter and sort
  const filteredProfiles = useMemo(() => {
    return filterAndSortProfiles(allCandidateProfiles, filters);
  }, [allCandidateProfiles, filters]);

  const activeCount = countActiveFilters(filters);

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <SEO 
        title="ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਖੋਜੋ (Mahasha Matches) - Advanced Matchmaking Filters"
        description="ਵਿੱਦਿਅਕ ਯੋਗਤਾ (LLM, B.Tech, MBBS), ਕਿੱਤਾ (Advocate, Software Engineer, Doctor, Govt Job), ਜ਼ਿਲ੍ਹਾ (ਗੁਰਦਾਸਪੁਰ, ਅੰਮ੍ਰਿਤਸਰ, ਜਲੰਧਰ) ਅਤੇ ਮਹਾਸ਼ਾ ਗੋਤਰ ਅਨੁਸਾਰ ਰਿਸ਼ਤੇ ਲੱਭੋ।"
        keywords={[
          'Mahasha matches search', 
          'Advocate matrimonial Punjab', 
          'Mahasha gotra match', 
          'Gurdaspur matrimonial', 
          'NRI Mahasha matrimonial', 
          'Software Engineer brides grooms'
        ]}
      />

      {/* Header Banner */}
      <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-amber-950 py-8 border-b border-amber-500/20 text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#f59e0b_1px,transparent_1px)] [background-size:16px_16px]"></div>
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div>
              <div className="inline-flex items-center gap-2 bg-rose-900/90 border border-amber-400/30 px-3 py-1 rounded-full text-xs font-bold text-amber-300 mb-2 shadow-xs">
                <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                <span>{isPa ? 'ਸਿਰਫ਼ ਮਹਾਸ਼ਾ ਸਮਾਜ ਲਈ (Mahasha Biradari Exclusive)' : 'Mahasha Community Exclusive'}</span>
              </div>
              <h1 className="text-2xl sm:text-3xl font-bold font-serif">
                {isPa ? 'ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਖੋਜੋ (Mahasha Matrimonial Matches)' : 'Explore Verified Mahasha Matches'}
              </h1>
              <p className="text-rose-200/90 text-xs sm:text-sm mt-1 max-w-2xl">
                {isPa 
                  ? 'ਵਿੱਦਿਅਕ ਡਿਗਰੀਆਂ (LLM/B.Tech), ਪੇਸ਼ੇਵਰ ਕੈਰੀਅਰ (Advocate/IT/Doctor), ਅਤੇ ਪੰਜਾਬ ਦੇ ਜ਼ਿਲ੍ਹਿਆਂ ਅਨੁਸਾਰ ਉੱਨਤ ਫਿਲਟਰ।'
                  : 'Advanced criteria search by education degrees (LLM, B.Tech, MBBS), careers, and Punjab districts.'}
              </p>
            </div>

            {/* Quick Metrics */}
            <div className="hidden md:flex items-center gap-4 bg-white/10 backdrop-blur-xs p-3 rounded-2xl border border-white/15 text-xs">
              <div className="text-center px-2">
                <div className="font-extrabold text-amber-300 text-lg font-serif">{filteredProfiles.length}</div>
                <div className="text-rose-200 text-[10px]">{isPa ? 'ਯੋਗ ਰਿਸ਼ਤੇ' : 'Matches'}</div>
              </div>
              <div className="h-7 w-px bg-white/20"></div>
              <div className="text-center px-2">
                <div className="font-extrabold text-white text-lg font-serif">100%</div>
                <div className="text-rose-200 text-[10px]">{isPa ? 'ਮਹਾਸ਼ਾ ਗੋਤਰ' : 'Mahasha'}</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Main Container */}
      <div className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-8">
        <div className="flex flex-col lg:flex-row gap-8 items-start">
          
          {/* Desktop Filter Sidebar */}
          <aside className="hidden lg:block w-80 shrink-0 sticky top-24">
            <AdvancedFilterSidebar
              filters={filters}
              onChange={handleFilterUpdate}
              onMultiChange={handleMultiChange}
              onReset={handleResetFilters}
            />
          </aside>

          {/* Main Results Column */}
          <main className="flex-1 w-full min-w-0">
            
            {/* Top Bar with Search, Sort, Pills, View Switcher */}
            <MatchesTopBar
              filters={filters}
              onChange={handleFilterUpdate}
              onReset={handleResetFilters}
              onOpenMobileFilter={() => setMobileFilterOpen(true)}
              totalResults={filteredProfiles.length}
              activeFilterCount={activeCount}
              viewMode={viewMode}
              onToggleViewMode={setViewMode}
            />

            {/* Content States */}
            {loading ? (
              <div className={viewMode === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6" : "space-y-4"}>
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <MatchCardSkeleton key={i} viewMode={viewMode} />
                ))}
              </div>
            ) : filteredProfiles.length === 0 ? (
              
              /* Empty State with Helpful Guidance */
              <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-8 sm:p-12 text-center">
                <div className="w-16 h-16 bg-rose-50 text-rose-800 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-rose-200">
                  <UserCircle className="w-10 h-10" />
                </div>
                <h3 className="text-xl font-bold text-gray-900 font-serif mb-2">
                  {isPa ? 'ਕੋਈ ਮਿਲਦਾ ਜੁਲਦਾ ਪ੍ਰੋਫਾਈਲ ਨਹੀਂ ਮਿਲਿਆ' : 'No matching profiles found'}
                </h3>
                <p className="text-xs sm:text-sm text-gray-600 max-w-md mx-auto mb-6">
                  {isPa 
                    ? 'ਤੁਹਾਡੇ ਚੁਣੇ ਫਿਲਟਰ ਬਹੁਤ ਸੀਮਤ ਹਨ। ਕਿਰਪਾ ਕਰਕੇ ਉਮਰ, ਵਿੱਦਿਆ ਜਾਂ ਜ਼ਿਲ੍ਹਾ ਫਿਲਟਰ ਨੂੰ ਥੋੜ੍ਹਾ ਖੁੱਲ੍ਹਾ ਰੱਖ ਕੇ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।'
                    : 'The current filter combination is too narrow. Try relaxing one or more criteria (such as education degree or district).'}
                </p>

                {/* Helpful Quick Presets */}
                <div className="flex flex-wrap justify-center gap-2 max-w-lg mx-auto mb-6">
                  <button
                    type="button"
                    onClick={() => handleFilterUpdate({ educationLevel: [], profession: [] })}
                    className="text-xs bg-amber-50 hover:bg-amber-100 text-rose-950 font-bold px-3 py-1.5 rounded-xl border border-amber-300 transition-colors"
                  >
                    Clear Education & Career Filters
                  </button>
                  <button
                    type="button"
                    onClick={() => handleFilterUpdate({ district: [], stateRegion: 'Any', country: 'Any' })}
                    className="text-xs bg-blue-50 hover:bg-blue-100 text-blue-950 font-bold px-3 py-1.5 rounded-xl border border-blue-200 transition-colors"
                  >
                    Search All Punjab Districts
                  </button>
                </div>

                <button 
                  type="button"
                  onClick={handleResetFilters}
                  className="inline-flex items-center gap-2 bg-gradient-to-r from-rose-900 to-rose-950 text-amber-300 border border-amber-500/30 px-6 py-2.5 rounded-xl font-bold text-xs shadow-xs hover:from-rose-800 hover:to-rose-900 transition-all"
                >
                  <RotateCcw className="w-3.5 h-3.5" />
                  <span>{isPa ? 'ਸਾਰੇ ਫਿਲਟਰ ਸਾਫ਼ ਕਰੋ (Reset All Filters)' : 'Reset All Filters'}</span>
                </button>
              </div>

            ) : (
              
              /* Results List / Grid */
              <div className={viewMode === 'grid' ? "grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-6" : "space-y-4"}>
                {filteredProfiles.map((profile) => (
                  <MatchCard
                    key={profile.id}
                    profile={profile}
                    viewMode={viewMode}
                  />
                ))}
              </div>

            )}

          </main>
        </div>
      </div>

      {/* Mobile Filter Overlay Modal */}
      {mobileFilterOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-end sm:items-center justify-center p-0 sm:p-4 animate-in fade-in duration-200">
          <div className="bg-white w-full max-w-lg max-h-[90vh] rounded-t-3xl sm:rounded-3xl shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-6 duration-200">
            <div className="overflow-y-auto flex-1">
              <AdvancedFilterSidebar
                filters={filters}
                onChange={handleFilterUpdate}
                onMultiChange={handleMultiChange}
                onReset={handleResetFilters}
                onApply={() => setMobileFilterOpen(false)}
                isMobileModal={true}
                onCloseMobile={() => setMobileFilterOpen(false)}
              />
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
