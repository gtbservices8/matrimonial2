import React, { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { useCMSConfig } from '../hooks/useCMSConfig';
import SEO from '../components/common/SEO';
import FAQAccordion, { faqs } from '../components/common/FAQAccordion';

export default function ContactUs() {
  const { t, language } = useLanguage();
  const { config } = useCMSConfig();
  const [formStatus, setFormStatus] = useState<'idle' | 'submitting' | 'success'>('idle');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setFormStatus('submitting');
    // Simulate form submission
    setTimeout(() => {
      setFormStatus('success');
      setTimeout(() => setFormStatus('idle'), 5000);
    }, 1500);
  };

  const contactText = {
    en: {
      title: 'Contact Us',
      subtitle: 'Get in touch with us for any queries, support or feedback.',
      address: 'Address',
      phone: 'Phone',
      email: 'Email',
      sendMsg: 'Send a Message',
      nameField: 'Full Name',
      emailField: 'Email Address',
      subjectField: 'Subject',
      messageField: 'Your Message',
      submitBtn: 'Send Message',
      submitting: 'Sending...',
      successMsg: 'Your message has been sent successfully. We will get back to you soon!',
    },
    pa: {
      title: 'ਸੰਪਰਕ ਕਰੋ (Contact Us)',
      subtitle: 'ਕਿਸੇ ਵੀ ਪੁੱਛਗਿੱਛ, ਸਹਾਇਤਾ ਜਾਂ ਫੀਡਬੈਕ ਲਈ ਸਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰੋ।',
      address: 'ਪਤਾ (Address)',
      phone: 'ਫੋਨ ਨੰਬਰ (Phone)',
      email: 'ਈਮੇਲ (Email)',
      sendMsg: 'ਸੁਨੇਹਾ ਭੇਜੋ (Send a Message)',
      nameField: 'ਪੂਰਾ ਨਾਮ (Full Name)',
      emailField: 'ਈਮੇਲ (Email Address)',
      subjectField: 'ਵਿਸ਼ਾ (Subject)',
      messageField: 'ਤੁਹਾਡਾ ਸੁਨੇਹਾ (Your Message)',
      submitBtn: 'ਸੁਨੇਹਾ ਭੇਜੋ',
      submitting: 'ਭੇਜਿਆ ਜਾ ਰਿਹਾ ਹੈ...',
      successMsg: 'ਤੁਹਾਡਾ ਸੁਨੇਹਾ ਸਫਲਤਾਪੂਰਵਕ ਭੇਜਿਆ ਗਿਆ ਹੈ। ਅਸੀਂ ਜਲਦੀ ਹੀ ਤੁਹਾਡੇ ਨਾਲ ਸੰਪਰਕ ਕਰਾਂਗੇ!',
    },
    hi: {
      title: 'संपर्क करें (Contact Us)',
      subtitle: 'किसी भी प्रश्न, सहायता या प्रतिक्रिया के लिए हमसे संपर्क करें।',
      address: 'पता (Address)',
      phone: 'फ़ोन (Phone)',
      email: 'ईमेल (Email)',
      sendMsg: 'संदेश भेजें',
      nameField: 'पूरा नाम (Full Name)',
      emailField: 'ईमेल (Email Address)',
      subjectField: 'विषय (Subject)',
      messageField: 'आपका संदेश (Your Message)',
      submitBtn: 'संदेश भेजें',
      submitting: 'भेजा जा रहा है...',
      successMsg: 'आपका संदेश सफलतापूर्वक भेज दिया गया है। हम जल्द ही आपसे संपर्क करेंगे!',
    }
  };

  const text = contactText[language as keyof typeof contactText] || contactText.en;

  const currentFaqs = faqs[language as keyof typeof faqs] || faqs.en;
  
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    "mainEntity": currentFaqs.map(faq => ({
      "@type": "Question",
      "name": faq.q,
      "acceptedAnswer": {
        "@type": "Answer",
        "text": faq.a
      }
    }))
  };

  return (
    <div className="min-h-screen bg-gray-50 pt-24 pb-12">
      <SEO 
        title={`${text.title} - ${config?.siteNameEn || 'Mahasha Matrimonial'}`}
        description={text.subtitle}
        keywords={['Contact us', 'Mahasha matrimony contact', 'support']}
        structuredData={faqSchema}
      />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl font-extrabold text-gray-900 font-serif mb-4">
            {text.title}
          </h1>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            {text.subtitle}
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Contact Information */}
          <div className="lg:col-span-1 space-y-8">
            <div className="bg-white rounded-3xl p-8 shadow-xl border border-rose-100">
              <h3 className="text-xl font-bold text-gray-900 font-serif mb-6">{text.title}</h3>
              
              <div className="space-y-6">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-rose-50 text-rose-900 rounded-xl shrink-0">
                    <MapPin className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">{text.address}</h4>
                    <p className="text-sm text-gray-600 leading-relaxed">
                      {language === 'pa' ? config?.addressPa : config?.addressEn}
                    </p>
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-amber-50 text-amber-700 rounded-xl shrink-0">
                    <Phone className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">{text.phone}</h4>
                    <p className="text-sm text-gray-600">
                      <a href={`tel:${config?.supportPhone}`} className="hover:text-amber-700 transition-colors">
                        {config?.supportPhone}
                      </a>
                    </p>
                    {config?.whatsappNumber && (
                      <p className="text-sm text-green-600 mt-1 font-medium">
                        <a href={`https://wa.me/${config.whatsappNumber.replace(/[^0-9]/g, '')}`} target="_blank" rel="noopener noreferrer">
                          WhatsApp: {config.whatsappNumber}
                        </a>
                      </p>
                    )}
                  </div>
                </div>

                <div className="flex items-start gap-4">
                  <div className="p-3 bg-blue-50 text-blue-700 rounded-xl shrink-0">
                    <Mail className="w-6 h-6" />
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-900 mb-1">{text.email}</h4>
                    <p className="text-sm text-gray-600">
                      <a href={`mailto:${config?.supportEmail}`} className="hover:text-blue-700 transition-colors">
                        {config?.supportEmail}
                      </a>
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Contact Form */}
          <div className="lg:col-span-2">
            <div className="bg-white rounded-3xl p-8 shadow-xl border border-amber-100">
              <h3 className="text-2xl font-bold text-gray-900 font-serif mb-8 flex items-center gap-3">
                <Send className="w-6 h-6 text-amber-600" />
                {text.sendMsg}
              </h3>

              {formStatus === 'success' ? (
                <div className="bg-green-50 border border-green-200 rounded-2xl p-8 text-center animate-in fade-in zoom-in duration-300">
                  <div className="w-16 h-16 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-4">
                    <CheckCircle2 className="w-8 h-8" />
                  </div>
                  <h4 className="text-xl font-bold text-green-900 mb-2">Message Sent!</h4>
                  <p className="text-green-700">{text.successMsg}</p>
                  <button 
                    onClick={() => setFormStatus('idle')}
                    className="mt-6 px-6 py-2 bg-green-600 text-white font-bold rounded-xl hover:bg-green-700 transition-colors"
                  >
                    Send Another Message
                  </button>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">{text.nameField}</label>
                      <input 
                        type="text" 
                        required
                        className="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                        placeholder="John Doe"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-semibold text-gray-700 mb-2">{text.emailField}</label>
                      <input 
                        type="email" 
                        required
                        className="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                        placeholder="john@example.com"
                      />
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">{text.subjectField}</label>
                    <input 
                      type="text" 
                      required
                      className="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                      placeholder="How can we help you?"
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-semibold text-gray-700 mb-2">{text.messageField}</label>
                    <textarea 
                      required
                      rows={5}
                      className="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none"
                      placeholder="Write your message here..."
                    ></textarea>
                  </div>

                  <button 
                    type="submit"
                    disabled={formStatus === 'submitting'}
                    className="w-full sm:w-auto px-8 py-3.5 bg-rose-900 text-amber-300 font-bold rounded-xl shadow-lg hover:bg-rose-800 focus:ring-4 focus:ring-rose-200 transition-all disabled:opacity-50 flex items-center justify-center gap-2"
                  >
                    {formStatus === 'submitting' ? (
                      <>
                        <div className="w-5 h-5 border-2 border-amber-300 border-t-transparent rounded-full animate-spin"></div>
                        {text.submitting}
                      </>
                    ) : (
                      <>
                        <Send className="w-5 h-5" />
                        {text.submitBtn}
                      </>
                    )}
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>

        <FAQAccordion />
      </div>
    </div>
  );
}
