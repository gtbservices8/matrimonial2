import React, { useState, useEffect } from 'react';
import { 
  ShieldCheck, Users, CheckCircle2, XCircle, Trash2, Search, 
  Filter, Eye, Sparkles, RefreshCw, BarChart3, Lock, Award, 
  MapPin, GraduationCap, Phone, Check, AlertTriangle, ExternalLink,
  MessageCircleHeart, Settings, LayoutDashboard, Database, Plus, Save,
  LineChart as ChartIcon, Download, Menu, X, LogOut, Camera,
  ChevronLeft, ChevronRight, PanelLeftClose, PanelLeft
} from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import { collection, getDocs, doc, updateDoc, deleteDoc, query, orderBy, setDoc, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { format } from 'date-fns';
import { ProfileData, SuccessStory, MetricItem, GlobalConfig, ActivityLog, FormConfig, FormFieldConfig } from '../types';
import AppLogo from '../components/common/AppLogo';
import SEO from '../components/common/SEO';
import AnalyticsDashboard from '../components/admin/AnalyticsDashboard';
import BulkUploadSettings from '../components/admin/BulkUploadSettings';
import { logActivity } from '../lib/activityLogger';
import { Clock as HistoryIcon } from 'lucide-react';

export default function AdminPanel() {
  const { user } = useAuth();
  const location = useLocation();
  const [lang, setLang] = useState<'en' | 'pa'>('en');
  const [profiles, setProfiles] = useState<ProfileData[]>([]);
  const [loading, setLoading] = useState(true);
  const [isAuthenticated, setIsAuthenticated] = useState(() => {
    return sessionStorage.getItem('mahasha_admin_auth') === 'true';
  });

  useEffect(() => {
    if (!isAuthenticated) {
      window.location.href = '/';
      return;
    }
    fetchAllData();

    // Check for auto-create parameter
    const params = new URLSearchParams(location.search);
    if (params.get('create') === 'true') {
      setActiveTab('add-profile');
      // Clean up URL
      window.history.replaceState({}, '', '/admin');
    }
  }, [isAuthenticated, location.search]);
  const [actionLoading, setActionLoading] = useState<string | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'verified' | 'unverified' | 'drafts'>('all');
  const [genderFilter, setGenderFilter] = useState<'all' | 'Male' | 'Female'>('all');
  const [selectedProfile, setSelectedProfile] = useState<ProfileData | null>(null);
  const [notification, setNotification] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [activeTab, setActiveTab] = useState<'profiles' | 'stories' | 'metrics' | 'settings' | 'analytics' | 'logs' | 'seo' | 'add-profile'>('profiles');
  const [settingsSubTab, setSettingsSubTab] = useState<'general' | 'app' | 'form' | 'lists'>('general');
  
  // CMS States
  const [stories, setStories] = useState<SuccessStory[]>([]);
  const [metrics, setMetrics] = useState<MetricItem[]>([]);
  const [editingStory, setEditingStory] = useState<Partial<SuccessStory> | null>(null);
  const [logs, setLogs] = useState<ActivityLog[]>([]);
  const [selectedProfiles, setSelectedProfiles] = useState<string[]>([]);
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [isCollapsed, setIsCollapsed] = useState(false);
  const [newProfile, setNewProfile] = useState<Partial<ProfileData>>({
    fullName: '',
    gender: 'Male',
    age: 25,
    fatherName: '',
    motherName: '',
    dateOfBirth: '',
    birthPlace: '',
    birthTime: '',
    complexion: 'Fair',
    height: '5\'4" (162 cm)',
    state: 'Punjab (ਪੰਜਾਬ)',
    district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    location: '',
    fatherGotra: 'Bajgal (Bhogal)',
    motherGotra: 'Ghangla',
    religion: 'Hindu',
    community: 'Mahasha (Bajgal)',
    qualification1: '',
    qualification2: '',
    qualification3: '',
    education: '',
    profession: '',
    occupationDetails: '',
    income: '',
    fatherOccupation: '',
    motherOccupation: '',
    brotherDetails: '',
    sisterDetails: '',
    familyType: 'Nuclear',
    maritalStatus: 'Never Married',
    contactNumber: '',
    alternateContact: '',
    aboutMe: '',
    photoUrls: [],
    videoUrl: '',
    isVerified: true
  });
  const [globalConfig, setGlobalConfig] = useState<GlobalConfig>({
    siteNameEn: 'Mahasha Matrimonial',
    siteNamePa: 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ',
    supportPhone: '+91 98765 43210',
    supportEmail: 'contact@mahashamatrimony.com',
    whatsappNumber: '+91 98765 43210',
    addressEn: 'Amritsar, Punjab',
    addressPa: 'ਅੰਮ੍ਰਿਤਸਰ, ਪੰਜਾਬ',
    isRegistrationOpen: true,
    maintenanceMode: false,
    registrationIncentiveDays: 30,
    registrationIncentiveLabelEn: 'Registration Bonus: 30 Days Free Premium Access',
    registrationIncentiveLabelPa: 'ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਬੋਨਸ: 30 ਦਿਨਾਂ ਦੀ ਮੁਫਤ ਪ੍ਰੀਮੀਅਮ ਪਹੁੰਚ',
    showUnverifiedProfiles: true,
    allowPublicProfiles: false,
    notificationFrequency: 'immediate',
    enableRealTimeAlerts: true
  });

  const [formConfig, setFormConfig] = useState<FormConfig>({
    fields: [],
    districts: [],
    gotras: [],
    complexions: [],
    professions: []
  });

  const fetchAllData = async () => {
    setLoading(true);
    try {
      // Fetch Profiles
      const profilesRef = collection(db, 'profiles');
      const profileSnap = await getDocs(profilesRef);
      const loadedProfiles: ProfileData[] = profileSnap.docs.map(d => ({ id: d.id, ...d.data() } as ProfileData));
      setProfiles(loadedProfiles);

      // Fetch Stories
      const storiesSnap = await getDocs(collection(db, 'success_stories'));
      setStories(storiesSnap.docs.map(d => ({ id: d.id, ...d.data() } as SuccessStory)));

      // Fetch Metrics
      const metricsSnap = await getDocs(collection(db, 'cms_settings'));
      const metricsDoc = metricsSnap.docs.find(d => d.id === 'site_metrics');
      if (metricsDoc) {
        setMetrics(metricsDoc.data().metrics || []);
      }

      // Fetch Global Config
      const configDoc = metricsSnap.docs.find(d => d.id === 'global_config');
      if (configDoc) {
        setGlobalConfig(configDoc.data() as GlobalConfig);
      }

      // Fetch Form Config
      const formDoc = metricsSnap.docs.find(d => d.id === 'form_config');
      if (formDoc) {
        const data = formDoc.data() as FormConfig;
        // Ensure 'state' field exists in fields array
        if (data.fields && !data.fields.find(f => f.id === 'state')) {
          data.fields.splice(10, 0, { id: 'state', labelEn: 'State', labelPa: 'ਸਟੇਟ', isRequired: true, isVisible: true, section: 'location' });
        }
        setFormConfig(data);
      } else {
        // Initialize default fields if document doesn't exist
        const defaultFields: FormFieldConfig[] = [
          { id: 'fullName', labelEn: 'Full Name', labelPa: 'ਪੂਰਾ ਨਾਮ', isRequired: true, isVisible: true, section: 'personal' },
          { id: 'gender', labelEn: 'Gender', labelPa: 'ਲਿੰਗ', isRequired: true, isVisible: true, section: 'personal' },
          { id: 'age', labelEn: 'Age', labelPa: 'ਉਮਰ', isRequired: true, isVisible: true, section: 'personal' },
          { id: 'dateOfBirth', labelEn: 'Date of Birth', labelPa: 'ਜਨਮ ਮਿਤੀ', isRequired: false, isVisible: true, section: 'personal' },
          { id: 'birthPlace', labelEn: 'Birth Place', labelPa: 'ਜਨਮ ਸਥਾਨ', isRequired: true, isVisible: true, section: 'physical' },
          { id: 'birthTime', labelEn: 'Birth Time', labelPa: 'ਜਨਮ ਸਮਾਂ', isRequired: false, isVisible: true, section: 'physical' },
          { id: 'complexion', labelEn: 'Complexion', labelPa: 'ਰੰਗ', isRequired: true, isVisible: true, section: 'physical' },
          { id: 'height', labelEn: 'Height', labelPa: 'ਕੱਦ', isRequired: true, isVisible: true, section: 'physical' },
          { id: 'district', labelEn: 'District', labelPa: 'ਜ਼ਿਲ੍ਹਾ', isRequired: true, isVisible: true, section: 'location' },
          { id: 'state', labelEn: 'State', labelPa: 'ਸਟੇਟ', isRequired: true, isVisible: true, section: 'location' },
          { id: 'location', labelEn: 'City/Village/Address', labelPa: 'ਸ਼ਹਿਰ/ਪਿੰਡ/ਪਤਾ', isRequired: true, isVisible: true, section: 'location' },
          { id: 'fatherGotra', labelEn: "Father's Gotra", labelPa: 'ਪਿਤਾ ਦਾ ਗੋਤਰ', isRequired: true, isVisible: true, section: 'gotra' },
          { id: 'motherGotra', labelEn: "Mother's Gotra", labelPa: 'ਮਾਤਾ ਦਾ ਗੋਤਰ', isRequired: true, isVisible: true, section: 'gotra' },
          { id: 'qualification1', labelEn: 'Main Qualification', labelPa: 'ਮੁੱਖ ਯੋਗਤਾ', isRequired: true, isVisible: true, section: 'education' },
          { id: 'profession', labelEn: 'Profession', labelPa: 'ਪੇਸ਼ਾ', isRequired: true, isVisible: true, section: 'career' },
          { id: 'fatherOccupation', labelEn: "Father's Details", labelPa: 'ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ', isRequired: true, isVisible: true, section: 'family' },
          { id: 'contactNumber', labelEn: 'Contact Number', labelPa: 'ਸੰਪਰਕ ਨੰਬਰ', isRequired: true, isVisible: true, section: 'contact' },
        ];
        
        // Initial list values from types if available, otherwise empty
        // Since we are in a file and can't easily import the constants from types.ts due to being in the same file or circular refs if we were careful
        // Actually they are exported from types.ts, so I can use them if they are imported.
        // Wait, they are exported as constants in types.ts.
        
        setFormConfig({
          fields: defaultFields,
          districts: [
            'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)', 'Amritsar (ਅੰਮ੍ਰਿਤਸਰ)', 'Pathankot (ਪਠਾਨਕੋਟ)', 'Hoshiarpur (ਹੁਸ਼ਿਆਰਪੁਰ)',
            'Jalandhar (ਜਲੰਧਰ)', 'Kapurthala (ਕਪੂਰਥਲਾ)', 'Ludhiana (ਲੁਧਿਆਣਾ)', 'Tarn Taran (ਤਰਨ ਤਾਰਨ)',
            'Bathinda (ਬਠਿੰਡਾ)', 'Patiala (ਪਟਿਆਲਾ)', 'SAS Nagar / Mohali (ਮੋਹਾਲੀ)', 'Rupnagar / Ropar (ਰੂਪਨਗਰ)',
            'Sangrur (ਸੰਗਰੂਰ)', 'Firozpur (ਫ਼ਿਰੋਜ਼ਪੁਰ)', 'Faridkot (ਫ਼ਰੀਦਕੋਟ)', 'Fazilka (ਫ਼ਾਜ਼ਿਲਕਾ)',
            'Mansa (ਮਾਨਸਾ)', 'Moga (ਮੋਗਾ)', 'Sri Muktsar Sahib (ਮੁਕਤਸਰ)', 'Fatehgarh Sahib (ਫ਼ਤਹਿਗੜ੍ਹ ਸਾਹਿਬ)',
            'Barnala (ਬਰਨਾਲਾ)', 'Malerkotla (ਮਾਲੇਰਕੋਟਲਾ)', 'Jammu (ਜੰਮੂ)', 'Kathua (ਕਠੂਆ)', 'Samba (ਸਾਂਬਾ)',
            'Chandigarh (ਚੰਡੀਗੜ੍ਹ)', 'Delhi NCR (ਦਿੱਲੀ)', 'Other / ਬਾਹਰਲਾ ਜ਼ਿਲ੍ਹਾ'
          ],
          states: [
            'Punjab (ਪੰਜਾਬ)', 'Haryana (ਹਰਿਆਣਾ)', 'Himachal Pradesh (ਹਿਮਾਚਲ ਪ੍ਰਦੇਸ਼)', 
            'Jammu & Kashmir (ਜੰਮੂ ਅਤੇ ਕਸ਼ਮੀਰ)', 'Delhi (ਦਿੱਲੀ)', 'Chandigarh (ਚੰਡੀਗੜ੍ਹ)', 
            'Rajasthan (ਰਾਜਸਥਾਨ)', 'Uttarakhand (ਉੱਤਰਾਖੰਡ)', 'Other (ਹੋਰ)'
          ],
          gotras: [
            { value: 'Bajgal (Bhogal)', label: 'ਬਜਗਲ / ਭੋਗਲ - Bajgal (Bhogal)' },
            { value: 'Ghangla', label: 'ਘਾਂਗਲਾ - Ghangla' },
            { value: 'Kaler', label: 'ਕਲੇਰ - Kaler' },
            { value: 'Badhan', label: 'ਬੱਧਣ - Badhan' },
            { value: 'Banga', label: 'ਬੰਗਾ - Banga' },
            { value: 'Kundal', label: 'ਕੁੰਡਲ - Kundal' },
            { value: 'Ghotra', label: 'ਘੋਤੜਾ - Ghotra' },
            { value: 'Karloopia', label: 'ਕਰਲੂਪੀਆ - Karloopia' },
            { value: 'Hans', label: 'ਹੰਸ - Hans' },
            { value: 'Taak', label: 'ਟਾਕ - Taak' },
            { value: 'Kajla', label: 'ਕਾਜਲਾ - Kajla' },
            { value: 'Suman', label: 'ਸੁਮਨ - Suman' },
            { value: 'Nahar', label: 'ਨਾਹਰ - Nahar' },
            { value: 'Bhatti', label: 'ਭੱਟੀ - Bhatti' },
            { value: 'Chumber', label: 'ਚੁੰਬਰ - Chumber' },
            { value: 'Gill', label: 'ਗਿੱਲ - Gill' },
            { value: 'Sandhu', label: 'ਸੰਧੂ - Sandhu' },
            { value: 'Other', label: 'ਹੋਰ ਮਹਾਸ਼ਾ ਗੋਤਰ (Other Gotra)' }
          ],
          complexions: [
            { value: 'Fair', label: 'ਗੋਰਾ (Fair)' },
            { value: 'Very Fair', label: 'ਬਹੁਤ ਗੋਰਾ (Very Fair)' },
            { value: 'Wheatish', label: 'ਕਣਕਵੰਨਾ (Wheatish)' },
            { value: 'Dusky', label: 'ਸਾਂਵਲਾ (Dusky)' }
          ],
          professions: [
            'Advocate / Lawyer', 'Software Engineer', 'Doctor / Medical', 'Business / Trader',
            'Teacher / Professor', 'Government Job', 'Banker / Finance', 'Chartered Accountant (CA)',
            'Armed Forces / Police', 'Judicial / PCS(J) Aspirant', 'Civil Services', 'Not Working / Homemaker', 'Other'
          ]
        });
      }

      // Fetch Activity Logs
      const logsSnap = await getDocs(query(collection(db, 'activity_logs'), orderBy('timestamp', 'desc')));
      setLogs(logsSnap.docs.map(d => ({ id: d.id, ...d.data() } as ActivityLog)));
    } catch (err: any) {
      console.error('Error fetching admin data:', err);
    } finally {
      setLoading(false);
    }
  };

  const showToast = (type: 'success' | 'error', msg: string) => {
    setNotification({ type, msg });
    setTimeout(() => setNotification(null), 4000);
  };

  const exportToCSV = (data: any[], fileName: string) => {
    if (data.length === 0) {
      showToast('error', 'ਨਿਰਯਾਤ ਕਰਨ ਲਈ ਕੋਈ ਡਾਟਾ ਨਹੀਂ ਹੈ। (No data to export)');
      return;
    }

    // Get all unique headers from all items
    const allKeys = new Set<string>();
    data.forEach(item => Object.keys(item).forEach(key => allKeys.add(key)));
    const headers = Array.from(allKeys).filter(k => k !== 'id' && k !== 'userId');
    
    const csvRows = [
      headers.join(','), // header row
      ...data.map(row => 
        headers.map(header => {
          let val = row[header];
          
          // Handle Firestore Timestamps
          if (val && typeof val === 'object' && val.toDate) {
            val = format(val.toDate(), 'yyyy-MM-dd HH:mm:ss');
          }
          
          // Escape quotes and wrap in quotes
          const escaped = ('' + (val ?? '')).replace(/"/g, '""');
          return `"${escaped}"`;
        }).join(',')
      )
    ];

    const csvString = csvRows.join('\n');
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${fileName}_${format(new Date(), 'yyyy-MM-dd')}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    showToast('success', 'CSV ਫਾਈਲ ਡਾਊਨਲੋਡ ਹੋ ਗਈ ਹੈ! (CSV downloaded successfully)');
  };

  const handleExportProfiles = () => {
    const exportData = filteredProfiles.map(p => ({
      'Full Name': p.fullName,
      'Gender': p.gender,
      'Age': p.age,
      'DOB': p.dateOfBirth,
      'Father Gotra': p.fatherGotra,
      'Mother Gotra': p.motherGotra,
      'District': p.district,
      'Location': p.location,
      'Birth Place': p.birthPlace,
      'Profession': p.profession,
      'Qualification 1': p.qualification1,
      'Qualification 2': p.qualification2,
      'Contact': p.contactNumber,
      'Alt Contact': p.alternateContact,
      'Father Occupation': p.fatherOccupation,
      'Mother Occupation': p.motherOccupation,
      'Marital Status': p.maritalStatus,
      'Verified': p.isVerified ? 'Yes' : 'No',
      'Status': p.isDraft ? 'Draft' : 'Final',
      'Created At': p.createdAt,
      'Updated At': p.updatedAt
    }));
    exportToCSV(exportData, 'Mahasha_Profiles');
  };

  const handleExportLogs = () => {
    const exportData = logs.map(l => ({
      'Timestamp': l.timestamp,
      'Type': l.type,
      'Action': l.action,
      'Details': l.details,
      'Performed By': l.performedByName || l.performedBy
    }));
    exportToCSV(exportData, 'Mahasha_Activity_Logs');
  };

  const handleSaveNewProfile = async () => {
    if (!newProfile.fullName || !newProfile.contactNumber) {
      showToast('error', 'ਨਾਮ ਅਤੇ ਸੰਪਰਕ ਨੰਬਰ ਜ਼ਰੂਰੀ ਹਨ। (Name and Contact are required)');
      return;
    }

    if (!newProfile.photoUrls || newProfile.photoUrls.length < 2) {
      showToast('error', 'ਕਿਰਪਾ ਕਰਕੇ ਘੱਟੋ ਘੱਟ 2 ਫੋਟੋਆਂ ਅਪਲੋਡ ਕਰੋ। (Please upload at least 2 photos)');
      return;
    }

    setLoading(true);
    try {
      const profileData = {
        ...newProfile,
        profileCompletion: 100,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
        isDraft: false,
        viewCount: 0
      };

      const docRef = await addDoc(collection(db, 'profiles'), profileData);
      
      await logActivity({
        type: 'admin_action',
        action: 'Direct Profile Created',
        details: `Admin created profile for ${newProfile.fullName}`,
        performedBy: user?.uid || 'Admin',
        performedByName: 'Administrator',
        targetId: docRef.id
      });

      showToast('success', 'ਪ੍ਰੋਫਾਈਲ ਸਫਲਤਾਪੂਰਵਕ ਬਣਾਈ ਗਈ ਹੈ! (Profile created successfully)');
      setActiveTab('profiles');
      setNewProfile({
        fullName: '',
        gender: 'Male',
        age: 25,
        fatherName: '',
        motherName: '',
        dateOfBirth: '',
        birthPlace: '',
        birthTime: '',
        complexion: 'Fair',
        height: '5\'4" (162 cm)',
        state: 'Punjab (ਪੰਜਾਬ)',
        district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
        location: '',
        fatherGotra: 'Bajgal (Bhogal)',
        motherGotra: 'Ghangla',
        religion: 'Hindu',
        community: 'Mahasha (Bajgal)',
        qualification1: '',
        qualification2: '',
        qualification3: '',
        education: '',
        profession: '',
        occupationDetails: '',
        income: '',
        fatherOccupation: '',
        motherOccupation: '',
        brotherDetails: '',
        sisterDetails: '',
        familyType: 'Nuclear',
        maritalStatus: 'Never Married',
        contactNumber: '',
        alternateContact: '',
        aboutMe: '',
        photoUrls: [],
        videoUrl: '',
        isVerified: true
      });
      fetchAllData(); // Refresh list
    } catch (err: any) {
      console.error('Error creating profile:', err);
      showToast('error', 'ਪ੍ਰੋਫਾਈਲ ਬਣਾਉਣ ਵਿੱਚ ਗਲਤੀ ਆਈ। (Error creating profile)');
    } finally {
      setLoading(false);
    }
  };

  // Toggle Verification status
  const handleToggleVerify = async (profileId: string, currentStatus: boolean) => {
    setActionLoading(profileId);
    try {
      if (!profileId.startsWith('demo-')) {
        const docRef = doc(db, 'profiles', profileId);
        await updateDoc(docRef, { isVerified: !currentStatus });
      }
      setProfiles(prev => prev.map(p => p.id === profileId ? { ...p, isVerified: !currentStatus } : p));
      
      const profile = profiles.find(p => p.id === profileId);
      await logActivity({
        type: 'admin_action',
        action: !currentStatus ? 'Profile Verified' : 'Verification Revoked',
        details: `${profile?.fullName || profileId} status changed to ${!currentStatus ? 'Verified' : 'Unverified'}`,
        performedBy: user?.uid || 'Admin',
        performedByName: 'Administrator',
        targetId: profileId
      });

      showToast('success', !currentStatus ? 'ਪ੍ਰੋਫਾਈਲ ਨੂੰ ਪ੍ਰਮਾਣਿਤ (Verified) ਕਰ ਦਿੱਤਾ ਗਿਆ ਹੈ!' : 'ਪ੍ਰਮਾਣੀਕਰਨ ਹਟਾ ਦਿੱਤਾ ਗਿਆ ਹੈ।');
    } catch (err: any) {
      showToast('error', 'ਸਥਿਤੀ ਬਦਲਣ ਵਿੱਚ ਗਲਤੀ: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  // Delete Profile
  const handleDeleteProfile = async (profileId: string, name: string) => {
    if (!window.confirm(`ਕੀ ਤੁਸੀਂ ਸੱਚਮੁੱਚ ${name} ਦੀ ਪ੍ਰੋਫਾਈਲ ਹਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ?`)) return;
    setActionLoading(profileId);
    try {
      if (!profileId.startsWith('demo-')) {
        const docRef = doc(db, 'profiles', profileId);
        await deleteDoc(docRef);
      }
      setProfiles(prev => prev.filter(p => p.id !== profileId));
      if (selectedProfile?.id === profileId) setSelectedProfile(null);
      
      await logActivity({
        type: 'admin_action',
        action: 'Profile Deleted',
        details: `Profile of ${name} (ID: ${profileId}) was permanently removed.`,
        performedBy: user?.uid || 'Admin',
        performedByName: 'Administrator',
        targetId: profileId
      });

      showToast('success', `${name} ਦੀ ਪ੍ਰੋਫਾਈਲ ਹਟਾ ਦਿੱਤੀ ਗਈ ਹੈ।`);
    } catch (err: any) {
      showToast('error', 'ਹਟਾਉਣ ਵਿੱਚ ਗਲਤੀ: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleBulkVerify = async () => {
    if (selectedProfiles.length === 0) return;
    if (!window.confirm(`ਕੀ ਤੁਸੀਂ ਚੁਣੀਆਂ ਹੋਈਆਂ ${selectedProfiles.length} ਪ੍ਰੋਫਾਈਲਾਂ ਨੂੰ ਪ੍ਰਮਾਣਿਤ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ?`)) return;
    
    setActionLoading('bulk');
    try {
      const promises = selectedProfiles.map(id => {
        if (!id.startsWith('demo-')) {
          return updateDoc(doc(db, 'profiles', id), { isVerified: true });
        }
        return Promise.resolve();
      });
      await Promise.all(promises);
      
      setProfiles(prev => prev.map(p => selectedProfiles.includes(p.id!) ? { ...p, isVerified: true } : p));
      
      await logActivity({
        type: 'admin_action',
        action: 'Bulk Verification',
        details: `${selectedProfiles.length} profiles were verified in bulk.`,
        performedBy: user?.uid || 'Admin',
        performedByName: 'Administrator'
      });

      showToast('success', `${selectedProfiles.length} ਪ੍ਰੋਫਾਈਲਾਂ ਪ੍ਰਮਾਣਿਤ ਹੋ ਗਈਆਂ ਹਨ!`);
      setSelectedProfiles([]);
    } catch (err: any) {
      showToast('error', 'ਬਲਕ ਵੈਰੀਫਿਕੇਸ਼ਨ ਵਿੱਚ ਗਲਤੀ: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const handleBulkDelete = async () => {
    if (selectedProfiles.length === 0) return;
    if (!window.confirm(`ਕੀ ਤੁਸੀਂ ਸੱਚਮੁੱਚ ਚੁਣੀਆਂ ਹੋਈਆਂ ${selectedProfiles.length} ਪ੍ਰੋਫਾਈਲਾਂ ਨੂੰ ਹਟਾਉਣਾ ਚਾਹੁੰਦੇ ਹੋ? ਇਹ ਕਾਰਵਾਈ ਵਾਪਸ ਨਹੀਂ ਲਈ ਜਾ ਸਕਦੀ।`)) return;
    
    setActionLoading('bulk');
    try {
      const promises = selectedProfiles.map(id => {
        if (!id.startsWith('demo-')) {
          return deleteDoc(doc(db, 'profiles', id));
        }
        return Promise.resolve();
      });
      await Promise.all(promises);
      
      setProfiles(prev => prev.filter(p => !selectedProfiles.includes(p.id!)));
      
      await logActivity({
        type: 'admin_action',
        action: 'Bulk Deletion',
        details: `${selectedProfiles.length} profiles were deleted in bulk.`,
        performedBy: user?.uid || 'Admin',
        performedByName: 'Administrator'
      });

      showToast('success', `${selectedProfiles.length} ਪ੍ਰੋਫਾਈਲਾਂ ਹਟਾ ਦਿੱਤੀਆਂ ਗਈਆਂ ਹਨ।`);
      setSelectedProfiles([]);
    } catch (err: any) {
      showToast('error', 'ਬਲਕ ਡਿਲੀਟ ਵਿੱਚ ਗਲਤੀ: ' + err.message);
    } finally {
      setActionLoading(null);
    }
  };

  const toggleProfileSelection = (id: string) => {
    setSelectedProfiles(prev => 
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  };

  const t = {
    en: {
      adminControl: "Admin Control",
      profiles: "Profile Management",
      addProfile: "Add Profile",
      analytics: "Analytics 360",
      logs: "Activity Logs",
      stories: "Success Stories",
      metrics: "Site Metrics",
      settings: "System Settings",
      seo: "SEO Settings",
      mainMenu: "Main Menu",
      cmsConfig: "CMS & Config",
      collapseSidebar: "Collapse Sidebar",
      matchesPage: "Matches Page",
      logout: "Logout",
      totalProfiles: "Total Profiles",
      registeredMembers: "Registered Members",
      verified: "Verified",
      unverified: "Unverified",
      pendingVerification: "Pending Verification",
      underReview: "Under Review",
      drafts: "Drafts",
      incompleteForms: "Incomplete Forms",
      grooms: "Grooms",
      brides: "Brides",
      maleCandidates: "Male Candidates",
      femaleCandidates: "Female Candidates",
      searchPlaceholder: "Search by name, gotra, district or profession...",
      all: "All",
      allGenders: "All Genders",
      exportCSV: "Export CSV",
      refresh: "Refresh Data",
      newProfile: "Add New Profile",
      dashboard: "Dashboard & Analytics",
      profilesSelected: "profiles selected",
      bulkVerify: "Bulk Verify",
      bulkDelete: "Bulk Delete",
      verifiedBadge: "Badge Active",
      siteName: "Mahasha Matrimony",
      deselect: "Deselect All",
      candidateHeader: "Candidate",
      gotraHeader: "Mahasha Gotra",
      qualificationHeader: "Education & Profession",
      locationHeader: "Location",
      statusHeader: "Status",
      actionsHeader: "Actions",
      noProfilesFound: "No profiles found. Try changing search or filters.",
      years: "Years",
      nanake: "Maternal Gotra",
      verifiedStatus: "Verified",
      unverifiedStatus: "Pending",
      draftStatus: "Draft",
      viewDetails: "View Details",
      deleteProfile: "Delete Profile",
      removeVerify: "Remove Verification",
      addVerify: "Verify Profile",
      backToProfiles: "Back to Profiles",
      photosVideo: "Photos & Video",
      personalDetails: "Personal Details",
      familyDetails: "Family Details",
      bio: "About / Bio",
      physicalBirth: "Physical & Birth",
      locationDetails: "Location Details",
      gotraCommunity: "Gotra & Community",
      educationCareer: "Education & Career",
      saveProfile: "Save Profile",
      cancel: "Cancel",
      remove: "Remove",
      verify: "Verify",
      unnamed: "No Name",
      professional: "Professional",
      noEducation: "N/A",
      punjab: "Punjab",
      thisProfile: "this profile",
      bride: "Bride",
      groom: "Groom",
      verifiedProfileTooltip: "Verified Profile",
      mahasha: "Mahasha",
      addNewProfile: "Add New Profile",
      backToProfilesLong: "Back to Profiles",
      select: "Select",
      neverMarried: "Never Married",
      divorced: "Divorced",
      widowed: "Widowed",
      awaitingDivorce: "Awaiting Divorce",
      directEntryForm: "Direct Admin Entry Form",
      photos: "Photos",
      videoProfile: "Video Profile",
      fullName: "Full Name",
      gender: "Gender",
      age: "Age",
      maritalStatus: "Marital Status",
      dateOfBirth: "Date of Birth",
      fatherName: "Father's Name",
      motherName: "Mother's Name",
      fatherOccupation: "Father's Occupation",
      motherOccupation: "Mother's Occupation",
      brotherDetails: "Brother Details",
      sisterDetails: "Sister Details",
      annualIncome: "Annual Income",
      height: "Height",
      complexion: "Complexion",
      birthPlace: "Birth Place",
      state: "State",
      district: "District",
      address: "Address",
      fatherGotra: "Father's Gotra",
      motherGotra: "Mother's Gotra",
      religion: "Religion",
      qualification: "Qualification",
      profession: "Profession",
      analyticsReports: "Analytics & Reports",
      analyzeGrowth: "Analyze platform growth and user trends",
      occupationDetails: "Occupation Details",
      contactInfo: "Contact Information",
      mobileNumber: "Mobile Number",
      markVerified: "Mark as Verified"
    },
    pa: {
      adminControl: "ਐਡਮਿਨ ਕੰਟਰੋਲ",
      profiles: "ਪ੍ਰੋਫਾਈਲ ਮੈਨੇਜਮੈਂਟ",
      addProfile: "ਪ੍ਰੋਫਾਈਲ ਜੋੜੋ",
      analytics: "ਐਨਾਲਿਟਿਕਸ 360",
      logs: "ਐਕਟੀਵਿਟੀ ਲੋਗਸ",
      stories: "ਸਫਲ ਕਹਾਣੀਆਂ",
      metrics: "ਸਾਈਟ ਮੈਟ੍ਰਿਕਸ",
      settings: "ਸਿਸਟਮ ਸੈਟਿੰਗਾਂ",
      seo: "SEO ਸੈਟਿੰਗਾਂ",
      mainMenu: "ਮੁੱਖ ਮੇਨੂ",
      cmsConfig: "CMS & ਸੰਰਚਨਾ",
      collapseSidebar: "ਸਾਈਡਬਾਰ ਛੋਟਾ ਕਰੋ",
      matchesPage: "ਮੈਚਿਸ ਪੇਜ",
      logout: "ਲੌਗ ਆਉਟ",
      totalProfiles: "ਕੁੱਲ ਪ੍ਰੋਫਾਈਲ",
      registeredMembers: "ਰਜਿਸਟਰਡ ਮੈਂਬਰ",
      verified: "ਪ੍ਰਮਾਣਿਤ",
      unverified: "ਬਿਨਾਂ ਤਸਦੀਕ",
      pendingVerification: "ਪੈਂਡਿੰਗ ਤਸਦੀਕ",
      underReview: "ਜਾਂਚ ਅਧੀਨ",
      drafts: "ਡਰਾਫਟ",
      incompleteForms: "ਅਧੂਰੇ ਫਾਰਮ",
      grooms: "ਲਾੜੇ",
      brides: "ਲਾੜੀਆਂ",
      maleCandidates: "ਪੁਰਸ਼ ਉਮੀਦਵਾਰ",
      femaleCandidates: "ਮਹਿਲਾ ਉਮੀਦਵਾਰ",
      searchPlaceholder: "ਨਾਮ, ਗੋਤਰ, ਜ਼ਿਲ੍ਹਾ ਜਾਂ ਕਿੱਤੇ ਨਾਲ ਖੋਜੋ...",
      all: "ਸਾਰੇ",
      allGenders: "ਸਾਰੇ ਲਿੰਗ",
      exportCSV: "CSV ਨਿਰਯਾਤ ਕਰੋ",
      refresh: "ਡੇਟਾ ਰਿਫ੍ਰੈਸ਼ ਕਰੋ",
      newProfile: "ਨਵਾਂ ਪ੍ਰੋਫਾਈਲ ਜੋੜੋ",
      dashboard: "ਡੈਸ਼ਬੋਰਡ & ਐਨਾਲਿਟਿਕਸ",
      profilesSelected: "ਪ੍ਰੋਫਾਈਲਾਂ ਚੁਣੀਆਂ ਗਈਆਂ",
      bulkVerify: "ਬਲਕ ਵੈਰੀਫਿਕੇਸ਼ਨ",
      bulkDelete: "ਬਲਕ ਡਿਲੀਟ",
      verifiedBadge: "ਬੈਜ ਐਕਟਿਵ",
      siteName: "ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ",
      deselect: "ਚੋਣ ਰੱਦ ਕਰੋ",
      candidateHeader: "ਉਮੀਦਵਾਰ",
      gotraHeader: "ਮਹਾਸ਼ਾ ਗੋਤਰ",
      qualificationHeader: "ਸਿੱਖਿਆ & ਕਿੱਤਾ",
      locationHeader: "ਰਿਹਾਇਸ਼",
      statusHeader: "ਸਥਿਤੀ",
      actionsHeader: "ਕਾਰਵਾਈਆਂ",
      noProfilesFound: "ਕੋਈ ਪ੍ਰੋਫਾਈਲ ਨਹੀਂ ਮਿਲੀ। ਖੋਜ ਜਾਂ ਫਿਲਟਰ ਬਦਲੋ।",
      years: "ਸਾਲ",
      nanake: "ਨਾਨਕੇ",
      verifiedStatus: "ਪ੍ਰਮਾਣਿਤ",
      unverifiedStatus: "ਜਾਂਚ ਬਾਕੀ",
      draftStatus: "ਡਰਾਫਟ",
      viewDetails: "ਵੇਰਵਾ ਦੇਖੋ",
      deleteProfile: "ਪ੍ਰੋਫਾਈਲ ਡਿਲੀਟ ਕਰੋ",
      removeVerify: "ਪ੍ਰਮਾਣੀਕਰਨ ਹਟਾਓ",
      addVerify: "ਪ੍ਰਮਾਣਿਤ ਬੈਜ ਦਿਓ",
      backToProfiles: "ਵਾਪਸ ਪ੍ਰੋਫਾਈਲਾਂ 'ਤੇ",
      photosVideo: "ਫੋਟੋਆਂ ਅਤੇ ਵੀਡੀਓ",
      personalDetails: "ਨਿੱਜੀ ਜਾਣਕਾਰੀ",
      familyDetails: "ਪਰਿਵਾਰਕ ਵੇਰਵਾ",
      bio: "ਮੇਰੇ ਬਾਰੇ",
      physicalBirth: "ਸਰੀਰਕ ਅਤੇ ਜਨਮ",
      locationDetails: "ਰਿਹਾਇਸ਼",
      gotraCommunity: "ਗੋਤਰ ਅਤੇ ਕਾਸਟ",
      educationCareer: "ਸਿੱਖਿਆ ਅਤੇ ਕਿੱਤਾ",
      saveProfile: "ਪ੍ਰੋਫਾਈਲ ਸੇਵ ਕਰੋ",
      cancel: "ਰੱਦ ਕਰੋ",
      remove: "ਹਟਾਓ",
      verify: "ਪ੍ਰਮਾਣਿਤ ਕਰੋ",
      unnamed: "ਬਿਨਾਂ ਨਾਮ",
      professional: "ਪੇਸ਼ੇਵਰ",
      noEducation: "ਯੋਗਤਾ ਦਰਜ ਨਹੀਂ",
      punjab: "ਪੰਜਾਬ",
      thisProfile: "ਇਹ ਪ੍ਰੋਫਾਈਲ",
      bride: "ਲਾੜੀ",
      groom: "ਲਾੜਾ",
      verifiedProfileTooltip: "ਪ੍ਰਮਾਣਿਤ ਪ੍ਰੋਫਾਈਲ",
      mahasha: "ਮਹਾਸ਼ਾ",
      addNewProfile: "ਨਵਾਂ ਪ੍ਰੋਫਾਈਲ ਜੋੜੋ",
      backToProfilesLong: "ਵਾਪਸ ਪ੍ਰੋਫਾਈਲਾਂ 'ਤੇ",
      select: "ਸਿਲੈਕਟ ਕਰੋ",
      neverMarried: "ਕਦੇ ਵਿਆਹ ਨਹੀਂ ਹੋਇਆ",
      divorced: "ਤਲਾਕਸ਼ੁਦਾ",
      widowed: "ਵਿਧਵਾ/ਵਿਧੁਰ",
      awaitingDivorce: "ਤਲਾਕ ਦੀ ਉਡੀਕ",
      directEntryForm: "Direct Admin Entry Form",
      photos: "ਫੋਟੋਆਂ",
      videoProfile: "ਵੀਡੀਓ ਪ੍ਰੋਫਾਈਲ",
      fullName: "ਪੂਰਾ ਨਾਮ",
      gender: "ਲਿੰਗ",
      age: "ਉਮਰ",
      maritalStatus: "ਵਿਆਹੁਤਾ ਸਥਿਤੀ",
      dateOfBirth: "ਜਨਮ ਮਿਤੀ",
      fatherName: "ਪਿਤਾ ਦਾ ਨਾਮ",
      motherName: "ਮਾਤਾ ਦਾ ਨਾਮ",
      fatherOccupation: "ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ",
      motherOccupation: "ਮਾਤਾ ਜੀ ਦਾ ਵੇਰਵਾ",
      brotherDetails: "ਭਰਾਵਾਂ ਦਾ ਵੇਰਵਾ",
      sisterDetails: "ਭੈਣਾਂ ਦਾ ਵੇਰਵਾ",
      annualIncome: "ਸਾਲਾਨਾ ਆਮਦਨ",
      height: "ਕੱਦ",
      complexion: "ਰੰਗ",
      birthPlace: "ਜਨਮ ਸਥਾਨ",
      state: "ਸਟੇਟ",
      district: "ਜ਼ਿਲ੍ਹਾ",
      address: "ਪਤਾ",
      fatherGotra: "ਪਿਤਾ ਦਾ ਗੋਤਰ",
      motherGotra: "ਮਾਤਾ ਦਾ ਗੋਤਰ",
      religion: "ਧਰਮ",
      qualification: "ਯੋਗਤਾ",
      profession: "ਪੇਸ਼ਾ",
      analyticsReports: "ਐਨਾਲਿਟਿਕਸ & ਰਿਪੋਰਟਸ",
      analyzeGrowth: "ਪਲੇਟਫਾਰਮ ਦੇ ਵਾਧੇ ਅਤੇ ਉਪਭੋਗਤਾ ਦੇ ਰੁਝਾਨਾਂ ਦਾ ਵਿਸ਼ਲੇਸ਼ਣ ਕਰੋ",
      occupationDetails: "ਕੰਮ ਦਾ ਵੇਰਵਾ",
      contactInfo: "ਸੰਪਰਕ ਵੇਰਵਾ",
      mobileNumber: "ਸੰਪਰਕ ਨੰਬਰ",
      markVerified: "ਤਸਦੀਕ ਕਰੋ"
    }
  }[lang];

  const toggleAllSelection = () => {
    if (selectedProfiles.length > 0 && selectedProfiles.length === filteredProfiles.length) {
      setSelectedProfiles([]);
    } else {
      setSelectedProfiles(filteredProfiles.map(p => p.id!).filter(id => id !== undefined));
    }
  };

  // Calculate Metrics
  const totalProfiles = profiles.length;
  const verifiedCount = profiles.filter(p => p.isVerified).length;
  const unverifiedCount = profiles.filter(p => !p.isVerified && !p.isDraft).length;
  const draftsCount = profiles.filter(p => p.isDraft).length;
  const groomsCount = profiles.filter(p => p.gender === 'Male').length;
  const bridesCount = profiles.filter(p => p.gender === 'Female').length;

  // Filter Profiles
  const filteredProfiles = profiles.filter(p => {
    const matchesSearch = 
      (p.fullName || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.district || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.fatherGotra || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.profession || '').toLowerCase().includes(searchTerm.toLowerCase());

    const matchesStatus = 
      statusFilter === 'all' ||
      (statusFilter === 'verified' && p.isVerified) ||
      (statusFilter === 'unverified' && !p.isVerified && !p.isDraft) ||
      (statusFilter === 'drafts' && p.isDraft);

    const matchesGender = genderFilter === 'all' || p.gender === genderFilter;

    return matchesSearch && matchesStatus && matchesGender;
  });

  const SidebarItem = ({ tab, icon: Icon, label }: { tab: typeof activeTab, icon: any, label: string }) => {
    const isActuallyCollapsed = isCollapsed && window.innerWidth >= 1024;
    
    return (
      <button
        onClick={() => {
          setActiveTab(tab);
          if (window.innerWidth < 1024) setIsSidebarOpen(false);
        }}
        title={isActuallyCollapsed ? label : ''}
        className={`w-full flex items-center ${isActuallyCollapsed ? 'justify-center px-0' : 'gap-3 px-4'} py-3 rounded-xl font-bold text-sm transition-all duration-200 group relative ${
          activeTab === tab 
            ? 'bg-rose-900 text-white shadow-md shadow-rose-900/20' 
            : 'text-gray-500 hover:bg-gray-100 hover:text-rose-950'
        }`}
      >
        <Icon className={`w-5 h-5 shrink-0 transition-colors ${activeTab === tab ? 'text-amber-300' : 'text-gray-400 group-hover:text-rose-900'}`} />
        {!isActuallyCollapsed && <span className="truncate">{label}</span>}
        {isActuallyCollapsed && (
          <div className="absolute left-full ml-4 px-3 py-2 bg-rose-900 text-white text-[11px] rounded-lg opacity-0 group-hover:opacity-100 pointer-events-none transition-all transform translate-x-2 group-hover:translate-x-0 shadow-xl z-50 whitespace-nowrap">
            {label}
            <div className="absolute right-full top-1/2 -translate-y-1/2 border-8 border-transparent border-right-rose-900 ml-[-8px]"></div>
          </div>
        )}
      </button>
    );
  };

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <SEO 
        title="ਐਡਮਿਨ ਪੈਨਲ & CMS ਕੰਟਰੋਲ - ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ"
        description="ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਐਡਮਿਨ ਡੈਸ਼ਬੋਰਡ - ਪ੍ਰੋਫਾਈਲ ਵੈਰੀਫਿਕੇਸ਼ਨ, CMS ਸੈਟਿੰਗਾਂ ਅਤੇ ਸਮਾਜ ਪ੍ਰਬੰਧਨ।"
        noIndex={true}
      />

      {/* Sidebar Overlay (Mobile) */}
      {isSidebarOpen && (
        <div 
          className="fixed inset-0 bg-black/50 z-40 lg:hidden backdrop-blur-sm transition-all"
          onClick={() => setIsSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <aside className={`
        fixed inset-y-0 left-0 z-50 bg-white border-r border-gray-200 transform transition-all duration-300 ease-in-out lg:relative lg:translate-x-0
        ${isSidebarOpen ? 'translate-x-0 w-72 shadow-2xl' : '-translate-x-full lg:translate-x-0'}
        ${!isSidebarOpen && isCollapsed ? 'lg:w-20' : 'lg:w-72'}
      `}>
        <div className={`h-full flex flex-col ${isCollapsed ? 'p-3' : 'p-6'} transition-all duration-300 relative`}>
          {/* Mobile Close Button */}
          {isSidebarOpen && (
            <button 
              onClick={() => setIsSidebarOpen(false)}
              className="lg:hidden absolute top-6 right-6 p-2 text-gray-400 hover:text-rose-950 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          )}

          <div className={`flex items-center ${isCollapsed ? 'justify-center' : 'gap-3'} mb-10 px-2`}>
            <div className="p-2.5 bg-rose-900 rounded-xl shadow-lg shadow-rose-900/20 shrink-0">
              <ShieldCheck className="w-6 h-6 text-amber-300" />
            </div>
            {!isCollapsed && (
              <div className="animate-in fade-in slide-in-from-left-2 duration-300">
                <h2 className="text-lg font-bold text-rose-950 font-serif leading-tight">{t.adminControl}</h2>
                <p className="text-[10px] text-gray-400 font-bold uppercase tracking-widest mt-0.5">{t.siteName}</p>
              </div>
            )}
          </div>

          <div className="flex-1 space-y-1 overflow-y-auto no-scrollbar">
            {!isCollapsed && <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-4 mb-2">{t.mainMenu}</div>}
            <SidebarItem tab="profiles" icon={Users} label={t.profiles} />
            <SidebarItem tab="add-profile" icon={Plus} label={t.addProfile} />
            <SidebarItem tab="analytics" icon={ChartIcon} label={t.analytics} />
            <SidebarItem tab="logs" icon={HistoryIcon} label={t.logs} />
            
            <div className={`pt-6 ${isCollapsed ? 'hidden' : 'block'}`}>
              <div className="text-[10px] font-bold text-gray-400 uppercase tracking-widest px-4 mb-2">{t.cmsConfig}</div>
              <SidebarItem tab="stories" icon={MessageCircleHeart} label={t.stories} />
              <SidebarItem tab="metrics" icon={BarChart3} label={t.metrics} />
              <SidebarItem tab="bulk-upload" icon={Database} label="Bulk Upload" />
              <SidebarItem tab="settings" icon={Settings} label={t.settings} />
              <SidebarItem tab="seo" icon={Sparkles} label={t.seo} />
            </div>
            {isCollapsed && (
              <div className="pt-6 flex flex-col items-center gap-1 border-t border-gray-100 mt-4">
                <SidebarItem tab="stories" icon={MessageCircleHeart} label={t.stories} />
                <SidebarItem tab="settings" icon={Settings} label={t.settings} />
              </div>
            )}
          </div>

          <div className="mt-auto pt-6 border-t border-gray-100 space-y-1">
            <button 
              onClick={() => setIsCollapsed(!isCollapsed)}
              className="hidden lg:flex w-full items-center gap-3 px-4 py-3 rounded-xl text-gray-500 hover:bg-gray-100 font-bold text-sm transition-all"
            >
              {isCollapsed ? <PanelLeft className="w-5 h-5 mx-auto" /> : (
                <>
                  <PanelLeftClose className="w-5 h-5" />
                  {t.collapseSidebar}
                </>
              )}
            </button>
             <Link 
              to="/matches" 
              className={`flex items-center ${isCollapsed ? 'justify-center px-0' : 'gap-3 px-4'} py-3 rounded-xl text-gray-500 hover:bg-rose-50 hover:text-rose-900 font-bold text-sm transition-all`}
            >
              <ExternalLink className="w-5 h-5 shrink-0" />
              {!isCollapsed && <span>{t.matchesPage}</span>}
            </Link>
            <button 
              onClick={() => {
                sessionStorage.removeItem('mahasha_admin_auth');
                window.location.href = '/';
              }}
              className={`w-full flex items-center ${isCollapsed ? 'justify-center px-0' : 'gap-3 px-4'} py-3 rounded-xl text-rose-600 hover:bg-rose-50 font-bold text-sm transition-all`}
            >
              <LogOut className="w-5 h-5 shrink-0" />
              {!isCollapsed && <span>{t.logout}</span>}
            </button>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col min-w-0 bg-gray-50 overflow-hidden">
        {/* Top Header */}
        <header className="bg-white border-b border-gray-200 h-16 shrink-0 flex items-center justify-between px-4 sm:px-8 z-30">
          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsSidebarOpen(true)}
              className="lg:hidden p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <Menu className="w-6 h-6" />
            </button>
            <h1 className="text-lg sm:text-xl font-bold text-rose-950 font-serif line-clamp-1">
              {activeTab === 'profiles' && t.profiles}
              {activeTab === 'add-profile' && t.newProfile}
              {activeTab === 'analytics' && t.dashboard}
              {activeTab === 'logs' && t.logs}
              {activeTab === 'stories' && t.stories}
              {activeTab === 'metrics' && t.metrics}
              {activeTab === 'bulk-upload' && 'Bulk Upload'}
              {activeTab === 'settings' && t.settings}
              {activeTab === 'seo' && t.seo}
            </h1>
          </div>

          <div className="flex items-center gap-2 sm:gap-4">
            <button
              onClick={() => setLang(lang === 'en' ? 'pa' : 'en')}
              className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-gray-200 text-xs font-bold text-gray-600 hover:bg-gray-50 transition-all"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-500" />
              {lang === 'en' ? 'ਪੰਜਾਬੀ' : 'English'}
            </button>
            <button
              onClick={fetchAllData}
              className="p-2 text-gray-500 hover:bg-gray-100 rounded-lg transition-all group"
              title={t.refresh}
            >
              <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : 'group-hover:rotate-180 transition-transform duration-500'}`} />
            </button>
            <div className="hidden sm:flex items-center gap-3 pl-4 border-l border-gray-200">
              <div className="text-right">
                <p className="text-xs font-bold text-gray-900 leading-none">Administrator</p>
                <p className="text-[10px] text-gray-500 mt-1 uppercase tracking-tighter">Super Admin</p>
              </div>
              <div className="w-8 h-8 rounded-full bg-rose-900 flex items-center justify-center text-amber-300 font-bold text-xs shadow-sm">
                AD
              </div>
            </div>
          </div>
        </header>

        {/* Scrollable Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-8 no-scrollbar">
          {/* Notification Toast */}
          {notification && (
            <div className="mb-6 animate-in fade-in slide-in-from-top-4 duration-300">
              <div className={`p-4 rounded-xl text-sm font-bold flex items-center justify-between shadow-lg ${
                notification.type === 'success' 
                  ? 'bg-emerald-600 text-white' 
                  : 'bg-rose-600 text-white'
              }`}>
                <div className="flex items-center gap-2">
                  {notification.type === 'success' ? <Check className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
                  <span>{notification.msg}</span>
                </div>
                <button onClick={() => setNotification(null)} className="p-1 hover:bg-white/20 rounded">
                  <X className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          <div className="max-w-7xl mx-auto">
            {activeTab === 'profiles' && (
          <>
            {/* KPI Stats Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4 mb-6">
          <div className="bg-white p-4 rounded-2xl border border-gray-200/80 shadow-xs">
            <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block">{t.totalProfiles}</span>
            <span className="text-2xl font-extrabold text-rose-950 mt-1 block font-serif">{totalProfiles}</span>
            <span className="text-[10px] text-gray-400">{t.registeredMembers}</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-emerald-200 shadow-xs bg-emerald-50/20">
            <span className="text-[11px] font-bold text-emerald-700 uppercase tracking-wider block">{t.verified}</span>
            <span className="text-2xl font-extrabold text-emerald-700 mt-1 block font-serif">{verifiedCount}</span>
            <span className="text-[10px] text-emerald-600 font-semibold">{t.verifiedBadge}</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-amber-200 shadow-xs bg-amber-50/20">
            <span className="text-[11px] font-bold text-amber-700 uppercase tracking-wider block">{t.pendingVerification}</span>
            <span className="text-2xl font-extrabold text-amber-800 mt-1 block font-serif">{unverifiedCount}</span>
            <span className="text-[10px] text-amber-700 font-semibold">{t.underReview}</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-purple-200 shadow-xs bg-purple-50/20">
            <span className="text-[11px] font-bold text-purple-700 uppercase tracking-wider block">{t.drafts}</span>
            <span className="text-2xl font-extrabold text-purple-800 mt-1 block font-serif">{draftsCount}</span>
            <span className="text-[10px] text-purple-600 font-semibold">{t.incompleteForms}</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-blue-200 shadow-xs bg-blue-50/20">
            <span className="text-[11px] font-bold text-blue-700 uppercase tracking-wider block">{t.grooms}</span>
            <span className="text-2xl font-extrabold text-blue-800 mt-1 block font-serif">{groomsCount}</span>
            <span className="text-[10px] text-blue-600 font-semibold">{t.maleCandidates}</span>
          </div>

          <div className="bg-white p-4 rounded-2xl border border-pink-200 shadow-xs bg-pink-50/20">
            <span className="text-[11px] font-bold text-pink-700 uppercase tracking-wider block">{t.brides}</span>
            <span className="text-2xl font-extrabold text-pink-800 mt-1 block font-serif">{bridesCount}</span>
            <span className="text-[10px] text-pink-600 font-semibold">{t.femaleCandidates}</span>
          </div>
        </div>

        {/* Filter and Search Controls */}
        <div className="bg-white p-4 sm:p-5 rounded-2xl border border-gray-200 shadow-xs mb-6 flex flex-col md:flex-row gap-4 justify-between items-center">
          
          {/* Search Input */}
          <div className="relative w-full md:w-80">
            <Search className="w-4 h-4 text-gray-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder={t.searchPlaceholder}
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9.5 pr-4 py-2.5 text-xs sm:text-sm border border-gray-300 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
            />
          </div>

          {/* Filter Pills */}
          <div className="flex flex-wrap items-center gap-2 w-full md:w-auto">
            
            {/* Status Filter */}
            <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
              <button
                onClick={() => setStatusFilter('all')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === 'all' ? 'bg-white text-rose-950 shadow-xs' : 'text-gray-600 hover:text-gray-900'
                }`}
              >
                {t.all} ({totalProfiles})
              </button>
              <button
                onClick={() => setStatusFilter('verified')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === 'verified' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-800 hover:text-emerald-950'
                }`}
              >
                {t.verified}
              </button>
              <button
                onClick={() => setStatusFilter('unverified')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === 'unverified' ? 'bg-amber-500 text-rose-950 shadow-xs' : 'text-amber-800 hover:text-amber-950'
                }`}
              >
                {t.unverified}
              </button>
              <button
                onClick={() => setStatusFilter('drafts')}
                className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                  statusFilter === 'drafts' ? 'bg-purple-600 text-white shadow-xs' : 'text-purple-800 hover:text-purple-950'
                }`}
              >
                {t.drafts}
              </button>
            </div>

            {/* Gender Filter */}
            <div className="flex items-center gap-1 bg-gray-100 p-1 rounded-xl">
              <button
                onClick={() => setGenderFilter('all')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold ${
                  genderFilter === 'all' ? 'bg-white text-rose-950 shadow-xs' : 'text-gray-600'
                }`}
              >
                {t.allGenders}
              </button>
              <button
                onClick={() => setGenderFilter('Male')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold ${
                  genderFilter === 'Male' ? 'bg-blue-600 text-white shadow-xs' : 'text-blue-800'
                }`}
              >
                {t.grooms}
              </button>
              <button
                onClick={() => setGenderFilter('Female')}
                className={`px-2.5 py-1.5 rounded-lg text-xs font-bold ${
                  genderFilter === 'Female' ? 'bg-pink-600 text-white shadow-xs' : 'text-pink-800'
                }`}
              >
                {t.brides}
              </button>
            </div>

            <button
              onClick={handleExportProfiles}
              className="ml-auto inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-sm transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              {t.exportCSV}
            </button>
          </div>
        </div>

        <div className="bg-white rounded-2xl border border-gray-200 shadow-xs overflow-hidden">
          {selectedProfiles.length > 0 && (
            <div className="bg-amber-50 px-4 py-3 border-b border-amber-200 flex items-center justify-between animate-in fade-in slide-in-from-top-2">
              <div className="flex items-center gap-3">
                <span className="text-sm font-bold text-amber-900">
                  {selectedProfiles.length} {t.profilesSelected}
                </span>
                <button 
                  onClick={() => setSelectedProfiles([])}
                  className="text-xs font-bold text-amber-700 hover:text-amber-800 underline decoration-2 underline-offset-2"
                >
                  {t.deselect}
                </button>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleBulkVerify}
                  disabled={actionLoading === 'bulk'}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm disabled:opacity-50"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  {t.bulkVerify}
                </button>
                <button
                  onClick={handleBulkDelete}
                  disabled={actionLoading === 'bulk'}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-rose-600 hover:bg-rose-700 text-white rounded-lg text-xs font-bold transition-all shadow-sm disabled:opacity-50"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  {t.bulkDelete}
                </button>
              </div>
            </div>
          )}
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs sm:text-sm">
              <thead className="bg-gray-50/80 border-b border-gray-200 text-gray-700 font-bold uppercase tracking-wider text-[11px]">
                <tr>
                  <th className="py-3.5 px-4 w-10">
                    <input 
                      type="checkbox" 
                      className="w-4 h-4 rounded border-gray-300 text-rose-900 focus:ring-rose-900"
                      checked={filteredProfiles.length > 0 && selectedProfiles.length === filteredProfiles.length}
                      onChange={toggleAllSelection}
                    />
                  </th>
                  <th className="py-3.5 px-4">{t.candidateHeader}</th>
                  <th className="py-3.5 px-4">{t.gotraHeader}</th>
                  <th className="py-3.5 px-4">{t.qualificationHeader}</th>
                  <th className="py-3.5 px-4">{t.locationHeader}</th>
                  <th className="py-3.5 px-4">{t.statusHeader}</th>
                  <th className="py-3.5 px-4 text-right">{t.actionsHeader}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100 text-gray-800">
                {filteredProfiles.length === 0 ? (
                  <tr>
                    <td colSpan={7} className="py-12 text-center text-gray-500 font-medium">
                      {t.noProfilesFound}
                    </td>
                  </tr>
                ) : (
                  filteredProfiles.map((p) => (
                    <tr key={p.id} className={`hover:bg-amber-50/30 transition-colors ${selectedProfiles.includes(p.id!) ? 'bg-amber-50/50' : ''}`}>
                      
                      {/* Checkbox Column */}
                      <td className="py-3.5 px-4">
                        <input 
                          type="checkbox" 
                          className="w-4 h-4 rounded border-gray-300 text-rose-900 focus:ring-rose-900"
                          checked={selectedProfiles.includes(p.id!)}
                          onChange={() => toggleProfileSelection(p.id!)}
                        />
                      </td>

                      {/* Candidate Column */}
                      <td className="py-3.5 px-4">
                        <div className="flex items-center gap-3">
                          <img
                            src={p.photoUrl || (p.photoUrls && p.photoUrls[0]) || (p.gender === 'Female' ? 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300' : 'https://images.unsplash.com/photo-1610173827002-62c0f1f1d1eb?q=80&w=300')}
                            alt={p.fullName}
                            className="w-11 h-11 rounded-xl object-cover border border-amber-300 shadow-2xs shrink-0"
                          />
                          <div>
                            <div className="font-bold text-gray-900 flex items-center gap-1.5">
                              {p.fullName || t.unnamed}
                              {p.isVerified && (
                                <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" title={t.verifiedProfileTooltip} />
                              )}
                            </div>
                            <div className="text-xs text-gray-500 flex items-center gap-1 mt-0.5">
                              <span className={`px-1.5 py-0.2 rounded font-bold text-[10px] ${
                                p.gender === 'Female' ? 'bg-pink-100 text-pink-800' : 'bg-blue-100 text-blue-800'
                              }`}>
                                {p.gender === 'Female' ? t.bride : t.groom}
                              </span>
                              <span>• {p.age ? `${p.age} ${t.years}` : ''}</span>
                              {p.height && <span>• {p.height}</span>}
                            </div>
                          </div>
                        </div>
                      </td>

                      {/* Gotra Column */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-rose-950">
                          {p.fatherGotra || p.community || t.mahasha}
                        </div>
                        {p.motherGotra && (
                          <div className="text-xs text-gray-500">
                            {t.nanake}: {p.motherGotra}
                          </div>
                        )}
                      </td>

                      {/* Education & Profession */}
                      <td className="py-3.5 px-4">
                        <div className="font-semibold text-gray-900 line-clamp-1">
                          {p.profession || t.professional}
                        </div>
                        <div className="text-xs text-gray-500 line-clamp-1">
                          {p.qualification1 || p.education || t.noEducation}
                        </div>
                      </td>

                      {/* Location Column */}
                      <td className="py-3.5 px-4">
                        <div className="text-xs font-semibold text-gray-800 flex items-center gap-1">
                          <MapPin className="w-3.5 h-3.5 text-amber-600 shrink-0" />
                          <span className="line-clamp-1">{p.district || p.location || t.punjab}</span>
                        </div>
                      </td>

                      {/* Status Column */}
                      <td className="py-3.5 px-4">
                        {p.isDraft ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-800 border border-purple-200">
                            ਡਰਾਫਟ (Draft)
                          </span>
                        ) : p.isVerified ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                            ਪ੍ਰਮਾਣਿਤ
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-bold bg-amber-100 text-amber-800 border border-amber-200">
                            ਜਾਂਚ ਬਾਕੀ
                          </span>
                        )}
                      </td>

                      {/* Actions Column */}
                      <td className="py-3.5 px-4 text-right space-x-2">
                        
                        {/* Toggle Verify Button */}
                        <button
                          type="button"
                          disabled={actionLoading === p.id}
                          onClick={() => handleToggleVerify(p.id!, !!p.isVerified)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                            p.isVerified
                              ? 'bg-gray-100 hover:bg-rose-100 text-gray-700 hover:text-rose-800 border border-gray-300'
                              : 'bg-emerald-600 hover:bg-emerald-500 text-white shadow-xs'
                          }`}
                          title={p.isVerified ? t.removeVerify : t.addVerify}
                        >
                          {p.isVerified ? t.remove : t.verify}
                        </button>

                        {/* View Profile */}
                        <button
                          type="button"
                          onClick={() => setSelectedProfile(p)}
                          className="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-amber-100 hover:bg-amber-200 text-rose-950 transition-colors"
                          title={t.viewDetails}
                        >
                          <Eye className="w-4 h-4 inline" />
                        </button>

                        {/* Delete Profile */}
                        <button
                          type="button"
                          disabled={actionLoading === p.id}
                          onClick={() => handleDeleteProfile(p.id!, p.fullName || t.thisProfile)}
                          className="px-2.5 py-1.5 rounded-lg text-xs font-bold bg-rose-100 hover:bg-rose-200 text-rose-800 transition-colors"
                          title={t.deleteProfile}
                        >
                          <Trash2 className="w-4 h-4 inline" />
                        </button>

                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
        </>
        )}

        {activeTab === 'add-profile' && (
          <div className="bg-white rounded-[2.5rem] border border-gray-200 shadow-sm overflow-hidden animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-gradient-to-r from-rose-900 to-rose-950 p-8 sm:p-10 text-white relative overflow-hidden">
              <div className="absolute top-0 right-0 w-64 h-64 bg-white/5 rounded-full -translate-y-1/2 translate-x-1/2 blur-3xl" />
              <div className="relative z-10 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
                <div>
                  <h2 className="text-2xl sm:text-3xl font-extrabold font-serif mb-2 text-white">{t.addNewProfile}</h2>
                  <p className="text-rose-100 font-bold text-xs uppercase tracking-widest opacity-80">{t.directEntryForm}</p>
                </div>
                <button 
                  onClick={() => setActiveTab('profiles')}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-white/10 hover:bg-white/20 rounded-xl transition-all font-bold text-xs text-white"
                >
                  <Users className="w-4 h-4" />
                  {t.backToProfilesLong}
                </button>
              </div>
            </div>

            <div className="p-8 sm:p-10 space-y-12">
               {/* Section: Photos & Video */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.photosVideo}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-4">
                  <label className="block text-[11px] font-bold text-gray-400 uppercase">{t.photos} (Max 5)</label>
                  <div className="grid grid-cols-3 sm:grid-cols-5 gap-3">
                    {newProfile.photoUrls?.map((url, idx) => (
                      <div key={idx} className="relative group aspect-square rounded-xl overflow-hidden border-2 border-gray-100">
                        <img src={url} alt="" className="w-full h-full object-cover" />
                        <button 
                          onClick={() => setNewProfile(prev => ({...prev, photoUrls: prev.photoUrls?.filter((_, i) => i !== idx)}))}
                          className="absolute top-1 right-1 bg-white/90 p-1 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-3 h-3 text-rose-600" />
                        </button>
                      </div>
                    ))}
                    {(newProfile.photoUrls?.length || 0) < 5 && (
                      <label className="aspect-square rounded-xl border-2 border-dashed border-gray-200 flex flex-col items-center justify-center cursor-pointer hover:bg-gray-50 transition-colors">
                        <Camera className="w-5 h-5 text-gray-400" />
                        <input 
                          type="file" 
                          className="hidden" 
                          multiple 
                          accept="image/*"
                          onChange={e => {
                            const files = e.target.files;
                            if (!files) return;
                            Array.from(files).forEach((file: File) => {
                              const reader = new FileReader();
                              reader.onload = (ev) => {
                                const result = ev.target?.result;
                                if (typeof result !== 'string') return;
                                const img = new Image();
                                img.onload = () => {
                                  const canvas = document.createElement('canvas');
                                  let width = img.width;
                                  let height = img.height;
                                  const MAX_SIZE = 500;
                                  if (width > height && width > MAX_SIZE) { height *= MAX_SIZE / width; width = MAX_SIZE; }
                                  else if (height > MAX_SIZE) { width *= MAX_SIZE / height; height = MAX_SIZE; }
                                  canvas.width = width; canvas.height = height;
                                  const ctx = canvas.getContext('2d');
                                  ctx?.drawImage(img, 0, 0, width, height);
                                  const dataUrl = canvas.toDataURL('image/jpeg', 0.6);
                                  setNewProfile(prev => ({...prev, photoUrls: [...(prev.photoUrls || []), dataUrl].slice(0, 5)}));
                                };
                                img.src = result as string;
                              };
                              reader.readAsDataURL(file as Blob);
                            });
                          }} 
                        />
                      </label>
                    )}
                  </div>
                </div>
                <div className="space-y-4">
                  <label className="block text-[11px] font-bold text-gray-400 uppercase">{t.videoProfile}</label>
                  <input 
                    type="text" 
                    placeholder="YouTube / Instagram Reel Link"
                    value={newProfile.videoUrl || ''}
                    onChange={e => setNewProfile({...newProfile, videoUrl: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm"
                  />
                </div>
              </div>
            </div>

            {/* Section: Personal */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.personalDetails}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.fullName}</label>
                  <input 
                    type="text" 
                    value={newProfile.fullName || ''}
                    onChange={e => setNewProfile({...newProfile, fullName: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                    placeholder="e.g. Aman Kaur"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.gender}</label>
                  <select 
                    value={newProfile.gender}
                    onChange={e => setNewProfile({...newProfile, gender: e.target.value as any})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="Male">{t.groom} (Male)</option>
                    <option value="Female">{t.bride} (Female)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.age}</label>
                  <input 
                    type="number" 
                    value={newProfile.age || ''}
                    onChange={e => setNewProfile({...newProfile, age: parseInt(e.target.value) || 0})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.maritalStatus}</label>
                  <select 
                    value={newProfile.maritalStatus || 'Never Married'}
                    onChange={e => setNewProfile({...newProfile, maritalStatus: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="Never Married">{t.neverMarried} (Never Married)</option>
                    <option value="Divorced">{t.divorced} (Divorced)</option>
                    <option value="Widowed">{t.widowed} (Widowed)</option>
                    <option value="Awaiting Divorce">{t.awaitingDivorce} (Awaiting Divorce)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.dateOfBirth}</label>
                  <input 
                    type="text" 
                    placeholder="DD-MM-YYYY"
                    value={newProfile.dateOfBirth || ''}
                    onChange={e => {
                      let v = e.target.value.replace(/\D/g, '');
                      if (v.length > 4) v = `${v.substring(0, 2)}-${v.substring(2, 4)}-${v.substring(4, 8)}`;
                      else if (v.length > 2) v = `${v.substring(0, 2)}-${v.substring(2, 4)}`;
                      setNewProfile({...newProfile, dateOfBirth: v});
                    }}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Section: Family */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.familyDetails}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.fatherName}</label>
                  <input 
                    type="text" 
                    value={newProfile.fatherName || ''}
                    onChange={e => setNewProfile({...newProfile, fatherName: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.motherName}</label>
                  <input 
                    type="text" 
                    value={newProfile.motherName || ''}
                    onChange={e => setNewProfile({...newProfile, motherName: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.fatherOccupation}</label>
                  <input 
                    type="text" 
                    value={newProfile.fatherOccupation || ''}
                    onChange={e => setNewProfile({...newProfile, fatherOccupation: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.motherOccupation}</label>
                  <input 
                    type="text" 
                    value={newProfile.motherOccupation || ''}
                    onChange={e => setNewProfile({...newProfile, motherOccupation: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.brotherDetails}</label>
                  <input 
                    type="text" 
                    value={newProfile.brotherDetails || ''}
                    onChange={e => setNewProfile({...newProfile, brotherDetails: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                    placeholder="e.g. 1 Brother (Married)"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.sisterDetails}</label>
                  <input 
                    type="text" 
                    value={newProfile.sisterDetails || ''}
                    onChange={e => setNewProfile({...newProfile, sisterDetails: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                    placeholder="e.g. 2 Sisters (Unmarried)"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.annualIncome}</label>
                  <input 
                    type="text" 
                    value={newProfile.income || ''}
                    onChange={e => setNewProfile({...newProfile, income: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                    placeholder="e.g. 10-20 Lakhs"
                  />
                </div>
              </div>
            </div>

            {/* Section: Bio */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.bio}</h3>
              <div>
                <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.bio}</label>
                <textarea 
                  value={newProfile.aboutMe || ''}
                  onChange={e => setNewProfile({...newProfile, aboutMe: e.target.value})}
                  className="w-full px-4 py-3 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold min-h-[120px]"
                  placeholder="Describe the person's character, expectations, and values..."
                />
              </div>
            </div>

            {/* Section: Physical */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.physicalBirth}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.height}</label>
                  <select 
                    value={newProfile.height || ''}
                    onChange={e => setNewProfile({...newProfile, height: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="">{t.select} (Select)</option>
                    {['4\'10" (147 cm)', '4\'11" (150 cm)', '5\'0" (152 cm)', '5\'1" (155 cm)', '5\'2" (157 cm)', '5\'3" (160 cm)', '5\'4" (162 cm)', '5\'5" (165 cm)', '5\'6" (168 cm)', '5\'7" (170 cm)', '5\'8" (173 cm)', '5\'9" (175 cm)', '5\'10" (178 cm)', '5\'11" (180 cm)', '6\'0" (183 cm)'].map(h => (
                      <option key={h} value={h}>{h}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.complexion}</label>
                  <select 
                    value={newProfile.complexion || ''}
                    onChange={e => setNewProfile({...newProfile, complexion: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="">{t.select} (Select)</option>
                    {formConfig.complexions.map(c => (
                      <option key={c.value} value={c.value}>{c.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.birthPlace}</label>
                  <input 
                    type="text" 
                    value={newProfile.birthPlace || ''}
                    onChange={e => setNewProfile({...newProfile, birthPlace: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Section: Location */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.locationDetails}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.state}</label>
                  <select 
                    value={newProfile.state || ''}
                    onChange={e => setNewProfile({...newProfile, state: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    {formConfig.states.map(s => (
                      <option key={s} value={s}>{s}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.district}</label>
                  <select 
                    value={newProfile.district || ''}
                    onChange={e => setNewProfile({...newProfile, district: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="">{t.select} (Select)</option>
                    {formConfig.districts.map(d => (
                      <option key={d} value={d}>{d}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.address}</label>
                  <input 
                    type="text" 
                    value={newProfile.location || ''}
                    onChange={e => setNewProfile({...newProfile, location: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Section: Caste/Gotra */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.gotraCommunity}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.fatherGotra}</label>
                  <select 
                    value={newProfile.fatherGotra || ''}
                    onChange={e => setNewProfile({...newProfile, fatherGotra: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="">{t.select} (Select)</option>
                    {formConfig.gotras.map(g => (
                      <option key={g.value} value={g.value}>{g.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.motherGotra}</label>
                  <select 
                    value={newProfile.motherGotra || ''}
                    onChange={e => setNewProfile({...newProfile, motherGotra: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="">{t.select} (Select)</option>
                    {formConfig.gotras.map(g => (
                      <option key={g.value} value={g.value}>{g.label}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.religion}</label>
                  <input 
                    type="text" 
                    value={newProfile.religion || 'Hindu'}
                    onChange={e => setNewProfile({...newProfile, religion: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Section: Education & Career */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.educationCareer}</h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.qualification}</label>
                  <input 
                    type="text" 
                    value={newProfile.qualification1 || ''}
                    onChange={e => setNewProfile({...newProfile, qualification1: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.profession}</label>
                  <select 
                    value={newProfile.profession || ''}
                    onChange={e => setNewProfile({...newProfile, profession: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                  >
                    <option value="">{t.select} (Select)</option>
                    {formConfig.professions.map(p => (
                      <option key={p} value={p}>{p}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.occupationDetails}</label>
                  <input 
                    type="text" 
                    value={newProfile.occupationDetails || ''}
                    onChange={e => setNewProfile({...newProfile, occupationDetails: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                  />
                </div>
              </div>
            </div>

            {/* Section: Contact */}
            <div className="space-y-6">
              <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">{t.contactInfo}</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">{t.mobileNumber}</label>
                  <input 
                    type="text" 
                    value={newProfile.contactNumber || ''}
                    onChange={e => setNewProfile({...newProfile, contactNumber: e.target.value})}
                    className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                    placeholder="+91"
                  />
                </div>
                <div className="flex items-center">
                  <label className="flex items-center gap-3 cursor-pointer group pt-6">
                    <input 
                      type="checkbox" 
                      checked={newProfile.isVerified}
                      onChange={e => setNewProfile({...newProfile, isVerified: e.target.checked})}
                      className="w-5 h-5 rounded accent-rose-900"
                    />
                    <span className="text-sm font-bold text-rose-950 group-hover:text-rose-700 transition-colors">{t.markVerified}</span>
                  </label>
                </div>
              </div>
            </div>

            <div className="pt-10 border-t border-gray-100 flex items-center justify-end gap-4">
              <button 
                onClick={() => setActiveTab('profiles')}
                className="px-6 py-3 border border-gray-200 text-gray-500 hover:bg-gray-50 rounded-2xl font-bold transition-all"
              >
                {t.cancel}
              </button>
              <button 
                onClick={handleSaveNewProfile}
                disabled={loading}
                className="px-10 py-3 bg-rose-900 hover:bg-rose-950 text-white rounded-2xl font-bold shadow-lg shadow-rose-900/20 transition-all flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                {loading ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                {t.saveProfile}
              </button>
            </div>
          </div>
        </div>
        )}

        {activeTab === 'analytics' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-2xl border border-gray-200 shadow-sm flex flex-col md:flex-row justify-between items-center gap-4">
              <div>
                <h2 className="text-xl font-bold text-rose-950 font-serif">{t.analyticsReports}</h2>
                <p className="text-xs text-gray-500 font-medium">{t.analyzeGrowth}</p>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleExportProfiles}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold text-xs shadow-sm transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  ਯੂਜ਼ਰ ਡਾਟਾ (Profiles)
                </button>
                <button
                  onClick={handleExportLogs}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-xl font-bold text-xs shadow-sm transition-all"
                >
                  <Download className="w-3.5 h-3.5" />
                  ਐਕਟੀਵਿਟੀ ਲੋਗਸ (Logs)
                </button>
              </div>
            </div>
            <AnalyticsDashboard profiles={profiles} logs={logs} metrics={metrics} />
          </div>
        )}

        {activeTab === 'stories' && (
          <div className="space-y-6">
            <div className="flex justify-between items-center">
              <h2 className="text-xl font-bold text-rose-950 font-serif">ਸਫਲ ਕਹਾਣੀਆਂ ਦਾ ਪ੍ਰਬੰਧਨ</h2>
              <button
                onClick={() => setEditingStory({ coupleName: '', fullStory: '', image: '', summaryPa: '', summaryEn: '', location: '', weddingDate: '' })}
                className="inline-flex items-center gap-2 px-4 py-2 bg-rose-900 text-amber-300 rounded-xl font-bold text-sm"
              >
                <Plus className="w-4 h-4" /> ਨਵੀਂ ਕਹਾਣੀ ਜੋੜੋ
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {stories.length === 0 ? (
                <div className="col-span-full py-12 text-center bg-white rounded-2xl border border-dashed border-gray-300">
                   <p className="text-gray-500">ਕੋਈ ਕਹਾਣੀ ਨਹੀਂ ਮਿਲੀ।</p>
                </div>
              ) : (
                stories.map(story => (
                  <div key={story.id} className="bg-white rounded-2xl overflow-hidden border border-gray-200 shadow-sm group">
                    <div className="h-40 relative">
                      <img src={story.image} alt={story.coupleName} className="w-full h-full object-cover" />
                      <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-3">
                        <button onClick={() => setEditingStory(story)} className="p-2 bg-white rounded-full text-blue-600"><Eye className="w-5 h-5" /></button>
                        <button onClick={async () => {
                          if(window.confirm('ਕੀ ਤੁਸੀਂ ਸੱਚਮੁੱਚ ਇਹ ਕਹਾਣੀ ਡਿਲੀਟ ਕਰਨਾ ਚਾਹੁੰਦੇ ਹੋ?')) {
                            await deleteDoc(doc(db, 'success_stories', story.id!));
                            await logActivity({
                              type: 'admin_action',
                              action: 'Success Story Deleted',
                              details: `Success story of ${story.coupleName} was deleted by admin.`,
                              performedBy: user?.uid || 'Admin',
                              performedByName: 'Administrator',
                              targetId: story.id
                            });
                            showToast('success', 'ਕਹਾਣੀ ਹਟਾ ਦਿੱਤੀ ਗਈ!');
                            fetchAllData();
                          }
                        }} className="p-2 bg-white rounded-full text-rose-600"><Trash2 className="w-5 h-5" /></button>
                      </div>
                    </div>
                    <div className="p-4">
                      <h3 className="font-bold text-gray-900">{story.coupleName}</h3>
                      <p className="text-xs text-gray-500 mt-1 line-clamp-2">{story.summaryPa || story.fullStory}</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {activeTab === 'metrics' && (
          <div className="bg-white rounded-2xl border border-gray-200 p-6">
            <h2 className="text-xl font-bold text-rose-950 font-serif mb-6">ਸਾਈਟ ਮੈਟ੍ਰਿਕਸ (Counting Metrics)</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {metrics.length === 0 ? (
                <div className="col-span-full py-6 text-center">
                   <button 
                    onClick={async () => {
                      const initialMetrics = [
                        { id: 'marriages', count: 5480, suffix: '+', title: 'Happy Marriages', punjabiTitle: 'ਸਫਲ ਵਿਆਹ', description: 'Beautiful unions celebrated', badge: '+34 This Month', color: 'text-rose-900', bgLight: 'bg-rose-50', borderLight: 'border-rose-100' },
                        { id: 'profiles', count: 48500, suffix: '+', title: 'Verified Profiles', punjabiTitle: 'ਤਸਦੀਕਸ਼ੁਦਾ ਪ੍ਰੋਫਾਈਲ', description: 'Genuine brides and grooms', badge: '100% Genuine', color: 'text-amber-600', bgLight: 'bg-amber-50', borderLight: 'border-amber-100' }
                      ];
                      await setDoc(doc(db, 'cms_settings', 'site_metrics'), { metrics: initialMetrics, updatedAt: serverTimestamp() });
                      fetchAllData();
                    }}
                    className="text-blue-600 font-bold"
                   >
                     ਕੋਈ ਮੈਟ੍ਰਿਕਸ ਨਹੀਂ ਹਨ। ਸ਼ੁਰੂਆਤੀ ਡਾਟਾ ਸੈੱਟਅੱਪ ਕਰੋ?
                   </button>
                </div>
              ) : (
                metrics.map((metric, idx) => (
                  <div key={metric.id} className="p-4 border rounded-xl bg-gray-50">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="col-span-2">
                        <label className="block text-xs font-bold text-gray-500 mb-1">Title (EN)</label>
                        <input 
                          type="text" 
                          value={metric.title} 
                          onChange={(e) => {
                            const newMetrics = [...metrics];
                            newMetrics[idx].title = e.target.value;
                            setMetrics(newMetrics);
                          }}
                          className="w-full p-2 border rounded-lg text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 mb-1">Title (PA)</label>
                        <input 
                          type="text" 
                          value={metric.punjabiTitle} 
                          onChange={(e) => {
                            const newMetrics = [...metrics];
                            newMetrics[idx].punjabiTitle = e.target.value;
                            setMetrics(newMetrics);
                          }}
                          className="w-full p-2 border rounded-lg text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-bold text-gray-500 mb-1">Count</label>
                        <input 
                          type="text" 
                          value={metric.count} 
                          onChange={(e) => {
                            const newMetrics = [...metrics];
                            newMetrics[idx].count = e.target.value;
                            setMetrics(newMetrics);
                          }}
                          className="w-full p-2 border rounded-lg text-sm font-bold"
                        />
                      </div>
                    </div>
                  </div>
                ))
              )}
            </div>
            {metrics.length > 0 && (
              <div className="mt-8 flex justify-end">
                <button 
                  onClick={async () => {
                    await setDoc(doc(db, 'cms_settings', 'site_metrics'), { metrics, updatedAt: serverTimestamp() });
                    showToast('success', 'ਮੈਟ੍ਰਿਕਸ ਸੇਵ ਕੀਤੇ ਗਏ!');
                  }}
                  className="inline-flex items-center gap-2 px-6 py-2.5 bg-rose-900 text-amber-300 rounded-xl font-bold shadow-md"
                >
                  <Save className="w-5 h-5" /> ਸਭ ਕੁਝ ਸੇਵ ਕਰੋ
                </button>
              </div>
            )}
          </div>
        )}

        {activeTab === 'bulk-upload' && (
          <BulkUploadSettings />
        )}

        {activeTab === 'settings' && (
          <div className="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8">
            <div className="flex items-center gap-3 mb-8 pb-4 border-b">
              <div className="p-2.5 bg-gray-100 rounded-xl">
                <Settings className="w-6 h-6 text-gray-700" />
              </div>
              <div>
                <h2 className="text-xl font-bold text-gray-900">ਸਿਸਟਮ ਸੈਟਿੰਗਾਂ & ਕੰਟਰੋਲ (Config)</h2>
                <p className="text-xs text-gray-500 font-medium">ਸਾਈਟ, ਫਾਰਮ ਅਤੇ ਡ੍ਰੌਪਡਾਉਨ ਲਿਸਟਾਂ ਨੂੰ ਮੈਨੇਜ ਕਰੋ</p>
              </div>
            </div>

            {/* Sub-tab Navigation */}
            <div className="flex border-b border-gray-100 mb-8 overflow-x-auto no-scrollbar gap-2">
              <button
                onClick={() => setSettingsSubTab('general')}
                className={`px-6 py-2.5 text-xs font-bold whitespace-nowrap transition-all rounded-t-xl ${
                  settingsSubTab === 'general' ? 'bg-rose-900 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'
                }`}
              >
                ਗਲੋਬਲ ਸੈਟਿੰਗਾਂ
              </button>
              <button
                onClick={() => setSettingsSubTab('app')}
                className={`px-6 py-2.5 text-xs font-bold whitespace-nowrap transition-all rounded-t-xl ${
                  settingsSubTab === 'app' ? 'bg-rose-900 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'
                }`}
              >
                ਪਲੇਟਫਾਰਮ ਸੰਰਚਨਾ (App Config)
              </button>
              <button
                onClick={() => setSettingsSubTab('form')}
                className={`px-6 py-2.5 text-xs font-bold whitespace-nowrap transition-all rounded-t-xl ${
                  settingsSubTab === 'form' ? 'bg-rose-900 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'
                }`}
              >
                ਪ੍ਰੋਫਾਈਲ ਫਾਰਮ ਲੇਬਲ (Labels)
              </button>
              <button
                onClick={() => setSettingsSubTab('lists')}
                className={`px-6 py-2.5 text-xs font-bold whitespace-nowrap transition-all rounded-t-xl ${
                  settingsSubTab === 'lists' ? 'bg-rose-900 text-white shadow-md' : 'text-gray-500 hover:bg-gray-50'
                }`}
              >
                ਡ੍ਰੌਪਡਾਉਨ ਲਿਸਟਾਂ (Lists)
              </button>
            </div>

            {settingsSubTab === 'general' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-8 animate-in fade-in duration-300">
                {/* Site Identity Section */}
                <div className="space-y-5">
                  <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">ਸਾਈਟ ਦੀ ਪਛਾਣ (Identity)</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Site Name (English)</label>
                      <input 
                        type="text" 
                        value={globalConfig.siteNameEn}
                        onChange={e => setGlobalConfig({...globalConfig, siteNameEn: e.target.value})}
                        className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all text-sm font-semibold"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">ਸਾਈਟ ਦਾ ਨਾਮ (ਪੰਜਾਬੀ)</label>
                      <input 
                        type="text" 
                        value={globalConfig.siteNamePa}
                        onChange={e => setGlobalConfig({...globalConfig, siteNamePa: e.target.value})}
                        className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none transition-all text-sm font-bold"
                      />
                    </div>
                  </div>
                </div>

                {/* Contact Information Section */}
                <div className="space-y-5">
                  <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">ਸੰਪਰਕ ਵੇਰਵੇ (Support)</h3>
                  <div className="grid grid-cols-1 gap-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Phone Number</label>
                        <input 
                          type="text" 
                          value={globalConfig.supportPhone}
                          onChange={e => setGlobalConfig({...globalConfig, supportPhone: e.target.value})}
                          className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-semibold"
                        />
                      </div>
                      <div>
                        <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">WhatsApp</label>
                        <input 
                          type="text" 
                          value={globalConfig.whatsappNumber}
                          onChange={e => setGlobalConfig({...globalConfig, whatsappNumber: e.target.value})}
                          className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-semibold"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Support Email</label>
                      <input 
                        type="email" 
                        value={globalConfig.supportEmail}
                        onChange={e => setGlobalConfig({...globalConfig, supportEmail: e.target.value})}
                        className="w-full px-4 py-2.5 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-semibold"
                      />
                    </div>
                  </div>
                </div>

                {/* System Flags */}
                <div className="space-y-5">
                   <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">ਸਿਸਟਮ ਕੰਟਰੋਲ</h3>
                   <div className="space-y-3">
                    <label className="flex items-center justify-between p-4 bg-gray-50 rounded-2xl cursor-pointer hover:bg-gray-100 transition-all border border-transparent hover:border-gray-200">
                      <div>
                        <span className="block text-sm font-bold text-gray-800">ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਖੋਲ੍ਹੋ (Registration)</span>
                        <span className="text-[10px] text-gray-500 uppercase font-bold">Allow new users to sign up</span>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={globalConfig.isRegistrationOpen}
                        onChange={e => setGlobalConfig({...globalConfig, isRegistrationOpen: e.target.checked})}
                        className="w-5 h-5 rounded accent-rose-900"
                      />
                    </label>
                    <label className="flex items-center justify-between p-4 bg-rose-50/50 rounded-2xl cursor-pointer hover:bg-rose-50 transition-all border border-transparent hover:border-rose-200">
                      <div>
                        <span className="block text-sm font-bold text-rose-900">ਮੇਨਟੇਨੈਂਸ ਮੋਡ (Maintenance)</span>
                        <span className="text-[10px] text-rose-500 uppercase font-bold">Disable site for public users</span>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={globalConfig.maintenanceMode}
                        onChange={e => setGlobalConfig({...globalConfig, maintenanceMode: e.target.checked})}
                        className="w-5 h-5 rounded accent-rose-900"
                      />
                    </label>
                   </div>
                </div>
                
                {/* Announcements */}
                <div className="space-y-5">
                  <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3">ਜ਼ਰੂਰੀ ਸੂਚਨਾ (Announcements)</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Punjabi Announcement</label>
                      <textarea 
                        rows={2}
                        value={globalConfig.announcementPa || ''}
                        onChange={e => setGlobalConfig({...globalConfig, announcementPa: e.target.value})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-medium resize-none"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">English Announcement</label>
                      <textarea 
                        rows={2}
                        value={globalConfig.announcementEn || ''}
                        onChange={e => setGlobalConfig({...globalConfig, announcementEn: e.target.value})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-medium resize-none"
                      />
                    </div>
                  </div>
                </div>
              </div>
            )}

            {settingsSubTab === 'app' && (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-x-12 gap-y-10 animate-in fade-in duration-300">
                {/* Registration Incentives */}
                <div className="space-y-6">
                  <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3 flex items-center gap-2">
                    <Award className="w-4 h-4" /> ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਪ੍ਰੋਤਸਾਹਨ (Registration Incentives)
                  </h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Free Premium Access (Days)</label>
                      <input 
                        type="number" 
                        value={globalConfig.registrationIncentiveDays || 0}
                        onChange={e => setGlobalConfig({...globalConfig, registrationIncentiveDays: parseInt(e.target.value) || 0})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Incentive Label (Punjabi)</label>
                      <input 
                        type="text" 
                        value={globalConfig.registrationIncentiveLabelPa || ''}
                        onChange={e => setGlobalConfig({...globalConfig, registrationIncentiveLabelPa: e.target.value})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-medium"
                      />
                    </div>
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Incentive Label (English)</label>
                      <input 
                        type="text" 
                        value={globalConfig.registrationIncentiveLabelEn || ''}
                        onChange={e => setGlobalConfig({...globalConfig, registrationIncentiveLabelEn: e.target.value})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-medium"
                      />
                    </div>
                  </div>
                </div>

                {/* User Visibility & Privacy */}
                <div className="space-y-6">
                  <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3 flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4" /> ਯੂਜ਼ਰ ਵਿਜ਼ੀਬਿਲਟੀ ਅਤੇ ਪ੍ਰਾਈਵੇਸੀ (Visibility & Privacy)
                  </h3>
                  
                  <div className="space-y-4 bg-gray-50/50 p-4 rounded-2xl border border-gray-100">
                    <label className="flex items-center justify-between cursor-pointer group">
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-rose-950 group-hover:text-rose-700 transition-colors">Show Unverified Profiles</span>
                        <span className="text-[10px] text-gray-500">ਗੈਰ-ਪ੍ਰਮਾਣਿਤ ਪ੍ਰੋਫਾਈਲਾਂ ਨੂੰ ਸਰਚ ਵਿੱਚ ਦਿਖਾਓ</span>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={globalConfig.showUnverifiedProfiles}
                        onChange={e => setGlobalConfig({...globalConfig, showUnverifiedProfiles: e.target.checked})}
                        className="w-5 h-5 rounded accent-rose-900"
                      />
                    </label>

                    <div className="h-px bg-gray-100 my-2" />

                    <label className="flex items-center justify-between cursor-pointer group">
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-rose-950 group-hover:text-rose-700 transition-colors">Allow Public Profiles</span>
                        <span className="text-[10px] text-gray-500">ਬਿਨਾਂ ਲੌਗਇਨ ਕੀਤੇ ਪ੍ਰੋਫਾਈਲਾਂ ਨੂੰ ਦੇਖਣ ਦੀ ਆਗਿਆ ਦਿਓ</span>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={globalConfig.allowPublicProfiles}
                        onChange={e => setGlobalConfig({...globalConfig, allowPublicProfiles: e.target.checked})}
                        className="w-5 h-5 rounded accent-rose-900"
                      />
                    </label>
                  </div>
                </div>

                {/* Notification Frequency Settings */}
                <div className="space-y-6">
                  <h3 className="text-sm font-bold text-rose-950 uppercase tracking-widest border-l-4 border-amber-500 pl-3 flex items-center gap-2">
                    <MessageCircleHeart className="w-4 h-4" /> ਨੋਟੀਫਿਕੇਸ਼ਨ ਸੈਟਿੰਗਾਂ (Notification Settings)
                  </h3>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-[11px] font-bold text-gray-400 uppercase mb-1.5">Email Digest Frequency</label>
                      <select 
                        value={globalConfig.notificationFrequency}
                        onChange={e => setGlobalConfig({...globalConfig, notificationFrequency: e.target.value as any})}
                        className="w-full px-4 py-2 bg-gray-50 border border-gray-200 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-sm font-bold bg-white"
                      >
                        <option value="immediate">ਤੁਰੰਤ (Immediate)</option>
                        <option value="daily">ਰੋਜ਼ਾਨਾ (Daily Digest)</option>
                        <option value="weekly">ਹਫ਼ਤਾਵਾਰੀ (Weekly Digest)</option>
                        <option value="none">ਕੋਈ ਨਹੀਂ (None)</option>
                      </select>
                    </div>

                    <label className="flex items-center justify-between cursor-pointer group bg-gray-50/50 p-4 rounded-2xl border border-gray-100">
                      <div className="flex flex-col">
                        <span className="text-sm font-bold text-rose-950 group-hover:text-rose-700 transition-colors">Enable Real-Time Alerts</span>
                        <span className="text-[10px] text-gray-500">ਰੂਮ ਮੈਸੇਜ ਅਤੇ ਅਲਰਟ ਤੁਰੰਤ ਭੇਜੋ</span>
                      </div>
                      <input 
                        type="checkbox" 
                        checked={globalConfig.enableRealTimeAlerts}
                        onChange={e => setGlobalConfig({...globalConfig, enableRealTimeAlerts: e.target.checked})}
                        className="w-5 h-5 rounded accent-rose-900"
                      />
                    </label>
                  </div>
                </div>
              </div>
            )}

            {settingsSubTab === 'form' && (
              <div className="animate-in fade-in duration-300">
                <div className="mb-6 flex justify-between items-center">
                  <div>
                    <h3 className="text-lg font-bold text-rose-950 font-serif">ਪ੍ਰੋਫਾਈਲ ਫਾਰਮ ਕੌਂਫਿਗਰੇਸ਼ਨ</h3>
                    <p className="text-xs text-gray-500">ਫਾਰਮ ਦੇ ਹਰੇਕ ਖੇਤਰ (Field) ਦੇ ਲੇਬਲ ਅਤੇ ਜ਼ਰੂਰਤਾਂ ਨੂੰ ਇੱਥੋਂ ਕੰਟਰੋਲ ਕਰੋ</p>
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-4">
                  {formConfig.fields.map((field, idx) => (
                    <div key={field.id} className="bg-gray-50 p-4 rounded-2xl border border-gray-200 flex flex-col md:flex-row gap-4 items-start md:items-center">
                      <div className="w-full md:w-48 shrink-0">
                        <span className="text-[10px] font-bold text-rose-900 uppercase tracking-tighter bg-rose-50 px-2 py-0.5 rounded border border-rose-100">{field.id}</span>
                        <span className="block text-[10px] text-gray-400 mt-1 uppercase font-bold tracking-widest">{field.section}</span>
                      </div>
                      
                      <div className="flex-1 grid grid-cols-1 sm:grid-cols-2 gap-4 w-full">
                        <div>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">Label (English)</label>
                          <input 
                            type="text" 
                            value={field.labelEn}
                            onChange={e => {
                              const newFields = [...formConfig.fields];
                              newFields[idx].labelEn = e.target.value;
                              setFormConfig({...formConfig, fields: newFields});
                            }}
                            className="w-full px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm font-semibold outline-none focus:ring-2 focus:ring-amber-500"
                          />
                        </div>
                        <div>
                          <label className="block text-[10px] font-bold text-gray-400 uppercase mb-1">ਲੇਬਲ (ਪੰਜਾਬੀ)</label>
                          <input 
                            type="text" 
                            value={field.labelPa}
                            onChange={e => {
                              const newFields = [...formConfig.fields];
                              newFields[idx].labelPa = e.target.value;
                              setFormConfig({...formConfig, fields: newFields});
                            }}
                            className="w-full px-3 py-1.5 bg-white border border-gray-200 rounded-lg text-sm font-bold outline-none focus:ring-2 focus:ring-amber-500"
                          />
                        </div>
                      </div>

                      <div className="flex items-center gap-4 shrink-0 mt-2 md:mt-0 pt-2 md:pt-0 border-t md:border-t-0 w-full md:w-auto">
                        <label className="flex items-center gap-2 cursor-pointer group">
                          <input 
                            type="checkbox" 
                            checked={field.isVisible}
                            onChange={e => {
                              const newFields = [...formConfig.fields];
                              newFields[idx].isVisible = e.target.checked;
                              setFormConfig({...formConfig, fields: newFields});
                            }}
                            className="w-4 h-4 rounded accent-rose-900"
                          />
                          <span className="text-xs font-bold text-gray-600 group-hover:text-rose-900 transition-colors">ਦਿਖਾਓ</span>
                        </label>
                        <label className="flex items-center gap-2 cursor-pointer group">
                          <input 
                            type="checkbox" 
                            checked={field.isRequired}
                            onChange={e => {
                              const newFields = [...formConfig.fields];
                              newFields[idx].isRequired = e.target.checked;
                              setFormConfig({...formConfig, fields: newFields});
                            }}
                            className="w-4 h-4 rounded accent-rose-900"
                          />
                          <span className="text-xs font-bold text-gray-600 group-hover:text-rose-900 transition-colors">ਜ਼ਰੂਰੀ</span>
                        </label>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {settingsSubTab === 'lists' && (
              <div className="animate-in fade-in duration-300 space-y-10">
                {/* States */}
                <div className="space-y-4 pt-6 border-t">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-bold text-rose-950 font-serif">ਸਟੇਟਸ ਦੀ ਸੂਚੀ (States List)</h3>
                      <p className="text-xs text-gray-500">ਰਾਜਾਂ ਦੀ ਸੂਚੀ ਮੈਨੇਜ ਕਰੋ</p>
                    </div>
                    <button 
                      onClick={() => setFormConfig({...formConfig, states: [...(formConfig.states || []), 'New State (ਨਵਾਂ ਸਟੇਟ)']})}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-rose-950 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> ਸਟੇਟ ਜੋੜੋ
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {(formConfig.states || []).map((state, idx) => (
                      <div key={idx} className="flex items-center gap-2 bg-gray-50 p-2 rounded-xl border border-gray-200">
                        <input 
                          type="text" 
                          value={state}
                          onChange={e => {
                            const newStates = [...formConfig.states];
                            newStates[idx] = e.target.value;
                            setFormConfig({...formConfig, states: newStates});
                          }}
                          className="flex-1 bg-transparent border-none outline-none text-xs font-bold text-gray-800"
                        />
                        <button 
                          onClick={() => {
                            const newStates = formConfig.states.filter((_, i) => i !== idx);
                            setFormConfig({...formConfig, states: newStates});
                          }}
                          className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Districts */}
                <div className="space-y-4 pt-6 border-t">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-bold text-rose-950 font-serif">ਜ਼ਿਲ੍ਹਿਆਂ ਦੀ ਸੂਚੀ (Districts List)</h3>
                      <p className="text-xs text-gray-500">ਪੰਜਾਬ ਅਤੇ ਹੋਰ ਖੇਤਰਾਂ ਦੀ ਸੂਚੀ ਮੈਨੇਜ ਕਰੋ</p>
                    </div>
                    <button 
                      onClick={() => setFormConfig({...formConfig, districts: [...formConfig.districts, 'New District (ਨਵਾਂ ਜ਼ਿਲ੍ਹਾ)']})}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-rose-950 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> ਜ਼ਿਲ੍ਹਾ ਜੋੜੋ
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                    {formConfig.districts.map((district, idx) => (
                      <div key={idx} className="flex items-center gap-2 bg-gray-50 p-2 rounded-xl border border-gray-200">
                        <input 
                          type="text" 
                          value={district}
                          onChange={e => {
                            const newDistricts = [...formConfig.districts];
                            newDistricts[idx] = e.target.value;
                            setFormConfig({...formConfig, districts: newDistricts});
                          }}
                          className="flex-1 bg-transparent border-none outline-none text-xs font-bold text-gray-800"
                        />
                        <button 
                          onClick={() => {
                            const newDistricts = formConfig.districts.filter((_, i) => i !== idx);
                            setFormConfig({...formConfig, districts: newDistricts});
                          }}
                          className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Gotras */}
                <div className="space-y-4 pt-6 border-t">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-bold text-rose-950 font-serif">ਮਹਾਸ਼ਾ ਗੋਤਰ (Mahasha Gotras)</h3>
                      <p className="text-xs text-gray-500">ਗੋਤਰਾਂ ਦੀ ਸੂਚੀ ਅਤੇ ਉਹਨਾਂ ਦੇ ਲੇਬਲ ਮੈਨੇਜ ਕਰੋ</p>
                    </div>
                    <button 
                      onClick={() => setFormConfig({...formConfig, gotras: [...formConfig.gotras, { value: 'New', label: 'ਨਵਾਂ ਗੋਤਰ (New Gotra)' }]})}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-rose-950 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> ਗੋਤਰ ਜੋੜੋ
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    {formConfig.gotras.map((gotra, idx) => (
                      <div key={idx} className="flex items-center gap-3 bg-gray-50 p-2 rounded-xl border border-gray-200">
                        <div className="flex-1 grid grid-cols-2 gap-2">
                           <input 
                            type="text" 
                            value={gotra.value}
                            placeholder="Value (e.g. Bajgal)"
                            onChange={e => {
                              const newGotras = [...formConfig.gotras];
                              newGotras[idx].value = e.target.value;
                              setFormConfig({...formConfig, gotras: newGotras});
                            }}
                            className="bg-white px-3 py-1.5 border rounded-lg outline-none text-xs font-bold text-gray-800"
                          />
                          <input 
                            type="text" 
                            value={gotra.label}
                            placeholder="Label (Punjabi)"
                            onChange={e => {
                              const newGotras = [...formConfig.gotras];
                              newGotras[idx].label = e.target.value;
                              setFormConfig({...formConfig, gotras: newGotras});
                            }}
                            className="bg-white px-3 py-1.5 border rounded-lg outline-none text-xs font-bold text-gray-800"
                          />
                        </div>
                        <button 
                          onClick={() => {
                            const newGotras = formConfig.gotras.filter((_, i) => i !== idx);
                            setFormConfig({...formConfig, gotras: newGotras});
                          }}
                          className="p-2 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Professions */}
                <div className="space-y-4 pt-6 border-t">
                  <div className="flex justify-between items-center">
                    <div>
                      <h3 className="text-lg font-bold text-rose-950 font-serif">ਕਿੱਤਾ/ਪੇਸ਼ਾ ਸੂਚੀ (Professions)</h3>
                      <p className="text-xs text-gray-500">ਸਟੈਂਡਰਡ ਪੇਸ਼ਿਆਂ ਦੀ ਸੂਚੀ</p>
                    </div>
                    <button 
                      onClick={() => setFormConfig({...formConfig, professions: [...formConfig.professions, 'New Profession']})}
                      className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-rose-950 rounded-xl text-xs font-bold transition-all shadow-sm flex items-center gap-2"
                    >
                      <Plus className="w-4 h-4" /> ਪੇਸ਼ਾ ਜੋੜੋ
                    </button>
                  </div>
                  <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
                    {formConfig.professions.map((prof, idx) => (
                      <div key={idx} className="flex items-center gap-2 bg-gray-50 p-2 rounded-xl border border-gray-200">
                        <input 
                          type="text" 
                          value={prof}
                          onChange={e => {
                            const newProf = [...formConfig.professions];
                            newProf[idx] = e.target.value;
                            setFormConfig({...formConfig, professions: newProf});
                          }}
                          className="flex-1 bg-transparent border-none outline-none text-xs font-bold text-gray-800"
                        />
                        <button 
                          onClick={() => {
                            const newProf = formConfig.professions.filter((_, i) => i !== idx);
                            setFormConfig({...formConfig, professions: newProf});
                          }}
                          className="p-1.5 text-gray-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-all"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            )}

            <div className="mt-12 flex justify-end pt-8 border-t gap-4">
              <button 
                onClick={async () => {
                  setActionLoading('save-settings');
                  try {
                    // Save Global Config
                    await setDoc(doc(db, 'cms_settings', 'global_config'), { 
                      ...globalConfig, 
                      updatedAt: serverTimestamp() 
                    });

                    // Save Form Config
                    await setDoc(doc(db, 'cms_settings', 'form_config'), { 
                      ...formConfig, 
                      updatedAt: serverTimestamp() 
                    });
                    
                    await logActivity({
                      type: 'admin_action',
                      action: 'Settings Updated',
                      details: `System settings (${settingsSubTab}) were updated by admin.`,
                      performedBy: user?.uid || 'Admin',
                      performedByName: 'Administrator'
                    });

                    showToast('success', 'ਸਾਰੀਆਂ ਸੈਟਿੰਗਾਂ ਸਫਲਤਾਪੂਰਵਕ ਸੇਵ ਕੀਤੀਆਂ ਗਈਆਂ ਹਨ!');
                  } catch (err) {
                    showToast('error', 'ਸੈਟਿੰਗਾਂ ਸੇਵ ਕਰਨ ਵਿੱਚ ਗਲਤੀ ਆਈ।');
                  } finally {
                    setActionLoading(null);
                  }
                }}
                disabled={actionLoading === 'save-settings'}
                className="inline-flex items-center gap-2 px-8 py-3 bg-rose-900 text-amber-300 rounded-2xl font-bold shadow-lg hover:bg-rose-950 transition-all disabled:opacity-50"
              >
                {actionLoading === 'save-settings' ? (
                  <RefreshCw className="w-5 h-5 animate-spin" />
                ) : (
                  <Save className="w-5 h-5" />
                )}
                ਸਾਰੀਆਂ ਸੈਟਿੰਗਾਂ ਸੇਵ ਕਰੋ
              </button>
            </div>
          </div>
        )}


        {activeTab === 'logs' && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden">
            <div className="p-6 border-b border-gray-100 flex justify-between items-center">
              <div>
                <h2 className="text-xl font-bold text-rose-950 font-serif">ਐਕਟੀਵਿਟੀ ਲੋਗਸ (Activity Logs)</h2>
                <p className="text-xs text-gray-500 font-medium">ਪਲੇਟਫਾਰਮ 'ਤੇ ਹੋ ਰਹੀਆਂ ਸਾਰੀਆਂ ਤਬਦੀਲੀਆਂ 'ਤੇ ਨਜ਼ਰ ਰੱਖੋ</p>
              </div>
              <div className="flex items-center gap-2">
                 <button
                  onClick={handleExportLogs}
                  className="inline-flex items-center gap-1.5 px-3 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition-all text-xs font-bold shadow-sm"
                >
                  <Download className="w-3.5 h-3.5" />
                  CSV ਨਿਰਯਾਤ ਕਰੋ
                </button>
                 <button
                  onClick={fetchAllData}
                  className="p-2 bg-gray-50 hover:bg-gray-100 rounded-lg border border-gray-200 transition-all"
                  title="Refresh Logs"
                >
                  <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
                </button>
              </div>
            </div>
            
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-gray-50/80 border-b border-gray-200 text-gray-700 font-bold uppercase tracking-wider text-[11px]">
                  <tr>
                    <th className="py-4 px-6">ਸਮਾਂ (Timestamp)</th>
                    <th className="py-4 px-6">ਕਿਸਮ (Type)</th>
                    <th className="py-4 px-6">ਕਾਰਵਾਈ (Action)</th>
                    <th className="py-4 px-6">ਵੇਰਵਾ (Details)</th>
                    <th className="py-4 px-6">ਕਰਤਾ (Performed By)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {logs.length === 0 ? (
                    <tr>
                      <td colSpan={5} className="py-12 text-center text-gray-500">
                        ਕੋਈ ਐਕਟੀਵਿਟੀ ਲੋਗ ਨਹੀਂ ਮਿਲਿਆ।
                      </td>
                    </tr>
                  ) : (
                    logs.map((log) => (
                      <tr key={log.id} className="hover:bg-gray-50/50 transition-colors">
                        <td className="py-4 px-6 whitespace-nowrap">
                          <div className="text-xs font-semibold text-gray-600">
                            {log.timestamp?.toDate ? format(log.timestamp.toDate(), 'MMM dd, hh:mm a') : 'Just now'}
                          </div>
                        </td>
                        <td className="py-4 px-6">
                          <span className={`inline-flex px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                            log.type === 'registration' ? 'bg-emerald-100 text-emerald-800' :
                            log.type === 'admin_action' ? 'bg-rose-100 text-rose-800' :
                            log.type === 'profile_update' ? 'bg-blue-100 text-blue-800' :
                            'bg-gray-100 text-gray-800'
                          }`}>
                            {log.type.replace('_', ' ')}
                          </span>
                        </td>
                        <td className="py-4 px-6 font-bold text-gray-900">
                          {log.action}
                        </td>
                        <td className="py-4 px-6 text-gray-600 text-xs">
                          {log.details}
                        </td>
                        <td className="py-4 px-6">
                          <div className="text-xs font-bold text-rose-950">
                            {log.performedByName || log.performedBy}
                          </div>
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'seo' && (
          <div className="bg-white rounded-2xl border border-gray-200 shadow-sm overflow-hidden animate-in fade-in slide-in-from-bottom-4">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-rose-950 font-serif">SEO & ਮੈਟਾ ਸੈਟਿੰਗਾਂ (Search Engine Optimization)</h2>
              <p className="text-xs text-gray-500 font-medium">ਗੂਗਲ ਖੋਜ (Google Search) ਵਿੱਚ ਸਾਈਟ ਦੀ ਦਿੱਖ ਨੂੰ ਬਿਹਤਰ ਬਣਾਓ</p>
            </div>
            <div className="p-8">
              <div className="grid grid-cols-1 gap-8">
                <div>
                  <label className="block text-sm font-bold text-rose-950 mb-2">ਮੁੱਖ ਟਾਈਟਲ (Meta Title)</label>
                  <input
                    type="text"
                    value={globalConfig.seoTitle || ''}
                    onChange={(e) => setGlobalConfig({ ...globalConfig, seoTitle: e.target.value })}
                    placeholder="e.g. Mahasha Matrimonial - Best Matchmaking for Mahasha Community"
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-rose-900 focus:border-rose-900 transition-all text-sm"
                  />
                  <p className="mt-2 text-[10px] text-gray-400 font-medium italic">* ਗੂਗਲ ਖੋਜ ਵਿੱਚ ਦਿਖਾਈ ਦੇਣ ਵਾਲਾ ਮੁੱਖ ਸਿਰਲੇਖ (Recommended: 50-60 characters)</p>
                </div>

                <div>
                  <label className="block text-sm font-bold text-rose-950 mb-2">ਵੇਰਵਾ (Meta Description)</label>
                  <textarea
                    rows={4}
                    value={globalConfig.seoDescription || ''}
                    onChange={(e) => setGlobalConfig({ ...globalConfig, seoDescription: e.target.value })}
                    placeholder="Enter site description..."
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-rose-900 focus:border-rose-900 transition-all text-sm resize-none"
                  />
                  <p className="mt-2 text-[10px] text-gray-400 font-medium italic">* ਸਾਈਟ ਬਾਰੇ ਛੋਟੀ ਜਾਣਕਾਰੀ (Recommended: 150-160 characters)</p>
                </div>

                <div>
                  <label className="block text-sm font-bold text-rose-950 mb-2">ਕੀਵਰਡਸ (Meta Keywords)</label>
                  <input
                    type="text"
                    value={globalConfig.seoKeywords || ''}
                    onChange={(e) => setGlobalConfig({ ...globalConfig, seoKeywords: e.target.value })}
                    placeholder="mahasha, matrimonial, punjab, rishtey..."
                    className="w-full px-4 py-3 rounded-xl border border-gray-200 focus:ring-2 focus:ring-rose-900 focus:border-rose-900 transition-all text-sm"
                  />
                  <p className="mt-2 text-[10px] text-gray-400 font-medium italic">* ਕਾਮੇ (comma) ਨਾਲ ਅਲੱਗ ਕੀਤੇ ਗਏ ਸ਼ਬਦ</p>
                </div>

                <div className="pt-6 border-t border-gray-100 flex justify-end">
                  <button
                    onClick={async () => {
                      try {
                        const docRef = doc(db, 'cms_settings', 'global_config');
                        await setDoc(docRef, { 
                          ...globalConfig, 
                          updatedAt: serverTimestamp() 
                        });
                        
                        await logActivity({
                          type: 'admin_action',
                          action: 'SEO Settings Updated',
                          details: 'Site SEO meta titles and descriptions were updated.',
                          performedBy: user?.uid || 'Admin',
                          performedByName: 'Administrator'
                        });

                        showToast('success', 'SEO ਸੈਟਿੰਗਾਂ ਸਫਲਤਾਪੂਰਵਕ ਸੇਵ ਹੋ ਗਈਆਂ ਹਨ!');
                      } catch (err) {
                        showToast('error', 'ਸੈਟਿੰਗਾਂ ਸੇਵ ਕਰਨ ਵਿੱਚ ਗਲਤੀ ਆਈ।');
                      }
                    }}
                    className="inline-flex items-center gap-2 px-8 py-3 bg-rose-900 hover:bg-rose-800 text-white rounded-xl font-bold transition-all shadow-md active:scale-95"
                  >
                    <Save className="w-5 h-5" />
                    SEO ਸੈਟਿੰਗਾਂ ਸੇਵ ਕਰੋ
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Story Editing Modal */}
      {editingStory && (
        <div className="fixed inset-0 z-[60] bg-black/60 flex items-center justify-center p-4 backdrop-blur-sm">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-8 max-h-[90vh] overflow-y-auto shadow-2xl relative">
            <button onClick={() => setEditingStory(null)} className="absolute top-6 right-6 p-2 text-gray-400 hover:text-gray-900"><XCircle className="w-6 h-6" /></button>
            <h2 className="text-2xl font-bold text-rose-950 font-serif mb-6">ਸਫਲ ਕਹਾਣੀ ਸੋਧੋ / ਜੋੜੋ</h2>
            
            <div className="grid grid-cols-2 gap-4">
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-500 mb-1">ਜੋੜੇ ਦਾ ਨਾਮ</label>
                <input 
                  type="text" 
                  value={editingStory.coupleName} 
                  onChange={e => setEditingStory({...editingStory, coupleName: e.target.value})}
                  className="w-full p-3 border rounded-xl outline-none focus:ring-2 focus:ring-rose-500"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">ਵਿਆਹ ਦੀ ਮਿਤੀ</label>
                <input 
                  type="text" 
                  value={editingStory.weddingDate} 
                  onChange={e => setEditingStory({...editingStory, weddingDate: e.target.value})}
                  className="w-full p-3 border rounded-xl outline-none"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-gray-500 mb-1">ਸ਼ਹਿਰ</label>
                <input 
                  type="text" 
                  value={editingStory.location} 
                  onChange={e => setEditingStory({...editingStory, location: e.target.value})}
                  className="w-full p-3 border rounded-xl outline-none"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-500 mb-1">ਫੋਟੋ URL</label>
                <input 
                  type="text" 
                  value={editingStory.image} 
                  onChange={e => setEditingStory({...editingStory, image: e.target.value})}
                  className="w-full p-3 border rounded-xl outline-none"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-500 mb-1">ਸੰਖੇਪ (Punjabi)</label>
                <input 
                  type="text" 
                  value={editingStory.summaryPa} 
                  onChange={e => setEditingStory({...editingStory, summaryPa: e.target.value})}
                  className="w-full p-3 border rounded-xl outline-none"
                />
              </div>
              <div className="col-span-2">
                <label className="block text-xs font-bold text-gray-500 mb-1">ਪੂਰੀ ਕਹਾਣੀ (Punjabi)</label>
                <textarea 
                  rows={4}
                  value={editingStory.fullStory} 
                  onChange={e => setEditingStory({...editingStory, fullStory: e.target.value})}
                  className="w-full p-3 border rounded-xl outline-none resize-none"
                />
              </div>
            </div>

            <div className="mt-8 flex justify-end gap-3">
              <button onClick={() => setEditingStory(null)} className="px-6 py-2.5 rounded-xl bg-gray-100 font-bold">ਰੱਦ ਕਰੋ</button>
              <button onClick={async () => {
                const payload = { ...editingStory };
                delete payload.id;
                if(editingStory.id) {
                  await updateDoc(doc(db, 'success_stories', editingStory.id), payload as any);
                  await logActivity({
                    type: 'admin_action',
                    action: 'Success Story Updated',
                    details: `Success story of ${payload.coupleName} was updated by admin.`,
                    performedBy: user?.uid || 'Admin',
                    performedByName: 'Administrator',
                    targetId: editingStory.id
                  });
                } else {
                  const docRef = await addDoc(collection(db, 'success_stories'), { ...payload, createdAt: serverTimestamp() });
                  await logActivity({
                    type: 'admin_action',
                    action: 'Success Story Added',
                    details: `New success story of ${payload.coupleName} was published.`,
                    performedBy: user?.uid || 'Admin',
                    performedByName: 'Administrator',
                    targetId: docRef.id
                  });
                }
                fetchAllData();
                setEditingStory(null);
                showToast('success', 'ਕਹਾਣੀ ਸੇਵ ਹੋ ਗਈ!');
              }} className="px-6 py-2.5 rounded-xl bg-rose-900 text-amber-300 font-bold shadow-lg">ਸੇਵ ਕਰੋ</button>
            </div>
          </div>
        </div>
      )}

      {/* Profile Detail Quick Inspection Modal */}
      {selectedProfile && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-2xl w-full p-6 max-h-[90vh] overflow-y-auto border-2 border-amber-300 shadow-2xl relative">
            <button
              onClick={() => setSelectedProfile(null)}
              className="absolute top-5 right-5 p-2 rounded-full bg-gray-100 hover:bg-gray-200 text-gray-600"
            >
              <XCircle className="w-6 h-6" />
            </button>

            <div className="flex items-center gap-4 border-b border-gray-200 pb-4">
              <img
                src={selectedProfile.photoUrl || (selectedProfile.photoUrls && selectedProfile.photoUrls[0]) || 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=300'}
                alt={selectedProfile.fullName}
                className="w-20 h-20 rounded-2xl object-cover border-2 border-amber-400 shadow-md"
              />
              <div className="flex-1">
                <input
                  type="text"
                  value={selectedProfile.fullName}
                  onChange={(e) => setSelectedProfile({...selectedProfile, fullName: e.target.value})}
                  className="text-xl font-bold text-rose-950 font-serif w-full bg-transparent border-b border-dashed border-gray-300 focus:border-amber-500 outline-none"
                />
                <p className="text-xs text-amber-800 font-semibold mt-1">
                  {selectedProfile.gender === 'Female' ? 'ਲਾੜੀ (Bride)' : 'ਲਾੜਾ (Groom)'} • {selectedProfile.age} ਸਾਲ
                </p>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4 text-xs text-gray-800">
              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="font-bold text-gray-500 block">ਪਿਤਾ ਗੋਤਰ:</span>
                <input
                  type="text"
                  value={selectedProfile.fatherGotra || ''}
                  onChange={(e) => setSelectedProfile({...selectedProfile, fatherGotra: e.target.value})}
                  className="font-semibold text-rose-950 mt-1 block w-full bg-transparent border-b border-dashed border-gray-300 outline-none"
                />
              </div>

              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="font-bold text-gray-500 block">ਕਿੱਤਾ:</span>
                <input
                  type="text"
                  value={selectedProfile.profession || ''}
                  onChange={(e) => setSelectedProfile({...selectedProfile, profession: e.target.value})}
                  className="font-semibold text-gray-900 mt-1 block w-full bg-transparent border-b border-dashed border-gray-300 outline-none"
                />
              </div>

              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="font-bold text-gray-500 block">ਸੰਪਰਕ ਨੰਬਰ:</span>
                <input
                  type="text"
                  value={selectedProfile.contactNumber || ''}
                  onChange={(e) => setSelectedProfile({...selectedProfile, contactNumber: e.target.value})}
                  className="font-semibold text-gray-900 mt-1 block w-full bg-transparent border-b border-dashed border-gray-300 outline-none"
                />
              </div>

              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="font-bold text-gray-500 block">ਯੋਗਤਾ:</span>
                <input
                  type="text"
                  value={selectedProfile.qualification1 || ''}
                  onChange={(e) => setSelectedProfile({...selectedProfile, qualification1: e.target.value})}
                  className="font-semibold text-gray-900 mt-1 block w-full bg-transparent border-b border-dashed border-gray-300 outline-none"
                />
              </div>

              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="font-bold text-gray-500 block">ਸ਼ਹਿਰ/ਪਿੰਡ:</span>
                <input
                  type="text"
                  value={selectedProfile.location || ''}
                  onChange={(e) => setSelectedProfile({...selectedProfile, location: e.target.value})}
                  className="font-semibold text-gray-900 mt-1 block w-full bg-transparent border-b border-dashed border-gray-300 outline-none"
                />
              </div>

              <div className="p-3 bg-gray-50 rounded-xl">
                <span className="font-bold text-gray-500 block">ਜ਼ਿਲ੍ਹਾ:</span>
                <input
                  type="text"
                  value={selectedProfile.district || ''}
                  onChange={(e) => setSelectedProfile({...selectedProfile, district: e.target.value})}
                  className="font-semibold text-gray-900 mt-1 block w-full bg-transparent border-b border-dashed border-gray-300 outline-none"
                />
              </div>

              <div className="p-3 bg-gray-50 rounded-xl col-span-full">
                <span className="font-bold text-gray-500 block">ਪਰਿਵਾਰਕ ਵੇਰਵਾ:</span>
                <textarea
                  value={selectedProfile.fatherOccupation || ''}
                  onChange={(e) => setSelectedProfile({...selectedProfile, fatherOccupation: e.target.value})}
                  className="font-semibold text-gray-900 mt-1 block w-full bg-transparent border-b border-dashed border-gray-300 outline-none resize-none"
                  rows={2}
                />
              </div>
            </div>

            <div className="mt-6 flex justify-end gap-3 pt-4 border-t border-gray-100">
              <button
                type="button"
                onClick={() => setSelectedProfile(null)}
                className="px-4 py-2 rounded-xl bg-gray-100 hover:bg-gray-200 text-gray-800 text-xs font-bold"
              >
                ਬੰਦ ਕਰੋ
              </button>
              <button
                type="button"
                onClick={async () => {
                    if(!selectedProfile.id.startsWith('demo-')) {
                        await updateDoc(doc(db, 'profiles', selectedProfile.id), {
                            fullName: selectedProfile.fullName,
                            fatherGotra: selectedProfile.fatherGotra,
                            profession: selectedProfile.profession,
                            contactNumber: selectedProfile.contactNumber,
                            qualification1: selectedProfile.qualification1,
                            location: selectedProfile.location,
                            district: selectedProfile.district,
                            fatherOccupation: selectedProfile.fatherOccupation
                        });
                        showToast('success', 'ਪ੍ਰੋਫਾਈਲ ਅਪਡੇਟ ਕੀਤੀ ਗਈ!');
                        fetchAllData();
                        setSelectedProfile(null);
                    }
                }}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-rose-950 text-xs font-bold shadow-sm"
              >
                ਸੇਵ ਕਰੋ
              </button>
            </div>
          </div>
        </div>
      )}

        </div>
      </main>
    </div>
  );
}
