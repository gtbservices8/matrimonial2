export interface ProfileData {
  id?: string;
  userId?: string;
  fullName: string;
  gender: 'Female' | 'Male' | 'Other' | string;
  age: number | string;
  dateOfBirth?: string;
  
  // Birth & Physical Details (ਜਨਮ ਅਤੇ ਸਰੀਰਕ ਵੇਰਵਾ)
  birthPlace: string;     // ਜਨਮ ਸਥਾਨ (Mandatory / ਜ਼ਰੂਰੀ)
  birthTime?: string;     // ਜਨਮ ਸਮਾਂ (ਵਿਕਲਪਿਕ / Optional)
  complexion: string;     // ਰੰਗ (Mandatory / ਜ਼ਰੂਰੀ)
  height: string;         // ਕੱਦ / Hight (Mandatory / ਜ਼ਰੂਰੀ)
  
  // Location & District (ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ ਅਤੇ ਪਤਾ)
  state: string;          // ਸਟੇਟ (Mandatory / ਜ਼ਰੂਰੀ)
  district: string;       // ਜ਼ਿਲ੍ਹਾ (Mandatory / ਜ਼ਰੂਰੀ)
  tehsil?: string;        // ਤਹਿਸੀਲ (Tehsil)
  location: string;       // ਪਿੰਡ/ਸ਼ਹਿਰ/ਪਤਾ (Mandatory / ਜ਼ਰੂਰੀ)
  
  // Mahasha Caste & Gotra Details (ਗੋਤਰ ਅਤੇ ਕਾਸਟ)
  fatherGotra: string;    // ਪਿਤਾ ਦਾ ਗੋਤਰ / Father Caste (Mandatory / ਜ਼ਰੂਰੀ - e.g. Bajgal / Bhogal)
  motherGotra: string;    // ਮਾਤਾ ਦਾ ਗੋਤਰ / ਨਾਨਕੇ ਕਾਸਟ (Mandatory / ਜ਼ਰੂਰੀ - e.g. Ghangla)
  religion?: string;      // ਧਰਮ (Hindu, Sikh, etc.)
  community?: string;     // ਮਹਾਸ਼ਾ
  
  // Multi-tier Educational Qualifications (ਵਿੱਦਿਅਕ ਯੋਗਤਾਵਾਂ)
  qualification1: string; // Qualification-1: ਮੁੱਖ ਯੋਗਤਾ (Mandatory / ਜ਼ਰੂਰੀ - e.g. Computer Engineering Diploma)
  qualification2?: string;// Qualification-2: ਦੂਜੀ ਯੋਗਤਾ (Optional - e.g. BA.LLB)
  qualification3?: string;// Qualification-3: ਉੱਚ ਯੋਗਤਾ (Optional - e.g. LLM Criminology)
  education?: string;     // Highest Degree summary
  
  // Career & Practice Details (ਕਿੱਤਾ ਅਤੇ ਅਭਿਆਸ)
  profession: string;        // ਪੇਸ਼ਾ (Mandatory / ਜ਼ਰੂਰੀ - e.g. Advocate / Lawyer)
  occupationDetails: string; // ਕੰਮ ਦਾ ਪੂਰਾ ਵੇਰਵਾ (Mandatory / ਜ਼ਰੂਰੀ - e.g. Now practicing as an Advocate with her mother & preparation of PCS (J))
  income?: string;           // ਸਾਲਾਨਾ ਆਮਦਨ
  
  // Family Details (ਪਰਿਵਾਰਕ ਵੇਰਵਾ)
  fatherName?: string;       // ਪਿਤਾ ਦਾ ਨਾਮ (Father's Name)
  motherName?: string;       // ਮਾਤਾ ਦਾ ਨਾਮ (Mother's Name)
  fatherOccupation: string;  // ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Mandatory / ਜ਼ਰੂਰੀ - e.g. (Expire) Retired cashier from CPWD)
  motherOccupation: string;  // ਮਾਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Mandatory / ਜ਼ਰੂਰੀ - e.g. Advocate)
  brotherDetails?: string;   // ਭਰਾ ਦਾ ਵੇਰਵਾ (Optional - e.g. Advocate)
  sisterDetails?: string;    // ਭੈਣਾਂ ਦਾ ਵੇਰਵਾ (Optional)
  familyType?: string;       // Nuclear / Joint
  
  // Contact Information (ਸੰਪਰਕ ਵੇਰਵਾ)
  contactNumber: string;     // ਸੰਪਰਕ ਨੰਬਰ (Mandatory / ਜ਼ਰੂਰੀ)
  alternateContact?: string; // ਦੂਜਾ ਨੰਬਰ / ਵਟਸਐਪ (Optional)
  
  // Other details
  maritalStatus?: string;
  aboutMe?: string;
  isVerified?: boolean;
  isDraft?: boolean;
  photoUrl?: string;
  photoUrls?: string[];
  videoUrl?: string;
  profileCompletion?: number;
  viewCount?: number;
  lastSeen?: any;
  createdAt?: any;
  updatedAt?: any;
}

export interface MatchCompatibility {
  totalScore: number; // 0 - 100
  rating: 'Exceptional (ਸ਼ਾਨਦਾਰ)' | 'Great (ਬਹੁਤ ਵਧੀਆ)' | 'Good (ਚੰਗਾ ਮੇਲ)' | 'Moderate (ਦਰਮਿਆਨਾ)';
  casteGotraScore: number; // 0 - 100
  educationScore: number;  // 0 - 100
  locationScore: number;   // 0 - 100
  professionScore: number; // 0 - 100
  ageScore: number;        // 0 - 100
  highlights: string[];
  considerations: string[];
}

export const MAHASHA_GOTRAS = [
  { value: 'Bajgal (Bhogal)', label: 'ਬਜਗਲ / ਭੋਗਲ - Bajgal (Bhogal)' },
  { value: 'Ghangla', label: 'ਘਾਂਗਲਾ - Ghangla' },
  { value: 'Kaler', label: 'ਕਲੇਰ - Kaler' },
  { value: 'Badhan', label: 'ਬੱਧਣ - Badhan' },
  { value: 'Banga', label: 'ਬੰਗਾ - Banga' },
  { value: 'Kundal', label: 'ਕੁੰਡਲ - Kundal' },
  { value: 'Ghotra', label: 'ਘੋਤੜਾ - Ghotra' },
  { value: 'Karloopia', label: 'ਕਰਲੂਪੀਆ - Karloopia' },
  { value: 'Hans', label: 'ਹੰਸ - Hans' },
  { value: 'Taak', label: 'ਟਾਕ - Taak' },
  { value: 'Kajla', label: 'ਕਾਜਲਾ - Kajla' },
  { value: 'Suman', label: 'ਸੁਮਨ - Suman' },
  { value: 'Nahar', label: 'ਨਾਹਰ - Nahar' },
  { value: 'Bhatti', label: 'ਭੱਟੀ - Bhatti' },
  { value: 'Chumber', label: 'ਚੁੰਬਰ - Chumber' },
  { value: 'Gill', label: 'ਗਿੱਲ - Gill' },
  { value: 'Sandhu', label: 'ਸੰਧੂ - Sandhu' },
  { value: 'Other', label: 'ਹੋਰ ਮਹਾਸ਼ਾ ਗੋਤਰ (Other Gotra)' },
];

export const PUNJAB_DISTRICTS = [
  'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
  'Amritsar (ਅੰਮ੍ਰਿਤਸਰ)',
  'Pathankot (ਪਠਾਨਕੋਟ)',
  'Hoshiarpur (ਹੁਸ਼ਿਆਰਪੁਰ)',
  'Jalandhar (ਜਲੰਧਰ)',
  'Kapurthala (ਕਪੂਰਥਲਾ)',
  'Ludhiana (ਲੁਧਿਆਣਾ)',
  'Tarn Taran (ਤਰਨ ਤਾਰਨ)',
  'Bathinda (ਬਠਿੰਡਾ)',
  'Patiala (ਪਟਿਆਲਾ)',
  'SAS Nagar / Mohali (ਮੋਹਾਲੀ)',
  'Rupnagar / Ropar (ਰੂਪਨਗਰ)',
  'Sangrur (ਸੰਗਰੂਰ)',
  'Firozpur (ਫ਼ਿਰੋਜ਼ਪੁਰ)',
  'Faridkot (ਫ਼ਰੀਦਕੋਟ)',
  'Fazilka (ਫ਼ਾਜ਼ਿਲਕਾ)',
  'Mansa (ਮਾਨਸਾ)',
  'Moga (ਮੋਗਾ)',
  'Sri Muktsar Sahib (ਮੁਕਤਸਰ)',
  'Fatehgarh Sahib (ਫ਼ਤਹਿਗੜ੍ਹ ਸਾਹਿਬ)',
  'Barnala (ਬਰਨਾਲਾ)',
  'Malerkotla (ਮਾਲੇਰਕੋਟਲਾ)',
  'Jammu (ਜੰਮੂ)',
  'Kathua (ਕਠੂਆ)',
  'Samba (ਸਾਂਬਾ)',
  'Chandigarh (ਚੰਡੀਗੜ੍ਹ)',
  'Delhi NCR (ਦਿੱਲੀ)',
  'Other / ਬਾਹਰਲਾ ਜ਼ਿਲ੍ਹਾ',
];

export const STATES = [
  'Punjab (ਪੰਜਾਬ)',
  'Haryana (ਹਰਿਆਣਾ)',
  'Himachal Pradesh (ਹਿਮਾਚਲ ਪ੍ਰਦੇਸ਼)',
  'Jammu & Kashmir (ਜੰਮੂ ਅਤੇ ਕਸ਼ਮੀਰ)',
  'Delhi (ਦਿੱਲੀ)',
  'Chandigarh (ਚੰਡੀਗੜ੍ਹ)',
  'Rajasthan (ਰਾਜਸਥਾਨ)',
  'Uttarakhand (ਉੱਤਰਾਖੰਡ)',
  'Other (ਹੋਰ)'
];

export const COMPLEXIONS = [
  { value: 'Fair', label: 'ਗੋਰਾ (Fair)' },
  { value: 'Very Fair', label: 'ਬਹੁਤ ਗੋਰਾ (Very Fair)' },
  { value: 'Wheatish', label: 'ਕਣਕਵੰਨਾ (Wheatish)' },
  { value: 'Dusky', label: 'ਸਾਂਵਲਾ (Dusky)' },
];

export const HEIGHT_OPTIONS = [
  '4\'10" (147 cm)',
  '4\'11" (150 cm)',
  '5\'0" (152 cm)',
  '5\'1" (155 cm)',
  '5\'2" (157 cm)',
  '5\'3" (160 cm)',
  '5\'4" (162 cm)',
  '5\'5" (165 cm)',
  '5\'6" (168 cm)',
  '5\'7" (170 cm)',
  '5\'8" (173 cm)',
  '5\'9" (175 cm)',
  '5\'10" (178 cm)',
  '5\'11" (180 cm)',
  '6\'0" (183 cm)',
  '6\'1" (185 cm)',
  '6\'2" (188 cm)',
  '6\'3"+ (190+ cm)'
];

export const STANDARD_PROFESSIONS = [
  'Advocate / Lawyer',
  'Software Engineer',
  'Doctor / Medical',
  'Business / Trader',
  'Teacher / Professor',
  'Government Job',
  'Banker / Finance',
  'Chartered Accountant (CA)',
  'Armed Forces / Police',
  'Judicial / PCS(J) Aspirant',
  'Civil Services',
  'Not Working / Homemaker',
  'Other'
];

export * from './types/notification';
export * from './types/filters';

export interface SuccessStory {
  id?: string;
  coupleName: string;
  brideName: string;
  groomName: string;
  weddingDate: string;
  location: string;
  communityEn: string;
  communityPa: string;
  ceremonyType: string;
  ceremonyTypePa: string;
  image: string;
  summaryEn: string;
  summaryPa: string;
  fullStory: string;
  rating: number;
  highlightQuoteEn: string;
  highlightQuotePa: string;
  gotras: string;
  createdAt?: any;
}

export interface MetricItem {
  id: string;
  count: number | string;
  suffix: string;
  title: string;
  punjabiTitle: string;
  description: string;
  badge: string;
  icon?: string; // Icon name from lucide-react
  color: string;
  bgLight: string;
  borderLight: string;
}

export interface GlobalConfig {
  siteNameEn: string;
  siteNamePa: string;
  supportPhone: string;
  supportEmail: string;
  whatsappNumber: string;
  addressEn: string;
  addressPa: string;
  facebookUrl?: string;
  instagramUrl?: string;
  youtubeUrl?: string;
  isRegistrationOpen: boolean;
  maintenanceMode: boolean;
  announcementEn?: string;
  announcementPa?: string;
  seoTitle?: string;
  seoDescription?: string;
  seoKeywords?: string;
  
  // App Configuration (ਪਲੇਟਫਾਰਮ ਸੰਰਚਨਾ)
  registrationIncentiveDays: number;
  registrationIncentiveLabelEn: string;
  registrationIncentiveLabelPa: string;
  showUnverifiedProfiles: boolean;
  allowPublicProfiles: boolean;
  notificationFrequency: 'immediate' | 'daily' | 'weekly' | 'none';
  enableRealTimeAlerts: boolean;
  
  updatedAt?: any;
}

export interface FormFieldConfig {
  id: string;
  labelEn: string;
  labelPa: string;
  isRequired: boolean;
  isVisible: boolean;
  section: string;
}

export interface FormConfig {
  fields: FormFieldConfig[];
  districts: string[];
  states: string[];
  gotras: { value: string; label: string }[];
  complexions: { value: string; label: string }[];
  professions: string[];
  tehsils?: string[];
  religions?: string[];
  birthPlaces?: string[];
  updatedAt?: any;
}

export interface ActivityLog {
  id?: string;
  type: 'registration' | 'profile_update' | 'admin_action' | 'system';
  action: string;
  details: string;
  performedBy: string; // userId or 'System' or 'Admin'
  performedByName?: string;
  targetId?: string; // id of profile, etc.
  timestamp: any;
}

export interface SiteSettings {
  metrics: MetricItem[];
  globalConfig?: GlobalConfig;
  updatedAt?: any;
}
