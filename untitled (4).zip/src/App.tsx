import type { ReactNode } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { LanguageProvider } from './contexts/LanguageContext';
import { NotificationProvider } from './contexts/NotificationContext';
import { SettingsProvider } from './contexts/SettingsContext';
import Navbar from './components/layout/Navbar';
import Footer from './components/layout/Footer';
import Home from './pages/Home';
import Login from './pages/Login';
import Register from './pages/Register';
import Dashboard from './pages/Dashboard';
import Matches from './pages/Matches';
import EditProfile from './pages/EditProfile';
import ProfileDetail from './pages/ProfileDetail';
import Notifications from './pages/Notifications';
import AdminPanel from './pages/AdminPanel';
import ContactUs from './pages/ContactUs';
import TermsConditions from './pages/TermsConditions';
import CookiePolicy from './pages/CookiePolicy';
import SuccessStories from './pages/SuccessStories';
import NotificationToast from './components/notifications/NotificationToast';
import AdminLoginModal from './components/AdminLoginModal';
import { useCMSConfig } from './hooks/useCMSConfig';
import AppLogo from './components/common/AppLogo';
import { AlertTriangle } from 'lucide-react';
import { runFirebaseDiagnostic } from './lib/firebase';

const ProtectedRoute = ({ children }: { children: ReactNode }) => {
  const { user, loading } = useAuth();
  
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }
  
  if (!user) {
    return <Navigate to="/login" />;
  }
  
  return <>{children}</>;
};

const AdminRoute = ({ children }: { children: ReactNode }) => {
  const isAdminAuth = sessionStorage.getItem('mahasha_admin_auth') === 'true';

  if (!isAdminAuth) {
    return <Navigate to="/" />;
  }

  return <>{children}</>;
};

function AppRoutes() {
  const [isAdminModalOpen, setIsAdminModalOpen] = useState(false);
  const { config, loading: configLoading } = useCMSConfig();
  const { user } = useAuth();
  
  const isAdmin = user?.email === 'gtbservices8@gmail.com';

  if (configLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-white">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }

  // Global Maintenance Mode check
  if (config?.maintenanceMode && !isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50 p-8 text-center">
        <div className="max-w-md w-full bg-white p-8 rounded-3xl shadow-xl border border-rose-100 flex flex-col items-center">
          <div className="w-20 h-20 bg-rose-50 rounded-full flex items-center justify-center mb-6">
            <AlertTriangle className="w-10 h-10 text-rose-600" />
          </div>
          <h1 className="text-2xl font-bold text-rose-950 font-serif mb-3">
            {config.siteNamePa || 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ'}
          </h1>
          <h2 className="text-lg font-bold text-gray-800 mb-4">ਸਾਈਟ ਮੇਨਟੇਨੈਂਸ ਅਧੀਨ ਹੈ</h2>
          <p className="text-gray-600 text-sm leading-relaxed mb-8">
            {config.announcementPa || 'ਅਸੀਂ ਵੈੱਬਸਾਈਟ ਨੂੰ ਹੋਰ ਬਿਹਤਰ ਬਣਾਉਣ ਲਈ ਕੁਝ ਜ਼ਰੂਰੀ ਕੰਮ ਕਰ ਰਹੇ ਹਾਂ। ਕਿਰਪਾ ਕਰਕੇ ਕੁਝ ਸਮੇਂ ਬਾਅਦ ਦੁਬਾਰਾ ਕੋਸ਼ਿਸ਼ ਕਰੋ।'}
          </p>
          <div className="pt-6 border-t border-gray-100 w-full text-[11px] text-gray-400 font-bold uppercase tracking-widest">
            Maintenance Mode Active
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col font-sans relative">
      <Navbar onOpenAdminModal={() => setIsAdminModalOpen(true)} />
      <main className="flex-grow">
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/contact" element={<ContactUs />} />
          <Route path="/terms" element={<TermsConditions />} />
          <Route path="/cookie-policy" element={<CookiePolicy />} />
          <Route path="/stories" element={<SuccessStories />} />
          <Route 
            path="/matches" 
            element={
              <ProtectedRoute>
                <Matches />
              </ProtectedRoute>
            } 
          />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
          <Route 
            path="/dashboard" 
            element={
              <ProtectedRoute>
                <Dashboard />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/notifications" 
            element={
              <ProtectedRoute>
                <Notifications />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/admin" 
            element={
              <AdminRoute>
                <AdminPanel />
              </AdminRoute>
            } 
          />
          <Route 
            path="/profile/edit" 
            element={
              <ProtectedRoute>
                <EditProfile />
              </ProtectedRoute>
            } 
          />
          <Route 
            path="/profile/:id" 
            element={
              <ProtectedRoute>
                <ProfileDetail />
              </ProtectedRoute>
            } 
          />
        </Routes>
      </main>
      <NotificationToast />
      <Footer />
      <AdminLoginModal
        isOpen={isAdminModalOpen}
        onClose={() => setIsAdminModalOpen(false)}
      />
    </div>
  );
}

export default function App() {
  useEffect(() => {
    runFirebaseDiagnostic();
  }, []);

  return (
    <LanguageProvider>
      <SettingsProvider>
        <AuthProvider>
          <NotificationProvider>
            <Router>
              <AppRoutes />
            </Router>
          </NotificationProvider>
        </AuthProvider>
      </SettingsProvider>
    </LanguageProvider>
  );
}
