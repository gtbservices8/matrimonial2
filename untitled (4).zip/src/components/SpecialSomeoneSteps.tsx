import { Link } from 'react-router-dom';
import { UserPlus, HeartHandshake, MessageSquareHeart, Sparkles, ArrowRight, ShieldCheck, CheckCircle2 } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export default function SpecialSomeoneSteps() {
  const { language } = useLanguage();

  const content = {
    pa: {
      badge: 'ਆਸਾਨ ਅਤੇ ਭਰੋਸੇਮੰਦ ਪ੍ਰਕਿਰਿਆ',
      title: 'Find your Special Someone',
      titlePa: 'ਆਪਣਾ ਖ਼ਾਸ ਜੀਵਨ ਸਾਥੀ ਲੱਭੋ',
      subtitle: 'ਵਿਆਹ ਦੀਆਂ ਖੁਸ਼ੀਆਂ ਵੱਲ ਵਧਣ ਲਈ ਸਿਰਫ਼ 3 ਸਧਾਰਨ ਕਦਮ ਪੂਰੇ ਕਰੋ',
      steps: [
        {
          number: '01',
          title: 'Sign Up',
          actionTitle: 'ਸਾਈਨ ਅੱਪ ਕਰੋ',
          desc: 'Register for free & put up your Matrimony Profile',
          descLocalized: 'ਕੁਝ ਹੀ ਮਿੰਟਾਂ ਵਿੱਚ ਮੁਫ਼ਤ ਰਜਿਸਟਰ ਕਰੋ ਅਤੇ ਆਪਣੀ ਪ੍ਰਮਾਣਿਤ ਬਾਇਓਡਾਟਾ ਪ੍ਰੋਫਾਈਲ ਤਿਆਰ ਕਰੋ।',
          btnText: 'ਰਜਿਸਟਰ ਕਰੋ (Free)',
          btnLink: '/register',
          badge: 'ਮੁਫ਼ਤ ਰਜਿਸਟ੍ਰੇਸ਼ਨ',
          icon: UserPlus,
          cardBg: 'from-amber-50/80 to-white',
          borderCol: 'border-amber-200/80',
          badgeBg: 'bg-amber-100 text-amber-900 border-amber-300/60',
          iconBg: 'bg-amber-500 text-rose-950',
        },
        {
          number: '02',
          title: 'Connect',
          actionTitle: 'ਰਿਸ਼ਤਿਆਂ ਨਾਲ ਜੁੜੋ',
          desc: 'Select & Connect with Matches you like',
          descLocalized: 'ਉਮਰ, ਜਾਤ, ਪੜ੍ਹਾਈ ਅਤੇ ਸ਼ਹਿਰ ਅਨੁਸਾਰ ਮਨਪਸੰਦ ਪ੍ਰੋਫਾਈਲ ਚੁਣੋ ਅਤੇ ਆਪਣੀ ਦਿਲਚਸਪੀ (Interest) ਭੇਜੋ।',
          btnText: 'ਮੈਚਿਜ਼ ਵੇਖੋ',
          btnLink: '/matches',
          badge: '100% ਪ੍ਰਮਾਣਿਤ ਪ੍ਰੋਫਾਈਲ',
          icon: HeartHandshake,
          cardBg: 'from-rose-50/70 to-white',
          borderCol: 'border-rose-200/80',
          badgeBg: 'bg-rose-100 text-rose-900 border-rose-300/60',
          iconBg: 'bg-rose-900 text-amber-300',
        },
        {
          number: '03',
          title: 'Interact',
          actionTitle: 'ਗੱਲਬਾਤ ਸ਼ੁਰੂ ਕਰੋ',
          desc: 'Become a Premium Member & Start a Conversation',
          descLocalized: 'ਪ੍ਰੀਮੀਅਮ ਮੈਂਬਰਸ਼ਿਪ ਨਾਲ ਸੰਪਰਕ ਨੰਬਰ ਵੇਖੋ, ਪਰਿਵਾਰਾਂ ਨਾਲ ਫੋਨ ਜਾਂ ਚੈਟ ਰਾਹੀਂ ਸਿੱਧੀ ਗੱਲਬਾਤ ਸ਼ੁਰੂ ਕਰੋ।',
          btnText: 'ਪ੍ਰੀਮੀਅਮ ਸ਼ੁਰੂ ਕਰੋ',
          btnLink: '/matches',
          badge: 'ਸੁਰੱਖਿਅਤ ਤੇ ਸਿੱਧਾ ਸੰਪਰਕ',
          icon: MessageSquareHeart,
          cardBg: 'from-amber-50/50 to-white',
          borderCol: 'border-amber-200/80',
          badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300/60',
          iconBg: 'bg-rose-950 text-amber-400 border border-amber-400/40',
        }
      ]
    },
    hi: {
      badge: 'सरल और सुरक्षित प्रक्रिया',
      title: 'Find your Special Someone',
      titlePa: 'अपना हमसफ़र चुनें',
      subtitle: 'खुशहाल वैवाहिक जीवन की शुरुआत के लिए 3 आसान कदम',
      steps: [
        {
          number: '01',
          title: 'Sign Up',
          actionTitle: 'साइन अप करें',
          desc: 'Register for free & put up your Matrimony Profile',
          descLocalized: 'मुफ्त में पंजीकरण करें और अपनी विस्तृत वैवाहिक प्रोफाइल बनाएं।',
          btnText: 'मुफ्त रजिस्टर करें',
          btnLink: '/register',
          badge: 'मुफ्त पंजीकरण',
          icon: UserPlus,
          cardBg: 'from-amber-50/80 to-white',
          borderCol: 'border-amber-200/80',
          badgeBg: 'bg-amber-100 text-amber-900 border-amber-300/60',
          iconBg: 'bg-amber-500 text-rose-950',
        },
        {
          number: '02',
          title: 'Connect',
          actionTitle: 'संपर्क बनाएं',
          desc: 'Select & Connect with Matches you like',
          descLocalized: 'अपनी पसंद के अनुसार मैच चुनें और उन्हें इंटरेस्ट (Interest) भेजें।',
          btnText: 'मैचेस देखें',
          btnLink: '/matches',
          badge: 'सत्यापित मैच',
          icon: HeartHandshake,
          cardBg: 'from-rose-50/70 to-white',
          borderCol: 'border-rose-200/80',
          badgeBg: 'bg-rose-100 text-rose-900 border-rose-300/60',
          iconBg: 'bg-rose-900 text-amber-300',
        },
        {
          number: '03',
          title: 'Interact',
          actionTitle: 'बातचीत शुरू करें',
          desc: 'Become a Premium Member & Start a Conversation',
          descLocalized: 'प्रीमियम सदस्य बनकर फोन नंबर प्राप्त करें और परिवारों से बातचीत शुरू करें।',
          btnText: 'बातचीत शुरू करें',
          btnLink: '/matches',
          badge: 'डायरेक्ट कॉन्टैक्ट',
          icon: MessageSquareHeart,
          cardBg: 'from-amber-50/50 to-white',
          borderCol: 'border-amber-200/80',
          badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300/60',
          iconBg: 'bg-rose-950 text-amber-400 border border-amber-400/40',
        }
      ]
    },
    en: {
      badge: 'Simple 3-Step Journey',
      title: 'Find your Special Someone',
      titlePa: 'Begin Your Journey of Love',
      subtitle: 'Three easy steps to connect with compatible matches and respectable families.',
      steps: [
        {
          number: '01',
          title: 'Sign Up',
          actionTitle: 'Create Profile',
          desc: 'Register for free & put up your Matrimony Profile',
          descLocalized: 'Create your detailed matrimonial profile with education, family values, and preferences.',
          btnText: 'Register Free',
          btnLink: '/register',
          badge: '100% Free Signup',
          icon: UserPlus,
          cardBg: 'from-amber-50/80 to-white',
          borderCol: 'border-amber-200/80',
          badgeBg: 'bg-amber-100 text-amber-900 border-amber-300/60',
          iconBg: 'bg-amber-500 text-rose-950',
        },
        {
          number: '02',
          title: 'Connect',
          actionTitle: 'Discover Matches',
          desc: 'Select & Connect with Matches you like',
          descLocalized: 'Filter by community, age, location and send free interests to compatible matches.',
          btnText: 'Explore Matches',
          btnLink: '/matches',
          badge: 'Smart Recommendations',
          icon: HeartHandshake,
          cardBg: 'from-rose-50/70 to-white',
          borderCol: 'border-rose-200/80',
          badgeBg: 'bg-rose-100 text-rose-900 border-rose-300/60',
          iconBg: 'bg-rose-900 text-amber-300',
        },
        {
          number: '03',
          title: 'Interact',
          actionTitle: 'Start Conversation',
          desc: 'Become a Premium Member & Start a Conversation',
          descLocalized: 'Unlock verified phone numbers and initiate direct family calls & messaging safely.',
          btnText: 'Start Connecting',
          btnLink: '/matches',
          badge: 'Direct & Safe Access',
          icon: MessageSquareHeart,
          cardBg: 'from-amber-50/50 to-white',
          borderCol: 'border-amber-200/80',
          badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300/60',
          iconBg: 'bg-rose-950 text-amber-400 border border-amber-400/40',
        }
      ]
    }
  };

  const current = content[language] || content.pa;

  return (
    <section className="py-20 bg-gradient-to-b from-white via-rose-50/30 to-amber-50/20 relative overflow-hidden border-t border-amber-100">
      {/* Decorative subtle background elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-200/15 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-rose-200/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        {/* Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-200/90 px-4 py-1.5 rounded-full text-xs font-bold text-rose-900 mb-3 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-amber-600" />
            <span>{current.badge}</span>
          </div>

          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 font-serif tracking-tight">
            Find your <span className="text-rose-900 relative inline-block">
              Special Someone
              <span className="absolute -bottom-1 left-0 right-0 h-1 bg-amber-400 rounded-full opacity-80"></span>
            </span>
          </h2>

          <p className="text-base sm:text-lg text-gray-600 mt-4 leading-relaxed">
            {current.subtitle}
          </p>
        </div>

        {/* 3 Step Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 relative">
          {/* Connector Line on Desktop */}
          <div className="hidden md:block absolute top-1/2 left-[15%] right-[15%] h-0.5 border-t-2 border-dashed border-amber-300/70 -translate-y-12 z-0" />

          {current.steps.map((step) => {
            const IconComp = step.icon;
            return (
              <div
                key={step.number}
                className={`relative z-10 bg-gradient-to-b ${step.cardBg} rounded-3xl p-8 border ${step.borderCol} shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col justify-between group hover:-translate-y-1.5`}
              >
                {/* Step Top Header: Number & Badge */}
                <div>
                  <div className="flex items-center justify-between mb-6">
                    <span className="font-serif text-3xl sm:text-4xl font-black text-rose-950/20 group-hover:text-rose-900/40 transition-colors">
                      {step.number}
                    </span>
                    <span className={`text-[11px] font-bold px-3 py-1 rounded-full border shadow-2xs ${step.badgeBg}`}>
                      {step.badge}
                    </span>
                  </div>

                  {/* Icon Circle */}
                  <div className="mb-6 flex items-center justify-center">
                    <div className={`w-20 h-20 rounded-2xl ${step.iconBg} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300`}>
                      <IconComp className="w-10 h-10" />
                    </div>
                  </div>

                  {/* Title & Description as explicitly requested */}
                  <div className="text-center mb-6">
                    <h3 className="text-2xl font-bold text-gray-900 font-serif tracking-tight">
                      {step.title}
                    </h3>
                    <p className="text-sm font-semibold text-rose-900 mt-1">
                      {step.actionTitle}
                    </p>
                    
                    {/* Exact User Requested Phrase */}
                    <div className="mt-3 bg-white/80 rounded-xl p-3 border border-gray-100 shadow-2xs">
                      <p className="text-sm font-bold text-gray-800 leading-snug">
                        {step.desc}
                      </p>
                    </div>

                    <p className="text-xs text-gray-500 mt-2.5 leading-relaxed">
                      {step.descLocalized}
                    </p>
                  </div>
                </div>

                {/* Bottom Action Button */}
                <div className="pt-4 border-t border-gray-100 mt-2">
                  <Link
                    to={step.btnLink}
                    className="w-full inline-flex items-center justify-center gap-2 bg-white hover:bg-rose-900 text-rose-900 hover:text-amber-300 border border-rose-200 hover:border-rose-900 py-3 px-4 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-xs group/btn"
                  >
                    <span>{step.btnText}</span>
                    <ArrowRight className="w-4 h-4 group-hover/btn:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>

        {/* Assurance bar below cards */}
        <div className="mt-12 bg-white rounded-2xl p-4 sm:p-5 border border-amber-200/70 shadow-xs flex flex-wrap items-center justify-around gap-4 text-xs sm:text-sm text-gray-700">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-600" />
            <span className="font-semibold">100% Privacy Protection</span>
          </div>
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-amber-600" />
            <span className="font-semibold">Manually Verified Contacts</span>
          </div>
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-rose-900" />
            <span className="font-semibold">Over 5,000+ Happy Marriages</span>
          </div>
        </div>
      </div>
    </section>
  );
}
