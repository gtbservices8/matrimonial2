import React from 'react';
import { Search, Filter, GraduationCap, Briefcase, MapPin } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import { EDUCATION_LEVEL_OPTIONS, OCCUPATION_OPTIONS } from '../types/filters';

export interface FilterState {
  gender: string;
  minAge: string;
  maxAge: string;
  community: string;
  profession: string[]; // Changed to array
  location: string;
  educationLevel?: string[]; // Changed to array
  district?: string[]; // Changed to array
  state?: string[]; // Added state filter
}

interface SearchSidebarProps {
  filters: FilterState;
  onChange: (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => void;
  onMultiChange: (name: string, value: string, checked: boolean) => void;
  onSearch: (e: React.FormEvent) => void;
  buttonLabel?: string;
}

export default function SearchSidebar({ filters, onChange, onMultiChange, onSearch, buttonLabel = "Apply Filters" }: SearchSidebarProps) {
  const { districts, states } = useSettings();
  
  const handleCheckboxChange = (name: string, value: string, checked: boolean) => {
    onMultiChange(name, value, checked);
  };

  const MultiSelectGroup = ({ 
    label, icon: Icon, name, options, selectedValues = [] 
  }: { 
    label: string, icon: any, name: string, options: { label: string, value: string }[], selectedValues: string[] 
  }) => (
    <div className="mb-4">
      <label className="block text-xs font-bold text-gray-700 mb-2 flex items-center gap-1.5">
        <Icon className="w-3.5 h-3.5" />
        {label}
      </label>
      <div className="space-y-1.5 max-h-32 overflow-y-auto pr-2">
        {options.map((opt) => (
          <label key={opt.value} className="flex items-center gap-2 text-xs font-medium text-gray-600 cursor-pointer">
            <input
              type="checkbox"
              checked={selectedValues.includes(opt.value)}
              onChange={(e) => handleCheckboxChange(name, opt.value, e.target.checked)}
              className="rounded text-amber-600 focus:ring-amber-500"
            />
            {opt.label}
          </label>
        ))}
      </div>
    </div>
  );

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-6 sticky top-24">
      <div className="flex items-center justify-between mb-6 border-b border-gray-100 pb-4">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-rose-900" />
          <h2 className="text-lg font-bold text-gray-900 font-serif">ਮਹਾਸ਼ਾ ਫਿਲਟਰ</h2>
        </div>
      </div>
      
      <form onSubmit={onSearch} className="space-y-4">
        <div>
          <label className="block text-xs font-bold text-gray-700 mb-1">Looking for</label>
          <select 
            name="gender" 
            value={filters.gender}
            onChange={onChange}
            className="w-full border-gray-300 rounded-xl shadow-xs focus:border-amber-500 focus:ring-amber-500 p-2.5 bg-gray-50 border text-xs font-medium"
          >
            <option value="Any">Any (ਸਾਰੇ)</option>
            <option value="Female">Bride (ਲਾੜੀ)</option>
            <option value="Male">Groom (ਲਾੜਾ)</option>
          </select>
        </div>

        {/* Multi-select Groups */}
        <MultiSelectGroup 
          label="Education (ਵਿੱਦਿਆ)" 
          icon={GraduationCap} 
          name="educationLevel" 
          options={EDUCATION_LEVEL_OPTIONS} 
          selectedValues={filters.educationLevel || []}
        />

        <MultiSelectGroup 
          label="Profession (ਪੇਸ਼ਾ)" 
          icon={Briefcase} 
          name="profession" 
          options={OCCUPATION_OPTIONS} 
          selectedValues={filters.profession}
        />

        <MultiSelectGroup 
          label="State (ਸਟੇਟ)" 
          icon={MapPin} 
          name="state" 
          options={states.map(s => ({label: s, value: s}))} 
          selectedValues={filters.state || []}
        />

        <MultiSelectGroup 
          label="District (ਜ਼ਿਲ੍ਹਾ)" 
          icon={MapPin} 
          name="district" 
          options={districts.map(d => ({label: d, value: d}))} 
          selectedValues={filters.district || []}
        />

        {/* Other fields... */}
        <button 
          type="submit" 
          className="w-full bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-rose-950 p-3 rounded-xl font-bold transition-all shadow-xs flex items-center justify-center gap-2 text-xs pt-3 mt-4"
        >
          <Search className="w-4 h-4" />
          {buttonLabel}
        </button>
      </form>
    </div>
  );
}
