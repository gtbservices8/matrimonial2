import { useState, useRef, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { 
  Bell, BellRing, Sparkles, MessageSquare, Eye, 
  CheckCheck, Volume2, VolumeX, PlusCircle, ExternalLink,
  ChevronRight, Inbox
} from 'lucide-react';
import { useNotifications } from '../../contexts/NotificationContext';
import { useLanguage } from '../../contexts/LanguageContext';
import NotificationCard from './NotificationCard';
import type { NotificationCategory } from '../../types/notification';

interface NotificationDropdownProps {
  onClose: () => void;
}

export default function NotificationDropdown({ onClose }: NotificationDropdownProps) {
  const { 
    notifications, 
    unreadCount, 
    markAllAsRead, 
    soundEnabled, 
    toggleSound, 
    simulateNotification 
  } = useNotifications();
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'all' | NotificationCategory>('all');
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        onClose();
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [onClose]);

  // Filter items based on selected tab
  const filteredNotifications = notifications.filter(item => {
    if (activeTab === 'all') return true;
    return item.category === activeTab;
  });

  const matchCount = notifications.filter(n => n.category === 'match' && !n.read).length;
  const reqCount = notifications.filter(n => n.category === 'message_request' && !n.read).length;
  const activityCount = notifications.filter(n => n.category === 'activity' && !n.read).length;

  return (
    <div 
      ref={dropdownRef}
      className="absolute right-0 top-full mt-2.5 w-80 sm:w-96 max-w-[95vw] bg-white rounded-3xl shadow-2xl border-2 border-amber-300/80 overflow-hidden z-50 animate-in fade-in slide-in-from-top-3 duration-200"
    >
      {/* Header */}
      <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-amber-950 text-white p-4 border-b border-amber-500/30">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="p-1.5 bg-amber-500/20 rounded-xl border border-amber-400/30">
              <BellRing className="w-4 h-4 text-amber-300" />
            </div>
            <div>
              <h3 className="text-base font-bold font-serif text-white flex items-center gap-2">
                <span>{language === 'pa' ? 'ਸੂਚਨਾਵਾਂ & ਅਲਰਟ' : 'In-App Notifications'}</span>
                {unreadCount > 0 && (
                  <span className="bg-amber-400 text-rose-950 text-[10px] font-extrabold px-2 py-0.5 rounded-full shadow-xs">
                    {unreadCount} {language === 'pa' ? 'ਨਵੀਆਂ' : 'New'}
                  </span>
                )}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            {/* Sound Toggle */}
            <button
              type="button"
              onClick={toggleSound}
              className={`p-1.5 rounded-lg border transition-all ${
                soundEnabled 
                  ? 'bg-amber-500/20 text-amber-300 border-amber-400/40 hover:bg-amber-500/30' 
                  : 'bg-white/10 text-gray-400 border-white/20 hover:bg-white/20'
              }`}
              title={soundEnabled ? 'Mute Alert Chime' : 'Enable Alert Chime'}
            >
              {soundEnabled ? <Volume2 className="w-3.5 h-3.5" /> : <VolumeX className="w-3.5 h-3.5" />}
            </button>

            {/* Mark All As Read */}
            {unreadCount > 0 && (
              <button
                type="button"
                onClick={markAllAsRead}
                className="inline-flex items-center gap-1 px-2.5 py-1 rounded-lg bg-white/10 hover:bg-white/20 text-amber-200 text-xs font-semibold border border-amber-400/20 transition-all"
                title="Mark all as read"
              >
                <CheckCheck className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">{language === 'pa' ? 'ਸਭ ਪੜ੍ਹੋ' : 'Read All'}</span>
              </button>
            )}
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex items-center gap-1 mt-3 bg-black/25 p-1 rounded-xl border border-white/10 text-xs">
          <button
            type="button"
            onClick={() => setActiveTab('all')}
            className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-center ${
              activeTab === 'all'
                ? 'bg-amber-400 text-rose-950 shadow-xs'
                : 'text-rose-100/80 hover:text-white hover:bg-white/10'
            }`}
          >
            {language === 'pa' ? 'ਸਾਰੇ' : 'All'}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('match')}
            className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-center flex items-center justify-center gap-1 ${
              activeTab === 'match'
                ? 'bg-amber-400 text-rose-950 shadow-xs'
                : 'text-rose-100/80 hover:text-white hover:bg-white/10'
            }`}
          >
            <Sparkles className="w-3 h-3 text-amber-300 group-hover:text-white" />
            <span>{language === 'pa' ? 'ਮੈਚ' : 'Matches'}</span>
            {matchCount > 0 && (
              <span className="w-1.5 h-1.5 rounded-full bg-amber-400" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('message_request')}
            className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-center flex items-center justify-center gap-1 ${
              activeTab === 'message_request'
                ? 'bg-amber-400 text-rose-950 shadow-xs'
                : 'text-rose-100/80 hover:text-white hover:bg-white/10'
            }`}
          >
            <MessageSquare className="w-3 h-3" />
            <span>{language === 'pa' ? 'ਸੁਨੇਹੇ' : 'Requests'}</span>
            {reqCount > 0 && (
              <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
            )}
          </button>

          <button
            type="button"
            onClick={() => setActiveTab('activity')}
            className={`flex-1 py-1.5 px-2 rounded-lg font-bold transition-all text-center flex items-center justify-center gap-1 ${
              activeTab === 'activity'
                ? 'bg-amber-400 text-rose-950 shadow-xs'
                : 'text-rose-100/80 hover:text-white hover:bg-white/10'
            }`}
          >
            <Eye className="w-3 h-3" />
            <span>{language === 'pa' ? 'ਗਤੀਵਿਧੀ' : 'Activity'}</span>
            {activityCount > 0 && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
            )}
          </button>
        </div>
      </div>

      {/* Notifications List */}
      <div className="max-h-[380px] overflow-y-auto p-3 space-y-2.5 divide-y-0">
        {filteredNotifications.length === 0 ? (
          <div className="py-10 text-center px-4">
            <Inbox className="w-12 h-12 text-gray-300 mx-auto mb-2" />
            <p className="text-sm font-bold text-gray-700 font-serif">
              {language === 'pa' ? 'ਕੋਈ ਨਵੀਂ ਸੂਚਨਾ ਨਹੀਂ' : 'No notifications in this tab'}
            </p>
            <p className="text-xs text-gray-500 mt-1">
              {language === 'pa' ? 'ਹੇਠਾਂ ਦਿੱਤੇ ਸਿਮੂਲੇਟਰ ਬਟਨ ਨਾਲ ਟੈਸਟ ਕਰੋ' : 'Test alerts using the simulation triggers below.'}
            </p>
          </div>
        ) : (
          filteredNotifications.map((notif) => (
            <NotificationCard
              key={notif.id}
              notification={notif}
              compact={true}
              onActionComplete={onClose}
            />
          ))
        )}
      </div>

      {/* Interactive Simulation & Footer */}
      <div className="p-3 bg-gray-50/90 border-t border-gray-200">
        {/* Quick Simulator Bar */}
        <div className="mb-2">
          <div className="flex items-center justify-between mb-1.5">
            <span className="text-[10px] font-bold text-gray-500 uppercase tracking-wider">
              {language === 'pa' ? 'ਲਾਈਵ ਅਲਰਟ ਟੈਸਟ (Simulate)' : 'Live In-App Alert Triggers:'}
            </span>
          </div>
          <div className="grid grid-cols-3 gap-1.5">
            <button
              type="button"
              onClick={() => simulateNotification('match')}
              className="py-1 px-1.5 bg-amber-100 hover:bg-amber-200 text-rose-950 text-[11px] font-bold rounded-lg border border-amber-300/80 transition-all text-center truncate shadow-2xs"
            >
              + 🔥 {language === 'pa' ? 'ਨਵਾਂ ਮੈਚ' : 'Match'}
            </button>
            <button
              type="button"
              onClick={() => simulateNotification('message_request')}
              className="py-1 px-1.5 bg-rose-100 hover:bg-rose-200 text-rose-900 text-[11px] font-bold rounded-lg border border-rose-300/80 transition-all text-center truncate shadow-2xs"
            >
              + 💌 {language === 'pa' ? 'ਸੁਨੇਹਾ' : 'Message'}
            </button>
            <button
              type="button"
              onClick={() => simulateNotification('activity')}
              className="py-1 px-1.5 bg-emerald-100 hover:bg-emerald-200 text-emerald-900 text-[11px] font-bold rounded-lg border border-emerald-300/80 transition-all text-center truncate shadow-2xs"
            >
              + 👁️ {language === 'pa' ? 'ਵਿਊ' : 'Activity'}
            </button>
          </div>
        </div>

        {/* View All Link */}
        <Link
          to="/notifications"
          onClick={onClose}
          className="w-full flex items-center justify-center gap-1.5 py-2 bg-white hover:bg-amber-50 text-rose-950 border border-amber-300 rounded-xl text-xs font-bold transition-all shadow-xs"
        >
          <span>{language === 'pa' ? 'ਸਾਰੀਆਂ ਸੂਚਨਾਵਾਂ ਵੇਖੋ (Notification Hub)' : 'View All in Notification Center'}</span>
          <ExternalLink className="w-3.5 h-3.5 text-amber-600" />
        </Link>
      </div>
    </div>
  );
}
