import { useNavigate } from 'react-router-dom';
import { 
  Sparkles, MessageSquare, Eye, Heart, CheckCircle2, 
  Trash2, ArrowRight, ShieldCheck, Check, X, Phone, UserCheck
} from 'lucide-react';
import type { NotificationItem } from '../../types/notification';
import { useNotifications } from '../../contexts/NotificationContext';
import { useLanguage } from '../../contexts/LanguageContext';

interface NotificationCardProps {
  key?: string | number;
  notification: NotificationItem;
  compact?: boolean;
  onActionComplete?: () => void;
}

export default function NotificationCard({
  notification,
  compact = false,
  onActionComplete
}: NotificationCardProps) {
  const { 
    markAsRead, 
    deleteNotification, 
    acceptMessageRequest, 
    declineMessageRequest 
  } = useNotifications();
  const { language } = useLanguage();
  const navigate = useNavigate();

  const handleCardClick = () => {
    if (!notification.read) {
      markAsRead(notification.id);
    }
    if (notification.actionUrl) {
      navigate(notification.actionUrl);
      if (onActionComplete) onActionComplete();
    }
  };

  const formatTimeAgo = (isoString: string) => {
    try {
      const date = new Date(isoString);
      const diffMs = Date.now() - date.getTime();
      const diffMins = Math.floor(diffMs / (1000 * 60));
      const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
      const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));

      if (diffMins < 1) return language === 'pa' ? 'ਹੁਣੇ' : 'Just now';
      if (diffMins < 60) return language === 'pa' ? `${diffMins} ਮਿੰਟ ਪਹਿਲਾਂ` : `${diffMins}m ago`;
      if (diffHours < 24) return language === 'pa' ? `${diffHours} ਘੰਟੇ ਪਹਿਲਾਂ` : `${diffHours}h ago`;
      if (diffDays === 1) return language === 'pa' ? 'ਕੱਲ੍ਹ' : 'Yesterday';
      return language === 'pa' ? `${diffDays} ਦਿਨ ਪਹਿਲਾਂ` : `${diffDays}d ago`;
    } catch {
      return '';
    }
  };

  const getCategoryConfig = () => {
    switch (notification.category) {
      case 'match':
        return {
          icon: Sparkles,
          iconBg: 'bg-amber-100 text-amber-800 border-amber-300',
          borderColor: 'border-amber-200 hover:border-amber-400',
          tagBg: 'bg-amber-50 text-rose-950 border-amber-200'
        };
      case 'message_request':
        return {
          icon: MessageSquare,
          iconBg: 'bg-rose-100 text-rose-900 border-rose-300',
          borderColor: 'border-rose-200 hover:border-rose-400',
          tagBg: 'bg-rose-50 text-rose-900 border-rose-200'
        };
      case 'activity':
      default:
        return {
          icon: Eye,
          iconBg: 'bg-emerald-100 text-emerald-800 border-emerald-300',
          borderColor: 'border-emerald-200 hover:border-emerald-400',
          tagBg: 'bg-emerald-50 text-emerald-900 border-emerald-200'
        };
    }
  };

  const config = getCategoryConfig();
  const IconComp = config.icon;

  const title = language === 'pa' && notification.titlePa ? notification.titlePa : notification.title;
  const message = language === 'pa' && notification.messagePa ? notification.messagePa : notification.message;
  const badgeText = language === 'pa' && notification.badgePa ? notification.badgePa : notification.badge;

  return (
    <div 
      className={`relative rounded-2xl border transition-all duration-200 group ${
        notification.read
          ? 'bg-white border-gray-200/90 hover:bg-gray-50/60'
          : 'bg-gradient-to-r from-amber-50/70 via-white to-rose-50/30 border-amber-300/80 shadow-xs ring-1 ring-amber-400/20'
      } ${compact ? 'p-3.5' : 'p-5'}`}
    >
      {/* Unread indicator dot */}
      {!notification.read && (
        <div className="absolute top-3.5 right-3.5 flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-amber-500 ring-4 ring-amber-200/60 animate-pulse" />
          <span className="text-[10px] font-bold text-amber-800 uppercase tracking-wider">
            {language === 'pa' ? 'ਨਵਾਂ' : 'New'}
          </span>
        </div>
      )}

      <div className="flex items-start gap-3.5">
        {/* Avatar or Icon */}
        <div className="relative shrink-0 cursor-pointer" onClick={handleCardClick}>
          {notification.avatarUrl ? (
            <img 
              src={notification.avatarUrl} 
              alt={notification.senderName || 'Notification'} 
              className="w-12 h-12 rounded-2xl object-cover border border-amber-300 shadow-2xs group-hover:scale-105 transition-transform"
            />
          ) : (
            <div className={`w-12 h-12 rounded-2xl flex items-center justify-center border shadow-2xs ${config.iconBg}`}>
              <IconComp className="w-6 h-6" />
            </div>
          )}
          
          <div className={`absolute -bottom-1 -right-1 w-5 h-5 rounded-full flex items-center justify-center border-2 border-white shadow-2xs ${config.iconBg}`}>
            <IconComp className="w-3 h-3" />
          </div>
        </div>

        {/* Text Content */}
        <div className="flex-1 min-w-0 pr-6">
          <div className="flex flex-wrap items-center gap-2 mb-1">
            {badgeText && (
              <span className={`inline-flex items-center gap-1 text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${config.tagBg}`}>
                {badgeText}
              </span>
            )}
            
            {notification.senderGotra && (
              <span className="text-[11px] font-bold text-rose-950 bg-rose-50 px-2 py-0.5 rounded-md border border-rose-200">
                ਗੋਤਰ: {notification.senderGotra}
              </span>
            )}

            <span className="text-[11px] text-gray-400 font-medium">
              {formatTimeAgo(notification.timestamp)}
            </span>
          </div>

          <h4 
            onClick={handleCardClick}
            className="text-xs sm:text-sm font-bold text-gray-900 font-serif leading-snug cursor-pointer group-hover:text-rose-950 transition-colors"
          >
            {title}
          </h4>

          <p className="text-xs text-gray-600 mt-1 leading-relaxed">
            {message}
          </p>

          {/* Special Action Row for Message Requests */}
          {notification.category === 'message_request' && notification.status === 'pending' && (
            <div className="mt-3 pt-2.5 border-t border-rose-100 flex flex-wrap items-center gap-2">
              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  acceptMessageRequest(notification.id);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gradient-to-r from-emerald-600 to-emerald-700 hover:from-emerald-500 hover:to-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs transition-all active:scale-95"
              >
                <Check className="w-3.5 h-3.5" />
                {language === 'pa' ? 'ਸਵੀਕਾਰ ਕਰੋ (Accept)' : 'Accept Request'}
              </button>

              <button
                type="button"
                onClick={(e) => {
                  e.stopPropagation();
                  declineMessageRequest(notification.id);
                }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-gray-100 hover:bg-gray-200 text-gray-700 rounded-xl text-xs font-semibold transition-all"
              >
                <X className="w-3.5 h-3.5" />
                {language === 'pa' ? 'ਰੱਦ ਕਰੋ (Decline)' : 'Decline'}
              </button>

              {notification.actionUrl && (
                <button
                  type="button"
                  onClick={handleCardClick}
                  className="text-xs font-bold text-rose-900 hover:text-rose-700 underline ml-auto"
                >
                  {language === 'pa' ? 'ਪ੍ਰੋਫਾਈਲ ਦੇਖੋ' : 'View Profile'}
                </button>
              )}
            </div>
          )}

          {/* Quick Action Button for Matches & Activities */}
          {(notification.category === 'match' || (notification.category === 'activity' && notification.actionUrl)) && (
            <div className="mt-2.5 flex items-center justify-between">
              <button
                type="button"
                onClick={handleCardClick}
                className="inline-flex items-center gap-1 text-xs font-bold text-rose-900 hover:text-rose-700 group-hover:translate-x-0.5 transition-transform"
              >
                <span>{notification.category === 'match' ? (language === 'pa' ? 'ਮੈਚ ਵੇਖੋ (View Match)' : 'View Match Compatibility') : (language === 'pa' ? 'ਵੇਰਵਾ ਦੇਖੋ (View)' : 'View Details')}</span>
                <ArrowRight className="w-3.5 h-3.5 text-amber-600" />
              </button>

              {/* Status accepted tag if message accepted */}
              {notification.status === 'accepted' && (
                <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-200 flex items-center gap-1">
                  <UserCheck className="w-3 h-3" />
                  {language === 'pa' ? 'ਸਵੀਕਾਰ ਕੀਤੀ' : 'Accepted'}
                </span>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Action icons on top right on hover */}
      <div className="absolute top-3 right-3 opacity-0 group-hover:opacity-100 transition-opacity flex items-center gap-1 bg-white/90 backdrop-blur-xs p-1 rounded-xl shadow-xs border border-gray-200">
        {!notification.read && (
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation();
              markAsRead(notification.id);
            }}
            className="p-1 text-gray-500 hover:text-emerald-700 hover:bg-emerald-50 rounded-lg transition-colors"
            title={language === 'pa' ? 'ਪੜ੍ਹਿਆ ਮਾਰਕ ਕਰੋ' : 'Mark as read'}
          >
            <CheckCircle2 className="w-4 h-4" />
          </button>
        )}
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            deleteNotification(notification.id);
          }}
          className="p-1 text-gray-400 hover:text-rose-700 hover:bg-rose-50 rounded-lg transition-colors"
          title={language === 'pa' ? 'ਹਟਾਓ' : 'Delete'}
        >
          <Trash2 className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}
