import { useState } from 'react';
import { Bell } from 'lucide-react';
import { useNotifications } from '../../contexts/NotificationContext';
import NotificationDropdown from './NotificationDropdown';

interface NotificationBellProps {
  variant?: 'navbar' | 'mobile';
}

export default function NotificationBell({ variant = 'navbar' }: NotificationBellProps) {
  const { unreadCount } = useNotifications();
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className="relative inline-block text-left">
      <button
        type="button"
        onClick={() => setIsOpen(prev => !prev)}
        className={`relative p-2 rounded-xl transition-all duration-200 ${
          isOpen
            ? 'bg-amber-100 text-rose-950 shadow-inner'
            : 'text-gray-700 hover:text-rose-950 hover:bg-amber-50/80'
        }`}
        aria-label="Notifications"
        aria-expanded={isOpen}
      >
        <Bell className={`w-5 h-5 transition-transform ${unreadCount > 0 ? 'text-rose-950 group-hover:rotate-12' : 'text-gray-600'}`} />

        {/* Unread Counter Badge */}
        {unreadCount > 0 && (
          <span className="absolute -top-1 -right-1 flex h-5 min-w-[20px] items-center justify-center px-1 rounded-full bg-gradient-to-r from-amber-500 to-rose-600 text-[10px] font-extrabold text-white shadow-md border-2 border-white animate-pulse">
            {unreadCount > 9 ? '9+' : unreadCount}
          </span>
        )}
      </button>

      {/* Dropdown Menu */}
      {isOpen && (
        <NotificationDropdown onClose={() => setIsOpen(false)} />
      )}
    </div>
  );
}
