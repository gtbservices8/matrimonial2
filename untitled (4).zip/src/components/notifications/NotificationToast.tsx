import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Heart, MessageSquare, Bell, Sparkles, CheckCircle2, 
  X, Eye, ArrowRight, UserCircle 
} from 'lucide-react';
import { useNotifications } from '../../contexts/NotificationContext';
import { useLanguage } from '../../contexts/LanguageContext';

export default function NotificationToast() {
  const { activeToast, dismissToast, markAsRead } = useNotifications();
  const { language } = useLanguage();
  const navigate = useNavigate();

  useEffect(() => {
    if (!activeToast) return;

    // Auto dismiss after 6.5 seconds
    const timer = setTimeout(() => {
      dismissToast();
    }, 6500);

    return () => clearTimeout(timer);
  }, [activeToast, dismissToast]);

  if (!activeToast) return null;

  const handleClickToast = () => {
    markAsRead(activeToast.id);
    if (activeToast.actionUrl) {
      navigate(activeToast.actionUrl);
    } else {
      navigate('/notifications');
    }
    dismissToast();
  };

  const getCategoryTheme = () => {
    switch (activeToast.category) {
      case 'match':
        return {
          icon: Sparkles,
          bg: 'from-amber-500 to-rose-600',
          badgeBg: 'bg-amber-100 text-rose-950 border-amber-300',
          accentBorder: 'border-amber-400',
          indicator: 'bg-amber-500'
        };
      case 'message_request':
        return {
          icon: MessageSquare,
          bg: 'from-rose-600 to-rose-900',
          badgeBg: 'bg-rose-100 text-rose-900 border-rose-300',
          accentBorder: 'border-rose-400',
          indicator: 'bg-rose-600'
        };
      case 'activity':
      default:
        return {
          icon: Eye,
          bg: 'from-emerald-600 to-teal-800',
          badgeBg: 'bg-emerald-100 text-emerald-900 border-emerald-300',
          accentBorder: 'border-emerald-400',
          indicator: 'bg-emerald-500'
        };
    }
  };

  const theme = getCategoryTheme();
  const IconComponent = theme.icon;

  const title = language === 'pa' && activeToast.titlePa ? activeToast.titlePa : activeToast.title;
  const message = language === 'pa' && activeToast.messagePa ? activeToast.messagePa : activeToast.message;
  const badgeText = language === 'pa' && activeToast.badgePa ? activeToast.badgePa : activeToast.badge;

  return (
    <div className="fixed bottom-5 right-5 z-50 max-w-sm sm:max-w-md w-full animate-in slide-in-from-bottom-5 fade-in duration-300 px-4 sm:px-0">
      <div 
        onClick={handleClickToast}
        className="bg-white rounded-2xl shadow-2xl border-2 border-amber-300/80 p-4 cursor-pointer hover:shadow-amber-500/20 hover:scale-[1.01] transition-all relative overflow-hidden group"
      >
        {/* Top colored accent line */}
        <div className={`absolute top-0 left-0 right-0 h-1.5 bg-gradient-to-r ${theme.bg}`} />

        <div className="flex items-start gap-3.5 pt-1">
          {/* Avatar or Category Icon */}
          <div className="relative shrink-0">
            {activeToast.avatarUrl ? (
              <img 
                src={activeToast.avatarUrl} 
                alt="Notification Avatar" 
                className="w-12 h-12 rounded-xl object-cover border border-amber-300 shadow-xs"
              />
            ) : (
              <div className={`w-12 h-12 rounded-xl bg-gradient-to-br ${theme.bg} flex items-center justify-center text-white shadow-xs`}>
                <IconComponent className="w-6 h-6" />
              </div>
            )}
            <div className={`absolute -bottom-1 -right-1 w-4 h-4 rounded-full ${theme.indicator} border-2 border-white`} />
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0 pr-6">
            <div className="flex items-center gap-2 mb-1">
              <span className={`text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full border ${theme.badgeBg}`}>
                {badgeText || (activeToast.category === 'match' ? 'Match Alert' : activeToast.category === 'message_request' ? 'Request' : 'Activity')}
              </span>
              <span className="text-[10px] text-gray-400 font-medium">Just now</span>
            </div>

            <h4 className="text-xs sm:text-sm font-bold text-gray-900 leading-snug line-clamp-1 group-hover:text-rose-900 transition-colors font-serif">
              {title}
            </h4>

            <p className="text-xs text-gray-600 mt-0.5 line-clamp-2 leading-relaxed">
              {message}
            </p>

            <div className="mt-2 flex items-center gap-1 text-[11px] font-bold text-amber-700 group-hover:text-amber-800">
              <span>{language === 'pa' ? 'ਹੁਣੇ ਵੇਖੋ (View Details)' : 'View Details'}</span>
              <ArrowRight className="w-3 h-3 group-hover:translate-x-1 transition-transform" />
            </div>
          </div>
        </div>

        {/* Close Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            dismissToast();
          }}
          className="absolute top-3 right-3 p-1 text-gray-400 hover:text-gray-700 hover:bg-gray-100 rounded-full transition-colors"
          title="Dismiss"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Auto dismiss progress animation bar */}
        <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-gray-100 overflow-hidden">
          <div className={`h-full bg-gradient-to-r ${theme.bg} animate-[shrink_6.5s_linear_forwards]`} style={{
            animation: 'shrink 6.5s linear forwards'
          }} />
        </div>
      </div>
    </div>
  );
}
