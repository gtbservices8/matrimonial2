import { useState, useRef, useEffect } from 'react';
import { Globe, ChevronDown, Check } from 'lucide-react';
import { useLanguage, SupportedLanguage } from '../../contexts/LanguageContext';

interface LanguageSelectorProps {
  variant?: 'navbar' | 'mobile' | 'footer';
}

export default function LanguageSelector({ variant = 'navbar' }: LanguageSelectorProps) {
  const { language, setLanguage, languages, currentLanguageOption } = useLanguage();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Close dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelect = (code: SupportedLanguage) => {
    setLanguage(code);
    setIsOpen(false);
  };

  if (variant === 'mobile') {
    return (
      <div className="py-2 border-t border-gray-100 my-2">
        <div className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-2 px-3 flex items-center gap-1.5">
          <Globe className="w-3.5 h-3.5 text-rose-900" />
          <span>ਭਾਸ਼ਾ ਚੁਣੋ / Select Language</span>
        </div>
        <div className="grid grid-cols-3 gap-1.5 px-2">
          {languages.map((lang) => (
            <button
              key={lang.code}
              type="button"
              onClick={() => handleSelect(lang.code)}
              className={`flex items-center justify-center gap-1.5 py-2 px-2 rounded-lg text-xs font-bold transition-all ${
                language === lang.code
                  ? 'bg-rose-900 text-amber-300 border border-amber-500/30 shadow-xs'
                  : 'bg-gray-100 text-gray-700 hover:bg-rose-50 hover:text-rose-900'
              }`}
            >
              <span>{lang.nativeName}</span>
              {language === lang.code && <Check className="w-3 h-3 text-amber-400" />}
            </button>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="relative inline-block text-left" ref={dropdownRef}>
      <button
        type="button"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-1.5 rounded-full border border-amber-500/40 bg-rose-50/70 hover:bg-rose-100/70 text-rose-950 text-xs font-bold transition-all shadow-xs hover:border-amber-500"
        aria-expanded={isOpen}
        aria-label="Language Selector"
      >
        <Globe className="w-4 h-4 text-rose-900" />
        <span className="font-semibold">{currentLanguageOption.nativeName}</span>
        <ChevronDown className={`w-3.5 h-3.5 text-rose-900 transition-transform duration-200 ${isOpen ? 'rotate-180' : ''}`} />
      </button>

      {isOpen && (
        <div className="origin-top-right absolute right-0 mt-2 w-48 rounded-2xl shadow-xl bg-white ring-1 ring-black/5 border border-amber-200/80 divide-y divide-gray-100 focus:outline-none z-50 animate-in fade-in zoom-in-95 duration-150 overflow-hidden">
          <div className="px-3.5 py-2 bg-gradient-to-r from-rose-950 to-rose-900 text-white">
            <span className="text-[11px] font-bold text-amber-300 tracking-wider uppercase flex items-center gap-1.5">
              <Globe className="w-3 h-3" /> Select Language
            </span>
          </div>

          <div className="p-1.5 space-y-1">
            {languages.map((lang) => {
              const isActive = language === lang.code;
              return (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => handleSelect(lang.code)}
                  className={`w-full flex items-center justify-between px-3 py-2 text-xs rounded-xl font-medium transition-all ${
                    isActive
                      ? 'bg-rose-900 text-amber-300 font-bold shadow-xs'
                      : 'text-gray-700 hover:bg-rose-50 hover:text-rose-900'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-sm">{lang.flag}</span>
                    <span className="text-xs font-bold">{lang.nativeName}</span>
                    <span className={`text-[11px] ${isActive ? 'text-amber-200/90' : 'text-gray-400'}`}>
                      ({lang.name})
                    </span>
                  </div>
                  {isActive && <Check className="w-3.5 h-3.5 text-amber-400 font-bold" />}
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
