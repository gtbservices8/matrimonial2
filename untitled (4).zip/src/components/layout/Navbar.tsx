import { Link, useLocation, useNavigate } from 'react-router-dom';
import { Heart, Menu, User, LogOut, ShieldCheck, Sparkles, Bell } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import LanguageSelector from './LanguageSelector';
import AppLogo from '../common/AppLogo';
import NotificationBell from '../notifications/NotificationBell';
import { useState } from 'react';

interface NavbarProps {
  onOpenAdminModal: () => void;
}

export default function Navbar({ onOpenAdminModal }: NavbarProps) {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const location = useLocation();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const isAdmin = user?.email === 'gtbservices8@gmail.com';
  const isAdminAuth = sessionStorage.getItem('mahasha_admin_auth') === 'true';

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="bg-white/95 backdrop-blur-md shadow-xs border-b border-amber-100 sticky top-0 z-50 transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20 items-center">
          
          {/* Logo */}
          <div className="flex items-center">
            <AppLogo size="md" variant="full" />
          </div>

          {/* Desktop Menu with Smooth Hover Effects */}
          <div className="hidden md:flex items-center space-x-2 lg:space-x-4">
            
            {/* Nav Links with Hover Underline & Glow */}
            <Link 
              to="/" 
              className={`whitespace-nowrap relative px-3.5 py-2 rounded-xl text-sm font-bold transition-all duration-200 group flex items-center gap-1.5 ${
                isActive('/') 
                  ? 'text-rose-950 bg-amber-50/90 shadow-2xs border border-amber-200/60' 
                  : 'text-gray-700 hover:text-rose-950 hover:bg-amber-50/50'
              }`}
            >
              <span>{t.navHome}</span>
              <span className={`absolute bottom-0 left-3 right-3 h-0.5 bg-gradient-to-r from-amber-500 to-rose-600 rounded-full transition-all duration-300 transform origin-left ${
                isActive('/') ? 'scale-x-100 opacity-100' : 'scale-x-0 opacity-0 group-hover:scale-x-100 group-hover:opacity-100'
              }`} />
            </Link>

            <Link 
              to="/matches" 
              className={`whitespace-nowrap relative px-3.5 py-2 rounded-xl text-sm font-bold transition-all duration-200 group flex items-center gap-1.5 ${
                isActive('/matches') 
                  ? 'text-rose-950 bg-amber-50/90 shadow-2xs border border-amber-200/60' 
                  : 'text-gray-700 hover:text-rose-950 hover:bg-amber-50/50'
              }`}
            >
              <span>{t.navMatches}</span>
              <span className={`absolute bottom-0 left-3 right-3 h-0.5 bg-gradient-to-r from-amber-500 to-rose-600 rounded-full transition-all duration-300 transform origin-left ${
                isActive('/matches') ? 'scale-x-100 opacity-100' : 'scale-x-0 opacity-0 group-hover:scale-x-100 group-hover:opacity-100'
              }`} />
            </Link>

            <Link 
              to="/stories" 
              className={`whitespace-nowrap relative px-3.5 py-2 rounded-xl text-sm font-bold transition-all duration-200 group ${
                isActive('/stories') ? 'text-rose-950 bg-amber-50' : 'text-gray-700 hover:text-rose-950 hover:bg-amber-50/50'
              }`}
            >
              <span>{t.navStories}</span>
              <span className={`absolute bottom-0 left-3 right-3 h-0.5 bg-gradient-to-r from-amber-500 to-rose-600 rounded-full transition-all duration-300 transform origin-left ${
                isActive('/stories') ? 'scale-x-100 opacity-100' : 'scale-x-0 opacity-0 group-hover:scale-x-100 group-hover:opacity-100'
              }`} />
            </Link>

            <Link 
              to="/contact" 
              className={`whitespace-nowrap relative px-3.5 py-2 rounded-xl text-sm font-bold transition-all duration-200 group ${
                isActive('/contact') ? 'text-rose-950 bg-amber-50' : 'text-gray-700 hover:text-rose-950 hover:bg-amber-50/50'
              }`}
            >
              <span>{t.navContact}</span>
              <span className={`absolute bottom-0 left-3 right-3 h-0.5 bg-gradient-to-r from-amber-500 to-rose-600 rounded-full transition-all duration-300 transform origin-left ${
                isActive('/contact') ? 'scale-x-100 opacity-100' : 'scale-x-0 opacity-0 group-hover:scale-x-100 group-hover:opacity-100'
              }`} />
            </Link>

            {/* Admin Panel Link */}
            <button
              type="button"
              onClick={() => onOpenAdminModal()}
              className={`whitespace-nowrap relative px-3 py-2 rounded-xl text-xs font-bold transition-all duration-200 group flex items-center gap-1.5 ${
                isActive('/admin')
                  ? 'text-amber-900 bg-amber-100/90 border border-amber-300 shadow-2xs'
                  : 'text-amber-800 bg-amber-50 hover:bg-amber-100/80 border border-amber-200/80 hover:border-amber-300 hover:shadow-xs'
              }`}
              title={t.navAdmin}
            >
              <ShieldCheck className="w-3.5 h-3.5 text-amber-700" />
              <span>{t.navAdmin}</span>
            </button>
            
            {/* Language Selector Button */}
            <LanguageSelector variant="navbar" />

            {/* In-App Notification Bell */}
            <NotificationBell variant="navbar" />

            {user ? (
              <div className="flex items-center gap-3 ml-2 pl-4 border-l border-amber-200/60">
                <Link 
                  to="/dashboard" 
                  className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-bold transition-all duration-200 ${
                    isActive('/dashboard')
                      ? 'bg-rose-900 text-white shadow-sm'
                      : 'text-rose-950 hover:bg-rose-50 border border-rose-900/20'
                  }`}
                >
                  <User className="h-4 w-4 text-amber-500" />
                  {t.navDashboard}
                </Link>
                <button 
                  onClick={handleLogout}
                  className="p-2 text-gray-500 hover:text-rose-700 hover:bg-rose-50 rounded-xl transition-all"
                  title={t.navLogout}
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-3 ml-2 pl-4 border-l border-amber-200/60">
                <Link 
                  to="/login" 
                  className="text-rose-950 font-bold hover:text-rose-800 hover:bg-rose-50 px-4 py-2 rounded-xl transition-all duration-200 text-sm"
                >
                  {t.navLogin}
                </Link>
                <Link 
                  to="/register" 
                  className="bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-rose-950 px-5 py-2 rounded-full font-bold transition-all duration-200 shadow-sm shadow-amber-500/25 hover:shadow-md hover:scale-[1.03] text-sm active:scale-95"
                >
                  {t.navRegister}
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu, notifications and language button */}
          <div className="flex items-center gap-1.5 md:hidden">
            <LanguageSelector variant="navbar" />
            <NotificationBell variant="mobile" />
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-700 hover:text-rose-900 p-2 rounded-xl hover:bg-amber-50 transition-colors"
              aria-label="Toggle menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white/98 border-t border-amber-100 px-4 pt-3 pb-5 space-y-2 shadow-xl animate-in fade-in slide-in-from-top-3 duration-200">
          <Link 
            to="/" 
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 text-base font-bold text-gray-800 hover:text-rose-950 hover:bg-amber-50 rounded-xl transition-colors"
          >
            {t.navHome}
          </Link>
          <Link 
            to="/matches" 
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3.5 py-2.5 text-base font-bold text-gray-800 hover:text-rose-950 hover:bg-amber-50 rounded-xl transition-colors"
          >
            {t.navMatches}
          </Link>
          <Link 
            to="/notifications" 
            onClick={() => setIsMobileMenuOpen(false)}
            className="flex items-center justify-between px-3.5 py-2.5 text-base font-bold text-gray-800 hover:text-rose-950 hover:bg-amber-50 rounded-xl transition-colors"
          >
            <div className="flex items-center gap-2">
              <Bell className="w-5 h-5 text-amber-600" />
              <span>{t.language === 'pa' ? 'ਸੂਚਨਾਵਾਂ (Notifications)' : 'Notifications'}</span>
            </div>
            <span className="text-xs bg-amber-100 text-rose-950 font-extrabold px-2 py-0.5 rounded-full border border-amber-300">
              Live Alerts
            </span>
          </Link>
          <Link 
            to="/stories" 
            onClick={() => setIsMobileMenuOpen(false)}
            className={`block px-3.5 py-2.5 text-base font-bold rounded-xl transition-colors ${
              isActive('/stories') ? 'text-rose-950 bg-amber-50' : 'text-gray-800 hover:text-rose-950 hover:bg-amber-50'
            }`}
          >
            {t.navStories}
          </Link>

          <Link 
            to="/contact" 
            onClick={() => setIsMobileMenuOpen(false)}
            className={`block px-3.5 py-2.5 text-base font-bold rounded-xl transition-colors ${
              isActive('/contact') ? 'text-rose-950 bg-amber-50' : 'text-gray-800 hover:text-rose-950 hover:bg-amber-50'
            }`}
          >
            {t.navContact}
          </Link>

          <button 
            type="button"
            onClick={() => {
              setIsMobileMenuOpen(false);
              onOpenAdminModal();
            }}
            className="flex items-center gap-2 w-full px-3.5 py-2.5 text-base font-bold text-amber-900 bg-amber-50 rounded-xl border border-amber-200"
          >
            <ShieldCheck className="w-4 h-4 text-amber-700" />
            <span>{t.navAdmin}</span>
          </button>
          
          {/* Mobile Language Selection Buttons */}
          <div className="pt-2">
            <LanguageSelector variant="mobile" />
          </div>

          {user ? (
            <div className="pt-2 border-t border-gray-100 space-y-2">
              <Link 
                to="/dashboard" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="flex items-center gap-2 px-3.5 py-2.5 text-base font-bold text-rose-950 bg-rose-50 rounded-xl"
              >
                <User className="h-4 w-4 text-amber-600" />
                {t.navDashboard}
              </Link>
              <button 
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  handleLogout();
                }} 
                className="flex items-center gap-2 w-full text-left px-3.5 py-2.5 text-base font-bold text-rose-700 hover:bg-rose-50 rounded-xl"
              >
                <LogOut className="h-4 w-4" />
                {t.navLogout}
              </button>
            </div>
          ) : (
            <div className="mt-4 pt-4 border-t border-amber-100 flex flex-col gap-2">
              <Link 
                to="/login" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="block w-full text-center px-4 py-2.5 font-bold text-rose-950 border border-rose-900/30 hover:bg-rose-50 rounded-xl transition-colors"
              >
                {t.navLogin}
              </Link>
              <Link 
                to="/register" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="block w-full text-center px-4 py-2.5 font-bold text-rose-950 bg-amber-500 hover:bg-amber-400 rounded-xl shadow-sm transition-colors"
              >
                {t.navRegister}
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}

