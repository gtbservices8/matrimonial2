import { Mail, Phone, MapPin } from 'lucide-react';
import AppLogo from '../common/AppLogo';
import { useLanguage } from '../../contexts/LanguageContext';
import LanguageSelector from './LanguageSelector';
import { useCMSConfig } from '../../hooks/useCMSConfig';

export default function Footer() {
  const { t, language } = useLanguage();
  const { config } = useCMSConfig();

  const siteName = language === 'pa' 
    ? (config?.siteNamePa || 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ') 
    : (config?.siteNameEn || 'Mahasha Matrimonial');

  return (
    <footer className="bg-rose-950 text-rose-100 pt-16 pb-8 border-t border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand */}
          <div className="space-y-4">
            <AppLogo size="lg" variant="full" textColor="light" />
            <p className="text-rose-200/90 text-sm leading-relaxed mt-4">
              {t.footerTagline}
            </p>
            <div className="pt-2">
              <LanguageSelector variant="navbar" />
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-amber-400 font-semibold mb-4 uppercase tracking-wider text-sm">Quick Links</h3>
            <ul className="space-y-3 text-sm text-rose-200/90">
              <li><a href="/" className="hover:text-amber-400 transition-colors">About Us</a></li>
              <li><a href="/stories" className="hover:text-amber-400 transition-colors">Success Stories</a></li>
              <li><a href="/matches" className="hover:text-amber-400 transition-colors">Browse Matches</a></li>
              <li><a href="/register" className="hover:text-amber-400 transition-colors">Free Registration</a></li>
              <li><a href="/contact" className="hover:text-amber-400 transition-colors">Contact Us</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-amber-400 font-semibold mb-4 uppercase tracking-wider text-sm">Legal & Privacy</h3>
            <ul className="space-y-3 text-sm text-rose-200/90">
              <li><a href="#" className="hover:text-amber-400 transition-colors">Privacy Policy</a></li>
              <li><a href="/terms" className="hover:text-amber-400 transition-colors">Terms & Conditions</a></li>
              <li><a href="/cookie-policy" className="hover:text-amber-400 transition-colors">Cookie Policy</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-amber-400 font-semibold mb-4 uppercase tracking-wider text-sm">Contact Support</h3>
            <ul className="space-y-3 text-sm text-rose-200/90">
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-amber-400" />
                {config?.supportEmail || 'support@mahashasangam.com'}
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-amber-400" />
                {config?.supportPhone || '+91 98765-43210'}
              </li>
              <li className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-amber-400" />
                {language === 'pa' ? (config?.addressPa || 'ਪੰਜਾਬ, ਭਾਰਤ') : (config?.addressEn || 'Punjab, India')}
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-rose-900/80 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-rose-300">
          <p>© {new Date().getFullYear()} {siteName}. All rights reserved.</p>
          <div className="flex gap-4">
            {config?.facebookUrl && <a href={config.facebookUrl} target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition-colors">Facebook</a>}
            {config?.instagramUrl && <a href={config.instagramUrl} target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition-colors">Instagram</a>}
            {config?.youtubeUrl && <a href={config.youtubeUrl} target="_blank" rel="noopener noreferrer" className="hover:text-amber-400 transition-colors">YouTube</a>}
          </div>
        </div>
      </div>
    </footer>
  );
}
