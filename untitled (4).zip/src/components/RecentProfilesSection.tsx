import { useState } from 'react';
import { Link } from 'react-router-dom';
import { Lock, Eye, CheckCircle2, MapPin, Briefcase, Users, GraduationCap, Sparkles, ArrowRight, ShieldCheck } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

export interface ShowcaseProfile {
  id: string;
  name: string;
  age: number;
  height: string;
  gender: 'Female' | 'Male';
  community: string;
  religion: string;
  profession: string;
  education: string;
  location: string;
  photoUrl: string;
  verified: boolean;
  memberId: string;
}

const RECENT_PROFILES: ShowcaseProfile[] = [
  {
    id: 'rec-advocate',
    name: 'Advocate Navpreet Kaur Bajgal',
    age: 26,
    height: '5\' 4"',
    gender: 'Female',
    community: 'Mahasha (Bajgal / Bhogal)',
    religion: 'Hindu',
    profession: 'Advocate (PCS-J Prep)',
    education: 'LLM (Criminology) & BA.LLB',
    location: 'Gurdaspur, Punjab',
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-98765'
  },
  {
    id: 'rec-1',
    name: 'Simranjit Kaur Kaler',
    age: 26,
    height: '5\' 4"',
    gender: 'Female',
    community: 'Mahasha (Kaler)',
    religion: 'Sikh',
    profession: 'Software Engineer',
    education: 'B.Tech (CSE)',
    location: 'Chandigarh / Mohali',
    photoUrl: 'https://images.unsplash.com/photo-1595922247653-9a3b68832a81?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-84920'
  },
  {
    id: 'rec-2',
    name: 'Gurinder Singh Badhan',
    age: 28,
    height: '5\' 11"',
    gender: 'Male',
    community: 'Mahasha (Badhan)',
    religion: 'Sikh',
    profession: 'Senior Data Scientist',
    education: 'M.S. in Computer Science',
    location: 'Amritsar ↔ Toronto, Canada',
    photoUrl: 'https://images.unsplash.com/photo-1610173827002-62c0f1f1d1eb?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-39201'
  },
  {
    id: 'rec-3',
    name: 'Dr. Tanvi Kundal',
    age: 27,
    height: '5\' 5"',
    gender: 'Female',
    community: 'Mahasha (Kundal)',
    religion: 'Hindu',
    profession: 'Dental Surgeon (MDS)',
    education: 'MDS Orthodontics',
    location: 'Jammu / Pathankot',
    photoUrl: 'https://images.unsplash.com/photo-1583939000140-5a507851a70c?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-71044'
  },
  {
    id: 'rec-4',
    name: 'Harmanpreet Singh Banga',
    age: 29,
    height: '5\' 10"',
    gender: 'Male',
    community: 'Mahasha (Banga)',
    religion: 'Sikh',
    profession: 'Assistant Executive Engineer',
    education: 'B.E. Civil & MBA',
    location: 'Jalandhar, Punjab',
    photoUrl: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-45210'
  },
  {
    id: 'rec-5',
    name: 'Navneet Kaur Ghotra',
    age: 25,
    height: '5\' 3"',
    gender: 'Female',
    community: 'Mahasha (Ghotra)',
    religion: 'Sikh',
    profession: 'Chartered Accountant (CA)',
    education: 'FCA & B.Com (Hons)',
    location: 'Hoshiarpur, Punjab',
    photoUrl: 'https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-62915'
  },
  {
    id: 'rec-6',
    name: 'Rohan Karloopia',
    age: 30,
    height: '6\' 0"',
    gender: 'Male',
    community: 'Mahasha (Karloopia)',
    religion: 'Hindu',
    profession: 'Product Manager (Fintech)',
    education: 'MBA & B.Tech',
    location: 'Jammu / Bangalore',
    photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-58133'
  },
  {
    id: 'rec-7',
    name: 'Jasleen Kaur Hans',
    age: 26,
    height: '5\' 6"',
    gender: 'Female',
    community: 'Mahasha (Hans)',
    religion: 'Sikh',
    profession: 'Corporate HR Specialist',
    education: 'MBA HR',
    location: 'Ludhiana, Punjab',
    photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-93218'
  },
  {
    id: 'rec-8',
    name: 'Dr. Amaninder Singh Taak',
    age: 31,
    height: '5\' 11"',
    gender: 'Male',
    community: 'Mahasha (Taak)',
    religion: 'Sikh',
    profession: 'Physician (MD Internal Med)',
    education: 'MBBS, MD',
    location: 'Gurdaspur ↔ London, UK',
    photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?q=80&w=600&auto=format&fit=crop',
    verified: true,
    memberId: 'MHS-81729'
  }
];

export default function RecentProfilesSection() {
  const { language } = useLanguage();
  const [activeTab, setActiveTab] = useState<'all' | 'Female' | 'Male'>('all');

  const translations = {
    pa: {
      badge: 'ਵਿਸ਼ੇਸ਼ ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ ਪ੍ਰੋਫਾਈਲ',
      title: 'ਤਾਜ਼ਾ ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ - ਲਾੜੀਆਂ ਅਤੇ ਲਾੜੇ',
      titleHighlight: 'Recent Mahasha Matches',
      subtitle: 'ਸਾਡੇ ਮਹਾਸ਼ਾ ਸਮਾਜ ਦੇ ਨਵੇਂ ਰਜਿਸਟਰ ਹੋਏ ਸੱਚੇ ਰਿਸ਼ਤੇ। ਪਰਿਵਾਰਕ ਪ੍ਰਾਈਵੇਸੀ ਕਾਰਨ ਸਾਰੀਆਂ ਫੋਟੋਆਂ ਸੁਰੱਖਿਅਤ (ਬਲਰ) ਰੱਖੀਆਂ ਗਈਆਂ ਹਨ।',
      allTab: 'ਸਭ ਮਹਾਸ਼ਾ ਪ੍ਰੋਫਾਈਲ (All)',
      bridesTab: 'ਮਹਾਸ਼ਾ ਲਾੜੀਆਂ (Brides)',
      groomsTab: 'ਮਹਾਸ਼ਾ ਲਾੜੇ (Grooms)',
      photoProtectedBadge: 'ਫੋਟੋ ਸੁਰੱਖਿਅਤ (Privacy Blurred)',
      photoProtectedDesc: 'ਪੂਰੀ ਫੋਟੋ ਦੇਖਣ ਲਈ ਲੌਗਇਨ / ਰਜਿਸਟਰ ਕਰੋ',
      viewProfileBtn: 'ਪ੍ਰੋਫਾਈਲ ਦੇਖੋ',
      connectBtn: 'ਗੱਲਬਾਤ ਕਰੋ',
      viewAllMatchesBtn: 'ਹੋਰ ਸਾਰੇ ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਦੇਖੋ',
      securityBannerTitle: 'ਮਹਾਸ਼ਾ ਪਰਿਵਾਰਕ ਮਰਿਆਦਾ ਅਤੇ ਪ੍ਰਾਈਵੇਸੀ ਸਾਡੀ ਪਹਿਲ ਹੈ',
      securityBannerDesc: 'ਫੋਟੋਆਂ ਸਿਰਫ ਪ੍ਰਮਾਣਿਤ ਮੈਂਬਰਾਂ ਦੀ ਆਪਸੀ ਸਹਿਮਤੀ ਅਤੇ ਬੇਨਤੀ ਸਵੀਕਾਰ ਹੋਣ ਤੇ ਹੀ ਸਪੱਸ਼ਟ ਦਿਖਾਈ ਦਿੰਦੀਆਂ ਹਨ।'
    },
    hi: {
      badge: 'विशेष महाशा समुदाय प्रोफाइल',
      title: 'नवीनतम महाशा रिश्ते - दूल्हा एवं दुल्हन',
      titleHighlight: 'Recent Mahasha Matches',
      subtitle: 'महाशा बिरादरी के हाल ही में जुड़े सत्यापित रिश्ते। पारिवारिक गोपनीयता (Privacy) के कारण फोटो ब्लर रखी गई हैं।',
      allTab: 'सभी महाशा प्रोफाइल (All)',
      bridesTab: 'महाशा दुल्हनें (Brides)',
      groomsTab: 'महाशा दूल्हे (Grooms)',
      photoProtectedBadge: 'फोटो सुरक्षित (Privacy Blurred)',
      photoProtectedDesc: 'पूरी फोटो देखने हेतु लॉगिन करें',
      viewProfileBtn: 'प्रोफाइल देखें',
      connectBtn: 'संपर्क करें',
      viewAllMatchesBtn: 'अन्य सभी महाशा रिश्ते देखें',
      securityBannerTitle: 'महाशा पारिवारिक मर्यादा और गोपनीयता हमारी प्राथमिकता',
      securityBannerDesc: 'तस्वीरें केवल सत्यापित सदस्यों के अनुरोध स्वीकार होने पर ही स्पष्ट दिखाई देती हैं।'
    },
    en: {
      badge: 'Exclusive Mahasha Community Profiles',
      title: 'Recent Mahasha Profiles - Brides & Grooms',
      titleHighlight: 'Recent Mahasha Matches',
      subtitle: 'Recently registered genuine profiles from Mahasha Samaj. Photos are intentionally blurred for member privacy & safety.',
      allTab: 'All Mahasha Profiles',
      bridesTab: 'Mahasha Brides',
      groomsTab: 'Mahasha Grooms',
      photoProtectedBadge: 'Photo Blurred for Privacy',
      photoProtectedDesc: 'Login or Register to View Full Photos',
      viewProfileBtn: 'View Profile',
      connectBtn: 'Connect Now',
      viewAllMatchesBtn: 'Browse All Mahasha Matches',
      securityBannerTitle: 'Mahasha Family Privacy & Dignity First',
      securityBannerDesc: 'Photos remain protected until interest is mutually accepted by both families.'
    }
  };

  const t = translations[language] || translations.pa;

  const filteredProfiles = activeTab === 'all' 
    ? RECENT_PROFILES 
    : RECENT_PROFILES.filter(p => p.gender === activeTab);

  return (
    <section className="pt-16 pb-20 bg-neutral-50/90 relative overflow-hidden border-b border-amber-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-200/90 px-3.5 py-1.5 rounded-full text-xs font-bold text-rose-900 mb-3 shadow-xs">
              <ShieldCheck className="w-3.5 h-3.5 text-rose-900" />
              <span>{t.badge}</span>
            </div>
            <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 font-serif tracking-tight">
              {t.title}
            </h2>
            <p className="text-gray-600 mt-2 max-w-2xl text-sm sm:text-base leading-relaxed">
              {t.subtitle}
            </p>
          </div>

          {/* Gender Filter Tabs */}
          <div className="flex items-center bg-white p-1.5 rounded-2xl border border-gray-200 shadow-xs self-start md:self-auto">
            <button
              onClick={() => setActiveTab('all')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === 'all'
                  ? 'bg-rose-900 text-amber-300 shadow-xs'
                  : 'text-gray-600 hover:text-rose-900 hover:bg-rose-50'
              }`}
            >
              {t.allTab}
            </button>
            <button
              onClick={() => setActiveTab('Female')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === 'Female'
                  ? 'bg-rose-900 text-amber-300 shadow-xs'
                  : 'text-gray-600 hover:text-rose-900 hover:bg-rose-50'
              }`}
            >
              {t.bridesTab}
            </button>
            <button
              onClick={() => setActiveTab('Male')}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold transition-all ${
                activeTab === 'Male'
                  ? 'bg-rose-900 text-amber-300 shadow-xs'
                  : 'text-gray-600 hover:text-rose-900 hover:bg-rose-50'
              }`}
            >
              {t.groomsTab}
            </button>
          </div>
        </div>

        {/* Profiles Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {filteredProfiles.map((profile) => (
            <div
              key={profile.id}
              className="bg-white rounded-2xl border border-amber-100/90 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group hover:-translate-y-1"
            >
              {/* Photo Area with Intentional Blur for Privacy */}
              <div className="relative h-64 w-full overflow-hidden bg-rose-950 select-none">
                {/* Image with Gaussian Blur applied */}
                <img
                  src={profile.photoUrl}
                  alt={profile.name}
                  className="w-full h-full object-cover filter blur-md scale-110 brightness-90 group-hover:scale-115 transition-all duration-500"
                />

                {/* Subtle vignette gradient */}
                <div className="absolute inset-0 bg-gradient-to-t from-rose-950/90 via-rose-950/30 to-rose-950/20" />

                {/* Top Badges: Gender & Verified */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
                  <span className={`text-[11px] font-bold px-2.5 py-1 rounded-full shadow-xs ${
                    profile.gender === 'Female'
                      ? 'bg-rose-100 text-rose-900 border border-rose-300'
                      : 'bg-amber-100 text-amber-900 border border-amber-300'
                  }`}>
                    {profile.gender === 'Female' ? 'Bride • ਲਾੜੀ' : 'Groom • ਲਾੜਾ'}
                  </span>

                  {profile.verified && (
                    <span className="bg-white/95 backdrop-blur-xs text-emerald-700 text-[11px] font-bold px-2.5 py-1 rounded-full flex items-center gap-1 shadow-xs">
                      <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" /> Verified
                    </span>
                  )}
                </div>

                {/* Center Privacy Lock Overlay */}
                <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-4 z-10 pointer-events-none">
                  <div className="w-12 h-12 rounded-full bg-black/40 backdrop-blur-md border border-white/30 flex items-center justify-center text-amber-300 mb-2 shadow-lg group-hover:scale-105 transition-transform">
                    <Lock className="w-5 h-5" />
                  </div>
                  <span className="bg-rose-950/90 backdrop-blur-md text-amber-300 text-[11px] font-bold px-3 py-1 rounded-full border border-amber-400/40 shadow-xs">
                    {t.photoProtectedBadge}
                  </span>
                </div>

                {/* Bottom ID on photo */}
                <div className="absolute bottom-2 left-3 right-3 flex items-center justify-between text-[11px] text-rose-200/90 z-10">
                  <span className="font-mono text-[10px] bg-black/30 px-2 py-0.5 rounded">
                    ID: {profile.memberId}
                  </span>
                  <span className="flex items-center gap-1 text-amber-300 font-medium">
                    <Eye className="w-3 h-3" /> Protected
                  </span>
                </div>
              </div>

              {/* Profile Details */}
              <div className="p-5 flex-1 flex flex-col justify-between">
                <div>
                  <div className="flex items-baseline justify-between mb-1.5">
                    <h3 className="font-serif font-bold text-gray-900 text-lg leading-tight">
                      {profile.name}
                    </h3>
                    <span className="text-xs font-bold text-rose-900 bg-rose-50 px-2 py-0.5 rounded-full border border-rose-100">
                      {profile.age} yrs • {profile.height}
                    </span>
                  </div>

                  {/* Attributes list */}
                  <div className="space-y-2 my-4 text-xs text-gray-600 border-t border-b border-gray-100 py-3">
                    <div className="flex items-center gap-2">
                      <Briefcase className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                      <span className="truncate font-medium text-gray-800">{profile.profession}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <GraduationCap className="w-3.5 h-3.5 text-rose-900 flex-shrink-0" />
                      <span className="truncate text-gray-600">{profile.education}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Users className="w-3.5 h-3.5 text-amber-600 flex-shrink-0" />
                      <span className="truncate text-gray-700">{profile.community} • {profile.religion}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <MapPin className="w-3.5 h-3.5 text-rose-900 flex-shrink-0" />
                      <span className="truncate text-gray-700">{profile.location}</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="pt-1 flex items-center gap-2">
                  <Link
                    to="/login"
                    className="flex-1 text-center bg-rose-900 hover:bg-rose-800 text-amber-300 py-2.5 px-3 rounded-xl font-bold text-xs transition-all shadow-xs border border-amber-500/30 flex items-center justify-center gap-1.5"
                  >
                    <Lock className="w-3.5 h-3.5 text-amber-400" />
                    <span>{t.viewProfileBtn}</span>
                  </Link>

                  <Link
                    to="/register"
                    className="px-3 py-2.5 rounded-xl text-xs font-bold text-gray-700 hover:text-rose-900 bg-gray-100 hover:bg-rose-50 border border-gray-200 transition-colors"
                    title="Register to connect"
                  >
                    {t.connectBtn}
                  </Link>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Security and Privacy Assurance Banner */}
        <div className="bg-white rounded-2xl p-6 sm:p-7 border border-amber-200/80 shadow-sm flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="flex items-center gap-4 text-center md:text-left">
            <div className="w-12 h-12 rounded-2xl bg-amber-50 border border-amber-200 flex items-center justify-center text-amber-600 flex-shrink-0">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <h4 className="text-base font-bold text-gray-900 font-serif">
                {t.securityBannerTitle}
              </h4>
              <p className="text-xs sm:text-sm text-gray-500 mt-1 max-w-2xl">
                {t.securityBannerDesc}
              </p>
            </div>
          </div>

          <Link
            to="/matches"
            className="flex-shrink-0 bg-amber-500 hover:bg-amber-400 text-rose-950 px-6 py-3 rounded-xl font-bold text-xs sm:text-sm transition-all shadow-sm flex items-center gap-2"
          >
            <span>{t.viewAllMatchesBtn}</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

      </div>
    </section>
  );
}
