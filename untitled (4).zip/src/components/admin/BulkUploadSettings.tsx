import React, { useState } from 'react';
import { UploadCloud, Download, CheckCircle, AlertTriangle, Loader2, Info } from 'lucide-react';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { FormConfig } from '../../types';

type ListType = 'gotras' | 'districts' | 'states' | 'tehsils' | 'religions' | 'birthPlaces';

export default function BulkUploadSettings() {
  const [selectedList, setSelectedList] = useState<ListType>('gotras');
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [message, setMessage] = useState<{ type: 'success' | 'error', text: string } | null>(null);

  const getSampleCsvContent = (type: ListType) => {
    switch (type) {
      case 'gotras':
        return 'Value,Label\nBajgal (Bhogal),ਬਜਗਲ / ਭੋਗਲ - Bajgal (Bhogal)\nGhangla,ਘਾਂਗਲਾ - Ghangla\nKaler,ਕਲੇਰ - Kaler';
      case 'districts':
        return 'Name\nGurdaspur (ਗੁਰਦਾਸਪੁਰ)\nAmritsar (ਅੰਮ੍ਰਿਤਸਰ)';
      case 'states':
        return 'Name\nPunjab (ਪੰਜਾਬ)\nHaryana (ਹਰਿਆਣਾ)';
      case 'tehsils':
        return 'Name\nBatala\nPathankot';
      case 'religions':
        return 'Name\nHindu (ਹਿੰਦੂ)\nSikh (ਸਿੱਖ)';
      case 'birthPlaces':
        return 'Name\nAmritsar\nJalandhar';
    }
  };

  const handleDownloadSample = () => {
    const csvContent = getSampleCsvContent(selectedList);
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `sample_${selectedList}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const parseCSV = (text: string) => {
    const lines = text.split('\n').filter(line => line.trim() !== '');
    if (lines.length < 2) return []; // Need at least header and one row
    
    // Simple CSV parser supporting quotes (basic)
    const result = [];
    const headers = lines[0].split(',').map(h => h.trim());
    
    for (let i = 1; i < lines.length; i++) {
      const obj: any = {};
      // Simplistic split by comma (assuming no commas inside data for these simple lists unless quoted... 
      // but actually, we just split by comma. For robust, we should use a proper split.)
      const currentline = lines[i].split(',');
      for (let j = 0; j < headers.length; j++) {
        if (currentline[j]) {
          obj[headers[j]] = currentline[j].replace(/^"|"$/g, '').trim();
        }
      }
      result.push(obj);
    }
    return result;
  };

  const handleUpload = async () => {
    if (!file) {
      setMessage({ type: 'error', text: 'ਕਿਰਪਾ ਕਰਕੇ ਇੱਕ ਫਾਈਲ ਚੁਣੋ (Please select a file)' });
      return;
    }

    setIsUploading(true);
    setMessage(null);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        const data = parseCSV(text);
        
        if (data.length === 0) {
          throw new Error('File is empty or invalid format.');
        }

        const docRef = doc(db, 'cms_settings', 'form_config');
        const docSnap = await getDoc(docRef);
        let currentData = docSnap.exists() ? docSnap.data() as FormConfig : {} as FormConfig;

        let newListData: any = [];

        if (selectedList === 'gotras') {
          newListData = data.map(item => ({
            value: item.Value || item.value || '',
            label: item.Label || item.label || ''
          })).filter(item => item.value && item.label);
        } else {
          // For string arrays
          newListData = data.map(item => item.Name || item.name || Object.values(item)[0]).filter(Boolean);
        }

        if (newListData.length === 0) {
           throw new Error('No valid data found in CSV. Please check headers.');
        }

        await updateDoc(docRef, {
          [selectedList]: newListData,
          updatedAt: new Date()
        });

        setMessage({ type: 'success', text: `ਸਫਲਤਾਪੂਰਵਕ ${newListData.length} ਆਈਟਮਾਂ ਅੱਪਡੇਟ ਕੀਤੀਆਂ ਗਈਆਂ!` });
        setFile(null);
        // Reset file input
        const fileInput = document.getElementById('csv-upload') as HTMLInputElement;
        if (fileInput) fileInput.value = '';

      } catch (error: any) {
        console.error('Error uploading CSV:', error);
        setMessage({ type: 'error', text: 'Error uploading file: ' + error.message });
      } finally {
        setIsUploading(false);
      }
    };
    reader.onerror = () => {
      setMessage({ type: 'error', text: 'Failed to read file.' });
      setIsUploading(false);
    };
    reader.readAsText(file);
  };

  const listLabels = {
    gotras: 'Mahasha Gotra (ਮਹਾਸ਼ਾ ਗੋਤਰ) / Father & Mother Gotra',
    districts: 'District (ਜ਼ਿਲ੍ਹਾ)',
    states: 'State (ਰਾਜ)',
    tehsils: 'Tehsil (ਤਹਿਸੀਲ)',
    religions: 'Religion (ਧਰਮ)',
    birthPlaces: 'Birth Place (ਜਨਮ ਸਥਾਨ)'
  };

  return (
    <div className="bg-white rounded-2xl border border-gray-200 p-6 sm:p-8">
      <div className="flex items-center gap-3 mb-8 pb-4 border-b">
        <div className="p-2.5 bg-rose-50 rounded-xl">
          <UploadCloud className="w-6 h-6 text-rose-800" />
        </div>
        <div>
          <h2 className="text-xl font-bold text-gray-900 font-serif">ਬਲਕ ਅੱਪਲੋਡ (Bulk Upload Excel/CSV)</h2>
          <p className="text-sm text-gray-500">ਐਕਸਲ (CSV) ਫਾਈਲ ਰਾਹੀਂ ਸੂਚੀਆਂ (Lists) ਅੱਪਡੇਟ ਕਰੋ</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="space-y-6">
          
          <div>
            <label className="block text-sm font-semibold text-gray-800 mb-2">ਸੂਚੀ ਚੁਣੋ (Select List to Update)</label>
            <select 
              value={selectedList}
              onChange={(e) => {
                  setSelectedList(e.target.value as ListType);
                  setMessage(null);
              }}
              className="w-full border border-gray-300 rounded-xl p-3 focus:ring-2 focus:ring-rose-500 outline-none font-medium bg-gray-50"
            >
              {(Object.keys(listLabels) as ListType[]).map(key => (
                <option key={key} value={key}>{listLabels[key]}</option>
              ))}
            </select>
            
            {selectedList === 'gotras' && (
              <p className="mt-2 text-xs text-amber-700 bg-amber-50 p-2 rounded-lg flex items-start gap-1">
                 <Info className="w-4 h-4 shrink-0" />
                 ਨੋਟ: Father Gotra ਅਤੇ Mother Gotra ਵੀ ਇਸੇ ਗੋਤਰ ਸੂਚੀ (Gotra List) ਵਿੱਚੋਂ ਹੀ ਚੁਣੇ ਜਾਂਦੇ ਹਨ। 
              </p>
            )}
          </div>

          <div>
             <button 
                onClick={handleDownloadSample}
                className="inline-flex items-center gap-2 px-4 py-2 bg-blue-50 text-blue-700 border border-blue-200 rounded-lg text-sm font-bold hover:bg-blue-100 transition-colors"
             >
                 <Download className="w-4 h-4" />
                 ਸੈਂਪਲ ਫਾਈਲ ਡਾਊਨਲੋਡ ਕਰੋ (Download Sample CSV)
             </button>
             <p className="text-xs text-gray-500 mt-2">
                 * ਪਹਿਲਾਂ ਸੈਂਪਲ ਫਾਈਲ ਡਾਊਨਲੋਡ ਕਰੋ। ਇਸਨੂੰ Excel ਵਿੱਚ ਖੋਲ੍ਹੋ, ਆਪਣਾ ਡਾਟਾ ਭਰੋ ਅਤੇ CSV (Comma delimited) ਫਾਰਮੈਟ ਵਿੱਚ ਸੇਵ ਕਰਕੇ ਇੱਥੇ ਅੱਪਲੋਡ ਕਰੋ।
             </p>
          </div>

          <div>
             <label className="block text-sm font-semibold text-gray-800 mb-2">ਫਾਈਲ ਚੁਣੋ (Choose CSV File)</label>
             <input 
                id="csv-upload"
                type="file" 
                accept=".csv"
                onChange={(e) => setFile(e.target.files ? e.target.files[0] : null)}
                className="block w-full text-sm text-gray-500 file:mr-4 file:py-2.5 file:px-4 file:rounded-xl file:border-0 file:text-sm file:font-semibold file:bg-rose-50 file:text-rose-700 hover:file:bg-rose-100 cursor-pointer border border-gray-200 rounded-xl"
             />
          </div>

          <button
            onClick={handleUpload}
            disabled={isUploading || !file}
            className="w-full sm:w-auto inline-flex justify-center items-center gap-2 px-6 py-3 bg-rose-900 text-amber-300 font-bold rounded-xl shadow-lg hover:bg-rose-800 focus:ring-4 focus:ring-rose-200 transition-all disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {isUploading ? <Loader2 className="w-5 h-5 animate-spin" /> : <UploadCloud className="w-5 h-5" />}
            {isUploading ? 'ਅੱਪਲੋਡ ਹੋ ਰਿਹਾ ਹੈ...' : 'ਡਾਟਾ ਅੱਪਲੋਡ ਕਰੋ (Upload Data)'}
          </button>

          {message && (
            <div className={`p-4 rounded-xl border flex gap-3 ${message.type === 'success' ? 'bg-green-50 border-green-200 text-green-800' : 'bg-red-50 border-red-200 text-red-800'}`}>
              {message.type === 'success' ? <CheckCircle className="w-5 h-5 shrink-0" /> : <AlertTriangle className="w-5 h-5 shrink-0" />}
              <span className="text-sm font-medium">{message.text}</span>
            </div>
          )}

        </div>
        
        <div className="bg-gray-50 border border-gray-200 rounded-xl p-5">
           <h3 className="font-bold text-gray-800 mb-3 border-b pb-2">ਹਿਦਾਇਤਾਂ (Instructions)</h3>
           <ul className="text-sm text-gray-600 space-y-2 list-disc pl-5">
              <li>ਸਿਰਫ਼ <b>.csv</b> ਫਾਈਲਾਂ ਹੀ ਅੱਪਲੋਡ ਕੀਤੀਆਂ ਜਾ ਸਕਦੀਆਂ ਹਨ। (Excel ਵਿੱਚ 'Save As' -{'>'} 'CSV' ਚੁਣੋ)।</li>
              <li>ਪਹਿਲੀ ਲਾਈਨ (Header) ਨੂੰ ਨਾ ਬਦਲੋ।</li>
              <li>ਪੁਰਾਣਾ ਡਾਟਾ ਮਿਟਾ ਦਿੱਤਾ ਜਾਵੇਗਾ ਅਤੇ ਨਵਾਂ ਡਾਟਾ ਸੇਵ ਹੋ ਜਾਵੇਗਾ। ਇਸ ਲਈ ਪੂਰੀ ਲਿਸਟ ਇੱਕਠੀ ਅੱਪਲੋਡ ਕਰੋ।</li>
              <li>Gotra ਦੀ ਲਿਸਟ ਵਿੱਚ ਦੋ ਕਾਲਮ (Value ਅਤੇ Label) ਹੋਣੇ ਜ਼ਰੂਰੀ ਹਨ। ਬਾਕੀ ਸਭ ਵਿੱਚ ਸਿਰਫ਼ ਇੱਕ ਕਾਲਮ (Name) ਹੋਵੇਗਾ।</li>
           </ul>
        </div>
      </div>
    </div>
  );
}
