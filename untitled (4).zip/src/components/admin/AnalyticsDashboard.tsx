import React, { useMemo } from 'react';
import { 
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, AreaChart, Area, Line
} from 'recharts';
import { format, subDays, startOfDay, isSameDay, eachDayOfInterval, isWithinInterval } from 'date-fns';
import { ProfileData, ActivityLog, MetricItem } from '../../types';
import { 
  Users, CheckCircle2, UserPlus, Zap, 
  MapPin, Briefcase, GraduationCap, Heart,
  TrendingUp, Activity, ShieldCheck, Clock,
  Award, RefreshCw
} from 'lucide-react';

interface AnalyticsDashboardProps {
  profiles: ProfileData[];
  logs?: ActivityLog[];
  metrics?: MetricItem[];
}

const COLORS = ['#9d174d', '#b45309', '#065f46', '#1e3a8a', '#7e22ce', '#db2777', '#c026d3', '#ea580c'];

export default function AnalyticsDashboard({ profiles, logs = [], metrics = [] }: AnalyticsDashboardProps) {
  // 0. Summary Stats
  const stats = useMemo(() => {
    const total = profiles.length;
    const verified = profiles.filter(p => p.isVerified).length;
    const newToday = profiles.filter(p => {
      if (!p.createdAt) return false;
      const date = p.createdAt.toDate ? p.createdAt.toDate() : new Date(p.createdAt);
      return isSameDay(date, new Date());
    }).length;
    
    const activeLast24h = logs.filter(l => {
      const date = l.timestamp?.toDate ? l.timestamp.toDate() : new Date(l.timestamp);
      return date > subDays(new Date(), 1);
    }).length;

    return [
      { label: 'ਕੁੱਲ ਪ੍ਰੋਫਾਈਲ (Total)', value: total, icon: Users, color: 'text-rose-600', bg: 'bg-rose-50' },
      { label: 'ਤਸਦੀਕਸ਼ੁਦਾ (Verified)', value: verified, icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
      { label: 'ਅੱਜ ਨਵੇਂ (New Today)', value: newToday, icon: UserPlus, color: 'text-amber-600', bg: 'bg-amber-50' },
      { label: 'ਐਕਟੀਵਿਟੀ (24h Logs)', value: activeLast24h, icon: Activity, color: 'text-blue-600', bg: 'bg-blue-50' },
    ];
  }, [profiles, logs]);

  // 1. Registration Trends (Last 30 days)
  const registrationTrends = useMemo(() => {
    const last30Days = eachDayOfInterval({
      start: subDays(new Date(), 29),
      end: new Date()
    });

    return last30Days.map(day => {
      const dayStart = startOfDay(day);
      const count = profiles.filter(p => {
        if (!p.createdAt) return false;
        const createdAt = p.createdAt.toDate ? p.createdAt.toDate() : new Date(p.createdAt);
        return isSameDay(createdAt, dayStart);
      }).length;

      return {
        date: format(day, 'MMM dd'),
        registrations: count
      };
    });
  }, [profiles]);

  // 2. Age Distribution
  const ageData = useMemo(() => {
    const groups = {
      '18-24': 0,
      '25-30': 0,
      '31-35': 0,
      '36-40': 0,
      '41+': 0
    };

    profiles.forEach(p => {
      const age = parseInt(p.age as string);
      if (isNaN(age)) return;
      if (age <= 24) groups['18-24']++;
      else if (age <= 30) groups['25-30']++;
      else if (age <= 35) groups['31-35']++;
      else if (age <= 40) groups['36-40']++;
      else groups['41+']++;
    });

    return Object.entries(groups).map(([name, value]) => ({ name, value }));
  }, [profiles]);

  // 3. Marital Status Breakdown
  const maritalData = useMemo(() => {
    const counts: Record<string, number> = {};
    profiles.forEach(p => {
      const status = p.maritalStatus || 'Never Married';
      counts[status] = (counts[status] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [profiles]);

  // 4. Gotra Distribution (Top 10)
  const gotraData = useMemo(() => {
    const counts: Record<string, number> = {};
    profiles.forEach(p => {
      const gotra = p.fatherGotra || 'Unknown';
      counts[gotra] = (counts[gotra] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  }, [profiles]);

  // 5. Profession Distribution (Top 8)
  const professionData = useMemo(() => {
    const counts: Record<string, number> = {};
    profiles.forEach(p => {
      const prof = p.profession || 'Other';
      counts[prof] = (counts[prof] || 0) + 1;
    });
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 8);
  }, [profiles]);

  // 6. District Distribution
  const districtData = useMemo(() => {
    const counts: Record<string, number> = {};
    profiles.forEach(p => {
      if (p.district) {
        counts[p.district] = (counts[p.district] || 0) + 1;
      }
    });
    return Object.entries(counts)
      .map(([name, value]) => ({ name, value }))
      .sort((a, b) => b.value - a.value)
      .slice(0, 10);
  }, [profiles]);

  return (
    <div className="space-y-8 pb-12 animate-in fade-in duration-700">
      {/* 1. Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((s, idx) => (
          <div key={idx} className="bg-white p-5 rounded-3xl border border-gray-100 shadow-sm flex items-center gap-4 hover:shadow-md transition-shadow">
            <div className={`p-3 rounded-2xl ${s.bg}`}>
              <s.icon className={`w-6 h-6 ${s.color}`} />
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{s.label}</p>
              <h4 className="text-xl font-black text-gray-900">{s.value.toLocaleString()}</h4>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Main Chart: Registration Trends */}
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm lg:col-span-2">
            <div className="flex items-center justify-between mb-8">
              <div>
                <h3 className="text-lg font-bold text-rose-950 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5" />
                  Registration Velocity (30 Days)
                </h3>
                <p className="text-xs text-gray-400 font-medium">Daily user signup trends</p>
              </div>
              <div className="flex items-center gap-1.5 px-3 py-1 bg-rose-50 text-rose-700 rounded-full text-[10px] font-bold uppercase tracking-tighter">
                Live Data
              </div>
            </div>
            <div className="h-[320px] w-full">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={registrationTrends}>
                  <defs>
                    <linearGradient id="colorReg" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#9d174d" stopOpacity={0.1}/>
                      <stop offset="95%" stopColor="#9d174d" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                  <XAxis 
                    dataKey="date" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fontSize: 10, fill: '#64748b'}} 
                    dy={10}
                  />
                  <YAxis 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fontSize: 10, fill: '#64748b'}}
                  />
                  <Tooltip 
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontSize: '12px' }}
                  />
                  <Area 
                    type="monotone" 
                    dataKey="registrations" 
                    stroke="#9d174d" 
                    strokeWidth={4}
                    fillOpacity={1} 
                    fill="url(#colorReg)" 
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Age Distribution Pie */}
          <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
            <h3 className="text-lg font-bold text-rose-950 mb-1 flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Age Breakdown
            </h3>
            <p className="text-xs text-gray-400 font-medium mb-6">User demographics by age group</p>
            <div className="h-[280px]">
                <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                    <Pie
                      data={ageData}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={85}
                      paddingAngle={8}
                      dataKey="value"
                    >
                    {ageData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                    </Pie>
                    <Tooltip />
                    <Legend verticalAlign="bottom" height={36} iconType="circle" wrapperStyle={{fontSize: '11px', fontWeight: 'bold'}}/>
                </PieChart>
                </ResponsiveContainer>
            </div>
          </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Gotra Stats */}
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-lg font-bold text-rose-950 flex items-center gap-2">
                <ShieldCheck className="w-5 h-5" />
                Community Insight (Gotras)
              </h3>
              <p className="text-xs text-gray-400 font-medium">Dominant family backgrounds</p>
            </div>
          </div>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={gotraData} layout="vertical" margin={{ left: 30, right: 30 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" axisLine={false} tickLine={false} hide />
                <YAxis 
                    type="category" 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fontSize: 10, fill: '#475569', fontWeight: 'bold'}}
                    width={110}
                />
                <Tooltip 
                    cursor={{fill: '#fff7ed'}}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontSize: '11px' }}
                />
                <Bar 
                    dataKey="value" 
                    fill="#9d174d" 
                    radius={[0, 8, 8, 0]}
                    barSize={20}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Profession Distribution */}
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <div className="flex items-center justify-between mb-8">
            <div>
              <h3 className="text-lg font-bold text-rose-950 flex items-center gap-2">
                <Briefcase className="w-5 h-5" />
                Professional Landscape
              </h3>
              <p className="text-xs text-gray-400 font-medium">Common careers among candidates</p>
            </div>
          </div>
          <div className="h-[350px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={professionData} layout="vertical" margin={{ left: 30, right: 30 }}>
                <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f1f5f9" />
                <XAxis type="number" axisLine={false} tickLine={false} hide />
                <YAxis 
                    type="category" 
                    dataKey="name" 
                    axisLine={false} 
                    tickLine={false} 
                    tick={{fontSize: 10, fill: '#475569', fontWeight: 'bold'}}
                    width={110}
                />
                <Tooltip 
                    cursor={{fill: '#eff6ff'}}
                    contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontSize: '11px' }}
                />
                <Bar 
                    dataKey="value" 
                    fill="#1e3a8a" 
                    radius={[0, 8, 8, 0]}
                    barSize={20}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Marital Status */}
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm">
          <h3 className="text-lg font-bold text-rose-950 mb-1 flex items-center gap-2">
            <Heart className="w-5 h-5" />
            Marital Status
          </h3>
          <p className="text-xs text-gray-400 font-medium mb-8">User relationship context</p>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={maritalData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={85}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {maritalData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" iconType="circle" wrapperStyle={{fontSize: '10px', fontWeight: 'bold'}} />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Location Breakdown */}
        <div className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm lg:col-span-2">
          <h3 className="text-lg font-bold text-rose-950 mb-1 flex items-center gap-2">
            <MapPin className="w-5 h-5" />
            Regional Reach (Top Districts)
          </h3>
          <p className="text-xs text-gray-400 font-medium mb-8">Geographic concentration of users</p>
          <div className="h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={districtData}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis 
                  dataKey="name" 
                  axisLine={false} 
                  tickLine={false} 
                  tick={{fontSize: 9, fill: '#64748b', fontWeight: 'bold'}} 
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                  height={50}
                />
                <YAxis axisLine={false} tickLine={false} tick={{fontSize: 10, fill: '#64748b'}} />
                <Tooltip 
                  contentStyle={{ borderRadius: '16px', border: 'none', boxShadow: '0 20px 25px -5px rgb(0 0 0 / 0.1)', fontSize: '11px' }}
                />
                <Bar dataKey="value" fill="#b45309" radius={[6, 6, 0, 0]} barSize={40} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Activity Overview (Logs) */}
      <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h3 className="text-xl font-bold text-rose-950 flex items-center gap-3">
              <Activity className="w-6 h-6 text-rose-600" />
              Platform Activity (360° Real-time)
            </h3>
            <p className="text-xs text-gray-400 font-medium mt-1">Live monitoring of system and user interactions</p>
          </div>
          <div className="hidden sm:block">
            <div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-gray-400">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Live Tracking Enabled
            </div>
          </div>
        </div>

        <div className="space-y-4">
          {logs.slice(0, 10).map((log, idx) => (
            <div key={idx} className="group flex items-start gap-4 p-4 rounded-2xl hover:bg-rose-50/50 transition-all border border-transparent hover:border-rose-100">
              <div className={`mt-1 p-2 rounded-xl shrink-0 ${
                log.type === 'registration' ? 'bg-emerald-50 text-emerald-600' :
                log.type === 'admin_action' ? 'bg-amber-50 text-amber-600' :
                log.type === 'profile_update' ? 'bg-blue-50 text-blue-600' :
                'bg-gray-50 text-gray-600'
              }`}>
                {log.type === 'registration' ? <UserPlus className="w-4 h-4" /> :
                 log.type === 'admin_action' ? <ShieldCheck className="w-4 h-4" /> :
                 log.type === 'profile_update' ? <RefreshCw className="w-4 h-4" /> :
                 <Clock className="w-4 h-4" />}
              </div>
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between gap-2">
                  <h4 className="text-sm font-bold text-gray-900 truncate">{log.action}</h4>
                  <span className="text-[10px] font-bold text-gray-400 uppercase tracking-tighter whitespace-nowrap">
                    {log.timestamp?.toDate ? format(log.timestamp.toDate(), 'MMM dd, HH:mm') : 'Just now'}
                  </span>
                </div>
                <p className="text-xs text-gray-500 mt-0.5 line-clamp-1">{log.details}</p>
                <div className="flex items-center gap-2 mt-2">
                   <span className="text-[10px] font-bold text-gray-400">Performed by:</span>
                   <span className="text-[10px] font-black text-gray-700 bg-gray-100 px-2 py-0.5 rounded-full">
                     {log.performedByName || log.performedBy}
                   </span>
                </div>
              </div>
            </div>
          ))}
          {logs.length === 0 && (
            <div className="text-center py-12 bg-gray-50 rounded-3xl border border-dashed border-gray-200">
              <p className="text-sm text-gray-400 font-bold">ਕੋਈ ਐਕਟੀਵਿਟੀ ਲੋਗ ਨਹੀਂ ਮਿਲਿਆ (No logs found)</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
