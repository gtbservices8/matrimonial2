import React from 'react';

interface SkeletonProps {
  className?: string;
  variant?: 'text' | 'rect' | 'circle';
}

export const Skeleton: React.FC<SkeletonProps> = ({ className = '', variant = 'rect' }) => {
  const baseClasses = 'animate-pulse bg-gray-200';
  const variantClasses = {
    text: 'h-4 w-full rounded-md',
    rect: 'h-full w-full rounded-xl',
    circle: 'rounded-full',
  };

  return (
    <div 
      className={`${baseClasses} ${variantClasses[variant]} ${className}`}
      aria-hidden="true"
    />
  );
};

export const MatchCardSkeleton: React.FC<{ viewMode: 'grid' | 'list' }> = ({ viewMode }) => {
  if (viewMode === 'grid') {
    return (
      <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm">
        <Skeleton className="aspect-[4/5] w-full" />
        <div className="p-4 space-y-3">
          <Skeleton variant="text" className="h-6 w-3/4" />
          <Skeleton variant="text" className="h-4 w-1/2" />
          <div className="flex gap-2">
            <Skeleton variant="text" className="h-4 w-1/4" />
            <Skeleton variant="text" className="h-4 w-1/4" />
          </div>
          <Skeleton className="h-10 w-full rounded-xl mt-2" />
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-3xl overflow-hidden border border-gray-100 shadow-sm flex flex-col sm:flex-row p-4 gap-4">
      <Skeleton className="w-full sm:w-48 aspect-square sm:aspect-auto sm:h-48 rounded-2xl shrink-0" />
      <div className="flex-1 space-y-4 py-2">
        <div className="space-y-2">
          <Skeleton variant="text" className="h-7 w-1/3" />
          <Skeleton variant="text" className="h-4 w-1/4" />
        </div>
        <div className="grid grid-cols-2 gap-x-8 gap-y-3">
          <Skeleton variant="text" className="h-4" />
          <Skeleton variant="text" className="h-4" />
          <Skeleton variant="text" className="h-4" />
          <Skeleton variant="text" className="h-4" />
        </div>
        <div className="flex justify-end gap-3 pt-2">
          <Skeleton className="h-10 w-32 rounded-xl" />
          <Skeleton className="h-10 w-32 rounded-xl" />
        </div>
      </div>
    </div>
  );
};

export const DashboardSkeleton: React.FC = () => {
  return (
    <div className="space-y-8 animate-in fade-in duration-500">
      {/* Welcome Section Skeleton */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
        <div className="space-y-2">
          <Skeleton variant="text" className="h-10 w-64" />
          <Skeleton variant="text" className="h-5 w-48" />
        </div>
        <Skeleton className="h-12 w-40 rounded-2xl" />
      </div>

      {/* Stats Grid Skeleton */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="bg-white p-6 rounded-3xl border border-gray-100 shadow-sm space-y-4">
            <div className="flex items-center gap-4">
              <Skeleton variant="circle" className="w-12 h-12 shrink-0" />
              <div className="space-y-2 flex-1">
                <Skeleton variant="text" className="h-4 w-1/2" />
                <Skeleton variant="text" className="h-7 w-3/4" />
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Charts / Activity Skeleton */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
          <Skeleton variant="text" className="h-8 w-48" />
          <Skeleton className="h-[300px] w-full rounded-2xl" />
        </div>
        <div className="bg-white p-8 rounded-[2rem] border border-gray-100 shadow-sm space-y-6">
          <Skeleton variant="text" className="h-8 w-40" />
          <div className="space-y-4">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="flex items-center gap-4">
                <Skeleton variant="circle" className="w-10 h-10 shrink-0" />
                <div className="space-y-2 flex-1">
                  <Skeleton variant="text" className="h-4 w-3/4" />
                  <Skeleton variant="text" className="h-3 w-1/2" />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};
