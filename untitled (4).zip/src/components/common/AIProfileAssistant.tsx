import React, { useState } from 'react';
import { Sparkles, Wand2, RefreshCw, Check, Copy, FileText, ArrowRight, Bot, X, Lightbulb } from 'lucide-react';
import { ProfileData } from '../../types';

interface AIProfileAssistantProps {
  formData: Partial<ProfileData>;
  onApplyFields: (fields: Partial<ProfileData>) => void;
  onClose?: () => void;
}

export default function AIProfileAssistant({
  formData,
  onApplyFields,
  onClose
}: AIProfileAssistantProps) {
  const [activeTab, setActiveTab] = useState<'bio' | 'quickFill' | 'polish'>('bio');
  const [promptNotes, setPromptNotes] = useState('');
  const [rawBiodataText, setRawBiodataText] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedBio, setGeneratedBio] = useState('');
  const [generatedFields, setGeneratedFields] = useState<Partial<ProfileData> | null>(null);
  const [statusMessage, setStatusMessage] = useState('');

  // 1. Generate Matrimonial Bio
  const handleGenerateBio = async (tone: 'traditional' | 'professional' | 'balanced' = 'balanced') => {
    setIsGenerating(true);
    setStatusMessage('AI ਬਾਇਓ ਤਿਆਰ ਕਰ ਰਿਹਾ ਹੈ...');

    // Simulate smart AI composition using context
    setTimeout(() => {
      const name = formData.fullName || 'ਉਮੀਦਵਾਰ';
      const prof = formData.profession || formData.occupationDetails || 'ਪੇਸ਼ੇਵਰ';
      const qual = formData.qualification1 || formData.education || 'ਉੱਚ ਸਿੱਖਿਆ ਪ੍ਰਾਪਤ';
      const dist = formData.district || 'ਪੰਜਾਬ';
      const gotra = formData.fatherGotra || 'ਮਹਾਸ਼ਾ';
      const gender = formData.gender === 'Female' ? 'ਲੜਕੀ' : 'ਲੜਕਾ';

      let bioResult = '';
      if (tone === 'traditional') {
        bioResult = `${name} ਇੱਕ ਸੰਸਕਾਰੀ, ਨੇਕ ਦਿਲ ਅਤੇ ਪਰਿਵਾਰਕ ਕਦਰਾਂ-ਕੀਮਤਾਂ ਵਾਲੀ ${gender} ਹੈ। ${gotra} ਮਹਾਸ਼ਾ ਪਰਿਵਾਰ ਨਾਲ ਸੰਬੰਧਤ ਹੈ। ${qual} ਦੀ ਵਿੱਦਿਆ ਮੁਕੰਮਲ ਕੀਤੀ ਹੈ ਅਤੇ ਇਸ ਵੇਲੇ ${prof} ਵਜੋਂ ਸੇਵਾ ਨਿਭਾ ਰਹੇ ਹਨ। ਅਸੀਂ ਸਮਝਦਾਰ, ਸੁਲਝੇ ਹੋਏ ਅਤੇ ਗੁਰੂ-ਘਰ/ਸੱਭਿਆਚਾਰ ਦਾ ਸਤਿਕਾਰ ਕਰਨ ਵਾਲੇ ਯੋਗ ਸਾਥੀ ਦੀ ਤਲਾਸ਼ ਵਿੱਚ ਹਾਂ।`;
      } else if (tone === 'professional') {
        bioResult = `${name} is an accomplished and career-oriented professional based in ${dist}. Belongs to respectable Mahasha (${gotra}) family. Completed ${qual} and currently working with dedication as ${prof}. Balance of modern progressive mindset with deep-rooted cultural values. Seeking an educated, supportive and goal-oriented life partner.`;
      } else {
        bioResult = `${name} ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ (${gotra}) ਦੇ ਇੱਕ ਸਤਿਕਾਰਯੋਗ ਪਰਿਵਾਰ ਨਾਲ ਸੰਬੰਧਤ ਹਨ। ${qual} ਦੀ ਡਿਗਰੀ ਹਾਸਲ ਕਰਨ ਉਪਰੰਤ ਇਸ ਵੇਲੇ ${prof} ਵਜੋਂ ਕਾਰਜਸ਼ੀਲ ਹਨ। ਧਾਰਮਿਕ, ਨਿਮਰ ਸੁਭਾਅ ਅਤੇ ਪਰਿਵਾਰ ਨੂੰ ਨਾਲ ਲੈ ਕੇ ਚੱਲਣ ਵਾਲੀ ਸ਼ਖਸੀਅਤ। Looking for an educated, understanding and compatible partner to start a beautiful new journey.`;
      }

      setGeneratedBio(bioResult);
      setIsGenerating(false);
      setStatusMessage('');
    }, 600);
  };

  // 2. Parse Raw Biodata / Resume Notes into Form Fields
  const handleParseBiodata = () => {
    if (!rawBiodataText.trim()) return;
    setIsGenerating(true);
    setStatusMessage('AI ਵੇਰਵਿਆਂ ਨੂੰ ਪੜ੍ਹ ਕੇ ਫਾਰਮ ਦੇ ਖਾਨੇ ਭਰ ਰਿਹਾ ਹੈ...');

    setTimeout(() => {
      const text = rawBiodataText;
      const parsed: Partial<ProfileData> = {};

      // Name extraction
      const nameMatch = text.match(/(?:Name|ਨਾਮ|Candidate)\s*[:=-]\s*([^\n\r,]+)/i);
      if (nameMatch) parsed.fullName = nameMatch[1].trim();

      // Age / DOB
      const ageMatch = text.match(/(?:Age|ਉਮਰ)\s*[:=-]\s*(\d{2})/i);
      if (ageMatch) parsed.age = parseInt(ageMatch[1], 10);

      const dobMatch = text.match(/(?:DOB|Date of Birth|ਜਨਮ ਮਿਤੀ)\s*[:=-]\s*([0-9\/\-\.]+)/i);
      if (dobMatch) parsed.dateOfBirth = dobMatch[1].trim();

      // Height
      const heightMatch = text.match(/(?:Height|ਕੱਦ)\s*[:=-]\s*([0-9\'\"\s\(\)cm]+)/i);
      if (heightMatch) parsed.height = heightMatch[1].trim();

      // Education
      const eduMatch = text.match(/(?:Qualification|Education|ਵਿੱਦਿਆ|Degree)\s*[:=-]\s*([^\n\r]+)/i);
      if (eduMatch) parsed.qualification1 = eduMatch[1].trim();

      // Profession
      const profMatch = text.match(/(?:Profession|Job|Occupation|ਕਿੱਤਾ|ਕੰਮ)\s*[:=-]\s*([^\n\r]+)/i);
      if (profMatch) {
        parsed.profession = profMatch[1].trim();
        parsed.occupationDetails = profMatch[1].trim();
      }

      // Parents
      const fatherMatch = text.match(/(?:Father|ਪਿਤਾ)\s*(?:Name)?\s*[:=-]\s*([^\n\r]+)/i);
      if (fatherMatch) parsed.fatherName = fatherMatch[1].trim();

      const motherMatch = text.match(/(?:Mother|ਮਾਤਾ)\s*(?:Name)?\s*[:=-]\s*([^\n\r]+)/i);
      if (motherMatch) parsed.motherName = motherMatch[1].trim();

      // Contact
      const phoneMatch = text.match(/(?:Contact|Phone|Mobile|ਨੰਬਰ|Mobile No)\s*[:=-]?\s*([0-9\+\-\s]{10,14})/i);
      if (phoneMatch) parsed.contactNumber = phoneMatch[1].replace(/[^0-9+]/g, '');

      // Location
      const locMatch = text.match(/(?:Location|Address|City|ਜ਼ਿਲ੍ਹਾ|District|ਪਤਾ)\s*[:=-]\s*([^\n\r]+)/i);
      if (locMatch) {
        parsed.location = locMatch[1].trim();
      }

      setGeneratedFields(parsed);
      setIsGenerating(false);
      setStatusMessage('ਖਾਨੇ ਸਫਲਤਾਪੂਰਵਕ ਲੱਭੇ ਗਏ! ਤੁਸੀਂ ਹੇਠਾਂ ਦਿੱਤੇ ਬਟਨ ਨਾਲ ਫਾਰਮ ਵਿੱਚ ਲਾਗੂ ਕਰ ਸਕਦੇ ਹੋ।');
    }, 700);
  };

  const handleApplyBio = () => {
    if (!generatedBio) return;
    onApplyFields({ aboutMe: generatedBio });
    setStatusMessage('ਬਾਇਓ ਫਾਰਮ ਵਿੱਚ ਭਰ ਦਿੱਤਾ ਗਿਆ ਹੈ! ✅');
  };

  const handleApplyAllParsedFields = () => {
    if (!generatedFields) return;
    onApplyFields(generatedFields);
    setStatusMessage('ਸਾਰੇ ਵੇਰਵੇ ਫਾਰਮ ਵਿੱਚ ਲਾਗੂ ਕਰ ਦਿੱਤੇ ਗਏ ਹਨ! ✅');
  };

  return (
    <div className="bg-gradient-to-br from-amber-50 via-white to-rose-50/50 rounded-2xl border-2 border-amber-300 p-5 shadow-lg relative">
      
      {/* Header */}
      <div className="flex items-center justify-between pb-3 border-b border-amber-200">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-xl bg-gradient-to-br from-rose-900 to-amber-900 text-amber-300 shadow-sm">
            <Bot className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-base font-bold text-rose-950 font-serif flex items-center gap-1.5">
              AI ਪ੍ਰੋਫਾਈਲ ਸਹਾਇਕ (Smart AI Assistant)
              <span className="text-[10px] uppercase tracking-wider bg-amber-200/80 text-rose-900 px-2 py-0.5 rounded-full font-sans font-bold">
                ਮੁਫ਼ਤ ਸਹਾਇਤਾ
              </span>
            </h3>
            <p className="text-xs text-amber-900/80">
              ਫਾਰਮ ਦੇ ਵੇਰਵੇ ਤੇ ਬਾਇਓ ਲਿਖਣ ਵਿੱਚ ਆਰਟੀਫੀਸ਼ੀਅਲ ਇੰਟੈਲੀਜੈਂਸ ਦੀ ਮਦਦ ਲਵੋ
            </p>
          </div>
        </div>

        {onClose && (
          <button
            type="button"
            onClick={onClose}
            className="p-1 text-gray-400 hover:text-gray-700 rounded-lg hover:bg-gray-100"
          >
            <X className="w-5 h-5" />
          </button>
        )}
      </div>

      {/* Tabs */}
      <div className="flex gap-2 mt-4">
        <button
          type="button"
          onClick={() => setActiveTab('bio')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'bio'
              ? 'bg-rose-900 text-white shadow-sm'
              : 'bg-white text-gray-700 hover:bg-amber-100/60 border border-gray-200'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5 text-amber-400" />
          ਬਾਇਓ ਬਣਾਓ (Auto Bio)
        </button>

        <button
          type="button"
          onClick={() => setActiveTab('quickFill')}
          className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
            activeTab === 'quickFill'
              ? 'bg-rose-900 text-white shadow-sm'
              : 'bg-white text-gray-700 hover:bg-amber-100/60 border border-gray-200'
          }`}
        >
          <Wand2 className="w-3.5 h-3.5 text-amber-400" />
          ਬਾਇਓਡਾਟਾ ਤੋਂ ਫਾਰਮ ਭਰੋ (Smart Paste)
        </button>
      </div>

      {/* Tab 1: Bio Generator */}
      {activeTab === 'bio' && (
        <div className="mt-4 space-y-3">
          <div className="p-3 bg-white rounded-xl border border-amber-200 text-xs text-gray-600">
            <p className="font-semibold text-rose-950 flex items-center gap-1.5 mb-1">
              <Lightbulb className="w-3.5 h-3.5 text-amber-600" />
              ਕਿਸ ਤਰ੍ਹਾਂ ਦਾ ਬਾਇਓ ਚਾਹੀਦਾ ਹੈ? ਸਟਾਈਲ ਚੁਣੋ:
            </p>
            <div className="flex flex-wrap gap-2 mt-2">
              <button
                type="button"
                onClick={() => handleGenerateBio('balanced')}
                className="px-3 py-1.5 rounded-lg bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 font-bold transition-colors"
              >
                ਸੰਤੁਲਿਤ (ਪੰਜਾਬੀ + English)
              </button>
              <button
                type="button"
                onClick={() => handleGenerateBio('traditional')}
                className="px-3 py-1.5 rounded-lg bg-rose-50 hover:bg-rose-100 text-rose-900 border border-rose-300 font-bold transition-colors"
              >
                ਰਵਾਇਤੀ ਪੰਜਾਬੀ (Traditional)
              </button>
              <button
                type="button"
                onClick={() => handleGenerateBio('professional')}
                className="px-3 py-1.5 rounded-lg bg-blue-50 hover:bg-blue-100 text-blue-900 border border-blue-300 font-bold transition-colors"
              >
                ਪੇਸ਼ੇਵਰ ਅੰਗਰੇਜ਼ੀ (Professional English)
              </button>
            </div>
          </div>

          {generatedBio && (
            <div className="mt-3 p-3.5 bg-white rounded-xl border-2 border-amber-300 shadow-sm animate-in fade-in">
              <div className="flex justify-between items-center mb-2">
                <span className="text-xs font-bold text-rose-900 uppercase tracking-wider">
                  ਤਿਆਰ ਕੀਤਾ ਬਾਇਓ (AI Generated Bio):
                </span>
                <span className="text-[11px] text-gray-500">ਤੁਸੀਂ ਇਸ ਵਿੱਚ ਸੋਧ ਵੀ ਕਰ ਸਕਦੇ ਹੋ</span>
              </div>
              <textarea
                value={generatedBio}
                onChange={(e) => setGeneratedBio(e.target.value)}
                rows={4}
                className="w-full text-xs sm:text-sm text-gray-800 p-2.5 border border-gray-200 rounded-lg outline-none focus:ring-2 focus:ring-amber-500"
              />
              <div className="mt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={handleApplyBio}
                  className="inline-flex items-center gap-1.5 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-rose-950 font-bold text-xs shadow-sm transition-all"
                >
                  <Check className="w-4 h-4" />
                  ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ ਲਾਗੂ ਕਰੋ (Apply to About Me)
                </button>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Smart Paste & Parse */}
      {activeTab === 'quickFill' && (
        <div className="mt-4 space-y-3">
          <div className="p-3 bg-white rounded-xl border border-amber-200 text-xs text-gray-600">
            <p className="font-semibold text-rose-950 mb-1">
              ਆਪਣਾ WhatsApp ਬਾਇਓਡਾਟਾ ਜਾਂ ਕੋਈ ਵੀ ਵੇਰਵਾ ਇੱਥੇ ਪੇਸਟ ਕਰੋ:
            </p>
            <textarea
              value={rawBiodataText}
              onChange={(e) => setRawBiodataText(e.target.value)}
              placeholder="ਜਿਵੇਂ: Name: Priya Kumar, DOB: 14/05/1998, Gotra: Kaler, Height: 5'4, Education: MCA, Job: Software Engineer, Father: Sh. Ram Lal (Govt Employee), Mother: Smt. Sunita..."
              rows={4}
              className="w-full text-xs text-gray-800 p-2.5 border border-gray-300 rounded-lg outline-none focus:ring-2 focus:ring-amber-500 mt-1"
            />
            <button
              type="button"
              disabled={isGenerating || !rawBiodataText.trim()}
              onClick={handleParseBiodata}
              className="mt-2.5 w-full py-2.5 rounded-xl bg-gradient-to-r from-rose-950 to-amber-900 text-amber-300 font-bold text-xs flex items-center justify-center gap-2 hover:opacity-95 disabled:opacity-50 transition-all shadow-sm"
            >
              {isGenerating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4 text-amber-400" />}
              AI ਨਾਲ ਫਾਰਮ ਦੇ ਖਾਨੇ ਆਟੋ-ਡਿਟੈਕਟ ਕਰੋ (Auto-Extract Details)
            </button>
          </div>

          {generatedFields && Object.keys(generatedFields).length > 0 && (
            <div className="p-3 bg-white rounded-xl border border-emerald-300 shadow-sm animate-in fade-in space-y-2">
              <span className="text-xs font-bold text-emerald-800 block">
                ਪ੍ਰਾਪਤ ਹੋਏ ਵੇਰਵੇ (Extracted Fields):
              </span>
              <div className="grid grid-cols-2 gap-2 text-xs text-gray-700 bg-emerald-50/50 p-2.5 rounded-lg border border-emerald-100">
                {generatedFields.fullName && <div><span className="font-bold">ਨਾਮ:</span> {generatedFields.fullName}</div>}
                {generatedFields.age && <div><span className="font-bold">ਉਮਰ:</span> {generatedFields.age}</div>}
                {generatedFields.qualification1 && <div><span className="font-bold">ਯੋਗਤਾ:</span> {generatedFields.qualification1}</div>}
                {generatedFields.profession && <div><span className="font-bold">ਕੰਮ:</span> {generatedFields.profession}</div>}
                {generatedFields.fatherName && <div><span className="font-bold">ਪਿਤਾ:</span> {generatedFields.fatherName}</div>}
                {generatedFields.motherName && <div><span className="font-bold">ਮਾਤਾ:</span> {generatedFields.motherName}</div>}
                {generatedFields.contactNumber && <div><span className="font-bold">ਫੋਨ:</span> {generatedFields.contactNumber}</div>}
              </div>
              <button
                type="button"
                onClick={handleApplyAllParsedFields}
                className="w-full py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow-sm transition-all"
              >
                <Check className="w-4 h-4" />
                ਸਾਰੇ ਵੇਰਵੇ ਫਾਰਮ ਵਿੱਚ ਭਰੋ (Fill All in Form)
              </button>
            </div>
          )}
        </div>
      )}

      {/* Status Message Toast */}
      {statusMessage && (
        <div className="mt-3 p-2 rounded-lg bg-amber-100/90 border border-amber-300 text-amber-900 text-xs font-semibold text-center animate-in fade-in">
          {statusMessage}
        </div>
      )}
    </div>
  );
}
