import React, { useState } from 'react';
import { ChevronDown, HelpCircle } from 'lucide-react';
import { useLanguage } from '../../contexts/LanguageContext';

export const faqs = {
  en: [
    { q: "How do I register a profile?", a: "Registration is completely free. Click on 'Register Free', fill in the basic details, and create your account. After that, you can complete your profile by adding educational, family, and professional details." },
    { q: "How is my profile verified?", a: "To maintain the safety and integrity of our Mahasha community, every profile is manually reviewed by our admin team before it goes live. We may contact you for further verification." },
    { q: "Is my data secure?", a: "Yes, your data is completely secure. We only show essential details to registered members, and your contact information is kept private until you choose to share it." },
    { q: "How does the Gotra matching work?", a: "Our system is designed according to the Mahasha community traditions. It ensures that matches do not fall under the same Father's or Mother's Gotra, providing culturally appropriate recommendations." },
  ],
  pa: [
    { q: "ਮੈਂ ਪ੍ਰੋਫਾਈਲ ਕਿਵੇਂ ਰਜਿਸਟਰ ਕਰਾਂ?", a: "ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਬਿਲਕੁਲ ਮੁਫ਼ਤ ਹੈ। 'ਮੁਫ਼ਤ ਰਜਿਸਟਰ ਕਰੋ' 'ਤੇ ਕਲਿੱਕ ਕਰੋ, ਮੁੱਢਲੀ ਜਾਣਕਾਰੀ ਭਰੋ ਅਤੇ ਆਪਣਾ ਖਾਤਾ ਬਣਾਓ। ਉਸ ਤੋਂ ਬਾਅਦ, ਤੁਸੀਂ ਆਪਣੀ ਵਿਦਿਅਕ, ਪਰਿਵਾਰਕ ਅਤੇ ਪੇਸ਼ੇਵਰ ਜਾਣਕਾਰੀ ਜੋੜ ਕੇ ਆਪਣੀ ਪ੍ਰੋਫਾਈਲ ਪੂਰੀ ਕਰ ਸਕਦੇ ਹੋ।" },
    { q: "ਮੇਰੀ ਪ੍ਰੋਫਾਈਲ ਦੀ ਤਸਦੀਕ (Verification) ਕਿਵੇਂ ਹੁੰਦੀ ਹੈ?", a: "ਸਾਡੇ ਮਹਾਸ਼ਾ ਭਾਈਚਾਰੇ ਦੀ ਸੁਰੱਖਿਆ ਨੂੰ ਬਣਾਈ ਰੱਖਣ ਲਈ, ਲਾਈਵ ਹੋਣ ਤੋਂ ਪਹਿਲਾਂ ਸਾਡੀ ਐਡਮਿਨ ਟੀਮ ਦੁਆਰਾ ਹਰੇਕ ਪ੍ਰੋਫਾਈਲ ਦੀ ਹੱਥੀਂ ਜਾਂਚ ਕੀਤੀ ਜਾਂਦੀ ਹੈ।" },
    { q: "ਕੀ ਮੇਰਾ ਡਾਟਾ ਸੁਰੱਖਿਅਤ ਹੈ?", a: "ਹਾਂ, ਤੁਹਾਡਾ ਡਾਟਾ ਪੂਰੀ ਤਰ੍ਹਾਂ ਸੁਰੱਖਿਅਤ ਹੈ। ਅਸੀਂ ਰਜਿਸਟਰਡ ਮੈਂਬਰਾਂ ਨੂੰ ਸਿਰਫ਼ ਜ਼ਰੂਰੀ ਵੇਰਵੇ ਹੀ ਦਿਖਾਉਂਦੇ ਹਾਂ, ਅਤੇ ਤੁਹਾਡੀ ਸੰਪਰਕ ਜਾਣਕਾਰੀ ਉਦੋਂ ਤੱਕ ਗੁਪਤ ਰੱਖੀ ਜਾਂਦੀ ਹੈ ਜਦੋਂ ਤੱਕ ਤੁਸੀਂ ਇਸਨੂੰ ਸਾਂਝਾ ਨਹੀਂ ਕਰਦੇ।" },
    { q: "ਗੋਤਰ ਮੈਚਿੰਗ ਕਿਵੇਂ ਕੰਮ ਕਰਦੀ ਹੈ?", a: "ਸਾਡਾ ਸਿਸਟਮ ਮਹਾਸ਼ਾ ਭਾਈਚਾਰੇ ਦੀਆਂ ਰਵਾਇਤਾਂ ਅਨੁਸਾਰ ਤਿਆਰ ਕੀਤਾ ਗਿਆ ਹੈ। ਇਹ ਯਕੀਨੀ ਬਣਾਉਂਦਾ ਹੈ ਕਿ ਰਿਸ਼ਤੇ ਪਿਤਾ ਜਾਂ ਮਾਤਾ ਦੇ ਗੋਤਰ ਵਿੱਚ ਨਾ ਹੋਣ।" },
  ],
  hi: [
    { q: "मैं प्रोफ़ाइल कैसे पंजीकृत करूं?", a: "पंजीकरण बिल्कुल मुफ्त है। 'नि:शुल्क पंजीकरण' पर क्लिक करें, बुनियादी विवरण भरें और अपना खाता बनाएं। उसके बाद, आप अपनी शैक्षिक, पारिवारिक और व्यावसायिक जानकारी जोड़कर अपना प्रोफ़ाइल पूरा कर सकते हैं।" },
    { q: "मेरी प्रोफ़ाइल का सत्यापन कैसे होता है?", a: "हमारे महाशा समुदाय की सुरक्षा बनाए रखने के लिए, लाइव होने से पहले हमारी एडमिन टीम द्वारा प्रत्येक प्रोफ़ाइल की मैन्युअल रूप से समीक्षा की जाती है।" },
    { q: "क्या मेरा डेटा सुरक्षित है?", a: "हां, आपका डेटा पूरी तरह सुरक्षित है। हम पंजीकृत सदस्यों को केवल आवश्यक विवरण दिखाते हैं, और आपकी संपर्क जानकारी तब तक निजी रखी जाती है जब तक आप इसे साझा नहीं करते।" },
    { q: "गोत्र मिलान कैसे काम करता है?", a: "हमारा सिस्टम महाशा समुदाय की परंपराओं के अनुसार डिज़ाइन किया गया है। यह सुनिश्चित करता है कि रिश्ते पिता या माता के गोत्र में न हों।" },
  ]
};

export default function FAQAccordion() {
  const { language } = useLanguage();
  const [openIndex, setOpenIndex] = useState<number | null>(0); // First one open by default

  const currentFaqs = faqs[language as keyof typeof faqs] || faqs.en;

  const toggleAccordion = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-20 pt-12 border-t border-gray-200">
      <div className="text-center mb-10">
        <h2 className="text-3xl font-extrabold text-gray-900 font-serif mb-4 flex items-center justify-center gap-3">
          <HelpCircle className="w-8 h-8 text-amber-500" />
          {language === 'pa' ? 'ਅਕਸਰ ਪੁੱਛੇ ਜਾਣ ਵਾਲੇ ਸਵਾਲ (FAQs)' : language === 'hi' ? 'अक्सर पूछे जाने वाले प्रश्न (FAQs)' : 'Frequently Asked Questions'}
        </h2>
        <p className="text-gray-600 text-lg">
          {language === 'pa' 
            ? 'ਰਜਿਸਟ੍ਰੇਸ਼ਨ ਅਤੇ ਪ੍ਰੋਫਾਈਲ ਤਸਦੀਕ ਬਾਰੇ ਆਮ ਸਵਾਲਾਂ ਦੇ ਜਵਾਬ।' 
            : language === 'hi' 
            ? 'पंजीकरण और प्रोफ़ाइल सत्यापन के बारे में सामान्य प्रश्नों के उत्तर।' 
            : 'Find answers to common questions about registration and profile verification.'}
        </p>
      </div>

      <div className="space-y-4">
        {currentFaqs.map((faq, index) => (
          <div 
            key={index} 
            className={`border rounded-2xl overflow-hidden transition-all duration-300 ${openIndex === index ? 'border-amber-300 shadow-md bg-white' : 'border-gray-200 bg-white hover:border-amber-200'}`}
          >
            <button
              onClick={() => toggleAccordion(index)}
              className="w-full text-left px-6 py-5 flex items-center justify-between gap-4 focus:outline-none"
            >
              <span className={`font-bold text-lg transition-colors ${openIndex === index ? 'text-amber-700' : 'text-gray-900'}`}>{faq.q}</span>
              <div className={`p-1 rounded-full transition-colors ${openIndex === index ? 'bg-amber-100' : 'bg-gray-100'}`}>
                <ChevronDown className={`w-5 h-5 transition-transform duration-300 shrink-0 ${openIndex === index ? 'rotate-180 text-amber-700' : 'text-gray-500'}`} />
              </div>
            </button>
            <div 
              className={`px-6 overflow-hidden transition-all duration-300 ease-in-out ${openIndex === index ? 'max-h-96 pb-6 opacity-100' : 'max-h-0 opacity-0'}`}
            >
              <div className="w-full h-px bg-gray-100 mb-4"></div>
              <p className="text-gray-600 leading-relaxed">
                {faq.a}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
