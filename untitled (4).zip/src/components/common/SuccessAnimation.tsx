import React from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

interface SuccessAnimationProps {
  isVisible: boolean;
  message?: string | React.ReactNode;
  className?: string;
  containerClassName?: string;
}

export default function SuccessAnimation({ isVisible, message, className = "", containerClassName = "bg-emerald-50 border-l-4 border-emerald-500 p-4 flex items-center gap-3 rounded-r-lg shadow-xs" }: SuccessAnimationProps) {
  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: 10 }}
          className={`${containerClassName} ${className}`}
        >
          <CheckCircle2 className="w-8 h-8 text-emerald-600 flex-shrink-0" />
          {message && <div className="text-emerald-800 font-bold text-sm">{message}</div>}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
