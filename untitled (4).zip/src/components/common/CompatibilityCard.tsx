import React, { useState } from 'react';
import { Sparkles, ShieldCheck, MapPin, GraduationCap, Users, Check, AlertCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { ProfileData, MatchCompatibility } from '../../types';
import { calculateCompatibility } from '../../utils/compatibility';

interface CompatibilityCardProps {
  userProfile?: Partial<ProfileData> | null;
  targetProfile: Partial<ProfileData>;
  compact?: boolean;
}

export default function CompatibilityCard({
  userProfile,
  targetProfile,
  compact = false
}: CompatibilityCardProps) {
  const [isExpanded, setIsExpanded] = useState(false);

  // If user profile is not provided, use default benchmark for Mahasha community matching
  const referenceUser: Partial<ProfileData> = userProfile || {
    fullName: 'ਤੁਹਾਡਾ ਪ੍ਰੋਫਾਈਲ (Your Profile)',
    gender: targetProfile.gender === 'Female' ? 'Male' : 'Female',
    community: 'Mahasha (Bajgal)',
    fatherGotra: targetProfile.fatherGotra === 'Kaler' ? 'Bajgal (Bhogal)' : 'Kaler',
    motherGotra: 'Badhan',
    district: targetProfile.district || 'Gurdaspur',
    location: targetProfile.location || 'Punjab',
    qualification1: 'Graduation / Post Graduation',
    profession: 'Professional / Govt / Tech',
    age: typeof targetProfile.age === 'number' ? targetProfile.age + 2 : 28
  };

  const compatibility: MatchCompatibility = calculateCompatibility(referenceUser, targetProfile);

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'from-emerald-500 to-teal-600 text-emerald-700 bg-emerald-50 border-emerald-200';
    if (score >= 80) return 'from-amber-500 to-rose-600 text-amber-800 bg-amber-50 border-amber-200';
    return 'from-rose-500 to-purple-600 text-rose-800 bg-rose-50 border-rose-200';
  };

  const scoreClass = getScoreColor(compatibility.totalScore);

  if (compact) {
    return (
      <div 
        className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-bold bg-gradient-to-r from-amber-50 to-rose-50 border border-amber-200 text-rose-950 shadow-sm cursor-pointer hover:border-amber-400 transition-all"
        title="ਕਾਸਟ, ਸਿੱਖਿਆ ਅਤੇ ਰਿਹਾਇਸ਼ੀ ਮੇਲ (Caste, Education & Location Match Score)"
        onClick={(e) => {
          e.preventDefault();
          e.stopPropagation();
          setIsExpanded(!isExpanded);
        }}
      >
        <Sparkles className="w-3.5 h-3.5 text-amber-600 animate-pulse" />
        <span>ਮੇਲ: {compatibility.totalScore}%</span>
        <span className="text-[10px] text-amber-800 hidden sm:inline">({compatibility.rating.split(' ')[0]})</span>
      </div>
    );
  }

  return (
    <div className="bg-gradient-to-br from-amber-50/60 via-white to-rose-50/40 rounded-2xl p-4 sm:p-5 border border-amber-200/80 shadow-sm transition-all">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        
        {/* Main Score Header */}
        <div className="flex items-center gap-3.5">
          <div className="relative flex items-center justify-center w-14 h-14 rounded-2xl bg-gradient-to-br from-rose-950 to-amber-900 text-white shadow-md border border-amber-400/40">
            <span className="text-xl font-extrabold tracking-tight text-amber-300 font-serif">
              {compatibility.totalScore}%
            </span>
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs uppercase tracking-wider font-bold text-amber-800 flex items-center gap-1">
                <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                ਸੰਜੋਗ ਮੇਲ ਸਕੋਰ (Compatibility Score)
              </span>
            </div>
            <h4 className="text-base sm:text-lg font-bold text-rose-950 font-serif mt-0.5">
              {compatibility.rating}
            </h4>
          </div>
        </div>

        {/* Toggle Detailed Breakdown */}
        <button
          type="button"
          onClick={() => setIsExpanded(!isExpanded)}
          className="inline-flex items-center gap-1.5 text-xs font-bold text-rose-900 hover:text-rose-700 bg-white hover:bg-amber-50 px-3.5 py-2 rounded-xl border border-amber-200 shadow-2xs transition-all self-start sm:self-center"
        >
          {isExpanded ? 'ਵੇਰਵਾ ਬੰਦ ਕਰੋ' : 'ਵਿਸਤਾਰ ਦੇਖੋ (Criteria Breakdown)'}
          {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
        </button>
      </div>

      {/* Highlights */}
      {compatibility.highlights.length > 0 && (
        <div className="mt-3.5 flex flex-wrap gap-2">
          {compatibility.highlights.map((item, idx) => (
            <span key={idx} className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-semibold bg-white/90 text-rose-900 border border-amber-200/70 shadow-2xs">
              <Check className="w-3.5 h-3.5 text-emerald-600 shrink-0" />
              {item}
            </span>
          ))}
        </div>
      )}

      {/* Expanded Breakdown */}
      {isExpanded && (
        <div className="mt-4 pt-4 border-t border-amber-200/60 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200">
          
          {/* Caste / Gotra Score */}
          <div>
            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-600" />
                ਮਹਾਸ਼ਾ ਗੋਤਰ & ਬਰਾਦਰੀ (Caste & Gotra Alignment - 35%)
              </span>
              <span className="text-rose-950">{compatibility.casteGotraScore}%</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-amber-500 to-rose-600 rounded-full transition-all duration-500" 
                style={{ width: `${compatibility.casteGotraScore}%` }} 
              />
            </div>
          </div>

          {/* Education Score */}
          <div>
            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
              <span className="flex items-center gap-1.5">
                <GraduationCap className="w-3.5 h-3.5 text-amber-600" />
                ਵਿੱਦਿਅਕ ਯੋਗਤਾ (Education Matching - 25%)
              </span>
              <span className="text-rose-950">{compatibility.educationScore}%</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-emerald-500 to-teal-600 rounded-full transition-all duration-500" 
                style={{ width: `${compatibility.educationScore}%` }} 
              />
            </div>
          </div>

          {/* Location & District Score */}
          <div>
            <div className="flex justify-between text-xs font-bold text-gray-700 mb-1">
              <span className="flex items-center gap-1.5">
                <MapPin className="w-3.5 h-3.5 text-amber-600" />
                ਰਿਹਾਇਸ਼ & ਜ਼ਿਲ੍ਹਾ ਨੇੜਤਾ (Location & District Proximity - 20%)
              </span>
              <span className="text-rose-950">{compatibility.locationScore}%</span>
            </div>
            <div className="w-full bg-gray-200 h-2 rounded-full overflow-hidden">
              <div 
                className="h-full bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full transition-all duration-500" 
                style={{ width: `${compatibility.locationScore}%` }} 
              />
            </div>
          </div>

          {/* Considerations if any */}
          {compatibility.considerations.length > 0 && (
            <div className="mt-3 p-2.5 rounded-xl bg-amber-100/70 border border-amber-300/60 text-xs text-amber-950 flex items-start gap-2">
              <AlertCircle className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div>
                <span className="font-bold">ਨੋਟ / ਪਰਿਵਾਰਕ ਵਿਚਾਰ: </span>
                {compatibility.considerations.join(', ')}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
