import { useEffect } from 'react';
import { useCMSConfig } from '../../hooks/useCMSConfig';

export interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string | string[];
  canonicalUrl?: string;
  ogType?: 'website' | 'profile' | 'article';
  ogImage?: string;
  structuredData?: Record<string, any> | Array<Record<string, any>>;
  noIndex?: boolean;
}

const DEFAULT_TITLE = 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ - ਵਿਸ਼ੇਸ਼ ਰਿਸ਼ਤਾ ਪੋਰਟਲ | Mahasha Matrimonial Punjab';
const DEFAULT_DESCRIPTION = 'ਮਹਾਸ਼ਾ ਸਮਾਜ (Mahasha Community) ਦਾ ਨੰਬਰ 1 ਭਰੋਸੇਯੋਗ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਪੋਰਟਲ। ਪੰਜਾਬ ਅਤੇ ਦੇਸ਼-ਵਿਦੇਸ਼ ਦੇ ਵੈਰੀਫਾਈਡ ਮਹਾਸ਼ਾ ਲਾੜੇ, ਲਾੜੀਆਂ ਅਤੇ ਗੋਤਰ ਮਿਲਾਣ ਦੇ ਸੰਪੂਰਨ ਬਾਇਓਡਾਟਾ।';
const DEFAULT_KEYWORDS = 'Mahasha matrimonial, mahasha rishtey, punjabi mahasha gotra, punjab matrimonial, mahasha samaj shaadi, mahasha marriage bureau, bajgal, badhan, kaler, kundal, sandhu gotra rishtey';
const DEFAULT_IMAGE = 'https://images.unsplash.com/photo-1583939003579-730e3918a45a?q=80&w=1200&auto=format&fit=crop';
const SITE_NAME = 'Mahasha Sangam Matrimonial';

export default function SEO({
  title,
  description,
  keywords,
  canonicalUrl,
  ogType = 'website',
  ogImage = DEFAULT_IMAGE,
  structuredData,
  noIndex = false,
}: SEOProps) {
  const { config } = useCMSConfig();

  // Use dynamic config from Firestore if available, otherwise fallback to props or defaults
  const metaTitle = title || config?.seoTitle || DEFAULT_TITLE;
  const metaDescription = description || config?.seoDescription || DEFAULT_DESCRIPTION;
  const metaKeywords = keywords || config?.seoKeywords || DEFAULT_KEYWORDS;

  const fullTitle = title 
    ? (title.includes('Mahasha') || title.includes('ਮਹਾਸ਼ਾ') ? title : `${title} | Mahasha Matrimonial`)
    : metaTitle;

  const keywordsString = Array.isArray(metaKeywords) ? metaKeywords.join(', ') : metaKeywords;

  useEffect(() => {
    // 1. Update document title
    document.title = fullTitle;

    // Helper to set or update meta tag by name or property
    const setMetaTag = (attrName: 'name' | 'property', attrValue: string, content: string) => {
      let meta = document.querySelector(`meta[${attrName}="${attrValue}"]`) as HTMLMetaElement | null;
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attrName, attrValue);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', content);
    };

    // Standard SEO Tags
    setMetaTag('name', 'description', metaDescription);
    setMetaTag('name', 'keywords', keywordsString);
    setMetaTag('name', 'robots', noIndex ? 'noindex, nofollow' : 'index, follow, max-image-preview:large, max-snippet:-1, max-video-preview:-1');
    setMetaTag('name', 'author', 'Mahasha Matrimonial Welfare Board');
    setMetaTag('name', 'language', 'Punjabi, English, Hindi');

    // OpenGraph Tags
    setMetaTag('property', 'og:site_name', SITE_NAME);
    setMetaTag('property', 'og:title', fullTitle);
    setMetaTag('property', 'og:description', metaDescription);
    setMetaTag('property', 'og:type', ogType);
    setMetaTag('property', 'og:url', typeof window !== 'undefined' ? (canonicalUrl || window.location.href) : '');
    setMetaTag('property', 'og:image', ogImage);
    setMetaTag('property', 'og:locale', 'pa_IN');

    // Twitter Card Tags
    setMetaTag('name', 'twitter:card', 'summary_large_image');
    setMetaTag('name', 'twitter:title', fullTitle);
    setMetaTag('name', 'twitter:description', metaDescription);
    setMetaTag('name', 'twitter:image', ogImage);

    // Canonical link
    let canonical = document.querySelector('link[rel="canonical"]') as HTMLLinkElement | null;
    if (!canonical) {
      canonical = document.createElement('link');
      canonical.setAttribute('rel', 'canonical');
      document.head.appendChild(canonical);
    }
    canonical.setAttribute('href', typeof window !== 'undefined' ? (canonicalUrl || window.location.href) : '');

    // Schema.org JSON-LD structured data injection
    const existingScript = document.getElementById('page-structured-data');
    if (existingScript) {
      existingScript.remove();
    }

    if (structuredData) {
      const script = document.createElement('script');
      script.id = 'page-structured-data';
      script.type = 'application/ld+json';
      script.textContent = JSON.stringify(structuredData);
      document.head.appendChild(script);
    }

    return () => {
      const cleanupScript = document.getElementById('page-structured-data');
      if (cleanupScript) {
        cleanupScript.remove();
      }
    };
  }, [fullTitle, metaDescription, keywordsString, canonicalUrl, ogType, ogImage, structuredData, noIndex]);

  return null;
}
