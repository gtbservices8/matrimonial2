import React from 'react';
import { Link } from 'react-router-dom';
import { useCMSConfig } from '../../hooks/useCMSConfig';
import { useLanguage } from '../../contexts/LanguageContext';

interface AppLogoProps {
  variant?: 'full' | 'icon' | 'compact';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  textColor?: 'dark' | 'light';
  className?: string;
  linkTo?: string;
}

export default function AppLogo({
  variant = 'full',
  size = 'md',
  textColor = 'dark',
  className = '',
  linkTo = '/'
}: AppLogoProps) {
  const { config } = useCMSConfig();
  const { language } = useLanguage();

  const siteName = language === 'pa' 
    ? (config?.siteNamePa || 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ') 
    : (config?.siteNameEn || 'Mahasha Matrimonial');

  const subtitle = language === 'pa'
    ? 'ਮਹਾਸ਼ਾ ਸਮਾਜ ਦਾ ਵਿਸ਼ਵਾਸਪਾਤਰ ਮੰਚ'
    : 'Trusted platform for Mahasha Community';

  // Dimension mappings
  const iconSizes = {
    sm: 'w-8 h-8',
    md: 'w-10 h-10',
    lg: 'w-13 h-13',
    xl: 'w-16 h-16',
  };

  const titleSizes = {
    sm: 'text-xl',
    md: 'text-2xl',
    lg: 'text-3xl',
    xl: 'text-4xl',
  };

  const subtitleSizes = {
    sm: 'text-[9px]',
    md: 'text-[11px]',
    lg: 'text-xs',
    xl: 'text-sm',
  };

  const logoIcon = (
    <div className={`relative flex items-center justify-center ${iconSizes[size]} rounded-2xl bg-gradient-to-br from-rose-950 via-rose-900 to-amber-950 p-2 shadow-md border border-amber-500/40 hover:border-amber-400/70 transition-all duration-300 group`}>
      {/* Background glow */}
      <div className="absolute inset-0 rounded-2xl bg-amber-500/10 blur-sm group-hover:bg-amber-400/20 transition-all" />
      
      {/* SVG Royal Matrimony Crest */}
      <svg 
        viewBox="0 0 100 100" 
        className="w-full h-full relative z-10 drop-shadow-[0_2px_4px_rgba(0,0,0,0.4)]"
        fill="none" 
        xmlns="http://www.w3.org/2000/svg"
      >
        <defs>
          <linearGradient id="goldGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FDE68A" />
            <stop offset="35%" stopColor="#F59E0B" />
            <stop offset="70%" stopColor="#D97706" />
            <stop offset="100%" stopColor="#FDE68A" />
          </linearGradient>
          <linearGradient id="rubyGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F43F5E" />
            <stop offset="100%" stopColor="#9F1239" />
          </linearGradient>
          <radialGradient id="sparkleRadial" cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFFBEB" />
            <stop offset="100%" stopColor="#F59E0B" />
          </radialGradient>
        </defs>

        {/* Outer auspicious circular bead ring */}
        <circle cx="50" cy="50" r="44" stroke="url(#goldGradient)" strokeWidth="1.5" strokeDasharray="2 3" opacity="0.7" />

        {/* Two Interlocking Sacred Wedding Rings */}
        <ellipse cx="40" cy="55" rx="18" ry="18" stroke="url(#goldGradient)" strokeWidth="4.5" fill="none" />
        <ellipse cx="60" cy="55" rx="18" ry="18" stroke="url(#goldGradient)" strokeWidth="4.5" fill="none" />

        {/* Central Auspicious Royal Lotus / Heart Emblem */}
        <path 
          d="M50 24 C43 14, 27 20, 27 34 C27 46, 50 63, 50 63 C50 63, 73 46, 73 34 C73 20, 57 14, 50 24 Z" 
          fill="url(#rubyGradient)" 
          stroke="url(#goldGradient)" 
          strokeWidth="2.5"
        />

        {/* Crown Lotus Petals */}
        <path 
          d="M50 16 C48 20, 44 26, 50 30 C56 26, 52 20, 50 16 Z" 
          fill="url(#goldGradient)" 
        />
        <path 
          d="M42 22 C37 23, 36 29, 43 31 C45 27, 44 24, 42 22 Z" 
          fill="url(#goldGradient)" 
          opacity="0.9"
        />
        <path 
          d="M58 22 C63 23, 64 29, 57 31 C55 27, 56 24, 58 22 Z" 
          fill="url(#goldGradient)" 
          opacity="0.9"
        />

        {/* Golden Diamond Core */}
        <polygon points="50,33 54,39 50,45 46,39" fill="url(#sparkleRadial)" stroke="#FFE4E6" strokeWidth="0.8" />

        {/* Glimmer Sparkles */}
        <circle cx="50" cy="39" r="1.8" fill="#FFFFFF" />
        <polygon points="34,50 36,52 34,54 32,52" fill="url(#goldGradient)" opacity="0.8" />
        <polygon points="66,50 68,52 66,54 64,52" fill="url(#goldGradient)" opacity="0.8" />
      </svg>
    </div>
  );

  const content = (
    <div className={`flex items-center gap-3 ${className}`}>
      {logoIcon}

      {variant !== 'icon' && (
        <div className="flex flex-col">
          <div className="flex items-center gap-1.5">
            <span className={`whitespace-nowrap font-serif font-extrabold tracking-tight ${titleSizes[size]} ${
              textColor === 'light' 
                ? 'text-white drop-shadow-sm' 
                : 'bg-gradient-to-r from-rose-950 via-rose-900 to-amber-900 bg-clip-text text-transparent'
            }`}>
              {siteName}
            </span>
          </div>
          
          <span className={`whitespace-nowrap font-sans font-bold tracking-wide ${subtitleSizes[size]} ${
            textColor === 'light' ? 'text-amber-300/90' : 'text-amber-800'
          }`}>
            {subtitle}
          </span>
        </div>
      )}
    </div>
  );

  if (linkTo) {
    return (
      <Link to={linkTo} className="inline-flex items-center group transition-transform duration-200 hover:scale-[1.02]">
        {content}
      </Link>
    );
  }

  return content;
}
