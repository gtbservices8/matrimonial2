import { useState, useEffect } from 'react';
import { Heart, Users, TrendingUp, Globe2, Sparkles, CheckCircle2 } from 'lucide-react';
import { collection, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { MetricItem } from '../types';

const ICON_MAP: Record<string, any> = {
  Heart,
  Users,
  TrendingUp,
  Globe2
};

export default function CountingMetrics() {
  const [metrics, setMetrics] = useState<MetricItem[]>([]);
  const [liveCount, setLiveCount] = useState(18);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchMetrics = async () => {
      try {
        const snap = await getDocs(collection(db, 'cms_settings'));
        const doc = snap.docs.find(d => d.id === 'site_metrics');
        if (doc) {
          setMetrics(doc.data().metrics || []);
        } else {
          // Fallback
          setMetrics([
            {
              id: 'marriages',
              count: 5480,
              suffix: '+',
              title: 'Happy Marriages',
              punjabiTitle: 'ਸਫਲ ਵਿਆਹ',
              description: 'Beautiful unions celebrated across India & overseas with family blessings',
              badge: '+34 This Month',
              icon: 'Heart',
              color: 'text-rose-900',
              bgLight: 'bg-rose-50',
              borderLight: 'border-rose-100',
            },
            {
              id: 'profiles',
              count: 48500,
              suffix: '+',
              title: 'Verified Profiles',
              punjabiTitle: 'ਤਸਦੀਕਸ਼ੁਦਾ ਪ੍ਰੋਫਾਈਲ',
              description: 'Hand-screened and phone-verified genuine brides and grooms',
              badge: '100% Genuine',
              icon: 'Users',
              color: 'text-amber-600',
              bgLight: 'bg-amber-50',
              borderLight: 'border-amber-100',
            }
          ]);
        }
      } catch (err) {
        console.error('Error fetching metrics:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchMetrics();
  }, []);

  useEffect(() => {
    // Subtle live activity ticker simulation
    const interval = setInterval(() => {
      setLiveCount(prev => prev + (Math.random() > 0.6 ? 1 : 0));
    }, 15000);
    return () => clearInterval(interval);
  }, []);

  if (loading || metrics.length === 0) return null;

  return (
    <section className="py-16 bg-gradient-to-b from-neutral-50 to-white relative overflow-hidden border-t border-b border-amber-100/60">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header with live ticker */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 mb-12">
          <div>
            <div className="inline-flex items-center gap-2 bg-amber-50 border border-amber-200 px-3.5 py-1.5 rounded-full text-xs font-bold text-amber-900 mb-3 shadow-xs">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" />
              <span>Milestones & Live Activity</span>
            </div>
            <h2 className="text-3xl font-bold text-gray-900 font-serif tracking-tight">
              Numbers That Speak For <span className="text-rose-900">Our Trust</span>
            </h2>
            <p className="text-gray-600 mt-1 max-w-xl text-sm md:text-base">
              Bringing compatible hearts and respected families together every single day.
            </p>
          </div>

          {/* Live Activity Pill */}
          <div className="flex items-center gap-2.5 bg-white border border-emerald-200 shadow-sm px-4 py-2.5 rounded-xl self-start md:self-auto">
            <span className="relative flex h-3 w-3">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
            </span>
            <span className="text-xs sm:text-sm font-semibold text-gray-800">
              <strong className="text-emerald-700 font-bold">{liveCount} new connections</strong> made today & counting
            </span>
          </div>
        </div>

        {/* 4 Counting Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {metrics.map((item) => {
            const IconComponent = item.icon ? ICON_MAP[item.icon] || Heart : Heart;
            return (
              <div 
                key={item.id}
                className="bg-white rounded-2xl p-6 border border-gray-200/90 shadow-sm hover:shadow-md transition-all duration-300 relative group flex flex-col justify-between"
              >
                {/* Top Row: Icon & Tag */}
                <div className="flex items-center justify-between mb-5">
                  <div className={`w-13 h-13 rounded-2xl ${item.bgLight} border ${item.borderLight} flex items-center justify-center shadow-xs group-hover:scale-105 transition-transform`}>
                    <IconComponent className={`w-6 h-6 ${item.color}`} />
                  </div>
                  <span className="text-xs font-bold tracking-wide px-2.5 py-1 rounded-full bg-amber-50 text-amber-900 border border-amber-200/80">
                    {item.badge}
                  </span>
                </div>

                {/* Big Count */}
                <div>
                  <div className="flex items-baseline gap-1">
                    <span className="text-3xl sm:text-4xl font-extrabold text-gray-900 font-serif tracking-tight">
                      {typeof item.count === 'number' && item.count > 1000 
                        ? item.count.toLocaleString() 
                        : item.count}
                    </span>
                    <span className="text-2xl font-bold text-amber-600 font-serif">{item.suffix}</span>
                  </div>

                  <h3 className="text-base font-bold text-gray-900 mt-2 flex items-center gap-1.5">
                    {item.title}
                    <span className="text-xs text-rose-900/70 font-normal">({item.punjabiTitle})</span>
                  </h3>
                  <p className="text-xs text-gray-600 mt-1.5 leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Bottom subtle check */}
                <div className="mt-5 pt-3 border-t border-gray-100 flex items-center gap-1.5 text-xs text-gray-500">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
                  <span>Real-time Verified Metric</span>
                </div>
              </div>
            );
          })}
        </div>

      </div>
    </section>
  );
}
