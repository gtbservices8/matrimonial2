import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Lock, Mail, X, KeyRound, AlertCircle } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface AdminLoginModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccessLogin?: () => void;
}

export default function AdminLoginModal({ isOpen, onClose, onSuccessLogin }: AdminLoginModalProps) {
  const { language } = useLanguage();
  const isPa = language === 'pa';
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const ADMIN_EMAIL = 'gtbservices8@gmail.com';
  const ADMIN_PASS = 'Admin@143515';

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('[AdminLoginModal] Attempting admin login...');
    console.log('[AdminLoginModal] Validating credentials for:', email);

    if (email.trim().toLowerCase() === ADMIN_EMAIL.toLowerCase() && password === ADMIN_PASS) {
      console.log('[AdminLoginModal] Credentials validated successfully.');
      setError('');
      
      try {
        // Store admin auth state in sessionStorage
        sessionStorage.setItem('mahasha_admin_auth', 'true');
        console.log('[AdminLoginModal] Auth state saved to sessionStorage successfully.');
        
        if (onSuccessLogin) onSuccessLogin();
        onClose();
        navigate('/admin');
      } catch (storageError) {
        console.error('[AdminLoginModal] Error saving to sessionStorage:', storageError);
        setError('Storage error: Unable to save session. Make sure private browsing is disabled.');
      }
    } else {
      console.warn('[AdminLoginModal] Invalid credentials provided.');
      setError(isPa ? 'ਗਲਤ ਯੂਜ਼ਰਨੇਮ/ਈਮੇਲ ਜਾਂ ਪਾਸਵਰਡ!' : 'Invalid Admin Email or Password!');
    }
  };

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-4 bg-black/60 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white w-full max-w-md rounded-3xl shadow-2xl overflow-hidden border border-amber-500/30 animate-in zoom-in-95 duration-200 relative">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-amber-950 p-6 text-white text-center relative overflow-hidden">
          <button
            type="button"
            onClick={onClose}
            className="absolute top-4 right-4 p-1.5 text-white/80 hover:text-white rounded-full bg-white/10 hover:bg-white/20 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="w-14 h-14 bg-amber-500/20 rounded-2xl flex items-center justify-center mx-auto mb-3 border border-amber-400/30 text-amber-300">
            <ShieldCheck className="w-8 h-8" />
          </div>

          <h3 className="text-xl font-bold font-serif text-white">
            {isPa ? 'ਐਡਮਿਨ ਪੈਨਲ ਲੌਗਇਨ' : 'Admin Panel Login'}
          </h3>
          <p className="text-xs text-rose-200 mt-1">
            {isPa ? 'ਮਹਾਸ਼ਾ ਸੰਗਮ ਪ੍ਰਬੰਧਕ ਖਾਤੇ ਲਈ ਪਛਾਣ ਦਰਜ ਕਰੋ' : 'Enter admin credentials to manage platform'}
          </p>
        </div>

        {/* Form Body */}
        <form onSubmit={handleSubmit} className="p-6 space-y-4">
          
          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-xl flex items-center gap-2 text-xs font-bold text-red-700">
              <AlertCircle className="w-4 h-4 shrink-0 text-red-600" />
              <span>{error}</span>
            </div>
          )}

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-rose-900" />
              <span>{isPa ? 'ਐਡਮਿਨ ਯੂਜ਼ਰਨੇਮ / ਈਮੇਲ' : 'Admin Username / Email'}</span>
            </label>
            <input
              type="email"
              required
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full text-xs font-semibold p-3 rounded-xl border border-gray-300 bg-gray-50 focus:border-rose-900 focus:bg-white focus:ring-1 focus:ring-rose-900 outline-hidden"
              placeholder="gtbservices8@gmail.com"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1.5 flex items-center gap-1.5">
              <Lock className="w-3.5 h-3.5 text-amber-700" />
              <span>{isPa ? 'ਐਡਮਿਨ ਪਾਸਵਰਡ' : 'Admin Password'}</span>
            </label>
            <input
              type="password"
              required
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full text-xs font-semibold p-3 rounded-xl border border-gray-300 bg-gray-50 focus:border-rose-900 focus:bg-white focus:ring-1 focus:ring-rose-900 outline-hidden"
              placeholder="••••••••"
            />
          </div>

          <div className="pt-2 space-y-2">
            <button
              type="submit"
              className="w-full bg-gradient-to-r from-rose-900 via-rose-950 to-rose-900 text-amber-300 border border-amber-500/30 p-3 rounded-xl font-bold text-xs shadow-md hover:from-rose-800 hover:to-rose-900 transition-all flex items-center justify-center gap-2"
            >
              <KeyRound className="w-4 h-4 text-amber-400" />
              <span>{isPa ? 'ਐਡਮਿਨ ਲੌਗਇਨ ਕਰੋ' : 'Login to Admin Panel'}</span>
            </button>

            <button
              type="button"
              onClick={onClose}
              className="w-full text-center text-xs font-semibold text-gray-500 hover:text-gray-800 py-1.5 transition-colors"
            >
              {isPa ? 'ਰੱਦ ਕਰੋ' : 'Cancel'}
            </button>
          </div>

        </form>

      </div>
    </div>
  );
}
