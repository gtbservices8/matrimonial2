import { useState, useEffect, useRef } from 'react';
import { 
  Heart, Star, MapPin, Calendar, Quote, ArrowRight, X, Sparkles, 
  CheckCircle2, Send, PartyPopper, ChevronLeft, ChevronRight, 
  Pause, Play, Award, MessageCircleHeart
} from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';
import { collection, getDocs, query, orderBy } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { SuccessStory } from '../types';

const SUCCESS_STORIES: SuccessStory[] = [];


export default function SuccessStories() {
  const { language } = useLanguage();
  const [stories, setStories] = useState<SuccessStory[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAutoPlaying, setIsAutoPlaying] = useState(true);
  const [selectedStory, setSelectedStory] = useState<SuccessStory | null>(null);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [submittedFeedback, setSubmittedFeedback] = useState(false);
  const [loading, setLoading] = useState(true);
  const autoPlayRef = useRef<NodeJS.Timeout | null>(null);

  useEffect(() => {
    const fetchStories = async () => {
      try {
        const q = query(collection(db, 'success_stories'), orderBy('createdAt', 'desc'));
        const snap = await getDocs(q);
        const loaded = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as SuccessStory));
        setStories(loaded);
      } catch (err) {
        console.error('Error fetching stories:', err);
      } finally {
        setLoading(false);
      }
    };
    fetchStories();
  }, []);

  const totalStories = stories.length;

  const handleNext = () => {
    if (totalStories === 0) return;
    setCurrentIndex((prev) => (prev + 1) % totalStories);
  };

  const handlePrev = () => {
    if (totalStories === 0) return;
    setCurrentIndex((prev) => (prev - 1 + totalStories) % totalStories);
  };

  // Auto play logic
  useEffect(() => {
    if (isAutoPlaying && !selectedStory && !showSubmitModal && totalStories > 1) {
      autoPlayRef.current = setInterval(() => {
        handleNext();
      }, 5500);
    }
    return () => {
      if (autoPlayRef.current) clearInterval(autoPlayRef.current);
    };
  }, [isAutoPlaying, selectedStory, showSubmitModal, totalStories]);

  if (loading || totalStories === 0) return null;

  const activeStory = stories[currentIndex];

  const localizedTitles = {
    pa: {
      badge: 'ਮਹਾਸ਼ਾ ਸਮਾਜ ਦੇ ਸਫਲ ਵਿਆਹ ਸਮਾਗਮ',
      title: 'ਸੱਚੀਆਂ ਪ੍ਰੇਮ ਕਹਾਣੀਆਂ ਤੇ',
      titleHighlight: 'ਸਫਲ ਵਿਆਹ ਸਮਾਰੋਹ',
      subtitle: 'ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਰਾਹੀਂ ਆਪਣਾ ਜੀਵਨ ਸਾਥੀ ਚੁਣਨ ਵਾਲੇ ਖੁਸ਼ਹਾਲ ਜੋੜਿਆਂ ਦੇ ਤਜਰਬੇ ਅਤੇ ਅਨੰਦ ਕਾਰਜ ਦੀਆਂ ਖੂਬਸੂਰਤ ਯਾਦਾਂ।',
      readFull: 'ਪੂਰੀ ਕਹਾਣੀ ਪੜ੍ਹੋ',
      shareStoryBtn: 'ਆਪਣਾ ਵਿਆਹ ਫੰਕਸ਼ਨ ਸਾਂਝਾ ਕਰੋ',
      shareStoryTitle: 'ਕੀ ਤੁਹਾਡਾ ਰਿਸ਼ਤਾ ਵੀ ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀ ਰਾਹੀਂ ਹੋਇਆ?',
      shareStoryDesc: 'ਆਪਣੀ ਵਿਆਹ ਫੋਟੋ ਅਤੇ ਕਹਾਣੀ ਸਾਂਝੀ ਕਰੋ ਅਤੇ ਸੰਗਮ ਟੀਮ ਵੱਲੋਂ ਸ਼ਗਨ ਦਾ ਤੋਹਫ਼ਾ ਪ੍ਰਾਪਤ ਕਰੋ।',
      verifiedText: 'ਸੰਗਮ ਮਹਾਸ਼ਾ ਵੱਲੋਂ ਪ੍ਰਮਾਣਿਤ',
      gotraLabel: 'ਗੋਤਰ ਜੋੜੀ',
      weddingDateLabel: 'ਵਿਆਹ ਦੀ ਮਿਤੀ',
      venueLabel: 'ਸ਼ਹਿਰ / ਦੇਸ਼',
      quoteTitle: 'ਜੋੜੇ ਦਾ ਤਜਰਬਾ',
      prevBtn: 'ਪਿਛਲੀ ਕਹਾਣੀ',
      nextBtn: 'ਅਗਲੀ ਕਹਾਣੀ',
    },
    hi: {
      badge: 'महाशा समुदाय के सफल वैवाहिक प्रसंग',
      title: 'सच्ची कहानियाँ और',
      titleHighlight: 'सफल विवाह समारोह',
      subtitle: 'महाशा मैट्रिमोनियल के माध्यम से मिले खुशहाल जोड़ों के अनुभव और फेरों की खूबसूरत स्मृतियाँ।',
      readFull: 'पूरी कहानी पढ़ें',
      shareStoryBtn: 'अपनी शादी की कहानी साझा करें',
      shareStoryTitle: 'क्या आपका रिश्ता भी महाशा मैट्रिमनी से तय हुआ?',
      shareStoryDesc: 'अपनी शादी के समारोह की तस्वीरें साझा करें और विशेष उपहार प्राप्त करें।',
      verifiedText: 'महाशा संगम द्वारा सत्यापित',
      gotraLabel: 'गोत्र युगल',
      weddingDateLabel: 'विवाह तिथि',
      venueLabel: 'स्थान',
      quoteTitle: 'दंपत्ति का अनुभव',
      prevBtn: 'पिछली कहानी',
      nextBtn: 'अगली कहानी',
    },
    en: {
      badge: 'Real Mahasha Wedding Testimonials',
      title: 'Cherished Journeys &',
      titleHighlight: 'Real Success Stories',
      subtitle: 'Heartwarming testimonials from Mahasha couples who found their soulmate through our verified gotra matchmaking portal.',
      readFull: 'Read Full Journey',
      shareStoryBtn: 'Share Your Story',
      shareStoryTitle: 'Did You Find Your Match on Mahasha Matrimonial?',
      shareStoryDesc: 'Share your wedding memories, inspire fellow families, and receive a special blessing gift hamper.',
      verifiedText: 'Verified by Mahasha Sangam',
      gotraLabel: 'Gotras',
      weddingDateLabel: 'Wedding Date',
      venueLabel: 'Location',
      quoteTitle: 'Couple\'s Experience',
      prevBtn: 'Previous Story',
      nextBtn: 'Next Story',
    }
  };

  const currentText = localizedTitles[language] || localizedTitles.pa;

  return (
    <section 
      id="success-stories-section"
      className="py-20 lg:py-24 bg-gradient-to-b from-white via-rose-50/40 to-white relative overflow-hidden"
      onMouseEnter={() => setIsAutoPlaying(false)}
      onMouseLeave={() => setIsAutoPlaying(true)}
    >
      {/* Background Decorative Elements */}
      <div className="absolute top-0 right-0 w-96 h-96 bg-amber-200/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-96 h-96 bg-rose-300/15 rounded-full blur-3xl pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative z-10">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-12 lg:mb-16">
          <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-200/80 px-4 py-1.5 rounded-full text-xs font-bold text-rose-900 mb-3 shadow-xs">
            <Heart className="w-3.5 h-3.5 fill-rose-900 text-rose-900" />
            <span>{currentText.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-gray-900 font-serif tracking-tight">
            {currentText.title} <span className="text-rose-950 underline decoration-amber-400 decoration-wavy decoration-2 underline-offset-8">{currentText.titleHighlight}</span>
          </h2>
          <p className="text-gray-600 mt-4 text-base sm:text-lg leading-relaxed">
            {currentText.subtitle}
          </p>
        </div>

        {/* Carousel Showcase Container */}
        <div className="relative max-w-6xl mx-auto mb-12">
          
          {/* Main Featured Testimonial Card */}
          <div className="bg-white rounded-3xl border border-amber-200/80 shadow-xl shadow-rose-950/5 overflow-hidden transition-all duration-300">
            <div
              key={activeStory.id}
              className="grid grid-cols-1 lg:grid-cols-12 min-h-[460px] transition-opacity duration-300 animate-in fade-in duration-300"
            >
              {/* Left: Couple Image with Ceremony Overlay */}
              <div className="lg:col-span-5 relative h-72 lg:h-auto min-h-[300px] overflow-hidden bg-rose-950 group">
                <img
                  src={activeStory.image}
                  alt={`${activeStory.coupleName} Wedding Ceremony`}
                  className="w-full h-full object-cover object-center transform scale-100 group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-rose-950/95 via-rose-950/30 to-transparent lg:bg-gradient-to-r lg:from-transparent lg:to-rose-950/40" />

                {/* Top Badges */}
                <div className="absolute top-4 left-4 right-4 flex items-center justify-between z-10">
                  <span className="inline-flex items-center gap-1.5 bg-rose-950/90 text-amber-300 text-xs font-bold px-3 py-1.5 rounded-full backdrop-blur-md border border-amber-400/40 shadow-sm">
                    <Award className="w-3.5 h-3.5 text-amber-400" />
                    {language === 'pa' ? activeStory.communityPa : activeStory.communityEn}
                  </span>

                  <span className="inline-flex items-center gap-1 bg-amber-400 text-rose-950 text-xs font-bold px-2.5 py-1 rounded-full shadow-md">
                    <PartyPopper className="w-3 h-3" />
                    {language === 'pa' ? activeStory.ceremonyTypePa : activeStory.ceremonyType}
                  </span>
                </div>

                {/* Bottom Image Overlay */}
                <div className="absolute bottom-4 left-4 right-4 text-white z-10">
                  <h3 className="font-serif font-bold text-2xl text-white drop-shadow-md">
                    {activeStory.coupleName}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-amber-200 mt-1">
                    <MapPin className="w-3.5 h-3.5 text-amber-400" />
                    <span>{activeStory.location}</span>
                  </div>
                </div>
              </div>

              {/* Right: Rich Testimonial & Details */}
              <div className="lg:col-span-7 p-6 sm:p-8 lg:p-10 flex flex-col justify-between bg-white relative">
                
                {/* Decorative background quote icon */}
                <Quote className="w-24 h-24 text-amber-100 absolute top-4 right-6 pointer-events-none opacity-60" />

                <div>
                  {/* Top Row: Ratings & Verification */}
                  <div className="flex flex-wrap items-center justify-between gap-3 mb-4 pb-4 border-b border-gray-100">
                    <div className="flex items-center gap-2">
                      <div className="flex">
                        {[...Array(activeStory.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 text-amber-400 fill-amber-400" />
                        ))}
                      </div>
                      <span className="text-xs font-bold text-gray-700 bg-amber-50 border border-amber-200/70 px-2 py-0.5 rounded-md">
                        5.0 / 5.0 Match
                      </span>
                    </div>

                    <div className="inline-flex items-center gap-1.5 text-xs font-semibold text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      <span>{currentText.verifiedText}</span>
                    </div>
                  </div>

                  {/* Highlight Quote */}
                  <h4 className="text-lg sm:text-xl font-serif font-bold text-gray-900 mb-3 text-rose-950 leading-snug">
                    "{language === 'pa' ? activeStory.highlightQuotePa : activeStory.highlightQuoteEn}"
                  </h4>

                  {/* Testimonial Summary */}
                  <p className="text-gray-600 text-sm sm:text-base leading-relaxed mb-6 italic">
                    "{language === 'pa' ? activeStory.summaryPa : activeStory.summaryEn}"
                  </p>

                  {/* Info Matrix */}
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 bg-rose-50/60 p-4 rounded-2xl border border-rose-100/80 mb-6">
                    <div>
                      <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block">
                        {currentText.gotraLabel}
                      </span>
                      <span className="text-xs sm:text-sm font-bold text-rose-950 mt-0.5 block">
                        {activeStory.gotras}
                      </span>
                    </div>
                    <div>
                      <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block">
                        {currentText.weddingDateLabel}
                      </span>
                      <span className="text-xs sm:text-sm font-bold text-gray-800 mt-0.5 block flex items-center gap-1">
                        <Calendar className="w-3 h-3 text-rose-900" />
                        {activeStory.weddingDate}
                      </span>
                    </div>
                    <div className="col-span-2 sm:col-span-1">
                      <span className="text-[11px] font-bold text-gray-500 uppercase tracking-wider block">
                        {currentText.venueLabel}
                      </span>
                      <span className="text-xs sm:text-sm font-bold text-gray-800 mt-0.5 block truncate">
                        {activeStory.location}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Card Bottom Actions */}
                <div className="pt-2 flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-gray-100">
                  <button
                    type="button"
                    onClick={() => setSelectedStory(activeStory)}
                    className="w-full sm:w-auto inline-flex items-center justify-center gap-2 px-6 py-3 rounded-xl bg-rose-950 hover:bg-rose-900 text-amber-300 font-bold text-xs sm:text-sm border border-amber-500/30 shadow-md transition-all group"
                  >
                    <MessageCircleHeart className="w-4 h-4 text-amber-400 group-hover:scale-110 transition-transform" />
                    <span>{currentText.readFull}</span>
                    <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
                  </button>

                  {/* Slide Counter */}
                  <div className="flex items-center gap-2 text-xs font-bold text-gray-500">
                    <span>{String(currentIndex + 1).padStart(2, '0')}</span>
                    <span className="text-gray-300">/</span>
                    <span>{String(totalStories).padStart(2, '0')}</span>
                  </div>
                </div>

              </div>
            </div>
          </div>

          {/* Carousel Navigation Arrows */}
          <button
            type="button"
            onClick={handlePrev}
            aria-label={currentText.prevBtn}
            className="absolute -left-3 sm:-left-6 top-1/2 -translate-y-1/2 z-20 w-11 h-11 sm:w-13 sm:h-13 rounded-full bg-white text-rose-950 border border-amber-200 shadow-xl flex items-center justify-center hover:bg-rose-950 hover:text-amber-300 hover:border-amber-400 transition-all duration-200 focus:outline-hidden"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>

          <button
            type="button"
            onClick={handleNext}
            aria-label={currentText.nextBtn}
            className="absolute -right-3 sm:-right-6 top-1/2 -translate-y-1/2 z-20 w-11 h-11 sm:w-13 sm:h-13 rounded-full bg-white text-rose-950 border border-amber-200 shadow-xl flex items-center justify-center hover:bg-rose-950 hover:text-amber-300 hover:border-amber-400 transition-all duration-200 focus:outline-hidden"
          >
            <ChevronRight className="w-6 h-6" />
          </button>

        </div>

        {/* Carousel Thumbnail Dots & Auto-Play Controller */}
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8 mb-14">
          
          {/* Dot Indicators */}
          <div className="flex items-center gap-2">
            {SUCCESS_STORIES.map((story, idx) => {
              const isActive = idx === currentIndex;
              return (
                <button
                  key={story.id}
                  onClick={() => setCurrentIndex(idx)}
                  className={`transition-all duration-300 rounded-full ${
                    isActive 
                      ? 'w-8 h-3 bg-rose-950 border border-amber-400' 
                      : 'w-3 h-3 bg-gray-300 hover:bg-rose-300'
                  }`}
                  aria-label={`Slide ${idx + 1}: ${story.coupleName}`}
                />
              );
            })}
          </div>

          {/* Auto-Play Toggle & Status */}
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => setIsAutoPlaying(!isAutoPlaying)}
              className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-semibold bg-gray-100 hover:bg-gray-200 text-gray-700 transition-colors"
              title={isAutoPlaying ? "Pause Auto-Slide" : "Play Auto-Slide"}
            >
              {isAutoPlaying ? (
                <>
                  <Pause className="w-3 h-3 text-rose-900" />
                  <span>ਆਟੋ-ਸਲਾਈਡ ਆਨ</span>
                </>
              ) : (
                <>
                  <Play className="w-3 h-3 text-emerald-700" />
                  <span>ਸਲਾਈਡ ਚਲਾਓ</span>
                </>
              )}
            </button>
          </div>

        </div>

        {/* Mini Preview Cards Row (Clickable quick selection) */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 mb-12">
          {SUCCESS_STORIES.map((story, idx) => {
            const isCurrent = idx === currentIndex;
            return (
              <button
                key={story.id}
                onClick={() => setCurrentIndex(idx)}
                className={`p-2.5 rounded-2xl border text-left transition-all duration-200 flex items-center gap-2.5 bg-white ${
                  isCurrent 
                    ? 'border-amber-400 shadow-md ring-2 ring-rose-950/20 bg-rose-50/50' 
                    : 'border-gray-200 hover:border-amber-300 shadow-xs'
                }`}
              >
                <img
                  src={story.image}
                  alt={story.coupleName}
                  className="w-10 h-10 rounded-xl object-cover flex-shrink-0"
                />
                <div className="overflow-hidden">
                  <div className="text-xs font-bold text-gray-900 truncate">
                    {story.coupleName}
                  </div>
                  <div className="text-[10px] text-gray-500 truncate">
                    {story.weddingDate}
                  </div>
                </div>
              </button>
            );
          })}
        </div>

        {/* Share Your Story CTA Banner */}
        <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-rose-950 rounded-3xl p-6 sm:p-10 text-white border border-amber-500/30 shadow-xl flex flex-col lg:flex-row items-center justify-between gap-6 relative overflow-hidden">
          
          <div className="absolute top-0 right-0 w-64 h-64 bg-amber-400/10 rounded-full blur-2xl pointer-events-none" />

          <div className="text-center lg:text-left relative z-10 max-w-2xl">
            <div className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-bold uppercase tracking-wider mb-2 bg-rose-900/60 px-3 py-1 rounded-full border border-amber-400/30">
              <Sparkles className="w-3.5 h-3.5" />
              <span>{currentText.shareStoryTitle}</span>
            </div>
            <h3 className="text-2xl sm:text-3xl font-bold font-serif text-white">
              {language === 'pa' ? 'ਸਾਡੇ ਨਾਲ ਆਪਣੀ ਵਿਆਹ ਯਾਤਰਾ ਸਾਂਝੀ ਕਰੋ' : language === 'hi' ? 'हमारे साथ अपनी विवाह गाथा साझा करें' : 'Share Your Wedding Journey With Us'}
            </h3>
            <p className="text-rose-200/90 text-xs sm:text-sm mt-2 leading-relaxed">
              {currentText.shareStoryDesc}
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setShowSubmitModal(true);
              setSubmittedFeedback(false);
            }}
            className="flex-shrink-0 bg-amber-500 hover:bg-amber-400 text-rose-950 px-8 py-4 rounded-2xl font-bold text-sm sm:text-base transition-all shadow-lg shadow-amber-500/20 flex items-center gap-2 hover:scale-105 active:scale-95"
          >
            <Heart className="w-5 h-5 fill-rose-950 text-rose-950" />
            <span>{currentText.shareStoryBtn}</span>
          </button>
        </div>

      </div>

      {/* Full Journey Detailed Modal */}
      {selectedStory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-xl w-full overflow-hidden shadow-2xl border border-amber-200 relative animate-in zoom-in-95 duration-200">
            {/* Header Image */}
            <div className="relative h-56 w-full bg-rose-950">
              <img 
                src={selectedStory.image} 
                alt={selectedStory.coupleName} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-rose-950 via-rose-950/40 to-transparent" />
              
              <button 
                onClick={() => setSelectedStory(null)}
                className="absolute top-4 right-4 bg-black/50 hover:bg-black/80 text-white p-2 rounded-full backdrop-blur-xs transition-colors"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6 text-white">
                <span className="inline-flex items-center gap-1.5 bg-amber-400 text-rose-950 text-xs font-bold px-2.5 py-0.5 rounded-full mb-1.5 shadow-sm">
                  <PartyPopper className="w-3.5 h-3.5 text-rose-900" />
                  {language === 'pa' ? selectedStory.ceremonyTypePa : selectedStory.ceremonyType}
                </span>
                <h3 className="text-2xl font-bold font-serif text-white">
                  {selectedStory.coupleName}
                </h3>
                <div className="flex items-center gap-3 text-xs text-rose-200 mt-1">
                  <span>{selectedStory.location}</span>
                  <span>•</span>
                  <span>Married: {selectedStory.weddingDate}</span>
                </div>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6 sm:p-8">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-100 text-xs text-gray-500">
                <span className="font-semibold text-rose-900 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
                  {language === 'pa' ? selectedStory.communityPa : selectedStory.communityEn}
                </span>
                <div className="flex items-center gap-1 text-amber-500">
                  {[...Array(selectedStory.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                  <span className="ml-1 text-gray-700 font-bold">5.0</span>
                </div>
              </div>

              <div className="prose prose-sm text-gray-700 leading-relaxed max-h-64 overflow-y-auto pr-1">
                <p className="text-sm font-medium text-gray-800 italic mb-3 bg-amber-50/60 p-3 rounded-xl border border-amber-100">
                  "{language === 'pa' ? selectedStory.summaryPa : selectedStory.summaryEn}"
                </p>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {selectedStory.fullStory}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> Authenticated by Mahasha Sangam
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedStory(null)}
                  className="bg-rose-950 hover:bg-rose-900 text-amber-300 border border-amber-500/30 px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs"
                >
                  {language === 'pa' ? 'ਬੰਦ ਕਰੋ (Close)' : 'Close'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Submit Story Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-amber-200 relative animate-in zoom-in-95 duration-200">
            <button 
              onClick={() => setShowSubmitModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1.5 rounded-full hover:bg-gray-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            {submittedFeedback ? (
              <div className="text-center py-6">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-200">
                  <Heart className="w-8 h-8 fill-emerald-600" />
                </div>
                <h3 className="text-2xl font-bold font-serif text-gray-900 mb-2">
                  {language === 'pa' ? 'ਧੰਨਵਾਦ ਅਤੇ ਮੁਬਾਰਕਾਂ!' : 'Thank You & Congratulations!'}
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  {language === 'pa' 
                    ? 'ਤੁਹਾਡੀ ਵਿਆਹ ਕਹਾਣੀ ਅਤੇ ਵੇਰਵੇ ਸਫਲਤਾਪੂਰਵਕ ਪ੍ਰਾਪਤ ਹੋ ਗਏ ਹਨ। ਸਾਡੀ ਟੀਮ ਸਮੀਖਿਆ ਤੋਂ ਬਾਅਦ ਇਸਨੂੰ ਪ੍ਰਕਾਸ਼ਿਤ ਕਰੇਗੀ।'
                    : 'Your wedding story and details have been received successfully. Our community team will review and publish it shortly.'}
                </p>
                <button
                  onClick={() => setShowSubmitModal(false)}
                  className="bg-rose-950 text-amber-300 px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-rose-900 transition-colors"
                >
                  {language === 'pa' ? 'ਠੀਕ ਹੈ (Done)' : 'Done'}
                </button>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="w-5 h-5 text-rose-900 fill-rose-900" />
                  <h3 className="text-xl font-bold font-serif text-gray-900">
                    {language === 'pa' ? 'ਆਪਣੀ ਵਿਆਹ ਕਹਾਣੀ ਸਾਂਝੀ ਕਰੋ' : 'Share Your Wedding Story'}
                  </h3>
                </div>
                <p className="text-xs text-gray-500 mb-6">
                  {language === 'pa' 
                    ? 'ਮਹਾਸ਼ਾ ਪੋਰਟਲ \'ਤੇ ਆਪਣੀ ਜੀਵਨ ਸਾਥੀ ਦੀ ਖੋਜ ਦਾ ਤਜਰਬਾ ਸਾਂਝਾ ਕਰੋ।'
                    : 'Share your life partner search journey on Mahasha Matrimonial.'}
                </p>

                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSubmittedFeedback(true);
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      {language === 'pa' ? 'ਜੋੜੇ ਦਾ ਨਾਮ' : 'Couple Names (e.g. Harpreet & Simran)'}
                    </label>
                    <input 
                      required 
                      type="text" 
                      placeholder={language === 'pa' ? 'ਲਾੜਾ ਅਤੇ ਲਾੜੀ ਦਾ ਨਾਮ' : 'Bride & Groom Names'}
                      className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        {language === 'pa' ? 'ਵਿਆਹ ਦਾ ਮਹੀਨਾ/ਸਾਲ' : 'Wedding Month/Year'}
                      </label>
                      <input 
                        required 
                        type="month" 
                        className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">
                        {language === 'pa' ? 'ਸ਼ਹਿਰ / ਦੇਸ਼' : 'City / Country'}
                      </label>
                      <input 
                        required 
                        type="text" 
                        placeholder="e.g. Amritsar, Canada"
                        className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      {language === 'pa' ? 'ਗੋਤਰ ਜੋੜੀ (Gotras)' : 'Gotras (e.g. Kaler & Badhan)'}
                    </label>
                    <input 
                      required 
                      type="text" 
                      placeholder="e.g. Kaler & Badhan"
                      className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">
                      {language === 'pa' ? 'ਤੁਹਾਡਾ ਤਜਰਬਾ ਤੇ ਸੁਨੇਹਾ' : 'Your Journey & Testimonial'}
                    </label>
                    <textarea 
                      required 
                      rows={3} 
                      placeholder={language === 'pa' ? 'ਤੁਸੀਂ ਕਿਵੇਂ ਮਿਲੇ? ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਦਾ ਕੀ ਯੋਗਦਾਨ ਰਿਹਾ?' : 'How did you meet? What made your match special?'}
                      className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-rose-950 hover:bg-rose-900 text-amber-300 border border-amber-500/30 p-3 rounded-xl font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    {language === 'pa' ? 'ਸਬਮਿਟ ਕਰੋ (Submit Story)' : 'Submit Wedding Story'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}

    </section>
  );
}
