import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { 
  UserCircle, CheckCircle2, MapPin, Briefcase, 
  GraduationCap, Users, Heart, Phone, Sparkles, 
  ShieldCheck, ArrowRight, Award, DollarSign, Eye, Clock
} from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import type { ProfileData } from '../../types';
import CompatibilityCard from '../common/CompatibilityCard';
import { useNotifications } from '../../contexts/NotificationContext';
import { useLanguage } from '../../contexts/LanguageContext';

interface MatchCardProps {
  key?: string | number;
  profile: ProfileData;
  viewMode?: 'grid' | 'list';
}

export default function MatchCard({ profile, viewMode = 'grid' }: MatchCardProps) {
  const { addNotification } = useNotifications();
  const { language } = useLanguage();
  const isPa = language === 'pa';
  const [interestSent, setInterestSent] = useState(false);

  const formatLastSeen = (timestamp: any) => {
    if (!timestamp) return isPa ? 'ਕਦੇ ਨਹੀਂ' : 'Never';
    try {
      const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
      const now = new Date();
      const diffInSeconds = Math.floor((now.getTime() - date.getTime()) / 1000);

      // If within last 5 mins, show "Online" or "Active Now"
      if (diffInSeconds < 5 * 60) return isPa ? 'ਹੁਣੇ ਸਰਗਰਮ (Active Now)' : 'Active Now';
      
      if (isPa) {
        if (diffInSeconds < 3600) return `${Math.floor(diffInSeconds / 60)} ਮਿੰਟ ਪਹਿਲਾਂ`;
        if (diffInSeconds < 86400) return `${Math.floor(diffInSeconds / 3600)} ਘੰਟੇ ਪਹਿਲਾਂ`;
        if (diffInSeconds < 2592000) return `${Math.floor(diffInSeconds / 86400)} ਦਿਨ ਪਹਿਲਾਂ`;
      }
      
      return formatDistanceToNow(date, { addSuffix: true });
    } catch (e) {
      return isPa ? 'ਹੁਣੇ' : 'just now';
    }
  };

  const handleSendInterest = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const nextState = !interestSent;
    setInterestSent(nextState);

    if (nextState) {
      addNotification({
        category: 'activity',
        type: 'interest_received',
        title: `Interest Sent to ${profile.fullName}`,
        titlePa: `${profile.fullName} ਨੂੰ ਰਿਸ਼ਤਾ ਬੇਨਤੀ (Interest) ਭੇਜੀ ਗਈ`,
        message: `Your matrimonial interest was sent to ${profile.fullName} (${profile.fatherGotra || 'Mahasha'} Gotra).`,
        messagePa: `ਤੁਹਾਡੀ ਰਿਸ਼ਤਾ ਬੇਨਤੀ ਸਫਲਤਾਪੂਰਵਕ ${profile.fullName} (${profile.fatherGotra || 'ਮਹਾਸ਼ਾ'} ਗੋਤਰ) ਨੂੰ ਭੇਜੀ ਗਈ।`,
        avatarUrl: profile.photoUrl || (profile.photoUrls && profile.photoUrls[0]),
        senderName: profile.fullName,
        senderGotra: profile.fatherGotra,
        targetProfileId: profile.id,
        actionUrl: `/profile/${profile.id}`,
        badge: 'Interest Sent',
        badgePa: 'ਬੇਨਤੀ ਭੇਜੀ',
        priority: 'high'
      });
    }
  };

  const photo = profile.photoUrl || (profile.photoUrls && profile.photoUrls[0]);

  // List View (Horizontal rich biodata layout)
  if (viewMode === 'list') {
    return (
      <div className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all group flex flex-col md:flex-row gap-5 p-5 relative">
        
        {/* Avatar / Photo */}
        <div className="w-full md:w-56 h-60 md:h-auto rounded-2xl overflow-hidden bg-gray-100 relative shrink-0">
          {photo ? (
            <img 
              src={photo} 
              alt={profile.fullName} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-rose-50 to-amber-50 text-rose-300">
              <UserCircle className="w-20 h-20" />
              <span className="text-[11px] font-bold text-gray-400 mt-1">Photo on Request</span>
            </div>
          )}

          {profile.isVerified && (
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-full flex items-center gap-1 text-[11px] font-bold text-emerald-800 border border-emerald-200 shadow-xs z-10">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Verified</span>
            </div>
          )}

          {/* Activity Signals Overlay */}
          <div className="absolute bottom-3 left-3 flex flex-col gap-1.5 z-10">
            {profile.lastSeen && (
              <div className="bg-emerald-500/90 backdrop-blur-sm text-white px-2 py-1 rounded-lg text-[9px] font-bold flex items-center gap-1 shadow-sm border border-white/20">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                {formatLastSeen(profile.lastSeen)}
              </div>
            )}
            <div className="bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded-lg text-[9px] font-bold flex items-center gap-1 shadow-sm border border-white/10 w-fit">
              <Eye className="w-3 h-3 text-amber-400" />
              {profile.viewCount || 0} {isPa ? 'ਵਾਰ ਦੇਖਿਆ' : 'Views'}
            </div>
          </div>

          <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-xs text-white px-2 py-0.5 rounded-lg text-[10px] font-semibold">
            {profile.gender || 'Profile'}
          </div>
        </div>

        {/* Content */}
        <div className="flex-1 flex flex-col justify-between space-y-4">
          
          <div>
            <div className="flex flex-wrap items-start justify-between gap-2 mb-1.5">
              <div>
                <h3 className="text-xl font-bold text-gray-900 font-serif group-hover:text-rose-950 transition-colors">
                  {profile.fullName}
                </h3>
                <div className="text-xs text-gray-500 font-medium flex flex-wrap items-center gap-2 mt-0.5">
                  <span>{profile.age || '26'} {isPa ? 'ਸਾਲ' : 'Yrs'}</span>
                  <span>•</span>
                  <span>{profile.height || "5'4\""}</span>
                  {profile.complexion && (
                    <>
                      <span>•</span>
                      <span>{profile.complexion}</span>
                    </>
                  )}
                  {profile.maritalStatus && profile.maritalStatus !== 'Never Married' && (
                    <>
                      <span>•</span>
                      <span className="text-purple-700 font-bold">{profile.maritalStatus}</span>
                    </>
                  )}
                </div>
              </div>

              <CompatibilityCard targetProfile={profile} compact={true} />
            </div>

            {/* Badges Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5 my-3.5">
              
              {/* Education Credentials */}
              <div className="bg-rose-50/60 border border-rose-100 p-2.5 rounded-2xl flex items-start gap-2.5">
                <GraduationCap className="w-4 h-4 text-rose-800 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-rose-950 uppercase tracking-wider">
                    {isPa ? 'ਵਿੱਦਿਆ (Education)' : 'Qualifications'}
                  </div>
                  <div className="text-xs font-bold text-gray-900 truncate">
                    {profile.qualification3 || profile.qualification2 || profile.qualification1 || profile.education || 'Higher Education'}
                  </div>
                  {profile.qualification2 && profile.qualification3 && (
                    <div className="text-[10px] text-gray-600 truncate">
                      {profile.qualification1} • {profile.qualification2}
                    </div>
                  )}
                </div>
              </div>

              {/* Occupation & Career */}
              <div className="bg-amber-50/60 border border-amber-100 p-2.5 rounded-2xl flex items-start gap-2.5">
                <Briefcase className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-rose-950 uppercase tracking-wider">
                    {isPa ? 'ਪੇਸ਼ਾ (Profession)' : 'Career & Profession'}
                  </div>
                  <div className="text-xs font-bold text-gray-900 truncate">
                    {profile.profession || 'Professional'}
                  </div>
                  {profile.occupationDetails && (
                    <div className="text-[10px] text-gray-600 truncate" title={profile.occupationDetails}>
                      {profile.occupationDetails}
                    </div>
                  )}
                </div>
              </div>

              {/* Gotra Details */}
              <div className="bg-purple-50/60 border border-purple-100 p-2.5 rounded-2xl flex items-start gap-2.5">
                <Users className="w-4 h-4 text-purple-700 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-purple-950 uppercase tracking-wider">
                    {isPa ? 'ਮਹਾਸ਼ਾ ਗੋਤਰ (Gotra)' : 'Father & Mother Gotra'}
                  </div>
                  <div className="text-xs font-bold text-gray-900 truncate">
                    ਪਿਤਾ: <span className="text-rose-950">{profile.fatherGotra || profile.community || 'Mahasha'}</span>
                    {profile.motherGotra && (
                      <span className="text-gray-500 ml-1">| ਮਾਤਾ: {profile.motherGotra}</span>
                    )}
                  </div>
                </div>
              </div>

              {/* Location & District */}
              <div className="bg-blue-50/60 border border-blue-100 p-2.5 rounded-2xl flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-blue-700 shrink-0 mt-0.5" />
                <div className="min-w-0">
                  <div className="text-[11px] font-bold text-blue-950 uppercase tracking-wider">
                    {isPa ? 'ਰਿਹਾਇਸ਼ (Location)' : 'District & Location'}
                  </div>
                  <div className="text-xs font-bold text-gray-900 truncate">
                    {profile.district || profile.location || 'Punjab'}
                  </div>
                  {profile.location && profile.district && profile.location !== profile.district && (
                    <div className="text-[10px] text-gray-600 truncate">
                      {profile.location}
                    </div>
                  )}
                </div>
              </div>

            </div>

            {profile.aboutMe && (
              <p className="text-xs text-gray-600 line-clamp-2 italic bg-gray-50 p-2.5 rounded-xl border border-gray-100">
                "{profile.aboutMe}"
              </p>
            )}
          </div>

          {/* Action Row */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-gray-100">
            <div className="text-xs font-semibold text-gray-500">
              {profile.income ? `ਆਮਦਨ: ${profile.income}` : 'Mahasha Verified Family'}
            </div>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={handleSendInterest}
                className={`px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs ${
                  interestSent 
                    ? 'bg-rose-100 text-rose-900 border border-rose-300'
                    : 'bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30'
                }`}
              >
                <Heart className={`w-3.5 h-3.5 ${interestSent ? 'fill-rose-900' : 'text-amber-400'}`} />
                <span>{interestSent ? (isPa ? 'ਬੇਨਤੀ ਭੇਜੀ ਗਈ' : 'Interest Sent') : (isPa ? 'ਰਿਸ਼ਤਾ ਭੇਜੋ' : 'Send Interest')}</span>
              </button>

              <Link
                to={`/profile/${profile.id}`}
                className="bg-amber-100 hover:bg-amber-200 text-rose-950 border border-amber-300 px-4 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 transition-colors"
              >
                <span>{isPa ? 'ਪੂਰਾ ਬਾਇਓਡਾਟਾ' : 'View Biodata'}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </Link>
            </div>
          </div>

        </div>

      </div>
    );
  }

  // Grid View (Standard responsive card)
  return (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-all group flex flex-col justify-between">
      
      <div>
        {/* Photo Header */}
        <div className="h-52 bg-gray-100 relative overflow-hidden">
          {photo ? (
            <img 
              src={photo} 
              alt={profile.fullName} 
              className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" 
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center bg-gradient-to-br from-rose-50 to-amber-50 text-rose-200">
              <UserCircle className="w-20 h-20" />
              <span className="text-[10px] font-bold text-gray-400 mt-1">Photo on Request</span>
            </div>
          )}

          {profile.isVerified && (
            <div className="absolute top-3 left-3 bg-white/95 backdrop-blur-xs px-2.5 py-1 rounded-full flex items-center gap-1 text-[11px] font-bold text-emerald-800 border border-emerald-200 shadow-xs z-10">
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
              <span>Verified</span>
            </div>
          )}

          {/* Activity Signals Overlay */}
          <div className="absolute bottom-3 left-3 flex flex-col gap-1.5 z-10">
            {profile.lastSeen && (
              <div className="bg-emerald-500/90 backdrop-blur-sm text-white px-2 py-1 rounded-lg text-[9px] font-bold flex items-center gap-1 shadow-sm border border-white/20">
                <div className="w-1.5 h-1.5 bg-white rounded-full animate-pulse" />
                {formatLastSeen(profile.lastSeen)}
              </div>
            )}
            <div className="bg-black/60 backdrop-blur-sm text-white px-2 py-1 rounded-lg text-[9px] font-bold flex items-center gap-1 shadow-sm border border-white/10 w-fit">
              <Eye className="w-3 h-3 text-amber-400" />
              {profile.viewCount || 0} {isPa ? 'ਵਾਰ ਦੇਖਿਆ' : 'Views'}
            </div>
          </div>

          <div className="absolute bottom-3 right-3 bg-black/60 backdrop-blur-xs text-white px-2 py-0.5 rounded-lg text-[10px] font-semibold">
            {profile.gender || 'Profile'}
          </div>
        </div>

        {/* Card Body */}
        <div className="p-5 space-y-3.5">
          
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="text-lg font-bold text-gray-900 font-serif line-clamp-1 group-hover:text-rose-950 transition-colors">
                {profile.fullName}
              </h3>
              <div className="text-xs text-gray-500 font-medium">
                {profile.age || '26'} {isPa ? 'ਸਾਲ' : 'yrs'} • {profile.height || "5'4\""}
              </div>
            </div>
            <CompatibilityCard targetProfile={profile} compact={true} />
          </div>

          {/* Key Details Rows */}
          <div className="space-y-2 text-xs text-gray-700 bg-gray-50/70 p-3 rounded-2xl border border-gray-100">
            
            {/* Education */}
            <div className="flex items-start gap-2">
              <GraduationCap className="w-4 h-4 text-rose-800 shrink-0 mt-0.5" />
              <div className="min-w-0">
                <span className="font-bold text-gray-900 truncate block">
                  {profile.qualification3 || profile.qualification2 || profile.qualification1 || profile.education || 'Graduate'}
                </span>
                {profile.qualification1 && profile.qualification3 && (
                  <span className="text-[10px] text-gray-500 truncate block">
                    {profile.qualification1}
                  </span>
                )}
              </div>
            </div>

            {/* Profession */}
            <div className="flex items-start gap-2">
              <Briefcase className="w-4 h-4 text-amber-700 shrink-0 mt-0.5" />
              <div className="min-w-0">
                <span className="font-bold text-gray-900 truncate block">
                  {profile.profession || 'Professional'}
                </span>
                {profile.occupationDetails && (
                  <span className="text-[10px] text-gray-500 truncate block" title={profile.occupationDetails}>
                    {profile.occupationDetails}
                  </span>
                )}
              </div>
            </div>

            {/* Gotra */}
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-purple-700 shrink-0" />
              <span className="truncate font-semibold text-rose-950">
                ਗੋਤਰ: {profile.fatherGotra || profile.community || 'Mahasha'}
                {profile.motherGotra && <span className="text-gray-500 font-normal"> (ਨਾਨਕੇ: {profile.motherGotra})</span>}
              </span>
            </div>

            {/* Location */}
            <div className="flex items-center gap-2">
              <MapPin className="w-4 h-4 text-blue-700 shrink-0" />
              <span className="truncate">{profile.district || profile.location || 'Punjab'}</span>
            </div>
          </div>

        </div>
      </div>

      {/* Action Buttons */}
      <div className="p-5 pt-0 flex items-center gap-2">
        <button
          type="button"
          onClick={handleSendInterest}
          className={`flex-1 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 transition-all shadow-xs ${
            interestSent 
              ? 'bg-rose-100 text-rose-900 border border-rose-300'
              : 'bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30'
          }`}
        >
          <Heart className={`w-3.5 h-3.5 ${interestSent ? 'fill-rose-900' : 'text-amber-400'}`} />
          <span>{interestSent ? (isPa ? 'ਬੇਨਤੀ ਭੇਜੀ' : 'Sent') : (isPa ? 'ਰਿਸ਼ਤਾ ਭੇਜੋ' : 'Send Interest')}</span>
        </button>

        <Link 
          to={`/profile/${profile.id}`}
          className="bg-amber-100 hover:bg-amber-200 text-rose-950 border border-amber-300 px-3.5 py-2.5 rounded-xl font-bold transition-all shadow-xs text-xs flex items-center gap-1"
        >
          <span>{isPa ? 'ਬਾਇਓਡਾਟਾ' : 'View'}</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </Link>
      </div>

    </div>
  );
}
