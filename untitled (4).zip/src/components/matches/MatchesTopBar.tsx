import React from 'react';
import { 
  Search, SlidersHorizontal, LayoutGrid, List, 
  X, Sparkles, RotateCcw, ArrowUpDown 
} from 'lucide-react';
import type { FilterCriteria } from '../../types/filters';
import { useLanguage } from '../../contexts/LanguageContext';

interface MatchesTopBarProps {
  filters: FilterCriteria;
  onChange: (updates: Partial<FilterCriteria>) => void;
  onReset: () => void;
  onOpenMobileFilter: () => void;
  totalResults: number;
  activeFilterCount: number;
  viewMode: 'grid' | 'list';
  onToggleViewMode: (mode: 'grid' | 'list') => void;
}

export default function MatchesTopBar({
  filters,
  onChange,
  onReset,
  onOpenMobileFilter,
  totalResults,
  activeFilterCount,
  viewMode,
  onToggleViewMode
}: MatchesTopBarProps) {
  const { language } = useLanguage();
  const isPa = language === 'pa';

  // Build active filter pills
  const activeTags: { label: string; onRemove: () => void }[] = [];

  if (filters.searchQuery.trim() !== '') {
    activeTags.push({
      label: `"${filters.searchQuery}"`,
      onRemove: () => onChange({ searchQuery: '' })
    });
  }

  if (filters.gender !== 'Any') {
    activeTags.push({
      label: filters.gender === 'Female' ? (isPa ? 'ਲਾੜੀ (Bride)' : 'Bride') : (isPa ? 'ਲਾੜਾ (Groom)' : 'Groom'),
      onRemove: () => onChange({ gender: 'Any' })
    });
  }

  if (filters.educationLevel.length > 0) {
    activeTags.push({
      label: `Edu: ${filters.educationLevel.join(', ')}`,
      onRemove: () => onChange({ educationLevel: [] })
    });
  }

  if (filters.educationField !== 'Any') {
    activeTags.push({
      label: `Field: ${filters.educationField}`,
      onRemove: () => onChange({ educationField: 'Any' })
    });
  }

  if (filters.qualificationDegree.trim() !== '') {
    activeTags.push({
      label: `Degree: ${filters.qualificationDegree}`,
      onRemove: () => onChange({ qualificationDegree: '' })
    });
  }

  if (filters.profession.length > 0) {
    activeTags.push({
      label: `Prof: ${filters.profession.join(', ')}`,
      onRemove: () => onChange({ profession: [] })
    });
  }

  if (filters.employmentType !== 'Any') {
    activeTags.push({
      label: `Sector: ${filters.employmentType}`,
      onRemove: () => onChange({ employmentType: 'Any' })
    });
  }

  if (filters.incomeRange !== 'Any') {
    activeTags.push({
      label: `Income: ${filters.incomeRange}`,
      onRemove: () => onChange({ incomeRange: 'Any' })
    });
  }

  if (filters.country !== 'Any') {
    activeTags.push({
      label: `Country: ${filters.country}`,
      onRemove: () => onChange({ country: 'Any' })
    });
  }

  if (filters.stateRegion !== 'Any') {
    activeTags.push({
      label: `Region: ${filters.stateRegion}`,
      onRemove: () => onChange({ stateRegion: 'Any' })
    });
  }

  if (filters.district.length > 0) {
    activeTags.push({
      label: `District: ${filters.district.map(d => d.split('(')[0].trim()).join(', ')}`,
      onRemove: () => onChange({ district: [] })
    });
  }

  if (filters.cityLocation.trim() !== '') {
    activeTags.push({
      label: `City: ${filters.cityLocation}`,
      onRemove: () => onChange({ cityLocation: '' })
    });
  }

  if (filters.fatherGotra !== 'Any') {
    activeTags.push({
      label: `Gotra: ${filters.fatherGotra.split('(')[0].trim()}`,
      onRemove: () => onChange({ fatherGotra: 'Any' })
    });
  }

  if (filters.motherGotra !== 'Any') {
    activeTags.push({
      label: `Mother Gotra: ${filters.motherGotra.split('(')[0].trim()}`,
      onRemove: () => onChange({ motherGotra: 'Any' })
    });
  }

  if (filters.verifiedOnly) {
    activeTags.push({
      label: isPa ? 'ਪ੍ਰਮਾਣਿਤ (Verified)' : 'Verified Only',
      onRemove: () => onChange({ verifiedOnly: false })
    });
  }

  if (filters.withPhotoOnly) {
    activeTags.push({
      label: isPa ? 'ਫੋਟੋ ਵਾਲੇ' : 'With Photo Only',
      onRemove: () => onChange({ withPhotoOnly: false })
    });
  }

  if (filters.maritalStatus !== 'Any') {
    activeTags.push({
      label: filters.maritalStatus,
      onRemove: () => onChange({ maritalStatus: 'Any' })
    });
  }

  return (
    <div className="bg-white rounded-3xl shadow-sm border border-gray-200 p-4 sm:p-5 mb-6 space-y-4">
      
      {/* Top Search & Filter Bar */}
      <div className="flex flex-col lg:flex-row items-stretch lg:items-center justify-between gap-3">
        
        {/* Search Input */}
        <div className="relative flex-1">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={filters.searchQuery}
            onChange={(e) => onChange({ searchQuery: e.target.value })}
            placeholder={
              isPa 
                ? "ਨਾਮ, ਗੋਤਰ (ਬਜਗਲ/ਕਲੇਰ), ਡਿਗਰੀ (LLM/B.Tech), ਜ਼ਿਲ੍ਹਾ (ਗੁਰਦਾਸਪੁਰ) ਜਾਂ ਕਿੱਤਾ ਖੋਜੋ..." 
                : "Search by Name, Gotra (Bajgal/Kaler), Degree (LLM/B.Tech), District, Profession..."
            }
            className="w-full pl-10 pr-10 py-2.5 sm:py-3 text-xs sm:text-sm bg-gray-50 hover:bg-gray-100/70 focus:bg-white rounded-2xl border border-gray-200 focus:border-amber-500 focus:ring-2 focus:ring-amber-500/20 outline-hidden transition-all shadow-2xs font-medium"
          />
          {filters.searchQuery && (
            <button
              type="button"
              onClick={() => onChange({ searchQuery: '' })}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 p-1 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Controls: Mobile Filter Button, Sort Dropdown, View Toggle */}
        <div className="flex items-center gap-2 sm:gap-3 flex-wrap sm:flex-nowrap justify-between">
          
          {/* Mobile Filter Toggle */}
          <button
            type="button"
            onClick={onOpenMobileFilter}
            className="lg:hidden flex items-center gap-2 bg-rose-950 text-white px-3.5 py-2.5 rounded-2xl font-bold text-xs shadow-xs"
          >
            <SlidersHorizontal className="w-4 h-4 text-amber-400" />
            <span>{isPa ? 'ਫਿਲਟਰ' : 'Filters'}</span>
            {activeFilterCount > 0 && (
              <span className="bg-amber-400 text-rose-950 text-[10px] px-1.5 py-0.2 rounded-full font-extrabold">
                {activeFilterCount}
              </span>
            )}
          </button>

          {/* Sort By Dropdown */}
          <div className="flex items-center gap-1.5 bg-gray-50 border border-gray-200 px-3 py-2 rounded-2xl">
            <ArrowUpDown className="w-3.5 h-3.5 text-gray-500 shrink-0" />
            <label className="text-[11px] font-bold text-gray-600 hidden sm:inline whitespace-nowrap">
              {isPa ? 'ਤਰਤੀਬ:' : 'Sort:'}
            </label>
            <select
              value={filters.sortBy}
              onChange={(e) => onChange({ sortBy: e.target.value as any })}
              className="bg-transparent text-xs font-bold text-gray-800 focus:outline-hidden cursor-pointer"
            >
              <option value="relevance">{isPa ? 'ਸਭ ਤੋਂ ਢੁਕਵੇਂ (Best Match)' : 'Most Relevant'}</option>
              <option value="score">{isPa ? 'ਗੋਤਰ ਅਨੁਕੂਲਤਾ (Compatibility Score)' : 'Compatibility Score'}</option>
              <option value="newest">{isPa ? 'ਨਵੇਂ ਰਜਿਸਟਰਡ (Newest)' : 'Newest Profiles'}</option>
              <option value="education_high">{isPa ? 'ਉੱਚ ਵਿੱਦਿਆ (Highest Edu)' : 'Highest Education'}</option>
              <option value="age_asc">{isPa ? 'ਉਮਰ: ਛੋਟੀ ਤੋਂ ਵੱਡੀ' : 'Age: Youngest First'}</option>
              <option value="age_desc">{isPa ? 'ਉਮਰ: ਵੱਡੀ ਤੋਂ ਛੋਟੀ' : 'Age: Oldest First'}</option>
              <option value="income_high">{isPa ? 'ਆਮਦਨ: ਵੱਧ ਤੋਂ ਘੱਟ' : 'Highest Income'}</option>
            </select>
          </div>

          {/* View Mode Toggle (Grid vs List) */}
          <div className="flex items-center bg-gray-100 p-1 rounded-2xl border border-gray-200">
            <button
              type="button"
              onClick={() => onToggleViewMode('grid')}
              className={`p-2 rounded-xl transition-all ${
                viewMode === 'grid'
                  ? 'bg-white text-rose-950 shadow-xs'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
              title="Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
            <button
              type="button"
              onClick={() => onToggleViewMode('list')}
              className={`p-2 rounded-xl transition-all ${
                viewMode === 'list'
                  ? 'bg-white text-rose-950 shadow-xs'
                  : 'text-gray-500 hover:text-gray-800'
              }`}
              title="Detailed Biodata List View"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        </div>

      </div>

      {/* Result Count & Active Filter Pills */}
      <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-gray-100">
        <div className="flex items-center gap-2">
          <span className="text-xs font-bold text-gray-700 font-serif">
            {isPa ? `ਕੁੱਲ ${totalResults} ਯੋਗ ਰਿਸ਼ਤੇ ਮਿਲੇ` : `Showing ${totalResults} Matched Profiles`}
          </span>
          {activeFilterCount > 0 && (
            <span className="text-[11px] text-amber-700 bg-amber-50 border border-amber-200 px-2 py-0.5 rounded-full font-semibold">
              {activeFilterCount} {isPa ? 'ਫਿਲਟਰ ਚਾਲੂ' : 'filters active'}
            </span>
          )}
        </div>

        {activeTags.length > 0 && (
          <button
            type="button"
            onClick={onReset}
            className="text-[11px] font-bold text-rose-900 hover:text-rose-700 flex items-center gap-1 hover:underline"
          >
            <RotateCcw className="w-3 h-3" />
            <span>{isPa ? 'ਸਾਰੇ ਹਟਾਓ (Clear All)' : 'Clear All'}</span>
          </button>
        )}
      </div>

      {/* Active Filter Chips */}
      {activeTags.length > 0 && (
        <div className="flex flex-wrap gap-1.5 pt-1">
          {activeTags.map((tag, idx) => (
            <span
              key={idx}
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold bg-rose-50 text-rose-950 border border-rose-200"
            >
              <span>{tag.label}</span>
              <button
                type="button"
                onClick={tag.onRemove}
                className="p-0.5 hover:bg-rose-200 text-rose-800 hover:text-rose-950 rounded-full transition-colors"
              >
                <X className="w-3 h-3" />
              </button>
            </span>
          ))}
        </div>
      )}

    </div>
  );
}
