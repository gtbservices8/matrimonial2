import React, { useState } from 'react';
import { 
  Filter, GraduationCap, Briefcase, MapPin, Users, 
  RotateCcw, Sparkles, ChevronDown, ChevronUp, Search, 
  ShieldCheck, Camera, DollarSign, Building2, Check, X
} from 'lucide-react';
import { 
  FilterCriteria, 
  DEFAULT_FILTERS, 
  EDUCATION_LEVEL_OPTIONS, 
  EDUCATION_FIELD_OPTIONS, 
  OCCUPATION_OPTIONS, 
  EMPLOYMENT_TYPE_OPTIONS, 
  INCOME_RANGE_OPTIONS, 
  COUNTRY_OPTIONS, 
  STATE_REGION_OPTIONS, 
  MARITAL_STATUS_OPTIONS 
} from '../../types/filters';
import { MAHASHA_GOTRAS, PUNJAB_DISTRICTS } from '../../types';
import { countActiveFilters } from '../../utils/filterMatches';
import { useLanguage } from '../../contexts/LanguageContext';
import { useSettings } from '../../contexts/SettingsContext';

interface AdvancedFilterSidebarProps {
  filters: FilterCriteria;
  onChange: (updates: Partial<FilterCriteria>) => void;
  onMultiChange?: (name: keyof FilterCriteria, value: string, checked: boolean) => void;
  onReset: () => void;
  onApply?: () => void;
  className?: string;
  isMobileModal?: boolean;
  onCloseMobile?: () => void;
}

export default function AdvancedFilterSidebar({
  filters,
  onChange,
  onReset,
  onApply,
  className = '',
  isMobileModal = false,
  onCloseMobile
}: AdvancedFilterSidebarProps) {
  const { language } = useLanguage();
  const isPa = language === 'pa';
  const { states } = useSettings();

  // Section Collapsible States
  const [openSections, setOpenSections] = useState({
    education: true,
    occupation: true,
    location: true,
    gotra: true,
    demographics: false,
    verification: true
  });

  const toggleSection = (key: keyof typeof openSections) => {
    setOpenSections(prev => ({ ...prev, [key]: !prev[key] }));
  };

  const activeCount = countActiveFilters(filters);

  // Quick Preset Handlers
  const applyPreset = (preset: Partial<FilterCriteria>) => {
    onChange(preset);
  };

  const handleMultiChange = (name: keyof FilterCriteria, value: string, checked: boolean) => {
    const currentValues = (filters[name] as string[]) || [];
    if (checked) {
      onChange({ [name]: [...currentValues, value] } as Partial<FilterCriteria>);
    } else {
      onChange({ [name]: currentValues.filter(v => v !== value) } as Partial<FilterCriteria>);
    }
  };

  const MultiSelectGroup = ({ 
    label, icon: Icon, name, options, selectedValues = [] 
  }: { 
    label: string, icon: any, name: keyof FilterCriteria, options: { label: string, value: string }[], selectedValues: string[] 
  }) => (
    <div className="space-y-2.5">
      <label className="block text-[11px] font-bold text-gray-700 uppercase tracking-wide flex items-center gap-1.5">
        <Icon className="w-3.5 h-3.5 text-amber-600" />
        {label}
      </label>
      <div className="space-y-1.5 max-h-36 overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-gray-200 scrollbar-track-transparent">
        {options.map((opt) => (
          <label 
            key={opt.value} 
            className={`flex items-center gap-2 text-xs font-medium p-1.5 rounded-lg transition-colors cursor-pointer ${
              selectedValues.includes(opt.value) ? 'bg-amber-50 text-rose-950 font-bold' : 'text-gray-600 hover:bg-gray-50'
            }`}
          >
            <input
              type="checkbox"
              checked={selectedValues.includes(opt.value)}
              onChange={(e) => handleMultiChange(name, opt.value, e.target.checked)}
              className="w-4 h-4 rounded border-gray-300 text-amber-600 focus:ring-amber-500"
            />
            {opt.label}
          </label>
        ))}
      </div>
    </div>
  );

  return (
    <div className={`bg-white rounded-3xl shadow-sm border border-gray-200 overflow-hidden ${className}`}>
      
      {/* Header */}
      <div className="p-5 bg-gradient-to-r from-rose-950 to-rose-900 text-white flex items-center justify-between border-b border-amber-500/20">
        <div className="flex items-center gap-2.5">
          <div className="p-2 bg-amber-500/20 rounded-xl text-amber-300 border border-amber-400/30">
            <Filter className="w-5 h-5" />
          </div>
          <div>
            <h2 className="text-base font-bold font-serif flex items-center gap-2">
              <span>{isPa ? 'ਐਡਵਾਂਸਡ ਫਿਲਟਰ' : 'Advanced Match Filters'}</span>
              {activeCount > 0 && (
                <span className="bg-amber-400 text-rose-950 text-xs px-2 py-0.5 rounded-full font-extrabold">
                  {activeCount}
                </span>
              )}
            </h2>
            <p className="text-[11px] text-rose-200">
              {isPa ? 'ਵਿੱਦਿਆ, ਕਿੱਤਾ ਅਤੇ ਜ਼ਿਲ੍ਹੇ ਅਨੁਸਾਰ ਖੋਜੋ' : 'Refine by Education, Career & Location'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {activeCount > 0 && (
            <button
              type="button"
              onClick={onReset}
              className="text-xs font-bold text-amber-300 hover:text-white flex items-center gap-1 bg-white/10 hover:bg-white/20 px-2.5 py-1.5 rounded-lg transition-colors"
              title="Reset all filters"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>{isPa ? 'ਰੀਸੈਟ' : 'Reset'}</span>
            </button>
          )}

          {isMobileModal && onCloseMobile && (
            <button
              type="button"
              onClick={onCloseMobile}
              className="p-1.5 text-white/80 hover:text-white rounded-lg hover:bg-white/10 ml-1"
            >
              <X className="w-5 h-5" />
            </button>
          )}
        </div>
      </div>

      {/* Quick Search Presets */}
      <div className="p-4 bg-amber-50/70 border-b border-amber-200/60">
        <div className="text-[11px] font-bold text-rose-950 mb-2 flex items-center gap-1.5">
          <Sparkles className="w-3.5 h-3.5 text-amber-600" />
          <span>{isPa ? 'ਮੁੱਖ ਪ੍ਰੀਸੈੱਟ (Quick Presets):' : 'Popular Search Presets:'}</span>
        </div>
        <div className="flex flex-wrap gap-1.5">
          <button
            type="button"
            onClick={() => applyPreset({ profession: ['Advocate'], educationField: 'Law' })}
            className={`text-xs px-2.5 py-1 rounded-lg font-bold border transition-all ${
              filters.profession.includes('Advocate')
                ? 'bg-rose-900 text-amber-300 border-rose-950 shadow-2xs'
                : 'bg-white text-gray-700 border-amber-200 hover:bg-amber-100 hover:text-rose-950'
            }`}
          >
            ⚖️ Advocate & Legal
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ profession: ['Software Engineer'], educationField: 'Engineering' })}
            className={`text-xs px-2.5 py-1 rounded-lg font-bold border transition-all ${
              filters.profession.includes('Software Engineer')
                ? 'bg-rose-900 text-amber-300 border-rose-950 shadow-2xs'
                : 'bg-white text-gray-700 border-amber-200 hover:bg-amber-100 hover:text-rose-950'
            }`}
          >
            💻 IT & Software
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ district: ['Gurdaspur'] })}
            className={`text-xs px-2.5 py-1 rounded-lg font-bold border transition-all ${
              filters.district.includes('Gurdaspur')
                ? 'bg-rose-900 text-amber-300 border-rose-950 shadow-2xs'
                : 'bg-white text-gray-700 border-amber-200 hover:bg-amber-100 hover:text-rose-950'
            }`}
          >
            📍 Gurdaspur (Majha)
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ educationLevel: ['Post Graduate'] })}
            className={`text-xs px-2.5 py-1 rounded-lg font-bold border transition-all ${
              filters.educationLevel.includes('Post Graduate')
                ? 'bg-rose-900 text-amber-300 border-rose-950 shadow-2xs'
                : 'bg-white text-gray-700 border-amber-200 hover:bg-amber-100 hover:text-rose-950'
            }`}
          >
            🎓 Post Graduate (LLM/M.Tech)
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ verifiedOnly: true })}
            className={`text-xs px-2.5 py-1 rounded-lg font-bold border transition-all ${
              filters.verifiedOnly
                ? 'bg-emerald-800 text-white border-emerald-900 shadow-2xs'
                : 'bg-white text-gray-700 border-emerald-200 hover:bg-emerald-50 hover:text-emerald-900'
            }`}
          >
            🛡️ Verified Only
          </button>
          <button
            type="button"
            onClick={() => applyPreset({ country: 'Canada' })}
            className={`text-xs px-2.5 py-1 rounded-lg font-bold border transition-all ${
              filters.country === 'Canada'
                ? 'bg-rose-900 text-amber-300 border-rose-950 shadow-2xs'
                : 'bg-white text-gray-700 border-amber-200 hover:bg-amber-100 hover:text-rose-950'
            }`}
          >
            🇨🇦 Canada NRI
          </button>
        </div>
      </div>

      {/* Accordion Filter Sections */}
      <div className="p-5 space-y-5 divide-y divide-gray-100">

        {/* 1. BASIC LOOKING FOR & GENDER */}
        <div className="pt-2 first:pt-0 space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-800 mb-1.5 uppercase tracking-wider">
              {isPa ? 'ਰਿਸ਼ਤਾ ਚਾਹੀਦਾ ਹੈ (Looking For)' : 'Looking For'}
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['Any', 'Female', 'Male'] as const).map((g) => (
                <button
                  key={g}
                  type="button"
                  onClick={() => onChange({ gender: g })}
                  className={`py-2 px-2 text-xs font-bold rounded-xl border text-center transition-all ${
                    filters.gender === g
                      ? 'bg-rose-900 text-amber-300 border-rose-950 shadow-xs'
                      : 'bg-gray-50 text-gray-700 border-gray-200 hover:bg-amber-50 hover:text-rose-900'
                  }`}
                >
                  {g === 'Any' ? (isPa ? 'ਸਾਰੇ' : 'All') : g === 'Female' ? (isPa ? 'ਲਾੜੀ (Bride)' : 'Bride') : (isPa ? 'ਲਾੜਾ (Groom)' : 'Groom')}
                </button>
              ))}
            </div>
          </div>

          <div>
            <div className="flex items-center justify-between text-xs font-bold text-gray-800 mb-1.5">
              <span>{isPa ? 'ਉਮਰ ਸੀਮਾ (Age Range)' : 'Age Range'}</span>
              <span className="text-rose-900 font-extrabold">{filters.minAge} - {filters.maxAge} Yrs</span>
            </div>
            <div className="flex items-center gap-2">
              <input 
                type="number"
                min="18"
                max="70"
                value={filters.minAge}
                onChange={(e) => onChange({ minAge: e.target.value })}
                className="w-full text-xs font-semibold p-2 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                placeholder="Min 18"
              />
              <span className="text-gray-400 text-xs font-bold">{isPa ? 'ਤੋਂ' : 'to'}</span>
              <input 
                type="number"
                min="18"
                max="70"
                value={filters.maxAge}
                onChange={(e) => onChange({ maxAge: e.target.value })}
                className="w-full text-xs font-semibold p-2 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                placeholder="Max 50"
              />
            </div>
          </div>
        </div>

        {/* 2. EDUCATION & QUALIFICATION FILTER */}
        <div className="pt-4 space-y-3">
          <button
            type="button"
            onClick={() => toggleSection('education')}
            className="w-full flex items-center justify-between text-left group"
          >
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-rose-50 rounded-lg text-rose-900 group-hover:bg-rose-100 transition-colors">
                <GraduationCap className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-gray-900 uppercase tracking-wider">
                {isPa ? 'ਵਿੱਦਿਅਕ ਯੋਗਤਾ (Education)' : 'Education & Degrees'}
              </span>
              {(filters.educationLevel.length > 0 || filters.educationField !== 'Any' || filters.qualificationDegree) && (
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              )}
            </div>
            {openSections.education ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </button>

          {openSections.education && (
            <div className="space-y-3 pt-1 animate-in fade-in duration-200">
              {/* Education Level */}
              <MultiSelectGroup
                label={isPa ? 'ਡਿਗਰੀ ਲੈਵਲ (Education Level)' : 'Degree Level'}
                icon={GraduationCap}
                name="educationLevel"
                options={EDUCATION_LEVEL_OPTIONS.filter(o => o.value !== 'Any')}
                selectedValues={filters.educationLevel}
              />

              {/* Education Field / Stream */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਵਿੱਦਿਆ ਦਾ ਖੇਤਰ (Field of Study)' : 'Field of Study / Stream'}
                </label>
                <select
                  value={filters.educationField}
                  onChange={(e) => onChange({ educationField: e.target.value })}
                  className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                >
                  {EDUCATION_FIELD_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Specific Degree Text (e.g. LLM, BA.LLB, B.Tech) */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਖਾਸ ਡਿਗਰੀ ਖੋਜ (Specific Degree / Diploma)' : 'Specific Degree Search (e.g. LLM, BA.LLB, B.Tech)'}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={filters.qualificationDegree}
                    onChange={(e) => onChange({ qualificationDegree: e.target.value })}
                    placeholder="e.g. LLM, BA.LLB, CSE, MBBS"
                    className="w-full text-xs font-medium p-2.5 pr-8 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                  />
                  {filters.qualificationDegree && (
                    <button
                      type="button"
                      onClick={() => onChange({ qualificationDegree: '' })}
                      className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 3. OCCUPATION, SECTOR & INCOME FILTER */}
        <div className="pt-4 space-y-3">
          <button
            type="button"
            onClick={() => toggleSection('occupation')}
            className="w-full flex items-center justify-between text-left group"
          >
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-amber-50 rounded-lg text-amber-700 group-hover:bg-amber-100 transition-colors">
                <Briefcase className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-gray-900 uppercase tracking-wider">
                {isPa ? 'ਕਿੱਤਾ ਅਤੇ ਆਮਦਨ (Career & Income)' : 'Occupation, Sector & Income'}
              </span>
              {(filters.profession.length > 0 || filters.employmentType !== 'Any' || filters.incomeRange !== 'Any') && (
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              )}
            </div>
            {openSections.occupation ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </button>

          {openSections.occupation && (
            <div className="space-y-3 pt-1 animate-in fade-in duration-200">
              {/* Profession Dropdown */}
              <MultiSelectGroup
                label={isPa ? 'ਪੇਸ਼ਾ / ਅਹੁਦਾ (Profession)' : 'Profession / Role'}
                icon={Briefcase}
                name="profession"
                options={OCCUPATION_OPTIONS.filter(o => o.value !== 'Any')}
                selectedValues={filters.profession}
              />

              {/* Employment Sector */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਰੁਜ਼ਗਾਰ ਦਾ ਖੇਤਰ (Employment Sector)' : 'Employment Sector'}
                </label>
                <select
                  value={filters.employmentType}
                  onChange={(e) => onChange({ employmentType: e.target.value })}
                  className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                >
                  {EMPLOYMENT_TYPE_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Income Range */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਸਾਲਾਨਾ ਆਮਦਨ (Annual Income Range)' : 'Annual Income Range'}
                </label>
                <select
                  value={filters.incomeRange}
                  onChange={(e) => onChange({ incomeRange: e.target.value })}
                  className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                >
                  {INCOME_RANGE_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* 4. SPECIFIC LOCATION & DISTRICT CRITERIA */}
        <div className="pt-4 space-y-3">
          <button
            type="button"
            onClick={() => toggleSection('location')}
            className="w-full flex items-center justify-between text-left group"
          >
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-blue-50 rounded-lg text-blue-700 group-hover:bg-blue-100 transition-colors">
                <MapPin className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-gray-900 uppercase tracking-wider">
                {isPa ? 'ਰਿਹਾਇਸ਼ ਅਤੇ ਜ਼ਿਲ੍ਹਾ (Location)' : 'Location & District Criteria'}
              </span>
              {(filters.country !== 'Any' || filters.stateRegion !== 'Any' || filters.district.length > 0 || filters.cityLocation) && (
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              )}
            </div>
            {openSections.location ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </button>

          {openSections.location && (
            <div className="space-y-3 pt-1 animate-in fade-in duration-200">
              {/* Country */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਦੇਸ਼ (Country)' : 'Country'}
                </label>
                <select
                  value={filters.country}
                  onChange={(e) => onChange({ country: e.target.value })}
                  className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                >
                  {COUNTRY_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* State / Region (Majha, Doaba, Malwa) */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਖੇਤਰ / ਰੀਜਨ (Region / Zone)' : 'Region / Zone'}
                </label>
                <select
                  value={filters.stateRegion}
                  onChange={(e) => onChange({ stateRegion: e.target.value })}
                  className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                >
                  {STATE_REGION_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* State Selection */}
              <MultiSelectGroup
                label={isPa ? 'ਸਟੇਟ / ਪ੍ਰਾਂਤ (State)' : 'State / Province'}
                icon={MapPin}
                name="state"
                options={states.map(s => ({label: s, value: s}))}
                selectedValues={filters.state}
              />

              {/* Specific Punjab District */}
              <MultiSelectGroup
                label={isPa ? 'ਖਾਸ ਜ਼ਿਲ੍ਹਾ (Specific District)' : 'Specific District (Punjab & J&K)'}
                icon={MapPin}
                name="district"
                options={PUNJAB_DISTRICTS.map(d => ({label: d, value: d}))}
                selectedValues={filters.district}
              />

              {/* City / Town search */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਸ਼ਹਿਰ ਜਾਂ ਪਿੰਡ (City / Town)' : 'City or Town Name'}
                </label>
                <div className="relative">
                  <input
                    type="text"
                    value={filters.cityLocation}
                    onChange={(e) => onChange({ cityLocation: e.target.value })}
                    placeholder="e.g. Batala, Dinanagar, Phagwara, Kharar"
                    className="w-full text-xs font-medium p-2.5 pr-8 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
                  />
                  {filters.cityLocation && (
                    <button
                      type="button"
                      onClick={() => onChange({ cityLocation: '' })}
                      className="absolute right-2.5 top-2.5 text-gray-400 hover:text-gray-600"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* 5. MAHASHA GOTRA & CASTE */}
        <div className="pt-4 space-y-3">
          <button
            type="button"
            onClick={() => toggleSection('gotra')}
            className="w-full flex items-center justify-between text-left group"
          >
            <div className="flex items-center gap-2">
              <div className="p-1.5 bg-purple-50 rounded-lg text-purple-700 group-hover:bg-purple-100 transition-colors">
                <Users className="w-4 h-4" />
              </div>
              <span className="text-xs font-bold text-gray-900 uppercase tracking-wider">
                {isPa ? 'ਮਹਾਸ਼ਾ ਗੋਤਰ (Gotra Match)' : 'Mahasha Gotra Match'}
              </span>
              {(filters.fatherGotra !== 'Any' || filters.motherGotra !== 'Any') && (
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              )}
            </div>
            {openSections.gotra ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </button>

          {openSections.gotra && (
            <div className="space-y-3 pt-1 animate-in fade-in duration-200">
              {/* Father Gotra */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਪਿਤਾ ਦਾ ਗੋਤਰ (Father Gotra)' : 'Father Gotra'}
                </label>
                <select
                  value={filters.fatherGotra}
                  onChange={(e) => onChange({ fatherGotra: e.target.value })}
                  className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden font-medium"
                >
                  <option value="Any">{isPa ? 'ਸਾਰੇ ਮਹਾਸ਼ਾ ਗੋਤਰ (All Gotras)' : 'All Mahasha Gotras'}</option>
                  {MAHASHA_GOTRAS.map((g) => (
                    <option key={g.value} value={g.value}>
                      {g.label}
                    </option>
                  ))}
                </select>
              </div>

              {/* Mother Gotra */}
              <div>
                <label className="block text-[11px] font-semibold text-gray-600 mb-1">
                  {isPa ? 'ਮਾਤਾ ਦਾ ਗੋਤਰ (Mother Gotra)' : 'Mother Gotra'}
                </label>
                <select
                  value={filters.motherGotra}
                  onChange={(e) => onChange({ motherGotra: e.target.value })}
                  className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden font-medium"
                >
                  <option value="Any">{isPa ? 'ਕੋਈ ਵੀ ਮਾਤਾ ਗੋਤਰ (Any Mother Gotra)' : 'Any Mother Gotra'}</option>
                  {MAHASHA_GOTRAS.map((g) => (
                    <option key={g.value} value={g.value}>
                      {g.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>
          )}
        </div>

        {/* 6. VERIFICATION & PREFERENCES TOGGLES */}
        <div className="pt-4 space-y-2.5">
          <div className="text-xs font-bold text-gray-900 uppercase tracking-wider mb-2">
            {isPa ? 'ਭਰੋਸੇਯੋਗਤਾ ਅਤੇ ਫੋਟੋ (Trust & Media)' : 'Trust & Media Filters'}
          </div>

          <label className="flex items-center justify-between p-2.5 bg-emerald-50/70 border border-emerald-200 rounded-xl cursor-pointer hover:bg-emerald-100/70 transition-colors">
            <span className="flex items-center gap-2 text-xs font-bold text-emerald-950">
              <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>{isPa ? 'ਸਿਰਫ਼ ਪ੍ਰਮਾਣਿਤ ਬਾਇਓਡਾਟਾ' : 'Verified Profiles Only'}</span>
            </span>
            <input
              type="checkbox"
              checked={filters.verifiedOnly}
              onChange={(e) => onChange({ verifiedOnly: e.target.checked })}
              className="w-4 h-4 text-emerald-600 rounded-md focus:ring-emerald-500"
            />
          </label>

          <label className="flex items-center justify-between p-2.5 bg-rose-50/70 border border-rose-200 rounded-xl cursor-pointer hover:bg-rose-100/70 transition-colors">
            <span className="flex items-center gap-2 text-xs font-bold text-rose-950">
              <Camera className="w-4 h-4 text-rose-600 shrink-0" />
              <span>{isPa ? 'ਸਿਰਫ਼ ਫੋਟੋ ਵਾਲੇ ਪ੍ਰੋਫਾਈਲ' : 'With Photo Only'}</span>
            </span>
            <input
              type="checkbox"
              checked={filters.withPhotoOnly}
              onChange={(e) => onChange({ withPhotoOnly: e.target.checked })}
              className="w-4 h-4 text-rose-600 rounded-md focus:ring-rose-500"
            />
          </label>
        </div>

        {/* 7. MARITAL STATUS & DEMOGRAPHICS */}
        <div className="pt-4 space-y-3">
          <button
            type="button"
            onClick={() => toggleSection('demographics')}
            className="w-full flex items-center justify-between text-left group"
          >
            <span className="text-xs font-bold text-gray-700 uppercase tracking-wider">
              {isPa ? 'ਵਿਆਹੁਤਾ ਸਥਿਤੀ (Marital Status)' : 'Marital Status'}
            </span>
            {openSections.demographics ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
          </button>

          {openSections.demographics && (
            <div className="pt-1 animate-in fade-in duration-200">
              <select
                value={filters.maritalStatus}
                onChange={(e) => onChange({ maritalStatus: e.target.value })}
                className="w-full text-xs font-medium p-2.5 rounded-xl border border-gray-300 bg-gray-50 focus:border-amber-500 focus:bg-white focus:ring-1 focus:ring-amber-500 outline-hidden"
              >
                {MARITAL_STATUS_OPTIONS.map((opt) => (
                  <option key={opt.value} value={opt.value}>
                    {opt.label}
                  </option>
                ))}
              </select>
            </div>
          )}
        </div>

      </div>

      {/* Footer Apply button */}
      <div className="p-4 bg-gray-50 border-t border-gray-100 space-y-2">
        {onApply && (
          <button
            type="button"
            onClick={onApply}
            className="w-full bg-gradient-to-r from-amber-500 to-amber-600 text-rose-950 p-3 rounded-xl font-extrabold text-xs shadow-xs hover:from-amber-400 hover:to-amber-500 transition-all flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4" />
            <span>{isPa ? 'ਫਿਲਟਰ ਲਾਗੂ ਕਰੋ' : 'Apply Filters'}</span>
          </button>
        )}
        
        {activeCount > 0 && (
          <button
            type="button"
            onClick={onReset}
            className="w-full text-center text-xs font-bold text-gray-600 hover:text-rose-900 py-1.5 transition-colors"
          >
            {isPa ? 'ਸਾਰੇ ਫਿਲਟਰ ਸਾਫ਼ ਕਰੋ (Clear All)' : 'Clear All Filter Criteria'}
          </button>
        )}
      </div>

    </div>
  );
}
