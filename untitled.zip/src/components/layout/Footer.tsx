import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-rose-950 text-rose-100 pt-16 pb-8 border-t border-amber-500/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
          
          {/* Brand */}
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <div className="bg-rose-900 p-2 rounded-lg backdrop-blur-sm border border-amber-500/30">
                <Heart className="h-6 w-6 text-amber-400 fill-amber-400" />
              </div>
              <span className="text-2xl font-bold text-white font-serif">Sangam</span>
            </div>
            <p className="text-rose-200/90 text-sm leading-relaxed mt-4">
              Finding your perfect match has never been easier. We bring communities together with trust, security, and smart matchmaking.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-amber-400 font-semibold mb-4 uppercase tracking-wider text-sm">Quick Links</h3>
            <ul className="space-y-3 text-sm text-rose-200/90">
              <li><a href="#" className="hover:text-amber-400 transition-colors">About Us</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Success Stories</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Premium Membership</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Community Blog</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Contact Support</a></li>
            </ul>
          </div>

          {/* Legal */}
          <div>
            <h3 className="text-amber-400 font-semibold mb-4 uppercase tracking-wider text-sm">Legal & Privacy</h3>
            <ul className="space-y-3 text-sm text-rose-200/90">
              <li><a href="#" className="hover:text-amber-400 transition-colors">Privacy Policy</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Terms & Conditions</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Cookie Policy</a></li>
              <li><a href="#" className="hover:text-amber-400 transition-colors">Safety Guidelines</a></li>
            </ul>
          </div>

          {/* Contact */}
          <div>
            <h3 className="text-amber-400 font-semibold mb-4 uppercase tracking-wider text-sm">Contact Us</h3>
            <ul className="space-y-3 text-sm text-rose-200/90">
              <li className="flex items-center gap-3">
                <Mail className="h-4 w-4 text-amber-400" />
                support@sangam.com
              </li>
              <li className="flex items-center gap-3">
                <Phone className="h-4 w-4 text-amber-400" />
                +1 (555) 123-4567
              </li>
              <li className="flex items-center gap-3">
                <MapPin className="h-4 w-4 text-amber-400" />
                Global HQ, 123 Match Ave
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-rose-900/80 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-rose-300">
          <p>© {new Date().getFullYear()} Sangam Matrimonial. All rights reserved.</p>
          <div className="flex gap-4">
            {/* Using text for icons right now if they aren't imported properly */}
            <a href="#" className="hover:text-amber-400 transition-colors">Facebook</a>
            <a href="#" className="hover:text-amber-400 transition-colors">Twitter</a>
            <a href="#" className="hover:text-amber-400 transition-colors">Instagram</a>
          </div>
        </div>
      </div>
    </footer>
  );
}
