import { Link, useNavigate } from 'react-router-dom';
import { Heart, Menu, User, LogOut } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { useLanguage } from '../../contexts/LanguageContext';
import LanguageSelector from './LanguageSelector';
import { useState } from 'react';

export default function Navbar() {
  const { user, logout } = useAuth();
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  const handleLogout = async () => {
    await logout();
    navigate('/');
  };

  return (
    <nav className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link to="/" className="flex items-center gap-2.5">
              <div className="bg-rose-900 p-2 rounded-lg shadow-sm border border-amber-500/30">
                <Heart className="h-6 w-6 text-amber-400 fill-amber-400" />
              </div>
              <div className="flex flex-col">
                <span className="text-2xl font-bold text-rose-950 font-serif leading-none">Sangam</span>
                <span className="text-[11px] font-bold text-amber-700 tracking-wide mt-0.5 font-sans">ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ</span>
              </div>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-6">
            <Link to="/" className="text-gray-600 hover:text-rose-900 font-medium transition-colors">{t.navHome}</Link>
            <Link to="/matches" className="text-gray-600 hover:text-rose-900 font-medium transition-colors">{t.navMatches}</Link>
            <Link to="/#stories" className="text-gray-600 hover:text-rose-900 font-medium transition-colors">{t.navStories}</Link>
            
            {/* Language Selector Button */}
            <LanguageSelector variant="navbar" />

            {user ? (
              <div className="flex items-center gap-3 ml-2 pl-4 border-l border-gray-200">
                <Link to="/dashboard" className="flex items-center gap-2 text-rose-900 font-bold hover:text-rose-700">
                  <User className="h-4 w-4 text-amber-600" />
                  {t.navDashboard}
                </Link>
                <button 
                  onClick={handleLogout}
                  className="p-2 text-gray-500 hover:text-rose-700 transition-colors"
                  title={t.navLogout}
                >
                  <LogOut className="h-5 w-5" />
                </button>
              </div>
            ) : (
              <div className="flex items-center gap-3 ml-2 pl-4 border-l border-gray-200">
                <Link 
                  to="/login" 
                  className="text-rose-900 font-semibold hover:text-rose-700 transition-colors px-3 py-1.5"
                >
                  {t.navLogin}
                </Link>
                <Link 
                  to="/register" 
                  className="bg-amber-500 hover:bg-amber-400 text-rose-950 px-5 py-2 rounded-full font-bold transition-all shadow-sm shadow-amber-500/20 text-sm"
                >
                  {t.navRegister}
                </Link>
              </div>
            )}
          </div>

          {/* Mobile menu and language button */}
          <div className="flex items-center gap-2 md:hidden">
            <LanguageSelector variant="navbar" />
            <button 
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              className="text-gray-600 hover:text-rose-900 p-2"
              aria-label="Toggle menu"
            >
              <Menu className="h-6 w-6" />
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 px-4 pt-2 pb-4 space-y-1 shadow-lg">
          <Link 
            to="/" 
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-rose-900 hover:bg-rose-50 rounded-md"
          >
            {t.navHome}
          </Link>
          <Link 
            to="/matches" 
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-rose-900 hover:bg-rose-50 rounded-md"
          >
            {t.navMatches}
          </Link>
          <Link 
            to="/#stories" 
            onClick={() => setIsMobileMenuOpen(false)}
            className="block px-3 py-2 text-base font-medium text-gray-700 hover:text-rose-900 hover:bg-rose-50 rounded-md"
          >
            {t.navStories}
          </Link>
          
          {/* Mobile Language Selection Buttons */}
          <LanguageSelector variant="mobile" />

          {user ? (
            <>
              <Link 
                to="/dashboard" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="block px-3 py-2 text-base font-medium text-rose-900 bg-rose-50 rounded-md"
              >
                {t.navDashboard}
              </Link>
              <button 
                onClick={() => {
                  setIsMobileMenuOpen(false);
                  handleLogout();
                }} 
                className="block w-full text-left px-3 py-2 text-base font-medium text-rose-700 hover:bg-rose-50 rounded-md"
              >
                {t.navLogout}
              </button>
            </>
          ) : (
            <div className="mt-4 pt-4 border-t border-gray-100 flex flex-col gap-2">
              <Link 
                to="/login" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="block w-full text-center px-4 py-2 font-medium text-rose-900 border border-rose-900 rounded-md"
              >
                {t.navLogin}
              </Link>
              <Link 
                to="/register" 
                onClick={() => setIsMobileMenuOpen(false)}
                className="block w-full text-center px-4 py-2 font-bold text-rose-950 bg-amber-500 hover:bg-amber-400 rounded-md shadow-sm"
              >
                {t.navRegister}
              </Link>
            </div>
          )}
        </div>
      )}
    </nav>
  );
}
