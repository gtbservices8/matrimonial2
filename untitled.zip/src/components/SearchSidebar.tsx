import React from 'react';
import { Search, Filter } from 'lucide-react';

export interface FilterState {
  gender: string;
  minAge: string;
  maxAge: string;
  community: string;
  profession: string;
  location: string;
}

interface SearchSidebarProps {
  filters: FilterState;
  onChange: (e: React.ChangeEvent<HTMLSelectElement | HTMLInputElement>) => void;
  onSearch: (e: React.FormEvent) => void;
  buttonLabel?: string;
}

export default function SearchSidebar({ filters, onChange, onSearch, buttonLabel = "Apply Filters" }: SearchSidebarProps) {
  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 sticky top-24">
      <div className="flex items-center justify-between mb-6 border-b border-gray-100 pb-4">
        <div className="flex items-center gap-2">
          <Filter className="w-5 h-5 text-rose-900" />
          <h2 className="text-lg font-bold text-gray-900">ਮਹਾਸ਼ਾ ਫਿਲਟਰ</h2>
        </div>
        <span className="text-[11px] font-bold bg-amber-100 text-rose-950 px-2.5 py-0.5 rounded-full border border-amber-300">
          ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ
        </span>
      </div>
      
      <form onSubmit={onSearch} className="space-y-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-1">Looking for</label>
            <select 
              name="gender" 
              value={filters.gender}
              onChange={onChange}
              className="w-full border-gray-300 rounded-lg shadow-sm focus:border-amber-500 focus:ring-amber-500 p-2.5 bg-gray-50 border"
            >
              <option value="Any">Any</option>
              <option value="Bride">Bride (Female)</option>
              <option value="Groom">Groom (Male)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Age Range</label>
            <div className="flex items-center gap-2">
              <input 
                type="number"
                name="minAge"
                value={filters.minAge}
                onChange={onChange}
                className="w-full border-gray-300 rounded-lg shadow-sm p-2.5 bg-gray-50 border focus:border-amber-500 focus:ring-amber-500" 
                min="18" 
              />
              <span className="text-gray-400">to</span>
              <input 
                type="number"
                name="maxAge"
                value={filters.maxAge}
                onChange={onChange}
                className="w-full border-gray-300 rounded-lg shadow-sm p-2.5 bg-gray-50 border focus:border-amber-500 focus:ring-amber-500" 
                max="70" 
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Location</label>
            <input 
              type="text"
              name="location"
              placeholder="e.g. Delhi, Punjab, Toronto"
              value={filters.location}
              onChange={onChange}
              className="w-full border-gray-300 rounded-lg shadow-sm focus:border-amber-500 focus:ring-amber-500 p-2.5 bg-gray-50 border" 
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">ਮਹਾਸ਼ਾ ਗੋਤਰ (Gotra)</label>
            <select 
              name="community"
              value={filters.community}
              onChange={onChange}
              className="w-full border-gray-300 rounded-lg shadow-sm focus:border-amber-500 focus:ring-amber-500 p-2.5 bg-gray-50 border font-medium"
            >
              <option value="Any">ਸਾਰੇ ਮਹਾਸ਼ਾ ਗੋਤਰ (All Gotras)</option>
              <option value="Kaler">ਕਲੇਰ (Kaler)</option>
              <option value="Badhan">ਬੱਧਣ (Badhan)</option>
              <option value="Banga">ਬੰਗਾ (Banga)</option>
              <option value="Kundal">ਕੁੰਡਲ (Kundal)</option>
              <option value="Ghotra">ਘੋਤੜਾ (Ghotra)</option>
              <option value="Karloopia">ਕਰਲੂਪੀਆ (Karloopia)</option>
              <option value="Hans">ਹੰਸ (Hans)</option>
              <option value="Taak">ਟਾਕ (Taak)</option>
              <option value="Kajla">ਕਾਜਲਾ (Kajla)</option>
              <option value="Suman">ਸੁਮਨ (Suman)</option>
              <option value="Nahar">ਨਾਹਰ (Nahar)</option>
              <option value="Bhatti">ਭੱਟੀ (Bhatti)</option>
              <option value="Chumber">ਚੁੰਬਰ (Chumber)</option>
              <option value="Gill">ਗਿੱਲ (Gill)</option>
              <option value="Sandhu">ਸੰਧੂ (Sandhu)</option>
            </select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Profession (ਪੇਸ਼ਾ)</label>
            <select 
              name="profession"
              value={filters.profession}
              onChange={onChange}
              className="w-full border-gray-300 rounded-lg shadow-sm focus:border-amber-500 focus:ring-amber-500 p-2.5 bg-gray-50 border font-medium"
            >
              <option value="Any">ਸਾਰੇ ਪੇਸ਼ੇ (Any Profession)</option>
              <option value="Software Engineer">ਸਾਫਟਵੇਅਰ ਇੰਜੀਨੀਅਰ (Software Engineer)</option>
              <option value="Doctor">ਡਾਕਟਰ (Doctor / Healthcare)</option>
              <option value="Business">ਕਾਰੋਬਾਰ (Business / Trader)</option>
              <option value="Teacher">ਅਧਿਆਪਕ (Teacher / Professor)</option>
              <option value="Government Job">ਸਰਕਾਰੀ ਨੌਕਰੀ (Government Job)</option>
            </select>
          </div>

          <button 
            type="submit" 
            className="w-full bg-amber-500 hover:bg-amber-400 text-rose-950 p-3 rounded-lg font-bold transition-all shadow-sm shadow-amber-500/20 flex items-center justify-center gap-2"
          >
            <Search className="w-4 h-4" />
            {buttonLabel}
          </button>
        </form>
    </div>
  );
}
