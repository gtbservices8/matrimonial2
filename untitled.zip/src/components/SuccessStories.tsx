import { useState } from 'react';
import { Heart, Star, MapPin, Calendar, Quote, ArrowRight, X, Sparkles, CheckCircle2, Send, PartyPopper } from 'lucide-react';
import { useLanguage } from '../contexts/LanguageContext';

interface SuccessStory {
  id: string;
  coupleName: string;
  brideName: string;
  groomName: string;
  weddingDate: string;
  location: string;
  community: string;
  ceremonyType: string;
  ceremonyTypePa: string;
  image: string;
  summary: string;
  fullStory: string;
  rating: number;
}

const SUCCESS_STORIES: SuccessStory[] = [
  {
    id: 'story-1',
    coupleName: 'Harpreet & Simranjit',
    brideName: 'Simranjit Kaur Kaler',
    groomName: 'Harpreet Singh Badhan',
    weddingDate: 'November 2024',
    location: 'Amritsar & Chandigarh',
    community: 'Mahasha (Kaler & Badhan)',
    ceremonyType: 'Anand Karaj Ceremony',
    ceremonyTypePa: 'ਅਨੰਦ ਕਾਰਜ ਸਮਾਰੋਹ',
    image: 'https://images.unsplash.com/photo-1610173827002-62c0f1f1d1eb?q=80&w=900&auto=format&fit=crop',
    summary: 'ਸੰਗਮ ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਰਾਹੀਂ ਸਾਡਾ ਰਿਸ਼ਤਾ ਤੈਅ ਹੋਇਆ। ਪਹਿਲੀ ਪਰਿਵਾਰਕ ਮੁਲਾਕਾਤ ਤੋਂ ਲੈ ਕੇ ਅਨੰਦ ਕਾਰਜ ਤੱਕ ਦੋਹਾਂ ਪਰਿਵਾਰਾਂ ਵਿੱਚ ਪੂਰਾ ਆਦਰ-ਸਤਿਕਾਰ ਬਣਿਆ ਰਿਹਾ।',
    fullStory: 'Simranjit and I both registered on Sangam Mahasha Matrimonial after recommendation from our community elders. What stood out immediately was that all profiles were strictly from the Mahasha Samaj with thorough verification. After our parents discussed gotra compatibility and initiated contact, our families met in Chandigarh. Within three months, our families arranged the Anand Karaj at Amritsar. Thank you Sangam for bringing our Mahasha families together!',
    rating: 5,
  },
  {
    id: 'story-2',
    coupleName: 'Gurinder & Amanpreet',
    brideName: 'Amanpreet Kaur Kundal',
    groomName: 'Gurinder Singh Banga',
    weddingDate: 'October 2024',
    location: 'Ludhiana ↔ Toronto, Canada',
    community: 'Mahasha (Kundal & Banga)',
    ceremonyType: 'Traditional Wedding Ceremony',
    ceremonyTypePa: 'ਵਿਆਹ ਮੰਡਪ ਰਸਮਾਂ',
    image: 'https://images.unsplash.com/photo-1544161515-4ab6ce6db874?q=80&w=900&auto=format&fit=crop',
    summary: 'ਕੈਨੇਡਾ ਵਿੱਚ ਰਹਿੰਦਿਆਂ ਆਪਣੀ ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ ਦਾ ਸੁਚੱਜਾ ਅਤੇ ਸੱਭਿਆਚਾਰਕ ਰਿਸ਼ਤਾ ਲੱਭਣਾ ਸਾਡੀ ਪਹਿਲ ਸੀ। ਸੰਗਮ ਮਹਾਸ਼ਾ ਪੋਰਟਲ ਨੇ ਸਾਡਾ ਸੁਪਨਾ ਪੂਰਾ ਕੀਤਾ।',
    fullStory: 'Living in Toronto, I was looking for a partner who deeply valued our Mahasha cultural heritage while embracing professional modern life. Amanpreet\'s profile in Ludhiana matched our criteria. The transparent gotra information and family background verification gave both families complete peace of mind. We tied the knot in Ludhiana surrounded by our loved ones.',
    rating: 5,
  },
  {
    id: 'story-3',
    coupleName: 'Vikram & Dr. Meenakshi',
    brideName: 'Dr. Meenakshi Karloopia',
    groomName: 'Vikram Ghotra',
    weddingDate: 'January 2025',
    location: 'Jammu & Delhi',
    community: 'Mahasha (Ghotra & Karloopia)',
    ceremonyType: 'Varmala & Reception',
    ceremonyTypePa: 'ਜੈਮਾਲਾ ਤੇ ਰਿਸੈਪਸ਼ਨ ਫੰਕਸ਼ਨ',
    image: 'https://images.unsplash.com/photo-1607190074257-dd4b7af0309f?q=80&w=900&auto=format&fit=crop',
    summary: 'ਮਹਾਸ਼ਾ ਸਮਾਜ ਵਿੱਚ ਡਾਕਟਰ ਅਤੇ ਸਾਫਟਵੇਅਰ ਪੇਸ਼ੇਵਰ ਸਾਥੀ ਲੱਭਣਾ ਬਹੁਤ ਆਸਾਨ ਹੋ ਗਿਆ। ਸਾਡੇ ਸ਼ਾਨਦਾਰ ਵਿਆਹ ਫੰਕਸ਼ਨ ਵਿੱਚ ਦੋਵੇਂ ਪਰਿਵਾਰ ਬਹੁਤ ਖੁਸ਼ ਹਨ।',
    fullStory: 'Being medical and software professionals from Jammu and Delhi, we needed an authentic platform dedicated to the Mahasha community. Sangam\'s gotra filters and detailed profiles helped us connect effortlessly. Our grand wedding reception in Delhi was attended by both families with immense joy. Truly a blessed match!',
    rating: 5,
  },
  {
    id: 'story-4',
    coupleName: 'Jasmeet & Navneet',
    brideName: 'Navneet Kaur Taak',
    groomName: 'Jasmeet Singh Hans',
    weddingDate: 'December 2024',
    location: 'Jalandhar ↔ London, UK',
    community: 'Mahasha (Hans & Taak)',
    ceremonyType: 'Grand Wedding Celebration',
    ceremonyTypePa: 'ਸ਼ਾਨਦਾਰ ਵਿਆਹ ਸਮਾਗਮ',
    image: 'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=900&auto=format&fit=crop',
    summary: 'ਪ੍ਰਾਈਵੇਸੀ ਅਤੇ ਪ੍ਰਮਾਣਿਤ ਮਹਾਸ਼ਾ ਪ੍ਰੋਫਾਈਲਾਂ ਸਦਕਾ ਸਾਡੇ ਪਰਿਵਾਰਾਂ ਨੂੰ ਪੂਰਾ ਵਿਸ਼ਵਾਸ ਮਿਲਿਆ। ਜਲੰਧਰ ਵਿਖੇ ਸਾਡਾ ਸ਼ਾਨਦਾਰ ਵਿਆਹ ਸਮਾਗਮ ਹੋਇਆ।',
    fullStory: 'Our parents were very cautious about finding a match strictly within the Mahasha community with verified family values. Sangam\'s secure privacy filters gave them complete confidence. Our wedding celebration in Jalandhar was filled with bhangra, warmth, and unforgettable memories!',
    rating: 5,
  },
];

export default function SuccessStories() {
  const { language } = useLanguage();
  const [selectedStory, setSelectedStory] = useState<SuccessStory | null>(null);
  const [showSubmitModal, setShowSubmitModal] = useState(false);
  const [submittedFeedback, setSubmittedFeedback] = useState(false);

  const localizedTitles = {
    pa: {
      badge: 'ਮਹਾਸ਼ਾ ਸਮਾਜ ਦੇ ਵਿਆਹ ਸਮਾਗਮਾਂ ਦੀਆਂ ਸੱਚੀਆਂ ਕਹਾਣੀਆਂ',
      title: 'Real Mahasha Weddings.',
      titleHighlight: 'ਮਹਾਸ਼ਾ ਸਫਲ ਵਿਆਹ ਕਹਾਣੀਆਂ',
      subtitle: 'ਸੰਗਮ ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਰਾਹੀਂ ਇੱਕ-ਦੂਜੇ ਨੂੰ ਮਿਲੇ ਮਹਾਸ਼ਾ ਜੋੜਿਆਂ ਦੇ ਵਿਆਹ ਫੰਕਸ਼ਨ, ਅਨੰਦ ਕਾਰਜ ਅਤੇ ਰਿਸੈਪਸ਼ਨ ਦੀਆਂ ਖੂਬਸੂਰਤ ਯਾਦਾਂ।',
      readFull: 'ਪੂਰੀ ਕਹਾਣੀ ਪੜ੍ਹੋ',
      shareStoryBtn: 'ਆਪਣਾ ਵਿਆਹ ਫੰਕਸ਼ਨ ਸਾਂਝਾ ਕਰੋ',
      shareStoryTitle: 'ਕੀ ਤੁਹਾਡਾ ਰਿਸ਼ਤਾ ਵੀ ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀ ਰਾਹੀਂ ਹੋਇਆ?',
      shareStoryDesc: 'ਆਪਣੀ ਵਿਆਹ ਫੋਟੋ ਅਤੇ ਕਹਾਣੀ ਸਾਂਝੀ ਕਰੋ ਅਤੇ ਸੰਗਮ ਟੀਮ ਵੱਲੋਂ ਸ਼ਗਨ ਦਾ ਤੋਹਫ਼ਾ ਪ੍ਰਾਪਤ ਕਰੋ।'
    },
    hi: {
      badge: 'महाशा समुदाय के विवाह समारोह की सच्ची कहानियाँ',
      title: 'Real Mahasha Weddings.',
      titleHighlight: 'महाशा सफल वैवाहिक कहानियाँ',
      subtitle: 'संगम महाशा मैट्रिमोनियल के माध्यम से मिले जोड़ों के विवाह समारोह और फेरों की खूबसूरत स्मृतियाँ।',
      readFull: 'पूरी कहानी पढ़ें',
      shareStoryBtn: 'अपनी शादी की कहानी साझा करें',
      shareStoryTitle: 'क्या आपका रिश्ता भी महाशा मैट्रिमनी से तय हुआ?',
      shareStoryDesc: 'अपनी शादी के समारोह की तस्वीरें साझा करें और विशेष उपहार प्राप्त करें।'
    },
    en: {
      badge: 'Mahasha Community Wedding Functions & Ceremonies',
      title: 'Real Mahasha Couples.',
      titleHighlight: 'Real Success Stories.',
      subtitle: 'Cherished memories from Anand Karaj, Mandap ceremonies, and wedding receptions of Mahasha couples who met on Sangam.',
      readFull: 'Read Full Journey',
      shareStoryBtn: 'Share Your Story',
      shareStoryTitle: 'Did You Find Your Match on Mahasha Matrimonial?',
      shareStoryDesc: 'Share your wedding function memories, inspire other families, and receive a special gift hamper.'
    }
  };

  const currentText = localizedTitles[language] || localizedTitles.pa;

  return (
    <section className="py-20 bg-white relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Section Header */}
        <div className="text-center max-w-3xl mx-auto mb-16">
          <div className="inline-flex items-center gap-2 bg-rose-50 border border-rose-200/80 px-4 py-1.5 rounded-full text-xs font-bold text-rose-900 mb-3 shadow-xs">
            <Heart className="w-3.5 h-3.5 fill-rose-900 text-rose-900" />
            <span>{currentText.badge}</span>
          </div>
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 font-serif tracking-tight">
            {currentText.title} <span className="text-rose-900">{currentText.titleHighlight}</span>
          </h2>
          <p className="text-gray-600 mt-3 text-base sm:text-lg leading-relaxed">
            {currentText.subtitle}
          </p>
        </div>

        {/* Story Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {SUCCESS_STORIES.map((story) => (
            <div 
              key={story.id}
              className="bg-white rounded-2xl border border-amber-100 shadow-sm hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col group"
            >
              {/* Wedding Function Image & Badges */}
              <div className="relative h-60 w-full overflow-hidden bg-rose-950">
                <img 
                  src={story.image} 
                  alt={`${story.coupleName} Wedding Ceremony`}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-700 brightness-95" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-rose-950/90 via-rose-950/30 to-transparent" />
                
                {/* Top Tags: Community & Rating */}
                <div className="absolute top-3 left-3 right-3 flex items-center justify-between z-10">
                  <span className="bg-white/95 backdrop-blur-xs text-rose-950 text-xs font-bold px-2.5 py-1 rounded-full shadow-xs">
                    {story.community}
                  </span>

                  <div className="bg-rose-950/80 backdrop-blur-xs px-2 py-1 rounded-full flex items-center gap-1 border border-amber-400/30">
                    <div className="flex">
                      {[...Array(story.rating)].map((_, i) => (
                        <Star key={i} className="w-3 h-3 text-amber-400 fill-amber-400" />
                      ))}
                    </div>
                  </div>
                </div>

                {/* Wedding Function Badge */}
                <div className="absolute bottom-14 left-3 z-10">
                  <span className="inline-flex items-center gap-1.5 bg-amber-400/95 backdrop-blur-xs text-rose-950 text-[11px] font-bold px-2.5 py-1 rounded-full shadow-md border border-amber-300">
                    <PartyPopper className="w-3 h-3 text-rose-900" />
                    <span>{language === 'pa' ? story.ceremonyTypePa : story.ceremonyType}</span>
                  </span>
                </div>

                {/* Bottom Overlay Info */}
                <div className="absolute bottom-3 left-3 right-3 text-white z-10">
                  <h3 className="font-serif font-bold text-lg leading-tight text-white drop-shadow-xs">
                    {story.coupleName}
                  </h3>
                  <div className="flex items-center gap-2 text-xs text-amber-200/95 mt-0.5">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-3 h-3 text-amber-400" /> {story.location}
                    </span>
                  </div>
                </div>
              </div>

              {/* Story Content */}
              <div className="p-5 flex-1 flex flex-col justify-between bg-white">
                <div>
                  <div className="flex items-center gap-1.5 text-xs text-gray-500 mb-3">
                    <Calendar className="w-3.5 h-3.5 text-rose-900" />
                    <span>Married: {story.weddingDate}</span>
                  </div>
                  
                  <div className="relative mb-4">
                    <Quote className="w-6 h-6 text-amber-300 absolute -top-1 -left-1 opacity-40" />
                    <p className="text-gray-600 text-xs sm:text-sm leading-relaxed relative z-10 italic pl-3">
                      "{story.summary}"
                    </p>
                  </div>
                </div>

                {/* Action button */}
                <div className="pt-3 border-t border-gray-100 flex items-center justify-between">
                  <button
                    onClick={() => setSelectedStory(story)}
                    className="text-xs font-bold text-rose-900 hover:text-rose-700 flex items-center gap-1 group-hover:gap-1.5 transition-all"
                  >
                    {currentText.readFull} <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <span className="text-xs text-emerald-700 font-semibold flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Verified
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Share Your Story CTA Banner */}
        <div className="bg-gradient-to-r from-rose-950 via-rose-900 to-rose-950 rounded-2xl p-6 sm:p-8 text-white border border-amber-500/20 shadow-lg flex flex-col sm:flex-row items-center justify-between gap-6">
          <div className="text-center sm:text-left">
            <div className="inline-flex items-center gap-1.5 text-amber-400 text-xs font-bold uppercase tracking-wider mb-1">
              <Sparkles className="w-3.5 h-3.5" />
              {currentText.shareStoryTitle}
            </div>
            <h3 className="text-xl sm:text-2xl font-bold font-serif text-white">
              Inspire Thousands — Share Your Success Story
            </h3>
            <p className="text-rose-200/90 text-sm mt-1 max-w-xl">
              {currentText.shareStoryDesc}
            </p>
          </div>

          <button
            onClick={() => {
              setShowSubmitModal(true);
              setSubmittedFeedback(false);
            }}
            className="flex-shrink-0 bg-amber-500 hover:bg-amber-400 text-rose-950 px-6 py-3 rounded-xl font-bold text-sm transition-all shadow-md shadow-amber-500/20 flex items-center gap-2"
          >
            <Heart className="w-4 h-4 fill-rose-950 text-rose-950" />
            {currentText.shareStoryBtn}
          </button>
        </div>

      </div>

      {/* Full Story Modal */}
      {selectedStory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-lg w-full overflow-hidden shadow-2xl border border-amber-200 relative animate-in zoom-in-95 duration-200">
            {/* Header Image */}
            <div className="relative h-48 w-full bg-rose-950">
              <img 
                src={selectedStory.image} 
                alt={selectedStory.coupleName} 
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-rose-950 via-rose-950/40 to-transparent" />
              
              <button 
                onClick={() => setSelectedStory(null)}
                className="absolute top-4 right-4 bg-black/40 hover:bg-black/60 text-white p-2 rounded-full backdrop-blur-xs transition-colors"
                title="Close"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="absolute bottom-4 left-6 right-6 text-white">
                <span className="inline-flex items-center gap-1.5 bg-amber-400 text-rose-950 text-xs font-bold px-2.5 py-0.5 rounded-full mb-1.5 shadow-sm">
                  <PartyPopper className="w-3.5 h-3.5 text-rose-900" />
                  {language === 'pa' ? selectedStory.ceremonyTypePa : selectedStory.ceremonyType}
                </span>
                <h3 className="text-2xl font-bold font-serif text-white">
                  {selectedStory.coupleName}
                </h3>
                <div className="flex items-center gap-3 text-xs text-rose-200 mt-1">
                  <span>{selectedStory.location}</span>
                  <span>•</span>
                  <span>Married: {selectedStory.weddingDate}</span>
                </div>
              </div>
            </div>

            {/* Modal Body */}
            <div className="p-6">
              <div className="flex items-center justify-between mb-4 pb-3 border-b border-gray-100 text-xs text-gray-500">
                <span className="font-semibold text-rose-900 bg-rose-50 px-2.5 py-1 rounded-full border border-rose-200">
                  {selectedStory.community}
                </span>
                <div className="flex items-center gap-1 text-amber-500">
                  {[...Array(selectedStory.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-amber-400" />
                  ))}
                  <span className="ml-1 text-gray-700 font-bold">5.0</span>
                </div>
              </div>

              <div className="prose prose-sm text-gray-700 leading-relaxed max-h-64 overflow-y-auto pr-1">
                <p className="text-sm font-medium text-gray-800 italic mb-3">
                  "{selectedStory.summary}"
                </p>
                <p className="text-sm text-gray-600 leading-relaxed">
                  {selectedStory.fullStory}
                </p>
              </div>

              <div className="mt-6 pt-4 border-t border-gray-100 flex items-center justify-between">
                <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-medium">
                  <CheckCircle2 className="w-4 h-4" /> Authenticated by Sangam Team
                </div>
                <button
                  onClick={() => setSelectedStory(null)}
                  className="bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30 px-5 py-2 rounded-xl text-xs font-bold transition-all shadow-xs"
                >
                  Close Story
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Submit Story Modal */}
      {showSubmitModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-xs">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 shadow-2xl border border-amber-200 relative">
            <button 
              onClick={() => setShowSubmitModal(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-700 p-1 rounded-full"
            >
              <X className="w-5 h-5" />
            </button>

            {submittedFeedback ? (
              <div className="text-center py-8">
                <div className="w-16 h-16 bg-emerald-50 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-200">
                  <Heart className="w-8 h-8 fill-emerald-600" />
                </div>
                <h3 className="text-2xl font-bold font-serif text-gray-900 mb-2">
                  ਧੰਨਵਾਦ! Congratulations!
                </h3>
                <p className="text-gray-600 text-sm leading-relaxed mb-6">
                  Your wedding story has been received. Our editorial team will review your photos and publish it with blessings.
                </p>
                <button
                  onClick={() => setShowSubmitModal(false)}
                  className="bg-rose-900 text-amber-300 px-6 py-2.5 rounded-xl font-bold text-sm hover:bg-rose-800 transition-colors"
                >
                  Done
                </button>
              </div>
            ) : (
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Heart className="w-5 h-5 text-rose-900 fill-rose-900" />
                  <h3 className="text-xl font-bold font-serif text-gray-900">
                    Share Your Wedding Story
                  </h3>
                </div>
                <p className="text-xs text-gray-500 mb-6">
                  Inspire other families with your journey of meeting on Sangam.
                </p>

                <form 
                  onSubmit={(e) => {
                    e.preventDefault();
                    setSubmittedFeedback(true);
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Couple Names (e.g. Harpreet & Simran)</label>
                    <input 
                      required 
                      type="text" 
                      placeholder="Bride & Groom names"
                      className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">Wedding Date</label>
                      <input 
                        required 
                        type="month" 
                        className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-semibold text-gray-700 mb-1">City / Country</label>
                      <input 
                        required 
                        type="text" 
                        placeholder="e.g. Amritsar, Canada"
                        className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-gray-700 mb-1">Your Story & Experience</label>
                    <textarea 
                      required 
                      rows={3} 
                      placeholder="How did you meet? What made your connection special?"
                      className="w-full text-sm border border-gray-300 rounded-xl p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none"
                    ></textarea>
                  </div>

                  <button
                    type="submit"
                    className="w-full bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30 p-3 rounded-xl font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2"
                  >
                    <Send className="w-4 h-4" />
                    Submit Your Story
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      )}

    </section>
  );
}
