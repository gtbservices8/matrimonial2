import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type SupportedLanguage = 'pa' | 'hi' | 'en';

export interface LanguageOption {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  flag: string;
}

export const LANGUAGES: LanguageOption[] = [
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', flag: '🇮🇳' },
  { code: 'hi', name: 'Hindi', nativeName: 'हिन्दी', flag: '🇮🇳' },
  { code: 'en', name: 'English', nativeName: 'English', flag: '🌐' },
];

export interface Translations {
  navHome: string;
  navMatches: string;
  navStories: string;
  navDashboard: string;
  navLogin: string;
  navRegister: string;
  navLogout: string;
  
  heroBadge: string;
  heroTitle1: string;
  heroTitleHighlight: string;
  heroSubtitle: string;
  heroRegisterBtn: string;
  heroExploreBtn: string;

  searchTitle: string;
  searchLookingFor: string;
  searchBride: string;
  searchGroom: string;
  searchAge: string;
  searchCommunity: string;
  searchSelectCommunity: string;
  searchBtn: string;

  verifiedTrustBadge: string;
  culturalValuesBadge: string;
  smartMatchBadge: string;

  languageLabel: string;
}

const TRANSLATIONS: Record<SupportedLanguage, Translations> = {
  pa: {
    navHome: 'ਘਰ',
    navMatches: 'ਰਿਸ਼ਤੇ ਲੱਭੋ',
    navStories: 'ਸਫਲ ਕਹਾਣੀਆਂ',
    navDashboard: 'ਡੈਸ਼ਬੋਰਡ',
    navLogin: 'ਲੌਗਇਨ',
    navRegister: 'ਮੁਫ਼ਤ ਰਜਿਸਟਰ ਕਰੋ',
    navLogout: 'ਲੌਗਆਉਟ',

    heroBadge: 'ਵਿਸ਼ੇਸ਼ ਮਹਾਸ਼ਾ ਬਰਾਦਰੀ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਮੰਚ',
    heroTitle1: 'ਮਹਾਸ਼ਾ ਸਮਾਜ ਵਿੱਚ ਵਿਸ਼ਵਾਸ ਨਾਲ ਲੱਭੋ',
    heroTitleHighlight: 'ਸੰਪੂਰਨ ਜੀਵਨ ਸਾਥੀ',
    heroSubtitle: 'ਸਿਰਫ਼ ਅਤੇ ਸਿਰਫ਼ ਮਹਾਸ਼ਾ ਕਮਿਊਨਿਟੀ ਦੇ ਸੱਚੇ, ਪੜ੍ਹੇ-ਲਿਖੇ ਅਤੇ ਪ੍ਰਮਾਣਿਤ ਪਰਿਵਾਰਾਂ ਲਈ ਸਮਰਪਿਤ ਵਿਸ਼ੇਸ਼ ਵਿਆਹ ਮੰਚ।',
    heroRegisterBtn: "ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀ 'ਤੇ ਮੁਫ਼ਤ ਰਜਿਸਟਰ ਕਰੋ",
    heroExploreBtn: 'ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਵੇਖੋ',

    searchTitle: 'ਤੁਰੰਤ ਮਹਾਸ਼ਾ ਰਿਸ਼ਤਾ ਖੋਜ',
    searchLookingFor: 'ਮੈਂ ਲੱਭ ਰਿਹਾ ਹਾਂ',
    searchBride: 'ਮਹਾਸ਼ਾ ਲਾੜੀ (Bride)',
    searchGroom: 'ਮਹਾਸ਼ਾ ਲਾੜਾ (Groom)',
    searchAge: 'ਉਮਰ ਸੀਮਾ',
    searchCommunity: 'ਮਹਾਸ਼ਾ ਗੋਤਰ (Gotra)',
    searchSelectCommunity: 'ਸਾਰੇ ਮਹਾਸ਼ਾ ਗੋਤਰ (All Gotras)',
    searchBtn: 'ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਲੱਭੋ',

    verifiedTrustBadge: '100% ਪ੍ਰਮਾਣਿਤ ਮਹਾਸ਼ਾ ਪ੍ਰੋਫਾਈਲ',
    culturalValuesBadge: 'ਮਹਾਸ਼ਾ ਸਮਾਜਿਕ ਮਰਿਆਦਾ',
    smartMatchBadge: 'ਗੋਤਰ ਅਤੇ ਕੁੰਡਲੀ ਮੈਚਿੰਗ',

    languageLabel: 'ਭਾਸ਼ਾ',
  },
  hi: {
    navHome: 'होम',
    navMatches: 'रिश्ते खोजें',
    navStories: 'सफलता की कहानियाँ',
    navDashboard: 'डैशबोर्ड',
    navLogin: 'लॉगिन',
    navRegister: 'नि:शुल्क पंजीकरण',
    navLogout: 'लॉगआउट',

    heroBadge: 'विशेष महाशा समुदाय वैवाहिक मंच',
    heroTitle1: 'महाशा समाज में विश्वास के साथ खोजें',
    heroTitleHighlight: 'आदर्श जीवन साथी',
    heroSubtitle: 'विशेष रूप से महाशा बिरादरी के परिवारों के लिए समर्पित विश्वसनीय एवं सुरक्षित वैवाहिक मंच।',
    heroRegisterBtn: 'आज ही निःशुल्क जुड़ें',
    heroExploreBtn: 'महाशा रिश्ते देखें',

    searchTitle: 'त्वरित महाशा रिश्ता खोज',
    searchLookingFor: 'तलाश है',
    searchBride: 'महाशा दुल्हन (Bride)',
    searchGroom: 'महाशा दूल्हा (Groom)',
    searchAge: 'आयु सीमा',
    searchCommunity: 'महाशा गोत्र (Gotra)',
    searchSelectCommunity: 'सभी महाशा गोत्र (All Gotras)',
    searchBtn: 'महाशा रिश्ते खोजें',

    verifiedTrustBadge: '100% सत्यापित महाशा प्रोफाइल',
    culturalValuesBadge: 'महाशा पारिवारिक मूल्य',
    smartMatchBadge: 'गोत्र एवं सटीक अनुकूलता',

    languageLabel: 'भाषा',
  },
  en: {
    navHome: 'Home',
    navMatches: 'Mahasha Matches',
    navStories: 'Success Stories',
    navDashboard: 'Dashboard',
    navLogin: 'Login',
    navRegister: 'Register Free',
    navLogout: 'Logout',

    heroBadge: 'Exclusive Mahasha Community Matrimonial',
    heroTitle1: 'Find Your Blessed Life Partner Within',
    heroTitleHighlight: 'Mahasha Samaj',
    heroSubtitle: 'Exclusively dedicated to connecting verified Mahasha Biradari families across Punjab, Jammu, Delhi, and globally.',
    heroRegisterBtn: 'Register Free in Mahasha Samaj',
    heroExploreBtn: 'Browse Mahasha Profiles',

    searchTitle: 'Quick Mahasha Match Search',
    searchLookingFor: 'Looking for',
    searchBride: 'Mahasha Bride',
    searchGroom: 'Mahasha Groom',
    searchAge: 'Age Range',
    searchCommunity: 'Mahasha Gotra',
    searchSelectCommunity: 'All Mahasha Gotras',
    searchBtn: 'Find Mahasha Matches',

    verifiedTrustBadge: '100% Verified Mahasha Profiles',
    culturalValuesBadge: 'Mahasha Community Traditions',
    smartMatchBadge: 'Gotra Compatibility',

    languageLabel: 'Language',
  }
};

interface LanguageContextType {
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: Translations;
  currentLanguageOption: LanguageOption;
  languages: LanguageOption[];
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    const saved = localStorage.getItem('sangam_lang');
    if (saved === 'pa' || saved === 'hi' || saved === 'en') {
      return saved;
    }
    return 'pa'; // Default to Punjabi as requested
  });

  const setLanguage = (newLang: SupportedLanguage) => {
    setLanguageState(newLang);
    localStorage.setItem('sangam_lang', newLang);
  };

  const t = TRANSLATIONS[language];
  const currentLanguageOption = LANGUAGES.find(l => l.code === language) || LANGUAGES[0];

  return (
    <LanguageContext.Provider value={{
      language,
      setLanguage,
      t,
      currentLanguageOption,
      languages: LANGUAGES,
    }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}
