import { useState, useEffect } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { collection, query, limit, getDocs, startAfter, DocumentData, QueryDocumentSnapshot, where } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { MapPin, Briefcase, Users, UserCircle, ChevronRight, CheckCircle2 } from 'lucide-react';
import { Link, useLocation } from 'react-router-dom';
import SearchSidebar, { FilterState } from '../components/SearchSidebar';

export default function Matches() {
  const locationState = useLocation().state as { filters?: FilterState } | null;
  const [profiles, setProfiles] = useState<DocumentData[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadingMore, setLoadingMore] = useState(false);
  const [lastDoc, setLastDoc] = useState<QueryDocumentSnapshot | null>(null);
  const [hasMore, setHasMore] = useState(true);

  // Filters State
  const [filters, setFilters] = useState<FilterState>(locationState?.filters || {
    gender: 'Any',
    community: 'Any',
    profession: 'Any',
    location: '',
    minAge: '18',
    maxAge: '50'
  });

  const fetchProfiles = async (isLoadMore = false) => {
    if (!isLoadMore) {
      setLoading(true);
      setProfiles([]);
    } else {
      setLoadingMore(true);
    }

    try {
      const profilesRef = collection(db, 'profiles');
      
      let constraints: any[] = [];
      
      if (filters.gender !== 'Any') {
        constraints.push(where('gender', '==', filters.gender));
      }
      if (filters.community !== 'Any') {
        constraints.push(where('community', '==', filters.community));
      }

      constraints.push(limit(12));

      if (isLoadMore && lastDoc) {
        constraints.push(startAfter(lastDoc));
      }

      const q = query(profilesRef, ...constraints);
      const snapshot = await getDocs(q);

      // Client-side filtering for fields that might require complex composite indexes
      let newProfiles: any[] = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      
      if (filters.profession && filters.profession !== 'Any' && filters.profession !== 'Other') {
        const pFilter = filters.profession.toLowerCase().trim();
        newProfiles = newProfiles.filter(p => {
          if (!p.profession) return false;
          const userProf = p.profession.toLowerCase();
          return userProf.includes(pFilter) || pFilter.includes(userProf);
        });
      }
      
      if (filters.location.trim() !== '') {
        const searchLoc = filters.location.toLowerCase();
        newProfiles = newProfiles.filter(p => p.location?.toLowerCase().includes(searchLoc));
      }
      
      if (filters.minAge) {
        const min = parseInt(filters.minAge, 10);
        newProfiles = newProfiles.filter(p => (typeof p.age === 'number' ? p.age >= min : true));
      }
      
      if (filters.maxAge) {
        const max = parseInt(filters.maxAge, 10);
        newProfiles = newProfiles.filter(p => (typeof p.age === 'number' ? p.age <= max : true));
      }

      if (newProfiles.length === 0 && !isLoadMore && snapshot.docs.length === 0) {
        let showcase = [
          {
            id: 'rec-advocate',
            fullName: 'Advocate Navpreet Kaur Bajgal',
            gender: 'Bride',
            age: 26,
            height: '5\' 4"',
            district: 'Gurdaspur',
            location: 'Gurdaspur, Punjab',
            community: 'Mahasha (Bajgal)',
            fatherGotra: 'Bajgal (Bhogal)',
            motherGotra: 'Ghangla',
            qualification1: 'Computer Engineering Diploma',
            qualification2: 'BA.LLB',
            qualification3: 'LLM (Criminology)',
            profession: 'Advocate (PCS-J Prep)',
            occupationDetails: 'Now practicing as an Advocate with her mother & preparation of PCS (J)',
            isVerified: true,
            photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop'
          },
          {
            id: 'rec-1',
            fullName: 'Simranjit Kaur Kaler',
            gender: 'Bride',
            age: 26,
            height: '5\' 4"',
            district: 'SAS Nagar / Mohali',
            location: 'Chandigarh / Mohali',
            community: 'Mahasha (Kaler)',
            fatherGotra: 'Kaler',
            motherGotra: 'Badhan',
            qualification1: 'B.Tech CSE',
            profession: 'Software Engineer',
            isVerified: true,
            photoUrl: 'https://images.unsplash.com/photo-1595922247653-9a3b68832a81?q=80&w=600&auto=format&fit=crop'
          },
          {
            id: 'rec-2',
            fullName: 'Gurinder Singh Badhan',
            gender: 'Groom',
            age: 28,
            height: '5\' 11"',
            district: 'Amritsar',
            location: 'Amritsar ↔ Toronto',
            community: 'Mahasha (Badhan)',
            fatherGotra: 'Badhan',
            motherGotra: 'Kundal',
            qualification1: 'M.S. in Computer Science',
            profession: 'Senior Data Scientist',
            isVerified: true,
            photoUrl: 'https://images.unsplash.com/photo-1610173827002-62c0f1f1d1eb?q=80&w=600&auto=format&fit=crop'
          }
        ];

        if (filters.gender !== 'Any') {
          showcase = showcase.filter(p => p.gender === filters.gender);
        }
        if (filters.community !== 'Any') {
          showcase = showcase.filter(p => p.community === filters.community);
        }
        if (filters.profession && filters.profession !== 'Any') {
          const pFilter = filters.profession.toLowerCase();
          showcase = showcase.filter(p => p.profession.toLowerCase().includes(pFilter));
        }
        if (filters.location) {
          const lFilter = filters.location.toLowerCase();
          showcase = showcase.filter(p => p.location.toLowerCase().includes(lFilter) || (p.district && p.district.toLowerCase().includes(lFilter)));
        }

        newProfiles = showcase;
      }

      if (isLoadMore) {
        setProfiles(prev => [...prev, ...newProfiles]);
      } else {
        setProfiles(newProfiles);
      }

      setLastDoc(snapshot.docs[snapshot.docs.length - 1] || null);
      setHasMore(snapshot.docs.length === 12);
    } catch (error) {
      handleFirestoreError(error, OperationType.LIST, 'profiles');
    } finally {
      setLoading(false);
      setLoadingMore(false);
    }
  };

  useEffect(() => {
    fetchProfiles();
  }, []); // Run on initial mount or when arriving from dashboard

  const handleFilterChange = (e: ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    fetchProfiles(false);
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <div className="bg-rose-950 py-8 border-b border-amber-500/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="inline-flex items-center gap-2 bg-rose-900/80 border border-amber-400/30 px-3 py-1 rounded-full text-xs font-bold text-amber-300 mb-2">
            ਸਿਰਫ਼ ਮਹਾਸ਼ਾ ਸਮਾਜ ਲਈ (Mahasha Biradari Exclusive)
          </div>
          <h1 className="text-3xl font-bold text-white font-serif">ਮਹਾਸ਼ਾ ਰਿਸ਼ਤੇ ਖੋਜੋ (Mahasha Matches)</h1>
          <p className="text-rose-200/90 mt-1">ਮਹਾਸ਼ਾ ਸਮਾਜ ਦੇ ਪ੍ਰਮਾਣਿਤ ਪਰਿਵਾਰਾਂ ਵਿੱਚੋਂ ਆਪਣੇ ਮਨਪਸੰਦ ਗੋਤਰ ਅਤੇ ਯੋਗਤਾ ਅਨੁਸਾਰ ਜੀਵਨ ਸਾਥੀ ਚੁਣੋ।</p>
        </div>
      </div>

      <div className="flex-grow max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 w-full py-8">
        <div className="flex flex-col md:flex-row gap-8">
          
          <aside className="w-full md:w-80 flex-shrink-0">
            <SearchSidebar 
              filters={filters}
              onChange={handleFilterChange}
              onSearch={handleSearch}
            />
          </aside>

          {/* Main Content - Results */}
          <div className="flex-1">
            {loading ? (
              <div className="flex justify-center items-center h-64">
                <div className="animate-spin rounded-full h-10 w-10 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
              </div>
            ) : profiles.length === 0 ? (
              <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-12 text-center">
                <UserCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
                <h3 className="text-xl font-bold text-gray-900 mb-2">No profiles found</h3>
                <p className="text-gray-500">We couldn't find any matches with the selected filters. Try broadening your search.</p>
                <button 
                  onClick={() => {
                    const defaultFilters = { gender: 'Any', community: 'Any', profession: 'Any', location: '', minAge: '18', maxAge: '50' };
                    setFilters(defaultFilters);
                    // fetchProfiles will need to be triggered manually since state updates are async
                  }}
                  className="mt-6 text-rose-900 font-medium hover:text-rose-700 underline"
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                  {profiles.map((profile) => (
                    <div key={profile.id} className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden hover:shadow-md transition-shadow group">
                      <div className="h-48 bg-gray-200 relative overflow-hidden">
                        {/* Placeholder for Profile Photo */}
                        {profile.photoUrl ? (
                          <img src={profile.photoUrl} alt={profile.fullName} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500" />
                        ) : (
                          <div className="w-full h-full flex items-center justify-center bg-rose-50">
                            <UserCircle className="w-20 h-20 text-rose-200" />
                          </div>
                        )}
                        {profile.isVerified && (
                          <div className="absolute top-3 right-3 bg-white/90 backdrop-blur-sm px-2 py-1 rounded-full flex items-center gap-1 text-xs font-semibold text-green-700 shadow-sm">
                            <CheckCircle2 className="w-3.5 h-3.5" /> Verified
                          </div>
                        )}
                      </div>
                      <div className="p-5">
                        <h3 className="text-lg font-bold text-gray-900 mb-1">{profile.fullName}</h3>
                        <div className="text-sm text-gray-500 mb-4">{profile.age || '25'} yrs • {profile.height || '5\'6"'}</div>
                        
                        <div className="space-y-2 mb-6">
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Briefcase className="w-4 h-4 text-gray-400" />
                            <span className="truncate">{profile.profession || 'Not specified'}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <Users className="w-4 h-4 text-gray-400" />
                            <span className="truncate">{profile.community || 'Not specified'}</span>
                          </div>
                          <div className="flex items-center gap-2 text-sm text-gray-600">
                            <MapPin className="w-4 h-4 text-gray-400" />
                            <span className="truncate">{profile.location || 'Not specified'}</span>
                          </div>
                        </div>

                        <Link 
                          to={`/profile/${profile.id}`}
                          className="block w-full text-center bg-gray-50 hover:bg-amber-500 hover:text-rose-950 text-gray-700 border border-gray-200 hover:border-amber-500 py-2.5 rounded-lg font-bold transition-all shadow-sm"
                        >
                          View Profile
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>

                {hasMore && (
                  <div className="mt-10 flex justify-center">
                    <button 
                      onClick={() => fetchProfiles(true)}
                      disabled={loadingMore}
                      className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 px-8 py-3 rounded-full font-medium transition-colors flex items-center gap-2 disabled:opacity-50 hover:border-rose-900 hover:text-rose-900"
                    >
                      {loadingMore ? 'Loading...' : 'Load More Profiles'}
                      {!loadingMore && <ChevronRight className="w-4 h-4" />}
                    </button>
                  </div>
                )}
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
