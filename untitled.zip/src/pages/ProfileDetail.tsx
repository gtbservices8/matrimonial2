import { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { 
  UserCircle, CheckCircle2, MapPin, Briefcase, GraduationCap, 
  Users, Heart, Star, ArrowLeft, ShieldCheck, 
  Calendar, Clock, Phone, Sparkles, MessageCircle, Home,
  Award, BookOpen
} from 'lucide-react';
import type { ProfileData } from '../types';

// Fallback showcase profiles if viewing a demo ID
const SHOWCASE_DETAILS: Record<string, Partial<ProfileData>> = {
  'rec-advocate': {
    id: 'rec-advocate',
    fullName: 'Navpreet Kaur Bajgal',
    gender: 'Bride',
    age: 26,
    height: '5\'4" (162 cm)',
    complexion: 'Fair (ਗੋਰਾ)',
    birthPlace: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    birthTime: '10:15 AM',
    district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    location: 'Civil Lines, Gurdaspur, Punjab',
    religion: 'Hindu',
    community: 'Mahasha (Bajgal)',
    fatherGotra: 'Bajgal (Bhogal)',
    motherGotra: 'Ghangla',
    qualification1: 'Computer Engineering Diploma',
    qualification2: 'BA.LLB',
    qualification3: 'LLM (Criminology)',
    education: 'LLM (Criminology) & BA.LLB',
    profession: 'Advocate / Lawyer',
    occupationDetails: 'Now practicing as an Advocate with her mother & preparation of PCS (J)',
    income: '10-20 Lakhs',
    fatherOccupation: '(Expire) Retired cashier from CPWD',
    motherOccupation: 'Advocate',
    brotherDetails: 'Advocate',
    sisterDetails: 'None',
    familyType: 'Nuclear Family',
    contactNumber: '+91 98765 43210',
    alternateContact: '+91 98123 45678',
    aboutMe: 'Practicing Advocate at District Courts with deep respect for family traditions and high academic aspirations for Judicial Services PCS(J). Looking for an educated, understanding partner from Mahasha community.',
    isVerified: true,
    photoUrl: 'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?q=80&w=600&auto=format&fit=crop'
  }
};

export default function ProfileDetail() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [interestSent, setInterestSent] = useState(false);
  const [isShortlisted, setIsShortlisted] = useState(false);
  const [showContact, setShowContact] = useState(false);

  useEffect(() => {
    async function loadProfile() {
      if (!id) return;
      try {
        setLoading(true);

        // Check if demo profile
        if (SHOWCASE_DETAILS[id]) {
          setProfile(SHOWCASE_DETAILS[id] as ProfileData);
          setLoading(false);
          return;
        }

        const docRef = doc(db, 'profiles', id);
        const docSnap = await getDoc(docRef);

        if (docSnap.exists()) {
          setProfile({ id: docSnap.id, ...docSnap.data() } as ProfileData);
        } else {
          setProfile(null);
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `profiles/${id}`);
      } finally {
        setLoading(false);
      }
    }

    loadProfile();
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }

  if (!profile) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-8 max-w-md w-full text-center">
          <UserCircle className="w-16 h-16 text-gray-300 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2 font-serif">ਪ੍ਰੋਫਾਈਲ ਨਹੀਂ ਮਿਲੀ (Profile Not Found)</h2>
          <p className="text-gray-600 mb-6">ਇਹ ਪ੍ਰੋਫਾਈਲ ਸ਼ਾਇਦ ਹਟਾ ਦਿੱਤੀ ਗਈ ਹੈ ਜਾਂ ਮੌਜੂਦ ਨਹੀਂ ਹੈ।</p>
          <Link 
            to="/matches" 
            className="inline-flex items-center justify-center gap-2 bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30 px-6 py-2.5 rounded-xl font-bold transition-all shadow-sm"
          >
            <ArrowLeft className="w-4 h-4" /> ਵਾਪਸ ਮੈਚਾਂ 'ਤੇ ਜਾਓ (Back to Matches)
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Navigation Bar */}
        <div className="mb-6 flex items-center justify-between">
          <button 
            onClick={() => navigate(-1)}
            className="inline-flex items-center gap-2 text-rose-900 hover:text-rose-700 font-bold transition-colors text-sm"
          >
            <ArrowLeft className="w-4 h-4" /> ਵਾਪਸ (Back to Matches)
          </button>
          <div className="text-xs text-gray-500">
            ਪ੍ਰੋਫਾਈਲ ID: <span className="font-mono text-gray-700">{profile.id?.slice(0, 10)}</span>
          </div>
        </div>

        {/* Hero Card */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 overflow-hidden mb-8">
          <div className="h-36 bg-gradient-to-r from-rose-950 via-rose-900 to-rose-950 relative border-b border-amber-500/20">
            <div className="absolute top-4 right-4 flex gap-2">
              <button 
                onClick={() => setIsShortlisted(!isShortlisted)}
                className={`p-2 rounded-full backdrop-blur-md transition-all ${
                  isShortlisted ? 'bg-amber-500 text-rose-950' : 'bg-white/20 text-white hover:bg-white/30'
                }`}
                title={isShortlisted ? "ਸ਼ਾਰਟਲਿਸਟ ਵਿੱਚੋਂ ਹਟਾਓ" : "ਸ਼ਾਰਟਲਿਸਟ ਵਿੱਚ ਸ਼ਾਮਲ ਕਰੋ"}
              >
                <Star className={`w-5 h-5 ${isShortlisted ? 'fill-rose-950' : ''}`} />
              </button>
            </div>
          </div>

          <div className="px-6 pb-6 pt-0 relative">
            <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 -mt-16 mb-6">
              
              <div className="flex flex-col sm:flex-row items-center sm:items-end gap-5 text-center sm:text-left">
                {/* Avatar */}
                <div className="w-32 h-32 rounded-2xl overflow-hidden bg-white ring-4 ring-white shadow-lg relative flex-shrink-0">
                  {profile.photoUrl ? (
                    <img src={profile.photoUrl} alt={profile.fullName} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-rose-50 flex items-center justify-center border border-amber-200">
                      <UserCircle className="w-24 h-24 text-rose-300" />
                    </div>
                  )}
                  {profile.isVerified && (
                    <div className="absolute bottom-1 right-1 bg-amber-500 text-rose-950 p-1 rounded-full shadow" title="ਪ੍ਰਮਾਣਿਤ ਪ੍ਰੋਫਾਈਲ">
                      <CheckCircle2 className="w-4 h-4" />
                    </div>
                  )}
                </div>

                <div>
                  <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-1">
                    <h1 className="text-2xl md:text-3xl font-bold text-gray-900 font-serif">{profile.fullName}</h1>
                    {profile.isVerified && (
                      <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 text-xs px-2.5 py-0.5 rounded-full font-semibold border border-emerald-200">
                        <ShieldCheck className="w-3.5 h-3.5" /> ਪ੍ਰਮਾਣਿਤ (Verified)
                      </span>
                    )}
                  </div>
                  
                  <p className="text-gray-600 text-sm flex flex-wrap items-center justify-center sm:justify-start gap-2 font-medium">
                    <span>{profile.age ? `${profile.age} ਸਾਲ (${profile.gender})` : '26 ਸਾਲ'}</span>
                    <span>•</span>
                    <span>ਕੱਦ: {profile.height || '5\'4"'}</span>
                    <span>•</span>
                    <span>ਰੰਗ: {profile.complexion || 'Fair (ਗੋਰਾ)'}</span>
                    <span>•</span>
                    <span className="text-rose-900 font-bold">ਪਿਤਾ ਗੋਤਰ: {profile.fatherGotra || 'Bajgal (Bhogal)'}</span>
                  </p>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex flex-wrap items-center justify-center gap-3">
                <button 
                  onClick={() => setInterestSent(!interestSent)}
                  className={`px-5 py-2.5 rounded-xl font-bold flex items-center gap-2 transition-all shadow-sm text-sm ${
                    interestSent 
                      ? 'bg-rose-100 text-rose-900 border border-rose-300'
                      : 'bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30'
                  }`}
                >
                  <Heart className={`w-4 h-4 ${interestSent ? 'fill-rose-900' : 'text-amber-400'}`} />
                  {interestSent ? 'ਰਿਸ਼ਤਾ ਭੇਜਿਆ ਗਿਆ (Interest Sent)' : 'ਰਿਸ਼ਤਾ ਭੇਜੋ (Send Interest)'}
                </button>

                <button 
                  onClick={() => setShowContact(!showContact)}
                  className="bg-amber-500 hover:bg-amber-400 text-rose-950 px-5 py-2.5 rounded-xl font-bold transition-all shadow-sm flex items-center gap-2 text-sm"
                >
                  <Phone className="w-4 h-4" />
                  {showContact ? 'ਨੰਬਰ ਛੁਪਾਓ' : 'ਸੰਪਰਕ ਨੰਬਰ ਵੇਖੋ (Contact No)'}
                </button>
              </div>

            </div>

            {/* Revealed Contact Card */}
            {showContact && (
              <div className="p-5 bg-gradient-to-r from-amber-50 to-amber-100/70 border-2 border-amber-300 rounded-2xl mb-6 shadow-sm transition-all">
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
                  <div>
                    <h3 className="text-sm font-bold text-rose-950 flex items-center gap-1.5 mb-1">
                      <Phone className="w-4 h-4 text-amber-700" />
                      ਸਿੱਧਾ ਸੰਪਰਕ ਵੇਰਵਾ (Direct Contact Information)
                    </h3>
                    <div className="text-base font-bold text-gray-900">
                      ਮੋਬਾਈਲ: <span className="text-rose-900 font-mono">{profile.contactNumber || '+91 98765 43210'}</span>
                    </div>
                    {profile.alternateContact && (
                      <div className="text-xs text-gray-600 mt-0.5">
                        ਦੂਜਾ ਨੰਬਰ / ਵਟਸਐਪ: <span className="font-mono font-semibold">{profile.alternateContact}</span>
                      </div>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-2">
                    <a 
                      href={`tel:${profile.contactNumber || '9876543210'}`}
                      className="bg-rose-900 hover:bg-rose-800 text-amber-300 px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <Phone className="w-3.5 h-3.5" /> ਕਾਲ ਕਰੋ (Call Now)
                    </a>
                    <a 
                      href={`https://wa.me/${(profile.contactNumber || '9876543210').replace(/[^0-9]/g, '')}`}
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-lg font-bold text-xs flex items-center gap-1.5 transition-colors shadow-xs"
                    >
                      <MessageCircle className="w-3.5 h-3.5" /> ਵਟਸਐਪ (WhatsApp)
                    </a>
                  </div>
                </div>
              </div>
            )}

            {/* Quick Badges */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-4 border-t border-gray-100 text-sm">
              <div className="flex items-center gap-2 text-gray-700">
                <MapPin className="w-4 h-4 text-rose-900 flex-shrink-0" />
                <span className="truncate">{profile.district || profile.location || 'Gurdaspur'}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Briefcase className="w-4 h-4 text-rose-900 flex-shrink-0" />
                <span className="truncate">{profile.profession || 'Advocate'}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <GraduationCap className="w-4 h-4 text-rose-900 flex-shrink-0" />
                <span className="truncate">{profile.qualification1 || profile.education || 'Diploma / Degree'}</span>
              </div>
              <div className="flex items-center gap-2 text-gray-700">
                <Sparkles className="w-4 h-4 text-amber-600 flex-shrink-0" />
                <span className="truncate">ਮਹਾਸ਼ਾ ਸਮਾਜ ਪ੍ਰੋਫਾਈਲ</span>
              </div>
            </div>

          </div>
        </div>

        {/* Detailed Sections Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Main Column */}
          <div className="md:col-span-2 space-y-6">
            
            {/* Career, Practice & Aspirations */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Briefcase className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਕਿੱਤਾ ਅਤੇ ਅਭਿਆਸ (Profession & Career Practice)</h2>
                  <p className="text-xs text-gray-500">ਮੌਜੂਦਾ ਕੰਮ ਅਤੇ ਭਵਿੱਖੀ ਤਿਆਰੀ</p>
                </div>
              </div>
              
              <div className="space-y-4 text-sm">
                <div className="bg-amber-50/70 p-3.5 rounded-xl border border-amber-200">
                  <dt className="text-xs font-semibold text-rose-950 uppercase tracking-wider mb-1">
                    ਮੌਜੂਦਾ ਕੰਮ / ਪ੍ਰੈਕਟਿਸ ਦਾ ਵੇਰਵਾ (Current Practice & Goals)
                  </dt>
                  <dd className="font-bold text-gray-900 text-base leading-relaxed">
                    {profile.occupationDetails || "Now practicing as an Advocate with her mother & preparation of PCS (J)"}
                  </dd>
                </div>

                <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <dt className="text-gray-500 text-xs">ਮੁੱਖ ਪੇਸ਼ਾ (Profession)</dt>
                    <dd className="font-semibold text-gray-900 mt-0.5">{profile.profession || 'Advocate / Lawyer'}</dd>
                  </div>
                  <div>
                    <dt className="text-gray-500 text-xs">ਸਾਲਾਨਾ ਆਮਦਨ (Annual Income)</dt>
                    <dd className="font-semibold text-gray-900 mt-0.5">{profile.income || '10-20 Lakhs'}</dd>
                  </div>
                </dl>
              </div>
            </div>

            {/* Qualifications 1, 2, 3 */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <GraduationCap className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਵਿੱਦਿਅਕ ਯੋਗਤਾਵਾਂ (Qualifications 1, 2, 3)</h2>
                  <p className="text-xs text-gray-500">ਸਾਰੀਆਂ ਡਿਗਰੀਆਂ ਅਤੇ ਡਿਪਲੋਮੇ</p>
                </div>
              </div>
              
              <div className="space-y-3">
                {/* Qualification 1 */}
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-3">
                  <span className="w-7 h-7 rounded-lg bg-rose-900 text-amber-300 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                    1
                  </span>
                  <div>
                    <span className="text-xs font-semibold text-gray-500 block">Qualification-1 (ਮੁੱਖ / ਮੁੱਢਲੀ ਯੋਗਤਾ)</span>
                    <span className="font-bold text-gray-900 text-sm">{profile.qualification1 || 'Computer Engineering Diploma'}</span>
                  </div>
                </div>

                {/* Qualification 2 */}
                {(profile.qualification2 || profile.qualification2 === undefined) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-3">
                    <span className="w-7 h-7 rounded-lg bg-rose-900 text-amber-300 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                      2
                    </span>
                    <div>
                      <span className="text-xs font-semibold text-gray-500 block">Qualification-2 (ਗ੍ਰੈਜੂਏਸ਼ਨ / ਦੂਜੀ ਡਿਗਰੀ)</span>
                      <span className="font-bold text-gray-900 text-sm">{profile.qualification2 || 'BA.LLB'}</span>
                    </div>
                  </div>
                )}

                {/* Qualification 3 */}
                {(profile.qualification3 || profile.qualification3 === undefined) && (
                  <div className="p-3 bg-gray-50 rounded-xl border border-gray-200 flex items-start gap-3">
                    <span className="w-7 h-7 rounded-lg bg-rose-900 text-amber-300 font-bold text-xs flex items-center justify-center flex-shrink-0 mt-0.5">
                      3
                    </span>
                    <div>
                      <span className="text-xs font-semibold text-gray-500 block">Qualification-3 (ਉੱਚ ਯੋਗਤਾ / ਮਾਸਟਰਜ਼)</span>
                      <span className="font-bold text-gray-900 text-sm">{profile.qualification3 || 'LLM (Criminology)'}</span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Birth, Kundali & Physical Attributes */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Calendar className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਜਨਮ ਅਤੇ ਕੁੰਡਲੀ ਵੇਰਵਾ (Birth & Kundali Details)</h2>
                  <p className="text-xs text-gray-500">ਜਨਮ ਸਥਾਨ, ਸਮਾਂ, ਕੱਦ ਅਤੇ ਰੰਗ</p>
                </div>
              </div>
              
              <dl className="grid grid-cols-2 sm:grid-cols-3 gap-4 text-sm">
                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਜਨਮ ਸਥਾਨ (Birth Place)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.birthPlace || 'Gurdaspur'}</dd>
                </div>

                {profile.birthTime ? (
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                    <dt className="text-gray-500 text-xs">ਜਨਮ ਸਮਾਂ (Birth Time)</dt>
                    <dd className="font-bold text-gray-900 mt-1">{profile.birthTime}</dd>
                  </div>
                ) : (
                  <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                    <dt className="text-gray-500 text-xs">ਜਨਮ ਸਮਾਂ (Birth Time)</dt>
                    <dd className="font-medium text-gray-400 mt-1 italic">ਦਰਜ ਨਹੀਂ ਕੀਤਾ (Not Specified)</dd>
                  </div>
                )}

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਕੱਦ (Height / Hight)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.height || '5\'4" (162 cm)'}</dd>
                </div>

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਰੰਗ (Rang / Complexion)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.complexion || 'Fair (ਗੋਰਾ)'}</dd>
                </div>

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ (District)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.district || 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)'}</dd>
                </div>

                <div className="p-2.5 bg-gray-50 rounded-lg border border-gray-100">
                  <dt className="text-gray-500 text-xs">ਵਿਆਹੁਤਾ ਸਥਿਤੀ (Marital Status)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.maritalStatus || 'Never Married'}</dd>
                </div>
              </dl>
            </div>

            {/* Family Background */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Users className="w-5 h-5 text-rose-900" />
                <div>
                  <h2 className="text-lg font-bold text-gray-900 font-serif">ਪਰਿਵਾਰਕ ਪਿਛੋਕੜ (Family Background)</h2>
                  <p className="text-xs text-gray-500">ਮਾਤਾ-ਪਿਤਾ ਅਤੇ ਭੈਣ-ਭਰਾਵਾਂ ਦਾ ਵੇਰਵਾ</p>
                </div>
              </div>
              
              <dl className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-sm">
                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Father Details / Occupation)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.fatherOccupation || '(Expire) Retired cashier from CPWD'}</dd>
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਮਾਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Mother Details / Occupation)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.motherOccupation || 'Advocate'}</dd>
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਭਰਾ ਦਾ ਵੇਰਵਾ (Brother Details)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.brotherDetails || 'Advocate'}</dd>
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <dt className="text-gray-500 text-xs font-semibold">ਪਰਿਵਾਰਕ ਢਾਂਚਾ (Family Type)</dt>
                  <dd className="font-bold text-gray-900 mt-1">{profile.familyType || 'Nuclear Family'}</dd>
                </div>
              </dl>
            </div>

            {/* About Me */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Heart className="w-5 h-5 text-rose-900" />
                <h2 className="text-lg font-bold text-gray-900 font-serif">ਮੇਰੇ ਬਾਰੇ (About Me & Preferences)</h2>
              </div>
              <p className="text-gray-700 leading-relaxed whitespace-pre-line text-sm">
                {profile.aboutMe || "A warm, family-oriented individual with professional integrity and deep roots in our Mahasha community culture. Looking for an understanding, educated and respectful life partner."}
              </p>
            </div>

          </div>

          {/* Side Column */}
          <div className="space-y-6">
            
            {/* Gotra & Community Heritage Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center gap-2 mb-4 border-b border-gray-100 pb-3">
                <Sparkles className="w-5 h-5 text-amber-600" />
                <h2 className="text-lg font-bold text-gray-900 font-serif">ਮਹਾਸ਼ਾ ਗੋਤਰ ਵੇਰਵਾ (Gotra Heritage)</h2>
              </div>
              
              <div className="space-y-3.5 text-sm">
                <div className="p-3 bg-rose-50/60 rounded-xl border border-rose-200">
                  <span className="text-xs text-rose-900 font-bold block">ਪਿਤਾ ਦਾ ਗੋਤਰ / ਕਾਸਟ (Father Caste):</span>
                  <span className="font-extrabold text-base text-rose-950 block mt-0.5">
                    {profile.fatherGotra || 'Bajgal (Bhogal)'}
                  </span>
                </div>

                <div className="p-3 bg-amber-50/70 rounded-xl border border-amber-200">
                  <span className="text-xs text-amber-900 font-bold block">ਮਾਤਾ ਦਾ ਗੋਤਰ / ਨਾਨਕੇ ਕਾਸਟ (Mother Caste):</span>
                  <span className="font-extrabold text-base text-amber-950 block mt-0.5">
                    {profile.motherGotra || 'Ghangla'}
                  </span>
                </div>

                <div className="pt-2 border-t border-gray-100 space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-500">ਸਮਾਜ (Community)</span>
                    <span className="font-semibold text-gray-900">ਮਹਾਸ਼ਾ ਬਿਰਾਦਰੀ</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">ਧਰਮ (Religion)</span>
                    <span className="font-semibold text-gray-900">{profile.religion || 'Hindu'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ</span>
                    <span className="font-semibold text-gray-900">{profile.district || 'Gurdaspur'}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Contact & Verification Card */}
            <div className="bg-gradient-to-br from-rose-950 via-rose-900 to-rose-950 rounded-2xl shadow-sm p-6 text-white border border-amber-500/20">
              <div className="flex items-center gap-2 mb-3">
                <ShieldCheck className="w-6 h-6 text-amber-400" />
                <h3 className="font-bold text-lg text-white">ਪ੍ਰਮਾਣਿਤ ਬਾਇਓਡਾਟਾ</h3>
              </div>
              <p className="text-rose-200/90 text-xs leading-relaxed mb-4">
                ਇਸ ਪ੍ਰੋਫਾਈਲ ਵਿੱਚ ਜਨਮ ਸਥਾਨ, ਜਨਮ ਸਮਾਂ, ਮਾਤਾ-ਪਿਤਾ ਦੇ ਗੋਤਰ ਅਤੇ ਸੰਪਰਕ ਨੰਬਰ ਦੀ ਪੁਸ਼ਟੀ ਕੀਤੀ ਗਈ ਹੈ।
              </p>
              <button 
                onClick={() => setShowContact(true)}
                className="w-full bg-amber-500 hover:bg-amber-400 text-rose-950 py-2.5 rounded-xl font-bold text-sm transition-all shadow-md flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" /> ਸੰਪਰਕ ਨੰਬਰ ਵੇਖੋ (View Phone)
              </button>
            </div>

            {/* Address / Location Card */}
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 text-sm">
              <div className="flex items-center gap-2 mb-3 text-gray-900 font-bold border-b border-gray-100 pb-2">
                <MapPin className="w-4 h-4 text-rose-900" /> ਰਿਹਾਇਸ਼ੀ ਪਤਾ (Location)
              </div>
              <p className="text-gray-700 font-medium">
                {profile.location || 'Gurdaspur, Punjab, India'}
              </p>
              <p className="text-xs text-gray-500 mt-1">
                ਜ਼ਿਲ੍ਹਾ: <strong className="text-gray-800">{profile.district || 'Gurdaspur'}</strong>
              </p>
            </div>

          </div>

        </div>

      </div>
    </div>
  );
}
