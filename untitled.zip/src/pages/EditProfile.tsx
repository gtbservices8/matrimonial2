import { useState, useEffect } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { 
  User, Briefcase, Users, Heart, Save, AlertCircle, 
  MapPin, GraduationCap, Phone, Clock, Sparkles, CheckCircle2 
} from 'lucide-react';
import { 
  MAHASHA_GOTRAS, PUNJAB_DISTRICTS, COMPLEXIONS, 
  HEIGHT_OPTIONS, STANDARD_PROFESSIONS 
} from '../types';

export default function EditProfile() {
  const { user } = useAuth();
  const navigate = useNavigate();
  
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  // Form State with user's requested matrimonial fields
  const [formData, setFormData] = useState({
    fullName: '',
    gender: 'Bride',
    age: '',
    dateOfBirth: '',
    birthPlace: '',
    birthTime: '',
    complexion: 'Fair',
    height: '5\'4" (162 cm)',
    district: 'Gurdaspur (ਗੁਰਦਾਸਪੁਰ)',
    location: '',
    fatherGotra: 'Bajgal (Bhogal)',
    motherGotra: 'Ghangla',
    religion: 'Hindu',
    community: 'Mahasha (Bajgal)',
    qualification1: '',
    qualification2: '',
    qualification3: '',
    education: '',
    profession: '',
    occupationDetails: '',
    income: '',
    fatherOccupation: '',
    motherOccupation: '',
    brotherDetails: '',
    sisterDetails: '',
    familyType: 'Nuclear',
    maritalStatus: 'Never Married',
    contactNumber: '',
    alternateContact: '',
    aboutMe: '',
  });

  // State for Profession dropdown and custom text box
  const [professionSelect, setProfessionSelect] = useState('');
  const [customProfession, setCustomProfession] = useState('');

  // State for custom Father / Mother Gotra if 'Other'
  const [fatherGotraSelect, setFatherGotraSelect] = useState('Bajgal (Bhogal)');
  const [customFatherGotra, setCustomFatherGotra] = useState('');
  const [motherGotraSelect, setMotherGotraSelect] = useState('Ghangla');
  const [customMotherGotra, setCustomMotherGotra] = useState('');

  useEffect(() => {
    async function fetchProfile() {
      if (!user) return;
      try {
        const docRef = doc(db, 'profiles', user.uid);
        const docSnap = await getDoc(docRef);
        
        if (docSnap.exists()) {
          const data = docSnap.data();
          setFormData(prev => ({
            ...prev,
            ...data
          }));

          // Handle Profession Select & Custom input
          if (data.profession) {
            if (STANDARD_PROFESSIONS.includes(data.profession)) {
              setProfessionSelect(data.profession);
              setCustomProfession('');
            } else {
              setProfessionSelect('Other');
              setCustomProfession(data.profession);
            }
          }

          // Handle Father Gotra
          if (data.fatherGotra) {
            const match = MAHASHA_GOTRAS.find(g => g.value === data.fatherGotra);
            if (match) {
              setFatherGotraSelect(data.fatherGotra);
            } else {
              setFatherGotraSelect('Other');
              setCustomFatherGotra(data.fatherGotra);
            }
          }

          // Handle Mother Gotra
          if (data.motherGotra) {
            const match = MAHASHA_GOTRAS.find(g => g.value === data.motherGotra);
            if (match) {
              setMotherGotraSelect(data.motherGotra);
            } else {
              setMotherGotraSelect('Other');
              setCustomMotherGotra(data.motherGotra);
            }
          }
        }
      } catch (err) {
        handleFirestoreError(err, OperationType.GET, `profiles/${user.uid}`);
      } finally {
        setLoading(false);
      }
    }

    fetchProfile();
  }, [user]);

  const handleChange = (e: ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleProfessionSelectChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const value = e.target.value;
    setProfessionSelect(value);
    if (value === 'Other') {
      setFormData(prev => ({ ...prev, profession: customProfession }));
    } else {
      setFormData(prev => ({ ...prev, profession: value }));
    }
  };

  const handleCustomProfessionChange = (e: ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    setCustomProfession(value);
    setFormData(prev => ({ ...prev, profession: value }));
  };

  const handleFatherGotraChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setFatherGotraSelect(val);
    if (val === 'Other') {
      setFormData(prev => ({ ...prev, fatherGotra: customFatherGotra || 'Other' }));
    } else {
      setFormData(prev => ({ ...prev, fatherGotra: val }));
    }
  };

  const handleMotherGotraChange = (e: ChangeEvent<HTMLSelectElement>) => {
    const val = e.target.value;
    setMotherGotraSelect(val);
    if (val === 'Other') {
      setFormData(prev => ({ ...prev, motherGotra: customMotherGotra || 'Other' }));
    } else {
      setFormData(prev => ({ ...prev, motherGotra: val }));
    }
  };

  // Calculate profile completion percentage based on required & important fields
  const calculateCompletion = (data: typeof formData) => {
    const essentialFields = [
      'fullName', 'gender', 'age', 'birthPlace', 
      'complexion', 'height', 'district', 'location', 
      'fatherGotra', 'motherGotra', 'qualification1', 
      'profession', 'occupationDetails', 'fatherOccupation', 
      'motherOccupation', 'contactNumber'
    ];
    const filled = essentialFields.filter(field => {
      const val = (data as any)[field];
      return val && val.toString().trim() !== '';
    });
    return Math.round((filled.length / essentialFields.length) * 100);
  };

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    
    // Validate that required fields are not empty
    const requiredCheck = [
      { key: 'fullName', label: 'ਪੂਰਾ ਨਾਮ (Full Name)' },
      { key: 'age', label: 'ਉਮਰ (Age)' },
      { key: 'birthPlace', label: 'ਜਨਮ ਸਥਾਨ (Birth Place)' },
      { key: 'complexion', label: 'ਰੰਗ (Rang / Complexion)' },
      { key: 'height', label: 'ਕੱਦ (Height)' },
      { key: 'district', label: 'ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ (Residence District)' },
      { key: 'location', label: 'ਪਤਾ / ਸ਼ਹਿਰ (Location)' },
      { key: 'fatherGotra', label: 'ਪਿਤਾ ਦਾ ਗੋਤਰ (Father Gotra)' },
      { key: 'motherGotra', label: 'ਮਾਤਾ ਦਾ ਗੋਤਰ (Mother Gotra)' },
      { key: 'qualification1', label: 'ਯੋਗਤਾ-1 (Qualification 1)' },
      { key: 'profession', label: 'ਪੇਸ਼ਾ (Profession)' },
      { key: 'occupationDetails', label: 'ਕੰਮ ਦਾ ਵੇਰਵਾ (Occupation Details)' },
      { key: 'fatherOccupation', label: 'ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Father Details)' },
      { key: 'motherOccupation', label: 'ਮਾਤਾ ਜੀ ਦਾ ਵੇਰਵਾ (Mother Details)' },
      { key: 'contactNumber', label: 'ਸੰਪਰਕ ਨੰਬਰ (Contact No)' },
    ];

    for (const item of requiredCheck) {
      const val = (formData as any)[item.key];
      if (!val || val.toString().trim() === '') {
        setError(`ਕਿਰਪਾ ਕਰਕੇ ਜਰੂਰੀ ਫੀਲਡ "${item.label}" ਦਰਜ ਕਰੋ। (Please fill required field: ${item.label})`);
        window.scrollTo({ top: 0, behavior: 'smooth' });
        return;
      }
    }

    setSaving(true);
    setError('');
    setSuccess('');

    try {
      const docRef = doc(db, 'profiles', user.uid);
      const completion = calculateCompletion(formData);
      
      // Auto-summarize highest qualification if not set
      const highestEdu = formData.qualification3 || formData.qualification2 || formData.qualification1;

      const dataToSave = {
        ...formData,
        userId: user.uid,
        age: formData.age ? parseInt(formData.age.toString(), 10) : null,
        community: `Mahasha (${formData.fatherGotra})`,
        education: highestEdu,
        profileCompletion: completion,
        updatedAt: serverTimestamp()
      };

      await setDoc(docRef, dataToSave, { merge: true });
      setSuccess('ਪ੍ਰੋਫਾਈਲ ਸਫਲਤਾਪੂਰਵਕ ਸੇਵ ਹੋ ਗਈ ਹੈ! (Profile updated successfully!)');
      
      // Scroll to top
      window.scrollTo({ top: 0, behavior: 'smooth' });
      
      setTimeout(() => navigate('/dashboard'), 1800);

    } catch (err: any) {
      setError(err.message || 'Failed to update profile.');
      handleFirestoreError(err, OperationType.UPDATE, `profiles/${user.uid}`);
    } finally {
      setSaving(false);
    }
  };

  const completionPercent = calculateCompletion(formData);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-10">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Page Header */}
        <div className="mb-8">
          <div className="flex flex-wrap items-center justify-between gap-4 mb-2">
            <h1 className="text-3xl font-bold text-gray-900 font-serif">
              ਮਹਾਸ਼ਾ ਮੈਟ੍ਰੀਮੋਨੀਅਲ ਬਾਇਓਡਾਟਾ (Edit Biodata)
            </h1>
            <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-bold bg-amber-100 text-rose-950 border border-amber-300">
              <Sparkles className="w-3.5 h-3.5 text-amber-600" /> ਸੰਪੂਰਨ ਪਰਿਵਾਰਕ ਪ੍ਰੋਫਾਈਲ
            </span>
          </div>
          <p className="text-gray-600">
            ਰਿਸ਼ਤੇ ਲਈ ਲੋੜੀਂਦੇ ਸਾਰੇ ਜ਼ਰੂਰੀ ਵੇਰਵੇ ਭਰੋ। ਲਾਲ ਤਾਰੇ (<span className="text-red-600 font-bold">*</span>) ਵਾਲੇ ਖਾਨੇ ਭਰਨੇ ਜ਼ਰੂਰੀ ਹਨ।
          </p>

          {/* Profile Completion Bar */}
          <div className="mt-4 bg-white p-4 rounded-xl border border-gray-200 shadow-xs">
            <div className="flex items-center justify-between text-sm font-semibold mb-1.5">
              <span className="text-gray-700 flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                ਪ੍ਰੋਫਾਈਲ ਮੁਕੰਮਲਤਾ (Profile Completion)
              </span>
              <span className="text-rose-900 font-bold">{completionPercent}%</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2.5 overflow-hidden">
              <div 
                className="bg-gradient-to-r from-amber-500 to-rose-700 h-2.5 rounded-full transition-all duration-500" 
                style={{ width: `${completionPercent}%` }}
              ></div>
            </div>
          </div>
        </div>

        {error && (
          <div className="mb-6 bg-rose-50 border-l-4 border-rose-500 p-4 flex items-start gap-3 rounded-r-lg shadow-xs">
            <AlertCircle className="w-5 h-5 text-rose-600 mt-0.5 flex-shrink-0" />
            <p className="text-rose-700 font-medium text-sm">{error}</p>
          </div>
        )}

        {success && (
          <div className="mb-6 bg-emerald-50 border-l-4 border-emerald-500 p-4 flex items-start gap-3 rounded-r-lg shadow-xs">
            <Save className="w-5 h-5 text-emerald-600 mt-0.5 flex-shrink-0" />
            <p className="text-emerald-800 font-medium text-sm">{success}</p>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-8">
          
          {/* Section 1: ਨਿੱਜੀ ਅਤੇ ਜਨਮ ਵੇਰਵਾ (Personal & Birth Details) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <User className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">1. ਨਿੱਜੀ ਅਤੇ ਜਨਮ ਵੇਰਵਾ (Personal & Birth Details)</h2>
                <p className="text-xs text-gray-500">ਕੁੰਡਲੀ ਅਤੇ ਪਛਾਣ ਲਈ ਜਨਮ ਦਾ ਸਹੀ ਵੇਰਵਾ ਦਰਜ ਕਰੋ</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਪੂਰਾ ਨਾਮ (Full Name) <span className="text-red-600">*</span>
                </label>
                <input 
                  required 
                  type="text" 
                  name="fullName" 
                  value={formData.fullName} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: Simranjit Kaur / Rajesh Kumar"
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                />
              </div>
              
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਲਿੰਗ / ਰਿਸ਼ਤਾ (Looking For) <span className="text-red-600">*</span>
                </label>
                <select 
                  name="gender" 
                  value={formData.gender} 
                  onChange={handleChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium"
                >
                  <option value="Bride">ਲਾੜੀ ਲਈ (Bride / Female)</option>
                  <option value="Groom">ਲਾੜੇ ਲਈ (Groom / Male)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਉਮਰ (Age) <span className="text-red-600">*</span>
                </label>
                <input 
                  required 
                  type="number" 
                  name="age" 
                  value={formData.age} 
                  onChange={handleChange} 
                  min="18" 
                  max="75" 
                  placeholder="e.g. 26" 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                />
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਜਨਮ ਮਿਤੀ (Date of Birth)
                </label>
                <input 
                  type="date" 
                  name="dateOfBirth" 
                  value={formData.dateOfBirth} 
                  onChange={handleChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                />
              </div>

              {/* Birth Place - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>ਜਨਮ ਸਥਾਨ (Birth Place) <span className="text-red-600">*</span></span>
                  <span className="text-xs text-rose-700 font-normal">ਕੁੰਡਲੀ ਲਈ ਲੋੜੀਂਦਾ</span>
                </label>
                <input 
                  required 
                  type="text" 
                  name="birthPlace" 
                  value={formData.birthPlace} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: Gurdaspur, Batala, Pathankot, Amritsar..." 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                />
              </div>

              {/* Birth Time - Optional */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>ਜਨਮ ਸਮਾਂ (Birth Time)</span>
                  <span className="text-xs text-gray-500 font-normal">ਵਿਕਲਪਿਕ (Optional)</span>
                </label>
                <div className="relative">
                  <input 
                    type="text" 
                    name="birthTime" 
                    value={formData.birthTime} 
                    onChange={handleChange} 
                    placeholder="ਜਿਵੇਂ: 10:30 AM, 04:15 PM (Optional)" 
                    className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none pl-10" 
                  />
                  <Clock className="w-5 h-5 text-gray-400 absolute left-3 top-3.5" />
                </div>
              </div>

              {/* Complexion / Rang - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਰੰਗ (Rang / Complexion) <span className="text-red-600">*</span>
                </label>
                <select 
                  name="complexion" 
                  value={formData.complexion} 
                  onChange={handleChange} 
                  required
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  {COMPLEXIONS.map(c => (
                    <option key={c.value} value={c.value}>{c.label}</option>
                  ))}
                </select>
              </div>

              {/* Height / Hight - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਕੱਦ (Height / Hight) <span className="text-red-600">*</span>
                </label>
                <select 
                  name="height" 
                  value={formData.height} 
                  onChange={handleChange} 
                  required
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  <option value="">ਕੱਦ ਸਿਲੈਕਟ ਕਰੋ (Select Height)</option>
                  {HEIGHT_OPTIONS.map(h => (
                    <option key={h} value={h}>{h}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਵਿਆਹੁਤਾ ਸਥਿਤੀ (Marital Status)
                </label>
                <select 
                  name="maritalStatus" 
                  value={formData.maritalStatus} 
                  onChange={handleChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  <option value="Never Married">ਕਦੇ ਵਿਆਹ ਨਹੀਂ ਹੋਇਆ (Never Married)</option>
                  <option value="Awaiting Divorce">ਤਲਾਕ ਅਧੀਨ (Awaiting Divorce)</option>
                  <option value="Divorced">ਤਲਾਕਸ਼ੁਦਾ (Divorced)</option>
                  <option value="Widowed">ਵਿਧਵਾ / ਵਿਧੁਰ (Widowed)</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਧਰਮ (Religion)
                </label>
                <select 
                  name="religion" 
                  value={formData.religion} 
                  onChange={handleChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  <option value="Hindu">ਹਿੰਦੂ (Hindu)</option>
                  <option value="Sikh">ਸਿੱਖ (Sikh)</option>
                  <option value="Other">ਹੋਰ (Other)</option>
                </select>
              </div>

            </div>
          </div>

          {/* Section 2: ਰਿਹਾਇਸ਼ੀ ਵੇਰਵਾ (Location & Residence District) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <MapPin className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">2. ਰਿਹਾਇਸ਼ੀ ਵੇਰਵਾ (Location & Residence)</h2>
                <p className="text-xs text-gray-500">ਤੁਹਾਡਾ ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ ਅਤੇ ਪਤਾ</p>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਰਿਹਾਇਸ਼ੀ ਜ਼ਿਲ੍ਹਾ (Residence / Location District) <span className="text-red-600">*</span>
                </label>
                <select 
                  name="district" 
                  value={formData.district} 
                  onChange={handleChange} 
                  required
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  <option value="">ਜ਼ਿਲ੍ਹਾ ਸਿਲੈਕਟ ਕਰੋ (Select District)</option>
                  {PUNJAB_DISTRICTS.map(d => (
                    <option key={d} value={d}>{d}</option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਮੌਜੂਦਾ ਸ਼ਹਿਰ / ਪਿੰਡ / ਪਤਾ (Current Location / City) <span className="text-red-600">*</span>
                </label>
                <input 
                  required 
                  type="text" 
                  name="location" 
                  value={formData.location} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: Gurdaspur City, Punjab" 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none" 
                />
              </div>
            </div>
          </div>

          {/* Section 3: ਮਹਾਸ਼ਾ ਗੋਤਰ ਅਤੇ ਕਾਸਟ ਵੇਰਵਾ (Father & Mother Caste/Gotra) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <Users className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">3. ਮਹਾਸ਼ਾ ਗੋਤਰ / ਕਾਸਟ ਵੇਰਵਾ (Gotra & Caste Heritage)</h2>
                <p className="text-xs text-gray-500">ਮਹਾਸ਼ਾ ਸਮਾਜ ਵਿੱਚ ਰਿਸ਼ਤਾ ਤੈਅ ਕਰਨ ਲਈ ਦੋਵੇਂ ਪਾਸੇ ਦੇ ਗੋਤਰ ਜ਼ਰੂਰੀ ਹਨ</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Father Gotra / Caste - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਪਿਤਾ ਦਾ ਗੋਤਰ / ਕਾਸਟ (Father Caste / Gotra) <span className="text-red-600">*</span>
                </label>
                <select 
                  name="fatherGotraSelect" 
                  value={fatherGotraSelect} 
                  onChange={handleFatherGotraChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  {MAHASHA_GOTRAS.map(g => (
                    <option key={g.value} value={g.value}>{g.label}</option>
                  ))}
                </select>

                {fatherGotraSelect === 'Other' && (
                  <div className="mt-2.5 p-2.5 bg-amber-50 border border-amber-300 rounded-lg">
                    <label className="block text-xs font-bold text-rose-950 mb-1">
                      ਪਿਤਾ ਦਾ ਗੋਤਰ ਲਿਖੋ (Type Custom Father Gotra) <span className="text-red-600">*</span>
                    </label>
                    <input 
                      type="text" 
                      value={customFatherGotra} 
                      onChange={(e) => {
                        setCustomFatherGotra(e.target.value);
                        setFormData(prev => ({ ...prev, fatherGotra: e.target.value }));
                      }}
                      placeholder="ਜਿਵੇਂ: Bajgal (Bhogal), Gill, Sandhu..." 
                      className="w-full border border-amber-400 rounded-md p-2 text-sm bg-white outline-none" 
                    />
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-1">ਜਿਵੇਂ: Bajgal (Bhogal), Kaler, Badhan, Banga...</p>
              </div>

              {/* Mother Gotra / Caste (ਨਾਨਕੇ ਗੋਤਰ) - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਮਾਤਾ ਦਾ ਗੋਤਰ - ਨਾਨਕੇ (Mother Caste / Gotra) <span className="text-red-600">*</span>
                </label>
                <select 
                  name="motherGotraSelect" 
                  value={motherGotraSelect} 
                  onChange={handleMotherGotraChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  {MAHASHA_GOTRAS.map(g => (
                    <option key={g.value} value={g.value}>{g.label}</option>
                  ))}
                </select>

                {motherGotraSelect === 'Other' && (
                  <div className="mt-2.5 p-2.5 bg-amber-50 border border-amber-300 rounded-lg">
                    <label className="block text-xs font-bold text-rose-950 mb-1">
                      ਮਾਤਾ ਦਾ ਗੋਤਰ ਲਿਖੋ (Type Custom Mother Gotra) <span className="text-red-600">*</span>
                    </label>
                    <input 
                      type="text" 
                      value={customMotherGotra} 
                      onChange={(e) => {
                        setCustomMotherGotra(e.target.value);
                        setFormData(prev => ({ ...prev, motherGotra: e.target.value }));
                      }}
                      placeholder="ਜਿਵੇਂ: Ghangla, Hans, Taak..." 
                      className="w-full border border-amber-400 rounded-md p-2 text-sm bg-white outline-none" 
                    />
                  </div>
                )}
                <p className="text-xs text-gray-500 mt-1">ਜਿਵੇਂ: Ghangla, Taak, Hans, Kundal...</p>
              </div>

            </div>
          </div>

          {/* Section 4: ਵਿੱਦਿਅਕ ਯੋਗਤਾਵਾਂ (Multi-tier Qualifications) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <GraduationCap className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">4. ਵਿੱਦਿਅਕ ਯੋਗਤਾਵਾਂ (Educational Qualifications)</h2>
                <p className="text-xs text-gray-500">ਡਿਪਲੋਮਾ, ਗ੍ਰੈਜੂਏਸ਼ਨ ਅਤੇ ਉੱਚ ਵਿੱਦਿਆ ਦੇ ਵੱਖਰੇ ਕਾਲਮ</p>
              </div>
            </div>
            
            <div className="space-y-4">
              {/* Qualification 1 - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>Qualification-1: ਮੁੱਖ / ਮੁੱਢਲੀ ਯੋਗਤਾ (Primary Qualification) <span className="text-red-600">*</span></span>
                  <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium">ਜ਼ਰੂਰੀ / Mandatory</span>
                </label>
                <input 
                  required 
                  type="text" 
                  name="qualification1" 
                  value={formData.qualification1} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: Computer Engineering Diploma, Polytechnic Diploma, B.A..." 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
              </div>

              {/* Qualification 2 - Optional */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>Qualification-2: ਦੂਜੀ ਡਿਗਰੀ (Second Degree / Graduation)</span>
                  <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ (Optional)</span>
                </label>
                <input 
                  type="text" 
                  name="qualification2" 
                  value={formData.qualification2} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: BA.LLB, B.Tech, B.Com, B.Sc, B.Ed..." 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
              </div>

              {/* Qualification 3 - Optional */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>Qualification-3: ਉੱਚ ਯੋਗਤਾ / ਮਾਸਟਰਜ਼ (Post-Graduation / Master's Degree)</span>
                  <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ (Optional)</span>
                </label>
                <input 
                  type="text" 
                  name="qualification3" 
                  value={formData.qualification3} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: LLM (Criminology), M.Tech, MBA, Ph.D..." 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
              </div>
            </div>
          </div>

          {/* Section 5: ਪੇਸ਼ਾ ਅਤੇ ਕੰਮ ਦਾ ਵੇਰਵਾ (Profession & Career Details) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <Briefcase className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">5. ਪੇਸ਼ਾ ਅਤੇ ਕੰਮ ਦਾ ਵੇਰਵਾ (Profession & Career Practice)</h2>
                <p className="text-xs text-gray-500">ਮੌਜੂਦਾ ਨੌਕਰੀ, ਪ੍ਰੈਕਟਿਸ ਜਾਂ ਪ੍ਰੀਖਿਆਵਾਂ ਦੀ ਤਿਆਰੀ</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Profession Dropdown - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਪੇਸ਼ਾ / ਅਹੁਦਾ (Profession Category) <span className="text-red-600">*</span>
                </label>
                <select 
                  name="professionSelect" 
                  value={professionSelect} 
                  onChange={handleProfessionSelectChange} 
                  required
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium bg-white"
                >
                  <option value="">ਸਿਲੈਕਟ ਕਰੋ / Select Profession</option>
                  <option value="Advocate / Lawyer">ਵਕੀਲ (Advocate / Lawyer)</option>
                  <option value="Judicial / PCS(J) Aspirant">ਜੁਡੀਸ਼ਰੀ / PCS (J) ਤਿਆਰੀ (Judicial Aspirant)</option>
                  <option value="Software Engineer">ਸਾਫਟਵੇਅਰ ਇੰਜੀਨੀਅਰ (Software Engineer)</option>
                  <option value="Doctor / Medical">ਡਾਕਟਰ / ਹੈਲਥਕੇਅਰ (Doctor / Healthcare)</option>
                  <option value="Business / Trader">ਕਾਰੋਬਾਰ / ਬਿਜ਼ਨਸ (Business / Trader)</option>
                  <option value="Teacher / Professor">ਅਧਿਆਪਕ / ਪ੍ਰੋਫੈਸਰ (Teacher / Professor)</option>
                  <option value="Government Job">ਸਰਕਾਰੀ ਨੌਕਰੀ (Government Job)</option>
                  <option value="Banker / Finance">ਬੈਂਕਿੰਗ / ਵਿੱਤ (Banker / Finance)</option>
                  <option value="Chartered Accountant (CA)">ਚਾਰਟਰਡ ਅਕਾਊਂਟੈਂਟ (Chartered Accountant CA)</option>
                  <option value="Armed Forces / Police">ਡਿਫੈਂਸ / ਪੁਲਿਸ (Armed Forces / Police)</option>
                  <option value="Not Working / Homemaker">ਵਰਕਿੰਗ ਨਹੀਂ (Not Working / Homemaker)</option>
                  <option value="Other">ਅਦਰ / ਹੋਰ ਪੇਸ਼ਾ (Other Profession)</option>
                </select>

                {professionSelect === 'Other' && (
                  <div className="mt-3 p-3.5 bg-amber-50/90 border border-amber-300 rounded-xl shadow-xs transition-all">
                    <label className="block text-xs font-bold text-rose-950 mb-1.5 flex items-center justify-between">
                      <span>ਆਪਣਾ ਖਾਸ ਪੇਸ਼ਾ ਇੱਥੇ ਲਿਖੋ (Type Custom Profession) <span className="text-red-600">*</span></span>
                    </label>
                    <input
                      type="text"
                      name="customProfessionInput"
                      value={customProfession}
                      onChange={handleCustomProfessionChange}
                      placeholder="ਜਿਵੇਂ: Architect, Civil Contractor, Pharmacist..."
                      required={professionSelect === 'Other'}
                      className="w-full border border-amber-400 rounded-lg p-2.5 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white text-gray-900 font-medium text-sm"
                    />
                  </div>
                )}
              </div>

              {/* Annual Income */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">ਸਾਲਾਨਾ ਆਮਦਨ (Annual Income)</label>
                <select 
                  name="income" 
                  value={formData.income} 
                  onChange={handleChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white font-medium"
                >
                  <option value="">ਸਿਲੈਕਟ ਕਰੋ (Select Income Range)</option>
                  <option value="Under 5 Lakhs">5 ਲੱਖ ਤੋਂ ਘੱਟ (Under 5 Lakhs)</option>
                  <option value="5-10 Lakhs">5 ਤੋਂ 10 ਲੱਖ (5-10 Lakhs)</option>
                  <option value="10-20 Lakhs">10 ਤੋਂ 20 ਲੱਖ (10-20 Lakhs)</option>
                  <option value="20-30 Lakhs">20 ਤੋਂ 30 ਲੱਖ (20-30 Lakhs)</option>
                  <option value="30+ Lakhs">30 ਲੱਖ ਤੋਂ ਵੱਧ (30+ Lakhs)</option>
                </select>
              </div>

              {/* Practice & Current Work Details - Mandatory */}
              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>ਮੌਜੂਦਾ ਕੰਮ ਅਤੇ ਅਭਿਆਸ ਦਾ ਪੂਰਾ ਵੇਰਵਾ (Current Practice & Aspirations) <span className="text-red-600">*</span></span>
                  <span className="text-xs text-rose-700 font-medium">ਜਿਵੇਂ ਉਦਾਹਰਣ ਦਿੱਤੀ ਗਈ ਸੀ</span>
                </label>
                <textarea 
                  required
                  rows={2}
                  name="occupationDetails" 
                  value={formData.occupationDetails} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: Now practicing as an Advocate with her mother & preparation of PCS (J)"
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none text-sm font-medium"
                ></textarea>
                <p className="text-xs text-gray-500 mt-1">
                  ਉਦਾਹਰਣ: "Now practicing as an Advocate with her mother & preparation of PCS (J)" ਜਾਂ "Working as Senior Consultant at TCS"
                </p>
              </div>

            </div>
          </div>

          {/* Section 6: ਪਰਿਵਾਰਕ ਪਿਛੋਕੜ (Family Background) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <Users className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">6. ਪਰਿਵਾਰਕ ਪਿਛੋਕੜ (Family Background Details)</h2>
                <p className="text-xs text-gray-500">ਮਾਤਾ-ਪਿਤਾ ਅਤੇ ਭੈਣ-ਭਰਾਵਾਂ ਦਾ ਵੇਰਵਾ</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Father Details - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਪਿਤਾ ਜੀ ਦਾ ਵੇਰਵਾ / ਪੇਸ਼ਾ (Father Details / Occupation) <span className="text-red-600">*</span>
                </label>
                <input 
                  required 
                  type="text" 
                  name="fatherOccupation" 
                  value={formData.fatherOccupation} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: (Expire) Retired cashier from CPWD / Business / Govt Service"
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
                <p className="text-xs text-gray-500 mt-1">ਉਦਾਹਰਣ: "(Expire) Retired cashier from CPWD" ਜਾਂ "Retired Teacher"</p>
              </div>

              {/* Mother Details - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1">
                  ਮਾਤਾ ਜੀ ਦਾ ਵੇਰਵਾ / ਪੇਸ਼ਾ (Mother Details / Occupation) <span className="text-red-600">*</span>
                </label>
                <input 
                  required 
                  type="text" 
                  name="motherOccupation" 
                  value={formData.motherOccupation} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: Advocate / Homemaker / Teacher / Govt Employee"
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
                <p className="text-xs text-gray-500 mt-1">ਉਦਾਹਰਣ: "Advocate" ਜਾਂ "Homemaker"</p>
              </div>

              {/* Brother Details - Optional */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>ਭਰਾ ਦਾ ਵੇਰਵਾ (Brother Details)</span>
                  <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ</span>
                </label>
                <input 
                  type="text" 
                  name="brotherDetails" 
                  value={formData.brotherDetails} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: Advocate, 1 Elder Brother (Married)..."
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
              </div>

              {/* Sister Details - Optional */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>ਭੈਣ ਦਾ ਵੇਰਵਾ (Sister Details)</span>
                  <span className="text-xs text-gray-500">ਜੇਕਰ ਲਾਗੂ ਹੋਵੇ</span>
                </label>
                <input 
                  type="text" 
                  name="sisterDetails" 
                  value={formData.sisterDetails} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: 1 Younger Sister (Unmarried) / None"
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
              </div>

              <div className="md:col-span-2">
                <label className="block text-sm font-semibold text-gray-800 mb-1">ਪਰਿਵਾਰਕ ਢਾਂਚਾ (Family Type)</label>
                <select 
                  name="familyType" 
                  value={formData.familyType} 
                  onChange={handleChange} 
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-white font-medium"
                >
                  <option value="Nuclear">ਇਕਹਿਰਾ ਪਰਿਵਾਰ (Nuclear Family)</option>
                  <option value="Joint">ਸੰਯੁਕਤ ਪਰਿਵਾਰ (Joint Family)</option>
                </select>
              </div>

            </div>
          </div>

          {/* Section 7: ਸੰਪਰਕ ਜਾਣਕਾਰੀ (Contact Information) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <Phone className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">7. ਸੰਪਰਕ ਜਾਣਕਾਰੀ (Contact Information)</h2>
                <p className="text-xs text-gray-500">ਰਿਸ਼ਤੇਦਾਰਾਂ ਨਾਲ ਸਿੱਧਾ ਸੰਪਰਕ ਕਰਨ ਲਈ ਮੋਬਾਈਲ ਨੰਬਰ</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              
              {/* Contact Number - Mandatory */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>ਸੰਪਰਕ ਨੰਬਰ (Contact No / Mobile) <span className="text-red-600">*</span></span>
                  <span className="text-xs text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded font-medium">ਜ਼ਰੂਰੀ / Mandatory</span>
                </label>
                <input 
                  required 
                  type="tel" 
                  name="contactNumber" 
                  value={formData.contactNumber} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: 9876543210 / +91 98765-43210"
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
              </div>

              {/* Alternate Contact / WhatsApp */}
              <div>
                <label className="block text-sm font-semibold text-gray-800 mb-1 flex items-center justify-between">
                  <span>ਵਟਸਐਪ ਜਾਂ ਦੂਜਾ ਨੰਬਰ (Alternate / WhatsApp No)</span>
                  <span className="text-xs text-gray-500">Optional</span>
                </label>
                <input 
                  type="tel" 
                  name="alternateContact" 
                  value={formData.alternateContact} 
                  onChange={handleChange} 
                  placeholder="ਜਿਵੇਂ: 9812345678"
                  className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none font-medium" 
                />
              </div>

            </div>
          </div>

          {/* Section 8: ਹੋਰ ਵੇਰਵਾ ਅਤੇ ਉਮੀਦਾਂ (About Me & Partner Preferences) */}
          <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8">
            <div className="flex items-center gap-2 mb-6 border-b border-gray-100 pb-4">
              <Heart className="w-6 h-6 text-rose-900" />
              <div>
                <h2 className="text-xl font-bold text-gray-900 font-serif">8. ਮੇਰੇ ਬਾਰੇ ਅਤੇ ਸਾਥੀ ਦੀ ਪਸੰਦ (About Me & Preferences)</h2>
                <p className="text-xs text-gray-500">ਸੁਭਾਅ, ਸ਼ੌਕ ਅਤੇ ਜੀਵਨ ਸਾਥੀ ਤੋਂ ਉਮੀਦਾਂ ਬਾਰੇ ਸੰਖੇਪ ਲਿਖੋ</p>
              </div>
            </div>
            
            <div>
              <textarea 
                name="aboutMe" 
                value={formData.aboutMe} 
                onChange={handleChange} 
                rows={4} 
                className="w-full border border-gray-300 rounded-lg p-3 focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none resize-none text-sm font-medium"
                placeholder="ਮੇਰੇ ਬਾਰੇ ਕੁਝ ਸ਼ਬਦ, ਪਰਿਵਾਰਕ ਕਦਰਾਂ-ਕੀਮਤਾਂ ਅਤੇ ਜੀਵਨ ਸਾਥੀ ਤੋਂ ਉਮੀਦਾਂ ਬਾਰੇ ਲਿਖੋ..."
              ></textarea>
            </div>
          </div>

          {/* Form Actions */}
          <div className="flex flex-col sm:flex-row items-center justify-end gap-4 pt-4">
            <button 
              type="button" 
              onClick={() => navigate('/dashboard')}
              className="w-full sm:w-auto px-6 py-3.5 border border-gray-300 text-gray-700 rounded-xl font-bold hover:bg-gray-100 transition-colors"
            >
              ਰੱਦ ਕਰੋ (Cancel)
            </button>
            <button 
              type="submit" 
              disabled={saving}
              className="w-full sm:w-auto px-8 py-3.5 bg-rose-900 hover:bg-rose-800 text-amber-300 border border-amber-500/30 rounded-xl font-bold text-base transition-all shadow-lg flex items-center justify-center gap-2 disabled:opacity-70"
            >
              {saving ? 'ਸੇਵ ਹੋ ਰਿਹਾ ਹੈ...' : (
                <>
                  <Save className="w-5 h-5 text-amber-400" /> ਪ੍ਰੋਫਾਈਲ ਸੇਵ ਕਰੋ (Save Profile)
                </>
              )}
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
