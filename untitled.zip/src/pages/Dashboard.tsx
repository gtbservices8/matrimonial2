import { useEffect, useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { doc, getDoc } from 'firebase/firestore';
import { UserCircle, Heart, Mail, Eye, Star, Settings } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import SearchSidebar, { FilterState } from '../components/SearchSidebar';

export default function Dashboard() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  
  const [searchFilters, setSearchFilters] = useState<FilterState>({
    gender: 'Any',
    minAge: '18',
    maxAge: '50',
    location: '',
    community: 'Any',
    profession: 'Any'
  });

  const handleFilterChange = (e: ChangeEvent<HTMLSelectElement | HTMLInputElement>) => {
    const { name, value } = e.target;
    setSearchFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleSearch = (e: FormEvent) => {
    e.preventDefault();
    navigate('/matches', { state: { filters: searchFilters } });
  };

  useEffect(() => {
    async function fetchProfile() {
      if (user) {
        try {
          const profileRef = doc(db, 'profiles', user.uid);
          const snap = await getDoc(profileRef);
          if (snap.exists()) {
            setProfile(snap.data());
          }
        } catch (error) {
          handleFirestoreError(error, OperationType.GET, `profiles/${user.uid}`);
        } finally {
          setLoading(false);
        }
      }
    }
    fetchProfile();
  }, [user]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-rose-900 border-t-2 border-t-amber-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 py-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Welcome Section */}
        <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6 md:p-8 mb-8">
          <div className="flex flex-col md:flex-row items-center gap-6">
            <div className="w-24 h-24 bg-rose-100 rounded-full flex items-center justify-center flex-shrink-0 border border-amber-200">
              <UserCircle className="w-16 h-16 text-rose-900" />
            </div>
            <div className="flex-1 text-center md:text-left">
              <h1 className="text-2xl md:text-3xl font-bold text-gray-900 font-serif">
                Welcome back, {profile?.fullName || user?.email?.split('@')[0]}!
              </h1>
              <p className="text-gray-600 mt-2">
                Your profile is {profile?.profileCompletion || 20}% complete. Let's get it to 100% for better matches.
              </p>
              
              <div className="mt-4 w-full max-w-md bg-gray-200 rounded-full h-2.5 overflow-hidden">
                <div className="bg-amber-500 h-2.5 rounded-full" style={{ width: `${profile?.profileCompletion || 20}%` }}></div>
              </div>
            </div>
            <div className="flex gap-3">
              <Link to="/profile/edit" className="bg-rose-900 text-white px-6 py-2.5 rounded-lg font-bold hover:bg-rose-800 transition-colors border border-amber-500/30">
                Edit Profile
              </Link>
            </div>
          </div>
        </div>

        {/* Stats Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex items-center gap-4 hover:shadow-md transition-shadow">
            <div className="bg-rose-50 p-3 rounded-xl border border-rose-100">
              <Eye className="w-6 h-6 text-rose-900" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">124</div>
              <div className="text-sm text-gray-600">Profile Views</div>
            </div>
          </div>
          
          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex items-center gap-4 hover:shadow-md transition-shadow">
            <div className="bg-amber-50 p-3 rounded-xl border border-amber-100">
              <Heart className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">12</div>
              <div className="text-sm text-gray-600">Interests Received</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex items-center gap-4 hover:shadow-md transition-shadow">
            <div className="bg-green-50 p-3 rounded-xl border border-green-100">
              <Mail className="w-6 h-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">5</div>
              <div className="text-sm text-gray-600">Unread Messages</div>
            </div>
          </div>

          <div className="bg-white p-6 rounded-2xl shadow-sm border border-gray-200 flex items-center gap-4 hover:shadow-md transition-shadow">
            <div className="bg-amber-50 p-3 rounded-xl border border-amber-100">
              <Star className="w-6 h-6 text-amber-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">8</div>
              <div className="text-sm text-gray-600">Shortlisted</div>
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content Area */}
          <div className="lg:col-span-2 space-y-8">
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-xl font-bold text-gray-900">Recommended Matches</h2>
                <Link to="/matches" className="text-rose-900 font-bold hover:text-rose-700">View All</Link>
              </div>
              
              <div className="text-center py-12 bg-gray-50 rounded-xl border border-gray-100 border-dashed">
                <Heart className="w-12 h-12 text-gray-300 mx-auto mb-3" />
                <h3 className="text-lg font-medium text-gray-900">Complete your profile</h3>
                <p className="text-gray-500 max-w-sm mx-auto mt-2">
                  To get AI-powered, highly compatible match recommendations, please complete your preferences and profile details.
                </p>
                <Link to="/profile/edit" className="mt-4 inline-block bg-rose-900 text-amber-300 border border-amber-500/30 px-6 py-2 rounded-lg font-bold hover:bg-rose-800 transition-colors">
                  Add Preferences
                </Link>
              </div>
            </div>
          </div>

          {/* Sidebar */}
          <div className="space-y-8">
            <SearchSidebar 
              filters={searchFilters}
              onChange={handleFilterChange}
              onSearch={handleSearch}
              buttonLabel="Search Matches"
            />
            
            <div className="bg-white rounded-2xl shadow-sm border border-gray-200 p-6">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Quick Actions</h2>
              <div className="space-y-3">
                <Link to="/profile/edit" className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-rose-50 text-left border border-transparent hover:border-rose-100 transition-colors">
                  <span className="font-medium text-gray-700 flex items-center gap-3">
                    <UserCircle className="w-5 h-5 text-rose-900" /> Edit Profile Details
                  </span>
                </Link>
                <Link to="/profile/edit" className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-rose-50 text-left border border-transparent hover:border-rose-100 transition-colors">
                  <span className="font-medium text-gray-700 flex items-center gap-3">
                    <Heart className="w-5 h-5 text-amber-600" /> Partner Preferences
                  </span>
                </Link>
                <button className="w-full flex items-center justify-between p-3 rounded-lg hover:bg-rose-50 text-left border border-transparent hover:border-rose-100 transition-colors">
                  <span className="font-medium text-gray-700 flex items-center gap-3">
                    <Settings className="w-5 h-5 text-rose-900" /> Account Settings
                  </span>
                </button>
              </div>
            </div>
            
            {/* Status Card */}
            <div className="bg-gradient-to-br from-rose-950 via-rose-900 to-rose-800 rounded-2xl shadow-sm p-6 text-white border border-amber-500/20">
              <h3 className="font-bold mb-2">Account Verification</h3>
              <p className="text-rose-200/90 text-sm mb-4">
                {profile?.isVerified 
                  ? "Your profile is verified. You have maximum visibility." 
                  : "Verify your profile to get a trust badge and 3x more responses."}
              </p>
              {!profile?.isVerified && (
                <button className="w-full bg-amber-500 text-rose-950 py-2 rounded-lg font-bold hover:bg-amber-400 transition-colors shadow-sm">
                  Verify Now
                </button>
              )}
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
